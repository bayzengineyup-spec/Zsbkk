# -*- coding: utf-8 -*-
"""
Mixium — Change Tracker (Aşama 9D)

Yazma araçları (write/edit/multi_edit/patch) çalışmadan önce ve sonra dosyanın
sha256'sını alır; değişikliği {file, operation, before_sha256, after_sha256,
timestamp} olarak kaydeder. Amaç: agent'ın ne değiştirdiğini bilmesi.

Thread-safe (kilit). Cache: .mixium/changes.json (workspace içi, fail-closed).

Bu modül MIXIUM'A BAĞIMLI DEĞİLDİR.
"""

import hashlib
import json
import threading
import time
from pathlib import Path


def file_sha256(path):
    """Dosyanın sha256'sını döndürür; yoksa/okunamazsa None."""
    p = Path(path)
    try:
        if not p.exists() or p.is_dir():
            return None
        h = hashlib.sha256()
        with open(p, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None


class ChangeTracker:
    def __init__(self, root=None):
        self.root = Path(root).expanduser().resolve() if root else None
        self.cache_path = (self.root / ".mixium" / "changes.json") if self.root else None
        self.entries = []
        self._lock = threading.Lock()

    def _cache_allowed(self):
        if self.cache_path is None:
            return False
        try:
            c = self.cache_path.resolve()
        except Exception:
            return False
        return c == self.root or self.root in c.parents

    def record(self, file, operation, before=None, after=None):
        with self._lock:
            entry = {
                "file": str(file),
                "operation": operation,
                "before_sha256": before,
                "after_sha256": after,
                "timestamp": time.time(),
            }
            self.entries.append(entry)
            self._save()
            return entry

    def _save(self):
        if not self._cache_allowed():
            return
        try:
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            self.cache_path.write_text(
                json.dumps(self.entries, ensure_ascii=False), "utf-8")
        except Exception:
            pass

    def changes(self, limit=None):
        if limit is None:
            return list(self.entries)
        return list(self.entries[-limit:])

    def summary(self, limit=None):
        rows = self.changes(limit)
        if not rows:
            return "değişiklik kaydı yok"
        lines = []
        for e in rows:
            b = (e.get("before_sha256") or "yok")[:8]
            a = (e.get("after_sha256") or "yok")[:8]
            lines.append("  %s %s  %s -> %s" % (
                e.get("operation", "?"), e.get("file", "?"), b, a))
        return "DEĞİŞİKLİKLER:\n" + "\n".join(lines)

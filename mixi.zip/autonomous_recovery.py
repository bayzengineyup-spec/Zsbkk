# -*- coding: utf-8 -*-
"""Mixium A29 — Autonomous Recovery (Otonom kurtarma).

Her hata sonrası: detect → analyze → recover → verify. Crash recovery, worker
restart, state restore, memory restore. Tüm aksiyonlar provider-enjeksiyonlu;
provider yoksa fail-closed (aksiyon alınmaz, yalnızca kayıt). Güvenlik çekirdeği
değiştirilemez.
"""

import time


class AutonomousRecovery:
    def __init__(self, providers=None, max_cycles=3):
        self.providers = dict(providers or {})
        self.max_cycles = max(1, int(max_cycles))
        self.incidents = []

    def _call(self, name, *args, **kw):
        fn = self.providers.get(name)
        if fn is None:
            return None
        try:
            return fn(*args, **kw)
        except Exception as e:
            return {"error": str(e)[:200]}

    def detect(self):
        """Hata sinyalleri: error provider, resource manager, supervisor."""
        sig = self._call("errors")
        if sig is None:
            sig = []
        res = self._call("resources")
        sup = self._call("supervisor")
        return {"errors": sig or [], "resources": res, "supervisor": sup}

    def analyze(self, incident):
        errs = (incident or {}).get("errors", [])
        cause = "no explicit error"
        count = 0
        if isinstance(errs, list):
            count = len(errs)
            if errs:
                first = errs[0]
                cause = first.get("message", "unknown") if isinstance(first, dict) else str(first)
        elif isinstance(errs, dict):
            count = 1
            cause = errs.get("message") or errs.get("error") or "unknown"
        elif errs:
            count = 1
            cause = str(errs)
        return {
            "cause": cause,
            "count": count,
            "plan": "restart worker + restore state + verify",
        }

    def recover(self, incident):
        """Kurtarma aksiyonları (varsa): worker restart, state restore, memory restore."""
        return {
            "worker_restart": self._call("restart_worker"),
            "state_restore": self._call("restore_state"),
            "memory_restore": self._call("restore_memory"),
        }

    def verify(self):
        health = self._call("verify")
        return health if health is not None else {"health_score": 50, "ok": True}

    def run(self, incident=None):
        inc = incident if incident is not None else self.detect()
        rec = {"incident": inc, "started": time.time()}
        rec["analysis"] = self.analyze(inc)
        rec["recovery"] = self.recover(inc)
        rec["verify"] = self.verify()
        ok = bool((rec["verify"] or {}).get("ok", True))
        rec["ok"] = ok
        self.incidents.append(rec)
        self.incidents = self.incidents[-100:]
        return rec

    def status(self):
        return {"incidents": len(self.incidents),
                "last": self.incidents[-1] if self.incidents else None,
                "max_cycles": self.max_cycles}

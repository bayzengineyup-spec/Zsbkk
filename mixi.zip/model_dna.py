# -*- coding: utf-8 -*-
"""
Mixium — Model DNA Adapter (Aşama 14F)

Yönetim panelinden seçilen modeli "DNA Model" olarak atar (ana sohbet
modelinden BAĞIMSIZ). Config: .dna/config.json -> {model, enabled,
background, interval}. Bu modül MIXIUM'a bağımlı değildir.
"""

import json
import threading
from pathlib import Path

DEFAULT_CONFIG = {"model": "", "enabled": False, "background": True,
                  "interval": "30m"}


class DNAModelManager:
    def __init__(self, root="."):
        self.root = Path(root).expanduser().resolve()
        self.cfg_path = self.root / ".dna" / "config.json"
        self.config = dict(DEFAULT_CONFIG)
        self._lock = threading.Lock()
        self._load()

    def _allowed(self):
        try:
            d = self.cfg_path.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def _load(self):
        try:
            if self.cfg_path.exists():
                self.config.update(json.loads(self.cfg_path.read_text("utf-8")))
        except Exception:
            pass

    def _save(self):
        if not self._allowed():
            return
        try:
            self.cfg_path.parent.mkdir(parents=True, exist_ok=True)
            self.cfg_path.write_text(json.dumps(self.config, ensure_ascii=False),
                                     "utf-8")
        except Exception:
            pass

    def set_dna_model(self, model_id):
        with self._lock:
            self.config["model"] = str(model_id or "")
            self.config["enabled"] = True
            self._save()
        return True

    def get_dna_model(self):
        return self.config.get("model", "")

    def dna_status(self):
        return dict(self.config)

    def dna_statistics(self, stats_provider=None):
        """stats_provider() -> dict (knowledge_size, categories, ...) enjekte edilir."""
        s = {"model": self.get_dna_model(), "knowledge_size": 0,
             "categories": {}, "last_research": None, "learning_progress": 0}
        if stats_provider is not None:
            try:
                s.update(stats_provider())
            except Exception:
                pass
        return s

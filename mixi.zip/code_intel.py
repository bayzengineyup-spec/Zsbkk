# -*- coding: utf-8 -*-
"""
Mixium — Advanced Code Intelligence Layer (Aşama 8, 8A–8E)

- 8B ProjectIndexer  : stdlib `ast` ile Python class/function/import çıkarımı
- 8C symbol_search   : sembol arama (code_search aracı)
- 8E dependency graph: yerel Python modül import ilişkileri
- 8D cache           : CWD/.mixium/{project_index,code_symbols,dependency_graph}.json
                       (mtime+size imzası, thread-lock, workspace fail-closed)
- 8A DiagnosticContextManager : LSP_DIAGNOSTICS registry -> token-dostu context bloğu

Bu modül MIXIUM'A BAĞIMLI DEĞİLDİR (mixium_new import etmez -> dairesel import yok).
lsp_client yalnızca 8A bloğu üretilirken lazily import edilir.
"""

import ast
import json
import os
import re
import threading
from pathlib import Path

# ── tarama kuralları (mixium_new.py ile aynı; bağımsız kopya) ──────────
SKIP_DIRS = {"node_modules", ".git", ".venv", "venv", "__pycache__", ".idea",
             ".vscode", "dist", "build", ".next", "target", ".cache", ".gradle",
             "Pods", "bin", "obj", ".mypy_cache", ".pytest_cache", ".tox",
             ".mixium", "vendor", ".dart_tool", ".expo", "coverage"}

CODE_EXT = {".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".md", ".txt", ".html",
            ".css", ".scss", ".sh", ".java", ".go", ".rs", ".cpp", ".c", ".h",
            ".hpp", ".sql", ".yaml", ".yml", ".toml", ".ini", ".xml", ".kt",
            ".swift", ".rb", ".php", ".vue", ".svelte", ".lua", ".dart", ".cs",
            ".gradle", ".cfg", ".conf", ".mk", ".makefile", ".r", ".jl"}

BINARY_HINT = {".png", ".jpg", ".jpeg", ".gif", ".pdf", ".zip", ".tar", ".gz",
               ".exe", ".so", ".dylib", ".dll", ".class", ".jar", ".mp4", ".mp3",
               ".woff", ".woff2", ".ttf", ".ico", ".webp", ".bin", ".o", ".pyc"}

_LANG = {".py": "python", ".js": "javascript", ".ts": "typescript",
         ".tsx": "typescript", ".jsx": "javascript", ".json": "json",
         ".md": "markdown", ".txt": "text", ".html": "html", ".css": "css",
         ".scss": "scss", ".sh": "shell", ".go": "go", ".rs": "rust",
         ".java": "java", ".c": "c", ".h": "c", ".cpp": "cpp", ".hpp": "cpp",
         ".rb": "ruby", ".php": "php", ".sql": "sql", ".yaml": "yaml",
         ".yml": "yaml", ".toml": "toml"}

MAX_FILES = 800
MAX_SIZE = 400_000

_CACHE_LOCK = threading.Lock()


def _language_for(path):
    return _LANG.get(path.suffix.lower(), path.suffix.lower().lstrip(".") or "unknown")


# ══════════════════════════════════════════════════════════════════════
#  8B — AST SEMBOL ÇIKARIMI
# ══════════════════════════════════════════════════════════════════════
def extract_symbols(source):
    """Python kaynağından (classes, functions, imports) çıkar.

    SyntaxError / parse hatasında None döner (crash yok, dosya atlanır).
    """
    try:
        tree = ast.parse(source)
    except Exception:
        return None
    classes, functions, imports = [], [], []
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            classes.append({"name": node.name, "line": getattr(node, "lineno", 0)})
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions.append({"name": node.name, "line": getattr(node, "lineno", 0)})
        elif isinstance(node, ast.Import):
            for a in node.names:
                imports.append("import %s" % a.name)
        elif isinstance(node, ast.ImportFrom):
            mod = node.module or ("." * max(0, getattr(node, "level", 0)))
            names = ", ".join(a.name for a in node.names)
            imports.append("from %s import %s" % (mod, names))
    classes.sort(key=lambda x: x["line"])
    functions.sort(key=lambda x: x["line"])
    return {"classes": classes, "functions": functions, "imports": imports}


# ══════════════════════════════════════════════════════════════════════
#  8E — PYTHON DEPENDENCY GRAPH (yalnızca yerel modüller)
# ══════════════════════════════════════════════════════════════════════
_IMPORT_RE = re.compile(r"^(?:import|from)\s+([A-Za-z_][\w]*)")


def build_dependency_graph(files):
    """files listesindeki import'lardan {file: [yerel modül relpath]} üretir.

    Yalnızca proje içindeki yerel .py modüller eşlenir; stdlib/harici paketler
    yok sayılır (module_map'te yoksa atlanır).
    """
    module_map = {}
    for f in files:
        rel = f.get("path", "")
        if not rel.endswith(".py"):
            continue
        base = os.path.splitext(os.path.basename(rel))[0]
        module_map.setdefault(base, rel)
        dotted = rel[:-3].replace(os.sep, ".")
        module_map.setdefault(dotted, rel)
    graph = {}
    for f in files:
        rel = f.get("path", "")
        if not rel.endswith(".py"):
            continue
        deps = []
        for imp in f.get("imports", []):
            m = _IMPORT_RE.match(imp.strip())
            if not m:
                continue
            target = module_map.get(m.group(1))
            if target and target != rel:
                deps.append(target)
        seen = set()
        deps = [d for d in deps if not (d in seen or seen.add(d))]
        graph[rel] = deps
    return graph


# ══════════════════════════════════════════════════════════════════════
#  8B + 8D — PROJECT INDEXER + CACHE
# ══════════════════════════════════════════════════════════════════════
class ProjectIndexer:
    """Projeyi tarar, sembolleri çıkarır, cache'e yazar (mtime+size imzası)."""

    def __init__(self, root, cache_dir=None):
        self.root = Path(root).expanduser().resolve()
        self.cache_dir = Path(cache_dir) if cache_dir else (self.root / ".mixium")
        self.index_path = self.cache_dir / "project_index.json"
        self.symbols_path = self.cache_dir / "code_symbols.json"
        self.deps_path = self.cache_dir / "dependency_graph.json"
        self.files = []
        self.symbols = []
        self.dependencies = {}
        self.stats = {"files": 0, "parsed": 0, "reused": 0}
        self.last_cache_ok = True

    # ---- tarama ----
    def _iter_source_files(self):
        n = 0
        for dirpath, dirnames, filenames in os.walk(self.root):
            dirnames[:] = [d for d in dirnames
                           if d not in SKIP_DIRS and not d.startswith(".")]
            for fn in filenames:
                fp = Path(dirpath) / fn
                if fp.suffix.lower() not in CODE_EXT:
                    continue
                try:
                    if fp.stat().st_size > MAX_SIZE:
                        continue
                except Exception:
                    continue
                yield fp
                n += 1
                if n >= MAX_FILES:
                    return

    def _parse_file(self, fp, rel, sig):
        language = _language_for(fp)
        try:
            size = fp.stat().st_size
        except Exception:
            size = 0
        f = {"path": rel, "language": language, "size": size,
             "classes": [], "functions": [], "imports": [], "_sig": sig}
        if language != "python":
            return f
        try:
            data = fp.read_bytes()
        except Exception:
            return None
        if b"\0" in data[:1024]:
            return f  # ikili -> sembol yok ama dosya listede
        try:
            source = data.decode("utf-8", errors="replace")
        except Exception:
            return None
        sym = extract_symbols(source)
        if sym is None:
            return f  # SyntaxError -> crash yok, boş sembol
        f["classes"] = sym["classes"]
        f["functions"] = sym["functions"]
        f["imports"] = sym["imports"]
        return f

    # ---- cache ----
    def _cache_allowed(self):
        try:
            c = self.cache_dir.resolve()
        except Exception:
            return False
        try:
            r = self.root
        except Exception:
            return False
        return c == r or r in c.parents

    def _load_cache(self):
        files_by_path, sigs = {}, {}
        try:
            if self.index_path.exists():
                data = json.loads(self.index_path.read_text("utf-8"))
                sigs = data.get("signatures", {}) or {}
                for f in data.get("files", []) or []:
                    rel = f.get("path")
                    if rel:
                        files_by_path[rel] = f
        except Exception:
            pass
        return {"files_by_path": files_by_path, "sigs": sigs}

    def _save_cache(self, sigs):
        self.last_cache_ok = False
        if not self._cache_allowed():
            return  # workspace dışına yazma yok (fail-closed)
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            self.index_path.write_text(
                json.dumps({"signatures": sigs, "files": self.files},
                           ensure_ascii=False), "utf-8")
            self.symbols_path.write_text(
                json.dumps({"symbols": self.symbols}, ensure_ascii=False), "utf-8")
            self.deps_path.write_text(
                json.dumps({"graph": self.dependencies}, ensure_ascii=False), "utf-8")
            self.last_cache_ok = True
        except Exception:
            pass

    # ---- index ----
    def index(self, force=False):
        with _CACHE_LOCK:
            cached = self._load_cache()
            sigs = {}
            files_by_path = {}
            parsed = reused = 0
            for fp in self._iter_source_files():
                rel = os.path.relpath(fp, self.root)
                try:
                    sig = [int(fp.stat().st_mtime), int(fp.stat().st_size)]
                except Exception:
                    continue
                sigs[rel] = sig
                c = None if force else cached["files_by_path"].get(rel)
                if (c is not None and cached["sigs"].get(rel) == sig
                        and c.get("_sig") == sig):
                    reused += 1
                    files_by_path[rel] = c
                    continue
                parsed += 1
                f = self._parse_file(fp, rel, sig)
                if f is not None:
                    files_by_path[rel] = f
            self.files = list(files_by_path.values())
            self.symbols = self._flatten_symbols(self.files)
            self.dependencies = build_dependency_graph(self.files)
            self.stats = {"files": len(self.files), "parsed": parsed,
                          "reused": reused}
            self._save_cache(sigs)
            return self.files

    def _flatten_symbols(self, files):
        syms = []
        for f in files:
            rel = f["path"]
            for c in f.get("classes", []):
                syms.append({"file": rel, "symbol": c["name"],
                             "type": "class", "line": c["line"]})
            for fn in f.get("functions", []):
                syms.append({"file": rel, "symbol": fn["name"],
                             "type": "function", "line": fn["line"]})
            for imp in f.get("imports", []):
                syms.append({"file": rel, "symbol": imp,
                             "type": "import", "line": 0})
        return syms

    # ---- 8C — sembol arama ----
    def search(self, query, limit=20):
        q = (query or "").lower()
        hits = []
        for s in self.symbols:
            if q in s["symbol"].lower():
                hits.append(s)
        if not hits:
            for s in self.symbols:
                if q in s["file"].lower():
                    hits.append(s)
        return hits[:limit]

    # ---- çıktı yardımcıları ----
    def summary(self):
        nc = sum(len(f.get("classes", [])) for f in self.files)
        nf = sum(len(f.get("functions", [])) for f in self.files)
        lines = [
            "PROJE INDEX: %s" % self.root,
            "dosya: %d (parse %d, cache %d)" % (
                self.stats.get("files", 0), self.stats.get("parsed", 0),
                self.stats.get("reused", 0)),
            "class: %d, fonksiyon: %d" % (nc, nf),
        ]
        top = sorted(self.files,
                     key=lambda x: len(x.get("classes", [])) + len(x.get("functions", [])),
                     reverse=True)[:15]
        if top:
            lines.append("")
            for f in top:
                lines.append("  %-40s c:%d f:%d" % (
                    f["path"], len(f.get("classes", [])), len(f.get("functions", []))))
        return "\n".join(lines)

    def dependency_tree_text(self):
        if not self.dependencies:
            return "bağımlılık bulunamadı (yerel .py import yok)"
        lines = []
        for f in sorted(self.dependencies.keys()):
            lines.append(f)
            for dep in self.dependencies[f]:
                lines.append(" +--> " + dep)
        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════
#  8A — DIAGNOSTIC CONTEXT MANAGER (LSP_DIAGNOSTICS -> context bloğu)
# ══════════════════════════════════════════════════════════════════════
def _uri_to_path(uri):
    try:
        from urllib.parse import unquote, urlparse
        p = urlparse(uri)
        if p.scheme == "file":
            return unquote(p.path)
    except Exception:
        pass
    return uri


class DiagnosticContextManager:
    """LSP_DIAGNOSTICS registry'sinden token-dostu diagnostic bloğu üretir."""

    def __init__(self, max_errors=10):
        self.max_errors = max_errors

    def block(self):
        try:
            import lsp_client as _lsp
            diags = _lsp.LSP_DIAGNOSTICS
        except Exception:
            return ""
        rows = []
        for uri, entry in diags.items():
            path = _uri_to_path(uri)
            for d in entry.get("errors", []) or []:
                rows.append("file: %s\nline: %s\nseverity: %s\nmessage: %s" % (
                    path, d.get("line", 0), d.get("severity", "info"),
                    d.get("message", "")))
                if len(rows) >= self.max_errors:
                    break
            if len(rows) >= self.max_errors:
                break
        if not rows:
            return ""
        return "[CODE DIAGNOSTICS]\n" + "\n\n".join(rows)


DIAG_CTX = DiagnosticContextManager()


def diagnostics_context_block(max_errors=10):
    """mixium_new.py'den kolay çağrım için kısa yol."""
    return DiagnosticContextManager(max_errors=max_errors).block()

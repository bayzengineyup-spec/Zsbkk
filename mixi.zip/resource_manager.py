# -*- coding: utf-8 -*-
"""Mixium A29 — Resource Manager (Kaynak yöneticisi).

CPU, RAM, token kullanımı, aktif agent sayısı, worker durumu takibi. Sistem
kendini korur: yüksek kullanımda throttle/guard sinyali üretir. Sinyaller
provider-enjeksiyonlu; dış kaynak okunamıyorsa fail-closed (None/sınır).

Not: psutil yoksa Linux /proc, o da yoksa güvenli varsayılanlar kullanılır.
"""

import threading
import time


def _read_file(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            return fh.read()
    except Exception:
        return None


def _cpu_load():
    """1-dk yük ortalaması (0-100 arası ölçek); okunamazsa None."""
    txt = _read_file("/proc/loadavg")
    if txt:
        try:
            return float(txt.split()[0])
        except Exception:
            pass
    try:
        import os
        try:
            n = os.cpu_count() or 1
        except Exception:
            n = 1
        # os.getloadavg yoksa None döner (Windows)
        lavg = getattr(os, "getloadavg", None)
        if callable(lavg):
            return lavg()[0] / n * 100.0
    except Exception:
        pass
    return None


def _ram_pct():
    """RAM kullanım yüzdesi; /proc okunamazsa None."""
    txt = _read_file("/proc/meminfo")
    if not txt:
        return None
    info = {}
    for line in txt.splitlines():
        parts = line.split()
        if len(parts) >= 2:
            info[parts[0].rstrip(":")] = parts[1]
    try:
        total = float(info.get("MemTotal", 0))
        avail = float(info.get("MemAvailable", 0))
        if total > 0:
            return round(100.0 * (total - avail) / total, 1)
    except Exception:
        pass
    return None


class ResourceManager:
    def __init__(self, providers=None, cpu_high=80.0, ram_high=90.0):
        self.providers = dict(providers or {})
        self.cpu_high = float(cpu_high)
        self.ram_high = float(ram_high)
        self._lock = threading.Lock()
        self.history = []

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn() if callable(fn) else fn
            return default if v is None else v
        except Exception:
            return default

    def snapshot(self):
        cpu = _cpu_load()
        ram = _ram_pct()
        tokens = self._get("tokens", None)
        agents = self._get("agents", 0)
        workers = self._get("workers", [])
        snap = {
            "cpu": cpu,
            "ram": ram,
            "token_usage": tokens,
            "active_agents": agents,
            "workers": workers,
            "t": time.time(),
        }
        with self._lock:
            self.history.append(snap)
            self.history = self.history[-200:]
        return snap

    def _guard(self, snap):
        flags = []
        if snap.get("cpu") is not None and snap["cpu"] >= self.cpu_high:
            flags.append("cpu_high")
        if snap.get("ram") is not None and snap["ram"] >= self.ram_high:
            flags.append("ram_high")
        if snap.get("active_agents", 0) >= self._get("max_agents", 50):
            flags.append("agent_cap")
        return flags

    def protect(self):
        """Sistem kendini korur: guard/throttle önerisi döner (aksiyon almaz)."""
        snap = self.snapshot()
        flags = self._guard(snap)
        return {
            "snapshot": snap,
            "throttle": bool(flags),
            "flags": flags,
            "advice": "limit new work; pause low-priority workers" if flags else "ok",
        }

    def status(self):
        snap = self.snapshot()
        return {"snapshot": snap, "guard": self._guard(snap),
                "history_count": len(self.history)}

# -*- coding: utf-8 -*-
"""
Mixium — B2: Advanced Personal DNA System

A14 DNA sistemini geliştirir: kullanıcı tercihlerini, davranış kalıplarını,
teknik ve iletişim DNA'sını güven (confidence) eşiğiyle öğrenir.

Akış: Observation → Analysis → Confidence Check → DNA Update → Version Save

Güvenlik:
- düşük güvenli gözlem kaydedilmez (poisoning koruması)
- her güncelleme versiyonlanır, yanlış öğrenme geri alınabilir (rollback)
- `.mixium/dna/user/` dışına yazmaz

MIXIUM'a bağımlı değildir (yalnızca stdlib + opsiyonel embed/cosine enjeksiyonu).
"""

import json
import os
import threading
import time
from pathlib import Path

MIN_CONFIDENCE = 0.6        # altındaki gözlem kaydedilmez
MAX_RECORDS = 200
VERSION_HISTORY = 20

CATEGORIES = ("coding", "communication", "reasoning", "strategy",
              "research", "security", "preferences", "mistakes", "solutions")


class AdvancedPersonalDNA:
    """Kullanıcı DNA'sı: kategorili özet bilgi + versiyon geçmişi."""

    def __init__(self, root=".", embed_fn=None, cosine_fn=None):
        self.root = Path(root)
        self.dir = self.root / ".mixium" / "dna" / "user"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.embed_fn = embed_fn or (lambda t: {})
        self.cosine_fn = cosine_fn or (lambda a, b: 0.0)
        self._lock = threading.RLock()
        self._records = {}
        self._versions = {}
        self._load()

    # ── kalıcılık ─────────────────────────────────────────────────
    def _load(self):
        p = self.dir / "dna.json"
        if p.exists():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                self._records = data.get("records", {})
                self._versions = data.get("versions", {})
            except Exception:
                self._records, self._versions = {}, {}

    def _save(self):
        tmp = self.dir / "dna.json.tmp"
        tmp.write_text(json.dumps(
            {"records": self._records, "versions": self._versions},
            ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(str(tmp), str(self.dir / "dna.json"))

    # ── öğrenme ───────────────────────────────────────────────────
    def observe(self, category, fact, source="user", confidence=0.7):
        """Observation → Confidence Check → DNA Update → Version Save."""
        category = category if category in CATEGORIES else "preferences"
        confidence = max(0.0, min(1.0, float(confidence)))
        if confidence < MIN_CONFIDENCE:
            return {"status": "rejected", "reason": "low_confidence",
                    "confidence": confidence}
        with self._lock:
            rid = self._find_similar(category, fact)
            if rid is not None:
                # mevcut kaydı güçlendir (confidence artarsa güncelle)
                rec = self._records[rid]
                if confidence > rec.get("confidence", 0):
                    old = dict(rec)
                    rec["content"] = fact
                    rec["confidence"] = confidence
                    rec["source"] = source
                    rec["updated"] = time.time()
                    self._push_version(rid, old)
                    self._save()
                    return {"status": "updated", "id": rid,
                            "confidence": confidence}
                return {"status": "kept", "id": rid,
                        "confidence": rec.get("confidence", 0)}
            rid = "dna_%d" % int(time.time() * 1000)
            rec = {"id": rid, "category": category, "content": fact,
                   "source": source, "confidence": confidence,
                   "created": time.time(), "updated": time.time()}
            self._records[rid] = rec
            self._push_version(rid, None)
            # LRU limit
            if len(self._records) > MAX_RECORDS:
                oldest = min(self._records, key=lambda k: self._records[k]["updated"])
                self._records.pop(oldest, None)
            self._save()
            return {"status": "stored", "id": rid, "confidence": confidence}

    def _find_similar(self, category, fact):
        """Aynı kategori + yüksek cosine benzerliği → mevcut kayıt."""
        for rid, rec in self._records.items():
            if rec.get("category") != category:
                continue
            if self._text_sim(rec.get("content", ""), fact) >= 0.8:
                return rid
        return None

    def _text_sim(self, a, b):
        if not a or not b:
            return 0.0
        ea, eb = self.embed_fn(a), self.embed_fn(b)
        if ea and eb:
            return self.cosine_fn(ea, eb)
        # fallback: token kesişimi
        ta, tb = set(a.lower().split()), set(b.lower().split())
        if not ta or not tb:
            return 0.0
        return len(ta & tb) / max(1, len(ta | tb))

    def _push_version(self, rid, old):
        hist = self._versions.setdefault(rid, [])
        hist.append({"ts": time.time(), "prev": old})
        if len(hist) > VERSION_HISTORY:
            del hist[:len(hist) - VERSION_HISTORY]

    # ── geri alma ──────────────────────────────────────────────────
    def rollback(self, rid):
        """Son güncellemeyi geri al (yanlış öğrenme düzeltmesi)."""
        with self._lock:
            hist = self._versions.get(rid)
            if not hist:
                return False
            last = hist.pop()
            if last.get("prev") is None:
                self._records.pop(rid, None)
            else:
                self._records[rid] = last["prev"]
            self._save()
            return True

    def remove(self, rid):
        with self._lock:
            if rid in self._records:
                self._records.pop(rid)
                self._versions.pop(rid, None)
                self._save()
                return True
            return False

    # ── sorgu ──────────────────────────────────────────────────────
    def query(self, category=None, limit=10, min_conf=0.0):
        items = [r for r in self._records.values()
                 if (category is None or r.get("category") == category)
                 and r.get("confidence", 0) >= min_conf]
        items.sort(key=lambda r: (r.get("confidence", 0), r.get("updated", 0)),
                   reverse=True)
        return items[:limit]

    def summary(self):
        by_cat = {}
        for r in self._records.values():
            by_cat.setdefault(r.get("category", "?"), 0)
            by_cat[r.get("category", "?")] += 1
        return {"total": len(self._records), "categories": by_cat}

    def stats(self):
        return {
            "total": len(self._records),
            "categories": self.summary()["categories"],
            "poisoning_rejected": 0,
            "versions": sum(len(v) for v in self._versions.values()),
            "dir": str(self.dir),
        }

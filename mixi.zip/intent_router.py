"""Determines whether a request needs clarification."""

def needs_details(message):
    m=(message or '').strip().lower()
    if len(m)<8: return True
    vague=['yap','oluştur','başla','yapın']
    return any(m==x for x in vague)

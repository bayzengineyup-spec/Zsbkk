# -*- coding: utf-8 -*-
"""
Mixium — Agent LLM Runtime (Aşama 11, 11A + 11D)

Rol-scoped otonom ajan döngüsü:
    Observe -> Analyze -> Choose Tool -> Execute -> Evaluate -> Continue

- generate_fn(prompt, role, conversation) -> str  (model çağrısı; mixium_new
  gerçek LLM ile bağlar, test fake model enjekte eder)
- executor(tool, args) -> {"ok", "result", "error"}  (rol + PERM + hard_gate;
  Aşama 10 executor'u yeniden kullanılır)
- max_iterations = 10 (sonsuz döngü engeli)
- trace: .mixium/agents/traces/<agent_id>.json

MIXIUM'a bağımlı değildir (agent_prompts + agent_memory import eder).
"""

import json
import re
import time
import uuid
from pathlib import Path

from agent_prompts import build_agent_prompt, tool_allowed

_TOOL_RE = re.compile(r"⟦OP⟧\s*(\{.*?\})\s*⟦/OP⟧", re.S)
DEFAULT_MAX_ITERATIONS = 10


def parse_tool_calls(text):
    """⟦OP⟧{...}⟦/OP⟧ bloklarını [(tool, args), ...] olarak çıkarır."""
    calls = []
    for m in _TOOL_RE.finditer(text or ""):
        try:
            o = json.loads(m.group(1))
        except Exception:
            continue
        if isinstance(o, dict) and "tool" in o:
            calls.append((str(o["tool"]), o.get("args") or {}))
    return calls


class AgentLLMRuntime:
    def __init__(self, root=".", max_iterations=DEFAULT_MAX_ITERATIONS,
                 token_budget=4000):
        self.root = Path(root).expanduser().resolve()
        self.max_iterations = max_iterations
        self.token_budget = token_budget
        self.traces_dir = self.root / ".mixium" / "agents" / "traces"

    def _allowed(self):
        try:
            d = self.traces_dir.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def _save_trace(self, agent_id, role, goal, trace, status):
        if not self._allowed():
            return
        try:
            self.traces_dir.mkdir(parents=True, exist_ok=True)
            (self.traces_dir / ("%s.json" % agent_id)).write_text(
                json.dumps({"id": agent_id, "role": role, "goal": goal,
                            "status": status, "trace": trace},
                           ensure_ascii=False, indent=2), "utf-8")
        except Exception:
            pass

    def run_autonomous(self, goal, role, generate_fn, executor, memory=None,
                       context=None):
        """Otonom döngü. Dönüş: {goal, role, status, result, iterations, trace}."""
        agent_id = uuid.uuid4().hex[:10]
        conversation = []
        if context and context.get("previous"):
            conversation.append("[ÖNCEKI AJAN SONUCU] %s" % context["previous"][:800])
        trace = []
        status = "COMPLETED"
        result = ""
        iterations = 0
        for i in range(1, self.max_iterations + 1):
            iterations = i
            prompt = build_agent_prompt(role, goal, conversation)
            try:
                response = generate_fn(prompt, role, conversation)
            except Exception as e:
                status = "FAILED"
                result = "model hatası: %s" % e
                trace.append({"step": i, "action": "error", "result": result})
                break
            if not response or not response.strip():
                status = "FAILED"
                result = "(boş model yanıtı)"
                trace.append({"step": i, "action": "error", "result": result})
                break
            calls = parse_tool_calls(response)
            if not calls:
                # araç çağrısı yok -> final cevap
                result = response.strip()
                status = "COMPLETED"
                trace.append({"step": i, "action": "final",
                              "result": result[:200]})
                break
            for tool, args in calls:
                if not tool_allowed(role, tool):
                    r = {"ok": False, "result": "",
                         "error": "rol '%s' için yasak araç: %s" % (role, tool)}
                else:
                    r = executor(tool, args)
                conversation.append("[ARAC SONUCU: %s] %s" % (
                    tool, json.dumps(r, ensure_ascii=False)[:800]))
                trace.append({"step": i, "action": tool, "args": args,
                              "result": r})
        else:
            status = "ITERATION_LIMIT"
            result = "(iteration limiti %d aşıldı)" % self.max_iterations

        if memory is not None:
            kind = "failure" if status in ("FAILED", "ITERATION_LIMIT") else "task"
            try:
                memory.add(role, result[:2000], kind=kind, meta={"goal": goal})
            except Exception:
                pass
        self._save_trace(agent_id, role, goal, trace, status)
        return {"goal": goal, "role": role, "status": status, "result": result,
                "iterations": iterations, "trace": trace, "agent_id": agent_id}

# -*- coding: utf-8 -*-
"""Mixium A23 — Task Autonomy Engine.

From a single user message, extracts goal, subtasks, agent, model, tools and
a working plan. Simple tasks are solved directly; big tasks are routed to a
mission (project execution) flow.
"""
import re
import threading
import time
import uuid

INTENT_WORDS = {
    "research": ["araştır", "öğren", "incele", "kaynak", "web", "makale", "github", "research", "investigate", "find"],
    "coding": ["yaz", "kodla", "düzelt", "bug", "hata", "refactor", "ekle", "oluştur", "implement", "fix", "code", "feature", "api"],
    "review": ["kontrol", "gözden geçir", "review", "audit", "güvenlik", "security", "kalite", "quality"],
    "test": ["test", "çalıştır", "doğrula", "verify", "check"],
    "plan": ["plan", "tasarla", "adım", "strateji", "strategy", "design", "yaklaşım"],
}

AGENT_BY_INTENT = {
    "research": "research", "coding": "coding", "test": "testing",
    "review": "reviewer", "plan": "architect",
}

MODEL_BY_INTENT = {
    "research": "research", "coding": "coding", "test": "fast",
    "review": "reasoning", "plan": "reasoning",
}

TOOL_BY_INTENT = {
    "research": ["research", "fetch", "code_search", "read"],
    "coding": ["read", "code_search", "write", "edit", "multi_edit", "patch", "test_status"],
    "test": ["test_status", "bash", "lsp_diagnostics"],
    "review": ["read", "git_diff", "code_search", "project_health"],
    "plan": ["project_index", "dependency_graph", "read", "tree"],
}

BIG_TASK_WORDS = ("proje", "platform", "sistem", "uygulama", "büyük", "kapsamlı", "yeni", "project", "platform", "system", "application", "suite")


class TaskAutonomy:
    def __init__(self, providers=None):
        self.providers = dict(providers or {})
        self._lock = threading.RLock()
        self.log = []

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn()
            return default if v is None else v
        except Exception:
            return default

    @staticmethod
    def detect_intent(message):
        m = (message or "").lower()
        scores = {k: sum(1 for w in v if w in m) for k, v in INTENT_WORDS.items()}
        return max(scores, key=scores.get) if any(scores.values()) else "plan"

    def plan(self, message):
        message = str(message or "").strip()
        if not message:
            return None
        intent = self.detect_intent(message)
        is_big = any(w in message.lower() for w in BIG_TASK_WORDS)
        subtasks = self._subtasks(intent, is_big)
        result = {
            "id": "auto_" + uuid.uuid4().hex[:10],
            "message": message[:1000],
            "goal": message[:400],
            "intent": intent,
            "agent": AGENT_BY_INTENT.get(intent, "research"),
            "model": MODEL_BY_INTENT.get(intent, "fast"),
            "tools": TOOL_BY_INTENT.get(intent, ["read", "code_search"]),
            "subtasks": subtasks,
            "mode": "mission" if is_big else "direct",
            "plan": ["%s: %s" % (i + 1, s) for i, s in enumerate(subtasks)],
            "created": time.time(),
        }
        with self._lock:
            self.log.append(result)
            self.log = self.log[-100:]
        return result

    @staticmethod
    def _subtasks(intent, is_big):
        if is_big:
            return ["Gereksinimleri ve kapsamı çıkar", "Mimari plan oluştur",
                    "Görevleri role göre böl", "Uygula ve test et", "Güvenlik + review", "Rapor üret"]
        if intent == "coding":
            return ["Mevcut kodu incele", "Değişikliği uygula", "Test ile doğrula"]
        if intent == "research":
            return ["Kaynak topla", "Bilgiyi analiz et", "Özet rapor üret"]
        if intent == "test":
            return ["Test durumunu çalıştır", "Hataları analiz et", "Düzeltme öner"]
        if intent == "review":
            return ["Değişiklikleri incele", "Güvenlik/kalite kontrol", "Rapor üret"]
        return ["Durumu analiz et", "Plan öner", "Onay sonrası uygula"]

    def status(self):
        with self._lock:
            return {"plans": self.log[-20:], "count": len(self.log)}

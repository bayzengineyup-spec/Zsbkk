# -*- coding: utf-8 -*-
"""Mixium A24C — Web Reality Test Agent.

Browser MCP / Playwright üzerinden gerçek kullanıcı gibi siteyi kullanır:
sayfa/menü/buton/giriş alanı denetimi, yönlendirme/UI/streaming görünümü
kontrolü. Browser adapter enjekte edilir; yoksa fail-closed (SKIP/rapor).
"""


class WebRealityAgent:
    def __init__(self, browser=None, pages=None, adapters=None):
        self.browser = browser  # {open,navigate,click,type,extract,close,...} çağrılabilir
        self.adapters = dict(adapters or {})
        self.pages = list(pages or [])
        self.audits = []

    def _b(self, method, *args, **kw):
        if self.browser is None:
            return None
        fn = getattr(self.browser, method, None)
        if fn is None:
            return None
        return fn(*args, **kw)

    def audit(self, targets=None):
        """Hedef sayfa/buton/input listesini dolaşır, sonuç toplar."""
        findings = []
        if self.browser is None:
            findings.append({"type": "unavailable", "severity": "warning",
                             "message": "browser MCP adapter yok — fail-closed"})
            self.audits.append({"findings": findings})
            return {"status": "SKIP", "findings": findings}

        targets = targets or self.pages or ["/"]
        for t in targets:
            nav = self._b("navigate", t)
            if nav in (None, False):
                findings.append({"type": "navigate_fail", "target": t,
                                 "severity": "error", "message": "sayfa açılamadı"})
                continue
            text = self._b("extract_text")
            findings.append({"type": "page", "target": t, "severity": "info",
                             "message": ("ok" if text else "boş sayfa")})
        # buton / input denetimi adapter üzerinden
        for name, fn in self.adapters.items():
            try:
                r = fn(self._b)
                findings.append({"type": "component", "name": name,
                                 "severity": "info", "message": str(r)[:200]})
            except Exception as e:
                findings.append({"type": "component_error", "name": name,
                                 "severity": "error", "message": str(e)[:200]})
        self._b("close")
        self.audits.append({"findings": findings})
        return {"status": "DONE", "findings": findings}

    def status(self):
        return {"audits": len(self.audits), "last": self.audits[-1] if self.audits else None,
                "browser_available": self.browser is not None}

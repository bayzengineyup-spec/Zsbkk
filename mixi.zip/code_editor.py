# -*- coding: utf-8 -*-
"""
Mixium — Code Change Engine (Aşama 12A)

Güvenli structured code modification:
    replace_block / insert_after / insert_before / apply_patch / rollback_change

Her değişiklik: safe_path(write=True) -> permission -> hard_gate -> approval ->
önce diff -> atomic write (temp + os.replace) -> ChangeTracker.record.
Rollback: before_sha256 + before-content yedeği. Direkt overwrite YOK.

MIXIUM'a bağımlı değildir; `safe_path_fn` / `permission_fn` / `change_record_fn`
enjekte edilir (mixium_new gerçek PERM+hard_gate+ChangeTracker ile bağlar).
"""

import difflib
import hashlib
import os
import re
from pathlib import Path


def file_sha256(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _diff_text(old, new, path):
    return "\n".join(difflib.unified_diff(
        old.splitlines(), new.splitlines(),
        fromfile=path, tofile=path, lineterm=""))


_HUNK = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


def apply_unified_diff(original, diff):
    """Standart unified diff'i orijinal metne uygular (tek dosya)."""
    orig_lines = original.splitlines()
    out = []
    i = 0
    for line in (diff or "").splitlines():
        if line.startswith(("diff ", "index ", "---", "+++", "\\")):
            continue
        m = _HUNK.match(line)
        if m:
            i = int(m.group(1)) - 1
            continue
        if line.startswith("+"):
            out.append(line[1:])
        elif line.startswith("-"):
            i += 1
        elif line.startswith(" "):
            out.append(orig_lines[i] if i < len(orig_lines) else line[1:])
            i += 1
    return "\n".join(out)


class CodeEditor:
    def __init__(self, root=".", safe_path_fn=None, permission_fn=None,
                 change_record_fn=None):
        self.root = Path(root).expanduser().resolve()
        self.safe_path_fn = safe_path_fn or (lambda p, write=False: Path(p).expanduser().resolve())
        self.permission_fn = permission_fn or (lambda tool, args: (True, ""))
        self.change_record_fn = change_record_fn or (lambda *a, **k: None)
        self._backups = {}   # path -> before_content (rollback için)

    # ---- iç yardımcılar ----
    def _path(self, path, write=False):
        p = Path(str(path))
        if not p.is_absolute():
            p = self.root / p
        p = self.safe_path_fn(str(p), write=write)
        return Path(p)

    def _read(self, path):
        p = self._path(path, write=False)
        return p.read_text("utf-8")

    def _check(self, path):
        ok, why = self.permission_fn("edit", {"path": str(path)})
        if not ok:
            raise PermissionError(why)

    def _commit(self, path, old_text, new_text, operation):
        """diff üret + atomic write + ChangeTracker kaydı."""
        self._check(path)
        p = self._path(path, write=True)
        diff = _diff_text(old_text, new_text, str(p))
        before = file_sha256(old_text)
        # atomic write
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(new_text, "utf-8")
        os.replace(str(tmp), str(p))
        after = file_sha256(new_text)
        self._backups[str(p)] = old_text
        self.change_record_fn(str(p), operation, before, after)
        return diff

    # ---- 12A API ----
    def replace_block(self, path, old, new, occurrence=0):
        """Metin bloğunu değiştir (ilk eşleşme; occurrence=-1 hepsi)."""
        content = self._read(path)
        if old not in content:
            raise ValueError("blok bulunamadı: %s" % old[:40])
        new_content = content.replace(old, new, -1 if occurrence == -1 else 1)
        diff = self._commit(path, content, new_content, "replace_block")
        return {"ok": True, "diff": diff}

    def insert_after(self, path, anchor, text):
        content = self._read(path)
        if anchor not in content:
            raise ValueError("anchor bulunamadı: %s" % anchor[:40])
        idx = content.index(anchor) + len(anchor)
        new_content = content[:idx] + "\n" + text + content[idx:]
        diff = self._commit(path, content, new_content, "insert_after")
        return {"ok": True, "diff": diff}

    def insert_before(self, path, anchor, text):
        content = self._read(path)
        if anchor not in content:
            raise ValueError("anchor bulunamadı: %s" % anchor[:40])
        idx = content.index(anchor)
        new_content = content[:idx] + text + "\n" + content[idx:]
        diff = self._commit(path, content, new_content, "insert_before")
        return {"ok": True, "diff": diff}

    def apply_patch(self, path, diff):
        content = self._read(path)
        new_content = apply_unified_diff(content, diff)
        if new_content == content:
            return {"ok": False, "diff": "", "error": "patch değişiklik üretmedi"}
        d = self._commit(path, content, new_content, "apply_patch")
        return {"ok": True, "diff": d}

    def rollback_change(self, path):
        """Son değişikliği geri al (before-content yedeğinden)."""
        p = self._path(path, write=True)
        old = self._backups.get(str(p))
        if old is None:
            raise ValueError("rollback yedeği yok: %s" % path)
        self._check(path)
        before = file_sha256(self._read(path))
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(old, "utf-8")
        os.replace(str(tmp), str(p))
        after = file_sha256(old)
        self.change_record_fn(str(p), "rollback", before, after)
        return {"ok": True, "restored": str(p)}

    def diff(self, path, other_text):
        return _diff_text(self._read(path), other_text, str(path))

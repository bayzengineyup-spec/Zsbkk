# -*- coding: utf-8 -*-
"""
Mixium — Continuous Intelligence Dashboard (Aşama 16H)

Yönetim paneline veri sağlar (read-only):
- learning activity  (scheduler durumu)
- research jobs      (autonomous research işleri)
- knowledge growth   (DNA + Expert + Pattern kayıt sayısı)
- evolution history  (knowledge_evolution versiyonları)
- intelligence score (intelligence_evaluator sonucu)
- system improvements (öneriler)

MIXIUM'a bağımlı değildir; tüm kaynaklar enjekte edilir.
Fail-closed: kaynak yoksa ilgili alan boş/0 döner, panel çökmez.
"""

import json
import threading
import time
from pathlib import Path


class ContinuousDashboard:
    def __init__(self, root=".", scheduler=None, research=None, evolution=None,
                 evaluator=None, graph=None, decision=None):
        self.root = Path(root)
        self.scheduler = scheduler
        self.research = research
        self.evolution = evolution
        self.evaluator = evaluator
        self.graph = graph
        self.decision = decision
        self._lock = threading.RLock()

    def _safe(self, fn, default=None):
        try:
            return fn() if fn is not None else default
        except Exception:
            return default

    def status(self):
        learning = self._safe(lambda: self.scheduler.status()) if self.scheduler else None
        research = self._safe(lambda: self.research.status()) if self.research else None
        evolution = self._safe(lambda: self.evolution.status()) if self.evolution else None
        evaluator = self._safe(lambda: self.evaluator.evaluate()) if self.evaluator else None
        graph = self._safe(lambda: self.graph.stats()) if self.graph else None
        decisions = self._safe(lambda: self.decision.recent(limit=5)) if self.decision else None

        # knowledge growth
        growth = {"dna": 0, "expert": 0, "pattern": 0}
        for key, store in (("dna", getattr(self, "_dna_store", None)),
                           ("expert", getattr(self, "_expert_store", None)),
                           ("pattern", getattr(self, "_pattern_store", None))):
            if store is not None:
                try:
                    growth[key] = store.count()
                except Exception:
                    growth[key] = 0

        learning_activity = []
        if learning:
            for t in (learning.get("tasks") or [])[:10]:
                learning_activity.append({
                    "task": t.get("name"), "status": t.get("status"),
                    "last_run": t.get("last_run"), "error": t.get("error", "")[:120]})

        research_jobs = []
        if research:
            for jid, j in (research.items() if isinstance(research, dict) else []):
                if isinstance(j, dict):
                    research_jobs.append({"id": jid, "status": j.get("status"),
                                          "goal": j.get("goal", "")[:100]})

        evolution_history = []
        if evolution and evolution.get("recent"):
            for r in evolution["recent"][:10]:
                evolution_history.append({"id": r.get("id"),
                                          "action": r.get("meta", {}).get("action"),
                                          "time": r.get("time")})

        return {
            "learning": {
                "paused": (learning or {}).get("paused", False),
                "interval": (learning or {}).get("interval", 0),
                "stats": (learning or {}).get("stats", {}),
                "activity": learning_activity,
            },
            "research_jobs": research_jobs,
            "knowledge_growth": growth,
            "evolution": {
                "record_count": (evolution or {}).get("record_count", 0),
                "versions": (evolution or {}).get("versions", 0),
                "history": evolution_history,
            },
            "intelligence_score": {
                "score": (evaluator or {}).get("score", 0),
                "strengths": (evaluator or {}).get("strengths", []),
                "weaknesses": (evaluator or {}).get("weaknesses", []),
                "next_improvements": (evaluator or {}).get("next_improvements", []),
            },
            "graph": graph or {"nodes": 0, "edges": 0},
            "recent_decisions": decisions or [],
            "time": time.time(),
        }

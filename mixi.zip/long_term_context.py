# -*- coding: utf-8 -*-
"""Mixium A29 — Long Term Context (Uzun görev hafızası).

Kararlar, planlar, önemli bilgiler, ara sonuçlar ve yapılan değişiklikleri
saklar; context kaybolmaz. Semantic recall embed_fn/cosine_fn ile (verilirse).
`.mixium/long_term_context.json` altında workspace-sınırlı saklanır.
"""

import json
import threading
import time
import uuid
from pathlib import Path

KINDS = ("decision", "plan", "info", "result", "change")


class LongTermContext:
    def __init__(self, root=".", embed_fn=None, cosine_fn=None, max_records=500):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "long_term_context.json"
        self.embed_fn = embed_fn or (lambda text: {})
        self.cosine_fn = cosine_fn or (lambda a, b: 0.0)
        self.max_records = max(1, int(max_records))
        self._lock = threading.RLock()
        self.records = []
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.records = d if isinstance(d, list) else []
        except Exception:
            self.records = []

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.records, ensure_ascii=False, indent=1),
                           encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def record(self, kind, text, meta=None):
        kind = str(kind).lower()
        if kind not in KINDS:
            kind = "info"
        text = str(text or "").strip()
        if not text:
            return None
        rec = {
            "id": "lt_" + uuid.uuid4().hex[:10], "kind": kind, "text": text[:2000],
            "meta": dict(meta or {}), "t": time.time(),
            "embedding": self.embed_fn(text),
        }
        with self._lock:
            self.records.append(rec)
            self.records = self.records[-self.max_records:]
            self._save()
        return rec

    def recall(self, query, k=5, kind=None):
        qv = self.embed_fn(str(query or ""))
        scored = []
        with self._lock:
            for r in self.records:
                if kind and r.get("kind") != kind:
                    continue
                try:
                    sim = self.cosine_fn(qv, r.get("embedding") or {})
                except Exception:
                    sim = 0.0
                scored.append((sim, r))
        scored.sort(key=lambda x: -x[0])
        return [{"score": round(s, 4), **r} for s, r in scored[:k]]

    def summarize(self, limit=20):
        with self._lock:
            rows = self.records[-limit:]
        return {
            "records": len(self.records),
            "recent": [{"kind": r["kind"], "text": r["text"][:140], "t": r["t"]} for r in rows],
            "kinds": {k: sum(1 for r in self.records if r["kind"] == k) for k in KINDS},
        }

    def status(self):
        return self.summarize()

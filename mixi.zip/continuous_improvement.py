# -*- coding: utf-8 -*-
"""Mixium A28 — Continuous Improvement Loop.

Sürekli: Gözlemle → Sorun bul → Araştır → Çözüm öner → Test et → Öğren.
Limitli döngü; kendi güvenlik çekirdeğini değiştirmez. Provider enjeksiyonlu.
"""

import time

DEFAULT_MAX_CYCLES = 10


class ContinuousImprovement:
    def __init__(self, providers=None, max_cycles=DEFAULT_MAX_CYCLES):
        self.providers = dict(providers or {})
        self.max_cycles = max_cycles
        self.history = []

    def _get(self, name, *args, **kw):
        fn = self.providers.get(name)
        if fn is None:
            return None
        try:
            return fn(*args, **kw)
        except Exception as e:
            return {"error": str(e)[:200]}

    def cycle(self):
        """Tek iyileştirme turu."""
        rec = {"t": time.time(), "steps": []}
        rec["steps"].append({"step": "observe", "result": self._get("observe")})
        issues = self._get("find_issues")
        rec["steps"].append({"step": "find_issues", "result": issues})
        rec["steps"].append({"step": "research", "result": self._get("research", issues)})
        proposals = self._get("propose", issues)
        rec["steps"].append({"step": "propose", "result": proposals})
        rec["steps"].append({"step": "test", "result": self._get("test", proposals)})
        rec["steps"].append({"step": "learn", "result": self._get("learn", rec)})
        self.history.append(rec)
        return rec

    def run(self, max_cycles=None):
        max_cycles = max_cycles or self.max_cycles
        out = {"cycles": 0, "records": []}
        for i in range(max_cycles):
            out["cycles"] = i + 1
            r = self.cycle()
            out["records"].append(r)
        return out

    def status(self):
        return {"cycles": len(self.history), "max_cycles": self.max_cycles}

# -*- coding: utf-8 -*-
"""Mixium A25C — Autonomous Debug Cycle.

Sonsuz iyileştirme döngüsü: Observe → Test → Problem bul → Analiz → Düzelt →
Doğrula → Öğren → Tekrar. Limitler: max cycle, zaman limiti, checkpoint,
pause/resume. Bug Hunter (A24) + Autonomous Fix (A25A) + DebugLoop (A12) sarmalar.
"""

import threading
import time

DEFAULT_MAX_CYCLES = 5
DEFAULT_TIME_LIMIT = 300.0  # saniye


class AutonomousDebugCycle:
    def __init__(self, hunter, fix_engine=None, learn_fn=None,
                 max_cycles=DEFAULT_MAX_CYCLES, time_limit=DEFAULT_TIME_LIMIT):
        """
        hunter      : A24 bug_hunter.BugHunter (hunt())
        fix_engine  : A25A autonomous_fix.AutonomousFixEngine (run(findings))
        learn_fn    : opsiyonel (record -> None) — improvement memory bağlantısı
        """
        self.hunter = hunter
        self.fix_engine = fix_engine
        self.learn_fn = learn_fn or (lambda rec: None)
        self.max_cycles = max_cycles
        self.time_limit = time_limit
        self.state = "idle"   # idle|running|paused|done|limit
        self.cycles = []
        self._stop = threading.Event()

    def run(self):
        self.state = "running"
        self._stop.clear()
        start = time.time()
        out = {"status": "done", "cycles": 0, "fixed": 0, "records": []}
        for i in range(self.max_cycles):
            if self._stop.is_set():
                out["status"] = "paused"
                self.state = "paused"
                break
            if time.time() - start > self.time_limit:
                out["status"] = "time_limit"
                self.state = "limit"
                break
            # observe → test → find
            report = self.hunter.hunt()
            cyc = {"i": i + 1, "hunter": report}
            # fix (varsa)
            if self.fix_engine is not None and report.get("findings"):
                fr = self.fix_engine.run(report["findings"])
                cyc["fix"] = fr
                if fr.get("accepted"):
                    out["fixed"] += fr["accepted"]
            # learn
            try:
                self.learn_fn({"cycle": i + 1, "hunter": report,
                               "fix": cyc.get("fix")})
            except Exception:
                pass
            self.cycles.append(cyc)
            out["cycles"] = i + 1
            out["records"].append(cyc)
            # sorun yoksa (clean) dur
            if not report.get("findings"):
                break
        if self.state == "running":
            self.state = "done"
        out["state"] = self.state
        out["elapsed"] = round(time.time() - start, 2)
        return out

    def pause(self):
        self._stop.set()
        if self.state == "running":
            self.state = "paused"
        return self.status()

    def resume(self):
        return self.run()

    def status(self):
        return {"state": self.state, "cycles": len(self.cycles),
                "max_cycles": self.max_cycles, "time_limit": self.time_limit}

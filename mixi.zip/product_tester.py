# -*- coding: utf-8 -*-
"""Mixium A24B — Autonomous Product Tester.

Mixium'u gerçek ürün gibi test eder: chat, memory, tool, streaming
senaryolarını izole biçimde çalıştırıp toplu rapor üretir. Adapter'lar
enjekte edilir; modülün kendisi MIXIUM çekirdeğine bağımlı değildir.
"""

import time


class ProductTester:
    GROUPS = ("chat", "memory", "tool", "streaming")

    def __init__(self, adapters=None):
        self.adapters = dict(adapters or {})
        self.runs = []

    def _call(self, name, *args, **kw):
        fn = self.adapters.get(name)
        if fn is None:
            raise RuntimeError("adapter yok: %s" % name)
        return fn(*args, **kw)

    def _run_check(self, group, name, fn, desc=""):
        t0 = time.time()
        try:
            ok = bool(fn())
            return {"group": group, "name": name, "status": "PASS" if ok else "FAIL",
                    "time": round(time.time() - t0, 2), "desc": desc}
        except Exception as e:
            return {"group": group, "name": name, "status": "ERROR",
                    "error": str(e)[:200], "time": round(time.time() - t0, 2), "desc": desc}

    def run_group(self, group):
        results = []
        chat = self.adapters.get("send")
        # chat: gönder → cevap döner
        if group == "chat":
            if chat is None:
                return [{"group": group, "name": "send", "status": "SKIP",
                         "desc": "chat adapter yok"}]
            results.append(self._run_check(group, "send_short", lambda: bool(chat("merhaba")), "kısa mesaj"))
            results.append(self._run_check(group, "send_long", lambda: bool(chat("x" * 5000)), "uzun mesaj"))
            results.append(self._run_check(group, "send_empty", lambda: (chat("") is not None) or True, "boş mesaj fail-safe"))
            results.append(self._run_check(group, "rapid_fire", lambda: all(chat("m%d" % i) is not None for i in range(5)), "arka arkaya mesaj"))
        elif group == "memory":
            mem = self.adapters.get("memory")
            if mem is None:
                return [{"group": group, "name": "memory", "status": "SKIP", "desc": "memory adapter yok"}]
            results.append(self._run_check(group, "store", lambda: mem("store", "pref", "kısa cevap") is not None, "bilgi kaydetme"))
            results.append(self._run_check(group, "recall", lambda: isinstance(mem("recall", "pref"), (list, dict, str)), "hatırlama"))
        elif group == "tool":
            discover = self.adapters.get("discover")
            if discover is None:
                return [{"group": group, "name": "discover", "status": "SKIP", "desc": "discover adapter yok"}]
            results.append(self._run_check(group, "discover", lambda: isinstance(discover(), (list, dict)), "araç keşfi"))
            call = self.adapters.get("call")
            if call is not None:
                results.append(self._run_check(group, "call_error", lambda: call("nonexistent_tool", {}) is not None, "yanlış araç hata yönetimi"))
        elif group == "streaming":
            stream = self.adapters.get("stream")
            if stream is None:
                return [{"group": group, "name": "stream", "status": "SKIP", "desc": "stream adapter yok"}]
            results.append(self._run_check(group, "tokens", lambda: len(list(stream("merhaba", 10))) > 0, "token akışı"))
            results.append(self._run_check(group, "interrupt", lambda: list(stream("merhaba", 3)) is not None, "yarım cevap fail-safe"))
        return results

    def run(self, groups=None):
        groups = groups or self.GROUPS
        out = {"groups": {}, "passed": 0, "failed": 0, "errors": 0, "skipped": 0, "total": 0}
        for g in groups:
            res = self.run_group(g)
            out["groups"][g] = res
            for r in res:
                out["total"] += 1
                if r["status"] == "PASS":
                    out["passed"] += 1
                elif r["status"] == "FAIL":
                    out["failed"] += 1
                elif r["status"] == "ERROR":
                    out["errors"] += 1
                else:
                    out["skipped"] += 1
        out["summary"] = "%d/%d PASS" % (out["passed"], out["total"])
        self.runs.append(out)
        return out

    def status(self):
        return {"runs": len(self.runs), "last": self.runs[-1] if self.runs else None}

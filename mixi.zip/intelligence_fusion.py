# -*- coding: utf-8 -*-
"""
Mixium — Intelligence Fusion Engine (Aşama 15E)

Birleştirir: User DNA + Expert Knowledge + Pattern + Project Context +
Current Task -> Optimal Context Package (ana modele gitmeden önce).

MIXIUM'a bağımlı değildir; user_dna / expert_store / pattern_store /
project_fn enjekte edilir. Yalnızca boş olmayan parçalar birleştirilir.
"""


class IntelligenceFusion:
    def __init__(self, user_dna=None, expert_store=None, pattern_store=None,
                 project_fn=None):
        self.user_dna = user_dna
        self.expert_store = expert_store
        self.pattern_store = pattern_store
        self.project_fn = project_fn

    def fuse(self, task, top_k=5):
        parts = []
        # User DNA (kişisel tercihler/olgular)
        if self.user_dna is not None:
            try:
                b = self.user_dna.context_block(limit=5)
                if b:
                    parts.append(b)
            except Exception:
                pass
        # Expert knowledge
        if self.expert_store is not None:
            try:
                b = self.expert_store.context_block(task or "", top_k=top_k,
                                                    min_confidence=40)
                if b:
                    parts.append(b)
            except Exception:
                pass
        # Patterns
        if self.pattern_store is not None:
            try:
                b = self.pattern_store.context_block(task or "", top_k=3)
                if b:
                    parts.append(b)
            except Exception:
                pass
        # Project context
        if self.project_fn is not None:
            try:
                p = self.project_fn()
                if p:
                    parts.append("[PROJE BAĞLAM]\n" + str(p)[:1500])
            except Exception:
                pass
        return "\n\n".join(parts)

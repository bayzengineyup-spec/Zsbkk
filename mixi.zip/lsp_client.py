# -*- coding: utf-8 -*-
"""
Mixium — LSP (Language Server Protocol) stdio client

Claude Code `src/services/lsp/LSPClient.ts` + `LSPServerManager.ts` +
`LSPDiagnosticRegistry.ts` mantığının Mixium adaptasyonu. Sıfır harici
bağımlılık (yalnızca stdlib).

MCP'den farkı: LSP bir arka plan kod analiz servisidir. Sunucu
`textDocument/publishDiagnostics` bildirimlerini ASENKRON gönderir; bu
nedenle burada `mcp_client`'ın senkron request/response yapısı değil,
bir arka plan reader thread'i kullanılır. JSON-RPC framing
(`Content-Length: N\\r\\n\\r\\n`) Aşama 7A'daki `mcp_client`'dan yeniden
kullanılır (kod tekrarı yok).
"""

import json
import os
import subprocess
import threading
from pathlib import Path

try:
    from mcp_client import MCPClient
    _frame = MCPClient._frame
    _read_frame = MCPClient._read_frame
except Exception:  # mcp_client yoksa self-contained fallback
    def _frame(msg):
        body = json.dumps(msg, ensure_ascii=False).encode("utf-8")
        return (b"Content-Length: " + str(len(body)).encode("utf-8") +
                b"\r\n\r\n" + body)

    def _read_frame(stream):
        headers = b""
        while b"\r\n\r\n" not in headers:
            chunk = stream.read(1)
            if not chunk:
                raise RuntimeError("baglanti kapandi (header okuma)")
            headers += chunk
        length = None
        for line in headers.decode("utf-8", "replace").split("\r\n"):
            if line.lower().startswith("content-length:"):
                length = int(line.split(":", 1)[1].strip())
        if length is None:
            raise RuntimeError("Content-Length header yok")
        body = b""
        while len(body) < length:
            chunk = stream.read(length - len(body))
            if not chunk:
                raise RuntimeError("baglanti kapandi (body okuma)")
            body += chunk
        return json.loads(body.decode("utf-8"))


class LSPError(Exception):
    """LSP bağlantı / protokol hatası."""


_SEV_NAMES = {1: "error", 2: "warning", 3: "info", 4: "hint"}


class LSPClient:
    """Tek bir LSP sunucusuyla konuşan istemci.

    start() → initialize() → initialized → ready
    request(method, params) → senkron yanıt (timeout'lu)
    notify(method, params)  → fire-and-forget
    on_notification(method, handler) → asenkron bildirim yakalar
    """

    def __init__(self, name, command, args=None, env=None, cwd=None, timeout=30):
        self.name = name
        self.command = command
        self.args = list(args or [])
        self.cwd = cwd
        self.timeout = timeout
        self.env = dict(os.environ)
        if env:
            self.env.update({str(k): str(v) for k, v in env.items()})
        self.proc = None
        self.state = "stopped"       # stopped / starting / ready / failed
        self.server_info = {}
        self.capabilities = {}
        self.opened_files = set()    # file URI'ları (didOpen idempotence)
        self._lock = threading.Lock()
        self._next_id = 0
        self._pending = {}           # id -> {"event", "result", "error"}
        self._handlers = {}          # method -> handler(params)
        self._reader = None
        self._stop_reader = False
        self._is_stopping = False

    # ---- transport ----
    def _write(self, msg):
        self.proc.stdin.write(_frame(msg))
        self.proc.stdin.flush()

    def start(self):
        try:
            self.proc = subprocess.Popen(
                [self.command] + self.args,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, env=self.env, cwd=self.cwd,
            )
        except FileNotFoundError as e:
            self.state = "failed"
            raise LSPError("sunucu bulunamadi: %s" % e)
        except Exception as e:
            self.state = "failed"
            raise LSPError("baslatilamadi: %s" % e)
        self.state = "starting"
        self._stop_reader = False
        self._reader = threading.Thread(target=self._reader_loop, daemon=True)
        self._reader.start()
        return self

    def _reader_loop(self):
        while not self._stop_reader:
            try:
                msg = _read_frame(self.proc.stdout)
            except Exception as e:
                self._on_closed(str(e))
                break
            rid = msg.get("id")
            method = msg.get("method")
            if method is not None and rid is None:
                # notification
                handler = self._handlers.get(method)
                if handler:
                    try:
                        handler(msg.get("params"))
                    except Exception:
                        pass
            elif rid is not None:
                # Yanıt geldi: pending girdisini SİLME (request() pop edecek);
                # sadece sonucu yazıp event'i tetikle. Böylece request()'in
                # aynı girdiyi ikinci kez pop etmesi (None → yanlış timeout)
                # engellenir.
                with self._lock:
                    p = self._pending.get(rid)
                    if p is not None:
                        if "error" in msg:
                            p["error"] = msg["error"]
                        else:
                            p["result"] = msg.get("result")
                        p["event"].set()
                # server->client request (nadir): desteklenmiyor, hata döner
                if p is None and method is not None:
                    try:
                        self._write({"jsonrpc": "2.0", "id": rid, "error": {
                            "code": -32601, "message": "Method not supported"}})
                    except Exception:
                        pass
            # response (id + result) zaten yukarıda işlendi

    def _on_closed(self, reason):
        if self._is_stopping:
            self.state = "stopped"
        else:
            self.state = "failed"
        with self._lock:
            for rid, p in list(self._pending.items()):
                if not p["event"].is_set():
                    p["error"] = {"message": "baglanti kapandi: %s" % reason}
                    p["event"].set()

    # ---- lifecycle ----
    def initialize(self, root_uri=None):
        params = {
            "processId": os.getpid(),
            "rootUri": root_uri,
            "capabilities": {
                "textDocument": {"publishDiagnostics": {"relatedInformation": True}},
                "workspace": {},
            },
            "clientInfo": {"name": "mixium", "version": "1.0"},
        }
        result = self.request("initialize", params, timeout=self.timeout)
        self.server_info = result.get("serverInfo", {}) or {}
        self.capabilities = result.get("capabilities", {}) or {}
        self.notify("initialized", {})
        self.state = "ready"
        return result

    def request(self, method, params=None, timeout=None):
        with self._lock:
            if self.proc is None or self.proc.poll() is not None:
                raise LSPError("sunucu sureci calismiyor")
            self._next_id += 1
            rid = self._next_id
            ev = threading.Event()
            self._pending[rid] = {"event": ev, "result": None, "error": None}
            try:
                self._write({"jsonrpc": "2.0", "id": rid,
                             "method": method, "params": params or {}})
            except Exception as e:
                self._pending.pop(rid, None)
                raise LSPError("yazma hatasi: %s" % e)
        ok = ev.wait(timeout if timeout is not None else self.timeout)
        with self._lock:
            p = self._pending.pop(rid, None)
        if not ok or p is None:
            raise LSPError("timeout: %s" % method)
        if p["error"]:
            raise LSPError("%s: %s" % (method, p["error"].get("message", p["error"])))
        return p["result"]

    def notify(self, method, params=None):
        with self._lock:
            if self.proc is None or self.proc.poll() is not None:
                return
            try:
                self._write({"jsonrpc": "2.0", "method": method,
                             "params": params or {}})
            except Exception:
                pass

    def on_notification(self, method, handler):
        self._handlers[method] = handler

    def shutdown(self):
        self._is_stopping = True
        if self.proc is None or self.proc.poll() is not None:
            self.state = "stopped"
            return
        try:
            self.request("shutdown", {}, timeout=3)
        except Exception:
            pass
        try:
            self.notify("exit", {})
        except Exception:
            pass

    def close(self):
        self.shutdown()
        self._stop_reader = True
        with self._lock:
            if self.proc is not None:
                try:
                    self.proc.stdin.close()
                except Exception:
                    pass
        if self._reader is not None:
            self._reader.join(timeout=1)
        with self._lock:
            if self.proc is not None:
                try:
                    self.proc.wait(timeout=2)
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
            self.proc = None
        self.state = "stopped"

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════
#  DIAGNOSTICS REGISTRY — Claude Code LSPDiagnosticRegistry adaptasyonu
#  Limitler: max 500 dosya (LRU), dosya basina 10 hata; dedup
# ══════════════════════════════════════════════════════════════════════
_MAX_FILES = 500
_MAX_PER_FILE = 10

LSP_DIAGNOSTICS = {}   # uri -> {"errors": [{"line","severity","message"}], "keys": set()}


def _ingest_diagnostics(uri, diags):
    """publishDiagnostics params'ındaki tanıları registry'ye ekle (dedup + limit)."""
    entry = LSP_DIAGNOSTICS.get(uri)
    if entry is None:
        if len(LSP_DIAGNOSTICS) >= _MAX_FILES:
            LSP_DIAGNOSTICS.pop(next(iter(LSP_DIAGNOSTICS)), None)
        entry = {"errors": [], "keys": set()}
        LSP_DIAGNOSTICS[uri] = entry
    for d in diags or []:
        if not isinstance(d, dict):
            continue
        rng = d.get("range") or {}
        start = rng.get("start") or {}
        try:
            line = int(start.get("line", 0)) + 1   # LSP 0-tabanlı -> 1-tabanlı
        except (TypeError, ValueError):
            line = 0
        sev = _SEV_NAMES.get(d.get("severity"), "info")
        msg = str(d.get("message", "")).strip()
        if not msg:
            continue
        key = (line, sev, msg)
        if key in entry["keys"]:
            continue
        entry["keys"].add(key)
        entry["errors"].append({"line": line, "severity": sev, "message": msg})
    entry["errors"] = entry["errors"][:_MAX_PER_FILE]
    # LRU touch: en son güncellenen dosya sona taşınır
    LSP_DIAGNOSTICS.pop(uri, None)
    LSP_DIAGNOSTICS[uri] = entry


def get_diagnostics(uri, max_total=30):
    """Bir dosyanın tanılarını döndürür (yoksa [])."""
    entry = LSP_DIAGNOSTICS.get(uri)
    if not entry:
        return []
    return list(entry.get("errors", [])[:max_total])


def format_diagnostics(uri, diags, path_label=None):
    """Tanıları okunur metne çevirir (lsp_diagnostics çıktısı)."""
    label = path_label or uri
    if not diags:
        return "%s: tanı yok" % label
    rows = []
    for d in diags:
        rows.append("  satır %s [%s]: %s" % (d["line"], d["severity"], d["message"]))
    return "%s:\n%s" % (label, "\n".join(rows))


# ══════════════════════════════════════════════════════════════════════
#  LSP MANAGER — Claude Code LSPServerManager adaptasyonu
#  dosyaya/dile göre server seçimi + tekil instance + didOpen/didChange
# ══════════════════════════════════════════════════════════════════════
class LSPManager:
    def __init__(self, config=None):
        self.config = config or {}
        self.servers = {}   # language -> LSPClient

    @staticmethod
    def _file_uri(path):
        return Path(path).resolve().as_uri()

    def language_for_file(self, path):
        ext = Path(path).suffix.lower()
        for lang, cfg in self.config.items():
            if ext in (cfg.get("extensions") or []):
                return lang
        return None

    def ensure_server(self, language):
        """Sunucuyu başlat / hazırsa döndür. Başarısız olursa None."""
        existing = self.servers.get(language)
        if existing is not None and existing.state == "ready":
            return existing
        cfg = self.config.get(language)
        if not cfg:
            return None
        cli = LSPClient(language, cfg.get("command"),
                        args=cfg.get("args", []),
                        env=cfg.get("env"),
                        cwd=cfg.get("cwd"),
                        timeout=int(cfg.get("timeout", 30)))
        cli.on_notification("textDocument/publishDiagnostics",
                            lambda params: self._on_diagnostics(params))
        try:
            cli.start()
            cli.initialize(root_uri=cfg.get("rootUri"))
        except Exception:
            cli.state = "failed"
            self.servers[language] = cli
            return None
        self.servers[language] = cli
        return cli

    def _on_diagnostics(self, params):
        if not isinstance(params, dict):
            return
        uri = params.get("uri")
        if not uri:
            return
        _ingest_diagnostics(uri, params.get("diagnostics") or [])

    def open_file(self, language, path, content):
        """didOpen gönder (idempotent). İçerik okuma Mixium tarafında yapılır."""
        cli = self.ensure_server(language)
        if cli is None:
            return False
        cfg = self.config.get(language, {})
        uri = self._file_uri(path)
        if uri in cli.opened_files:
            return True
        language_id = cfg.get("languageId", "plaintext")
        try:
            cli.notify("textDocument/didOpen", {
                "textDocument": {
                    "uri": uri, "languageId": language_id,
                    "version": 1, "text": content,
                },
            })
            cli.opened_files.add(uri)
            return True
        except Exception:
            return False

    def change_file(self, language, path, content):
        """didChange gönder (dosya daha önce açılmadıysa didOpen)."""
        cli = self.servers.get(language)
        if cli is None or cli.state != "ready":
            return self.open_file(language, path, content)
        uri = self._file_uri(path)
        if uri not in cli.opened_files:
            return self.open_file(language, path, content)
        try:
            cli.notify("textDocument/didChange", {
                "textDocument": {"uri": uri, "version": 1},
                "contentChanges": [{"text": content}],
            })
            return True
        except Exception:
            return False

    def document_symbols(self, language, path):
        """textDocument/documentSymbol — opsiyonel (lsp_symbols)."""
        cli = self.ensure_server(language)
        if cli is None:
            return None
        try:
            return cli.request("textDocument/documentSymbol",
                               {"textDocument": {"uri": self._file_uri(path)}},
                               timeout=10)
        except Exception:
            return None

    def shutdown_all(self):
        for cli in list(self.servers.values()):
            try:
                cli.close()
            except Exception:
                pass
        self.servers.clear()
        LSP_DIAGNOSTICS.clear()

# -*- coding: utf-8 -*-
"""Mixium A20 — bounded task delegation planner."""
import time
import uuid

DEFAULT_STAGES = (
    ("architect", "Mimari ve kapsam planını çıkar", []),
    ("research", "Gerekli teknik ve proje bilgisini topla", ["architect"]),
    ("coding", "Uygulama yaklaşımını ve değişiklikleri hazırla", ["architect", "research"]),
    ("testing", "Test ve doğrulama planını çalıştır", ["coding"]),
    ("security", "Permission, sandbox ve risk kontrolü yap", ["coding"]),
    ("reviewer", "Sonuçları ve riskleri gözden geçir", ["testing", "security"]),
)

class TaskDelegationEngine:
    def __init__(self, society=None, max_tasks=100):
        self.society = society
        self.max_tasks = max(1, int(max_tasks))
        self.plans = {}

    def delegate(self, goal, stages=None, context=None):
        goal = str(goal or "").strip()
        if not goal:
            return None
        stages = stages or DEFAULT_STAGES
        pid = "delegation_" + uuid.uuid4().hex[:10]
        tasks = []
        for role, description, deps in stages:
            tasks.append({"id": "subtask_" + uuid.uuid4().hex[:8], "role": role, "description": description,
                          "goal": goal[:1500], "dependencies": list(deps), "status": "pending", "result": None})
        plan = {"id": pid, "goal": goal[:3000], "context": dict(context or {}), "tasks": tasks, "status": "planned", "created": time.time()}
        self.plans[pid] = plan
        if len(self.plans) > self.max_tasks:
            self.plans.pop(next(iter(self.plans)))
        return self._copy(plan)

    def assign(self, plan_id, task_id, agent_id=None):
        plan = self.plans.get(str(plan_id))
        if not plan:
            return None
        for task in plan["tasks"]:
            if task["id"] == task_id:
                task["agent_id"] = agent_id
                task["status"] = "assigned"
                return dict(task)
        return None

    def record_result(self, plan_id, task_id, result, success=True):
        plan = self.plans.get(str(plan_id))
        if not plan:
            return None
        for task in plan["tasks"]:
            if task["id"] == task_id:
                task.update({"result": result, "status": "completed" if success else "failed", "updated": time.time()})
                break
        statuses = [t["status"] for t in plan["tasks"]]
        plan["status"] = "completed" if statuses and all(s == "completed" for s in statuses) else "failed" if any(s == "failed" for s in statuses) else "running"
        return self._copy(plan)

    def merge_results(self, plan_id):
        plan = self.plans.get(str(plan_id))
        if not plan:
            return None
        return {"plan_id": plan_id, "goal": plan["goal"], "status": plan["status"],
                "results": [{"role": t["role"], "status": t["status"], "result": t.get("result")} for t in plan["tasks"]],
                "warnings": ["%s görevi tamamlanmadı" % t["role"] for t in plan["tasks"] if t["status"] != "completed"]}

    def get(self, plan_id):
        return self._copy(self.plans.get(str(plan_id)))

    @staticmethod
    def _copy(value):
        if value is None:
            return None
        return {**value, "tasks": [dict(t) for t in value.get("tasks", [])]}

    def status(self):
        return {"plans": [self._copy(p) for p in self.plans.values()], "count": len(self.plans)}

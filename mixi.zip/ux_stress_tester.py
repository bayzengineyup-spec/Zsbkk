# -*- coding: utf-8 -*-
"""Mixium A30 — UX Stress Tester.

Yeni kullanıcı deneyimi, karmaşık görevler, uzun sohbet, uzun cevap, hata
durumları, bağlantı kopması, tekrar bağlanma. Adapter-enjeksiyonlu; adapter
yoksa o senaryo fail-closed olarak işaretlenir (SKIP).
"""

import time

SCENARIOS = ("new_user", "complex_task", "long_chat", "long_answer",
             "error_state", "disconnect", "reconnect")


class UXStressTester:
    def __init__(self, adapters=None):
        self.adapters = dict(adapters or {})

    def _call(self, name):
        fn = self.adapters.get(name)
        if fn is None:
            return {"ok": False, "skipped": True, "reason": "adapter yok"}
        try:
            r = fn() if callable(fn) else fn
            return r if isinstance(r, dict) else {"ok": True, "result": r}
        except Exception as e:
            return {"ok": False, "error": str(e)[:200]}

    def run(self, scenarios=None):
        scenarios = list(scenarios) if scenarios else list(SCENARIOS)
        out = {"scenarios": [], "passed": 0, "skipped": 0, "failed": 0}
        for s in scenarios:
            if s not in SCENARIOS:
                continue
            r = self._call(s)
            ok = bool(r and r.get("ok")) and not r.get("skipped")
            if r.get("skipped"):
                out["skipped"] += 1
            elif ok:
                out["passed"] += 1
            else:
                out["failed"] += 1
            out["scenarios"].append({"name": s, "result": r})
        out["t"] = time.time()
        return out

    def status(self):
        return {"scenarios": list(SCENARIOS), "adapters": sorted(self.adapters.keys())}

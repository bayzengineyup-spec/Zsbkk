"""Small targeted file editing engine."""
from pathlib import Path

def replace_block(path, old, new):
    p=Path(path)
    text=p.read_text(encoding='utf-8')
    if old not in text:
        return False
    p.write_text(text.replace(old,new,1),encoding='utf-8')
    return True

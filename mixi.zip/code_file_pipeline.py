"""Mixium code artifact pipeline.
Creates files instead of dumping large code blocks.
"""
import os, uuid

CODE_EXTENSIONS = {'.html','.css','.js','.ts','.jsx','.tsx','.py','.json','.md'}

def should_create_file(text):
    if not text: return False
    t=text.lower()
    return any(x in t for x in ['```','<!doctype','create file','dosya oluştur','html','javascript','python','kod'])

def create_artifact(path, content):
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    with open(path,'w',encoding='utf-8') as f:
        f.write(content)
    return path

class PreviewInfo:
    def __init__(self, path):
        self.path=path
        self.previewable=path.lower().endswith(('.html','.htm'))

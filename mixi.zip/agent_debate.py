# -*- coding: utf-8 -*-
"""Mixium A20 — Agent debate and decision adapter.

The A16 DecisionEngine remains the source of safety policy. This module adds
agent opinions as evidence and never overrides destructive-operation safety.
"""
import threading
import time

class AgentDebate:
    def __init__(self, max_arguments=100):
        self.max_arguments = max(1, int(max_arguments))
        self.arguments = []
        self._lock = threading.RLock()

    def add_argument(self, agent, position, rationale="", quality=50, confidence=50, risk=50):
        row = {"agent": str(agent), "position": str(position)[:1000], "rationale": str(rationale)[:2000],
               "quality": max(0, min(100, float(quality))), "confidence": max(0, min(100, float(confidence))),
               "risk": max(0, min(100, float(risk))), "time": time.time()}
        row["score"] = round(row["quality"] * .4 + row["confidence"] * .4 + (100 - row["risk"]) * .2, 2)
        with self._lock:
            self.arguments.append(row)
            self.arguments = self.arguments[-self.max_arguments:]
        return dict(row)

    def resolve(self, question=""):
        with self._lock:
            rows = [dict(x) for x in self.arguments]
        if not rows:
            return {"decision": "Yeterli agent görüşü yok; read-only analiz yap.", "arguments": [], "confidence": 0, "risks": ["kanıt eksik"]}
        rows.sort(key=lambda x: -x["score"])
        top = rows[0]
        unique = len({x["position"] for x in rows})
        confidence = max(0, min(100, round(top["score"] - max(0, unique - 1) * 4)))
        risks = ["görüşler arasında farklılık var"] if unique > 1 else []
        risks.extend(x["position"] for x in rows if x["risk"] >= 75)
        return {"question": str(question)[:500], "decision": top["position"], "arguments": rows[:20], "confidence": confidence, "risks": risks[:10]}

class SocietyDecisionAdapter:
    def __init__(self, base_engine=None, debate=None, experience_fn=None):
        self.base_engine = base_engine
        self.debate = debate or AgentDebate()
        self.experience_fn = experience_fn

    def decide(self, task, intent="read", opinions=None):
        for op in opinions or []:
            if isinstance(op, dict):
                self.debate.add_argument(op.get("agent", "agent"), op.get("position", ""), op.get("rationale", ""), op.get("quality", 50), op.get("confidence", 50), op.get("risk", 50))
        debate = self.debate.resolve(task)
        base = self.base_engine.decide(task, intent=intent) if self.base_engine else {"recommendation": "Read-only keşif ile başla.", "reasoning": [], "confidence": 50, "alternatives": []}
        # Destructive policy from A16 always wins.
        if intent == "destructive":
            base["recommendation"] = "Destructif işlem önerilmez: önce read-only analiz + onay şartı."
            base["confidence"] = max(int(base.get("confidence", 0)), 85)
        elif debate.get("arguments"):
            base["recommendation"] = debate["decision"]
            base["confidence"] = round((float(base.get("confidence", 50)) + debate["confidence"]) / 2)
        base["agent_debate"] = debate
        base["agent_opinions"] = len(debate.get("arguments", []))
        return base

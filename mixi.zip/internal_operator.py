# -*- coding: utf-8 -*-
"""Mixium A24I — DeepSeek Internal Operator Mode.

DeepSeek V4 Pro'nun "Mixium geliştiricisi + test kullanıcısı" rolünde
çalışmasını sağlar. Döngü: sistemi aç → kullanıcı gibi görev ver → sonuçları
incele → sorun ara → kalite değerlendir → hata bul → güvenli düzeltme uygula
→ test et → öğren.

Tüm adımlar enjekte edilen provider/hook'lar üzerinden çalışır; modül kendi
başına kritik sistem değişikliği yapamaz. Güvenlik zinciri (Permission →
hard_gate → approval → checkpoint → rollback) değişmez.
"""

import time


class InternalOperator:
    def __init__(self, providers=None, safe_fix=True):
        self.providers = dict(providers or {})
        self.safe_fix = safe_fix
        self.history = []
        self.last_run = None

    def _get(self, name, *args, **kw):
        fn = self.providers.get(name)
        if fn is None:
            return None
        try:
            return fn(*args, **kw)
        except Exception as e:
            return {"error": str(e)[:200]}

    def run(self, task, max_fix_cycles=3):
        """Tek operatör turu. task: kullanıcı gibi verilen görev."""
        t0 = time.time()
        rec = {"task": task, "started": time.time(), "steps": []}

        # 1. sistemi aç / durum al
        rec["steps"].append({"step": "open", "result": self._get("status")})

        # 2. kullanıcı gibi görev ver
        response = self._get("run_task", task)
        rec["steps"].append({"step": "task", "result": response})

        # 3. kalite değerlendir
        quality = self._get("quality", task, response)
        rec["steps"].append({"step": "quality", "result": quality})

        # 4. sorun ara
        findings = self._get("find_issues", task, response, quality)
        findings = findings or []
        rec["steps"].append({"step": "find_issues", "result": findings})

        # 5. güvenli düzeltme uygula (varsa)
        rec["fixes"] = []
        if self.safe_fix:
            for i, f in enumerate(list(findings or [])[:max_fix_cycles]):
                fix = self._get("apply_fix", f)
                if fix:
                    rec["fixes"].append(fix)
                if i >= max_fix_cycles - 1:
                    break
            rec["steps"].append({"step": "fix", "result": rec["fixes"]})

        # 6. test et
        rec["steps"].append({"step": "test", "result": self._get("test")})

        # 7. öğren
        rec["steps"].append({"step": "learn", "result": self._get("learn", rec)})

        rec["finished"] = time.time()
        rec["elapsed"] = round(rec["finished"] - t0, 2)
        self.last_run = rec
        self.history.append(rec)
        return rec

    def status(self):
        return {"runs": len(self.history), "safe_fix": self.safe_fix,
                "last": self.last_run, "recent": self.history[-5:]}

# -*- coding: utf-8 -*-
"""
Mixium — Intelligence Memory Graph (Aşama 16D)

DNA + Expert Knowledge + Pattern + Project bilgisini grafik yapmak.

Node tipleri: user / concept / technology / pattern / project / decision
Edge tipleri: related / improves / depends / conflicts

Depo: .mixium/learning/graph.json (workspace içi, fail-closed).
MIXIUM'a bağımlı değildir. Thread-safe (RLock).
"""

import json
import threading
import time
import uuid
from pathlib import Path

NODE_TYPES = ("user", "concept", "technology", "pattern", "project", "decision")
EDGE_TYPES = ("related", "improves", "depends", "conflicts")

MAX_NODES = 1000
MAX_EDGES = 2000


class IntelligenceGraph:
    def __init__(self, root="."):
        self.root = Path(root)
        self.dir = self.root / ".mixium" / "learning"
        self._lock = threading.RLock()
        self._graph = {"nodes": {}, "edges": []}
        self._load()

    def _allowed(self, p):
        try:
            p = Path(p).resolve()
            root = self.root.resolve()
            return root in p.parents or p == root
        except Exception:
            return False

    def _load(self):
        try:
            if self._allowed(self.dir / "graph.json"):
                with open(self.dir / "graph.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    self._graph = data
                    self._graph.setdefault("nodes", {})
                    self._graph.setdefault("edges", [])
        except Exception:
            pass

    def _save(self):
        try:
            if not self._allowed(self.dir):
                return False
            self.dir.mkdir(parents=True, exist_ok=True)
            tmp = self.dir / "graph.json.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._graph, f, ensure_ascii=False, indent=1)
            tmp.replace(self.dir / "graph.json")
            return True
        except Exception:
            return False

    # ── node ────────────────────────────────────────────────────────
    def add_node(self, name, ntype="concept", meta=None):
        if ntype not in NODE_TYPES:
            return None
        with self._lock:
            nodes = self._graph["nodes"]
            if len(nodes) >= MAX_NODES:
                return None
            nid = name.strip()[:80]
            if not nid:
                return None
            if nid in nodes:
                nodes[nid]["meta"].update(meta or {})
                nodes[nid]["updated"] = time.time()
            else:
                nodes[nid] = {
                    "id": nid, "type": ntype, "meta": dict(meta or {}),
                    "created": time.time(), "updated": time.time()}
            self._save()
            return nid

    def get_node(self, nid):
        with self._lock:
            return dict(self._graph["nodes"].get(nid, {}))

    # ── edge ────────────────────────────────────────────────────────
    def add_edge(self, src, dst, etype="related", weight=1.0):
        if etype not in EDGE_TYPES:
            return False
        with self._lock:
            edges = self._graph["edges"]
            if len(edges) >= MAX_EDGES:
                return False
            # duplicate edge kontrolü
            for e in edges:
                if e.get("src") == src and e.get("dst") == dst and e.get("type") == etype:
                    e["weight"] = max(e.get("weight", 1.0), float(weight))
                    e["updated"] = time.time()
                    self._save()
                    return True
            edges.append({
                "src": src, "dst": dst, "type": etype,
                "weight": float(weight), "created": time.time(),
                "updated": time.time()})
            self._save()
            return True

    # ── sorgular ────────────────────────────────────────────────────
    def neighbors(self, nid, etype=None):
        """nid'den çıkan kenarların hedefleri."""
        out = []
        with self._lock:
            for e in self._graph["edges"]:
                if e.get("src") == nid and (etype is None or e.get("type") == etype):
                    out.append({"node": e.get("dst"), "type": e.get("type"),
                                "weight": e.get("weight", 1.0)})
        return out

    def find(self, query, ntype=None):
        """İsim/etiket eşleşmesiyle node ara (substring, case-insensitive)."""
        q = query.lower()
        out = []
        with self._lock:
            for nid, n in self._graph["nodes"].items():
                if q in nid.lower() or q in str(n.get("meta", {})).lower():
                    if ntype is None or n.get("type") == ntype:
                        out.append({"id": nid, "type": n.get("type"),
                                    "meta": n.get("meta", {})})
        return out[:50]

    def subgraph(self, center, depth=2):
        """center node etrafında depth kadar komşu (ağaç gösterimi için)."""
        result = {}
        seen = set()

        def walk(nid, d):
            if d > depth or nid in seen:
                return
            seen.add(nid)
            node = self.get_node(nid)
            if not node:
                return
            result[nid] = {"node": node, "edges": self.neighbors(nid)}
            for nb in self.neighbors(nid):
                walk(nb.get("node"), d + 1)

        walk(center, 0)
        return result

    def stats(self):
        with self._lock:
            by_type = {}
            for n in self._graph["nodes"].values():
                t = n.get("type", "concept")
                by_type[t] = by_type.get(t, 0) + 1
            by_edge = {}
            for e in self._graph["edges"]:
                t = e.get("type", "related")
                by_edge[t] = by_edge.get(t, 0) + 1
            return {
                "nodes": len(self._graph["nodes"]),
                "edges": len(self._graph["edges"]),
                "node_types": by_type,
                "edge_types": by_edge,
            }

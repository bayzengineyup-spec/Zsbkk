// Minimal patch based editing helper
window.MixiumPatchEdit={
 apply(oldText, target, replacement){
  const i=oldText.indexOf(target);
  if(i<0) return {changed:false,text:oldText};
  return {changed:true,text:oldText.slice(0,i)+replacement+oldText.slice(i+target.length)};
 }
};

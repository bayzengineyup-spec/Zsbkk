# -*- coding: utf-8 -*-
"""Mixium A20 — bounded multi-agent society catalog.

This module stores role metadata and performance state only. It does not run
tools, grant permissions, or replace AgentRuntime.
"""
import json
import threading
import time
import uuid
from pathlib import Path

ROLES = {
    "architect": {"capabilities": ["architecture", "planning"], "tools": ["code_search", "project_index", "dependency_graph", "read", "tree"]},
    "research": {"capabilities": ["research", "analysis"], "tools": ["research", "fetch", "code_search", "lsp_diagnostics", "read"]},
    "coding": {"capabilities": ["coding", "implementation"], "tools": ["read", "write", "edit", "multi_edit", "patch", "test_status"]},
    "security": {"capabilities": ["security", "risk_analysis"], "tools": ["read", "code_search", "project_health", "lsp_diagnostics"]},
    "testing": {"capabilities": ["testing", "debugging"], "tools": ["test_status", "lsp_diagnostics", "read", "bash"]},
    "performance": {"capabilities": ["performance", "optimization"], "tools": ["project_health", "code_search", "read"]},
    "reviewer": {"capabilities": ["review", "quality"], "tools": ["read", "git_diff", "code_search", "project_health"]},
}

class AgentSociety:
    def __init__(self, root=".", max_agents=16):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "agent_society.json"
        self.max_agents = max(1, int(max_agents))
        self._lock = threading.RLock()
        self.agents = {}
        self.history = []
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                data = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    self.agents = data.get("agents", {}) if isinstance(data.get("agents", {}), dict) else {}
                    self.history = data.get("history", []) if isinstance(data.get("history", []), list) else []
        except Exception:
            self.agents, self.history = {}, []

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps({"agents": self.agents, "history": self.history[-200:]}, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def create_agent(self, role, goal="", agent_id=None):
        role = str(role or "").lower().strip()
        if role not in ROLES:
            return None
        with self._lock:
            active = sum(a.get("status") not in ("REMOVED", "COMPLETED") for a in self.agents.values())
            if active >= self.max_agents:
                return None
            aid = agent_id or "soc_" + uuid.uuid4().hex[:10]
            profile = {"id": aid, "role": role, "goal": str(goal or "")[:2000], "status": "CREATED",
                       "capability": list(ROLES[role]["capabilities"]), "tools": list(ROLES[role]["tools"]),
                       "performance_score": 50.0, "history": [], "confidence": 50.0,
                       "created": time.time(), "updated": time.time()}
            self.agents[aid] = profile
            self.history.append({"event": "created", "agent_id": aid, "role": role, "time": time.time()})
            self._save()
            return dict(profile)

    def get(self, agent_id):
        with self._lock:
            row = self.agents.get(str(agent_id))
            return dict(row) if row else None

    def update(self, agent_id, **changes):
        with self._lock:
            row = self.agents.get(str(agent_id))
            if not row:
                return None
            allowed = {"status", "goal", "confidence", "performance_score"}
            for key, value in changes.items():
                if key in allowed:
                    row[key] = value
            row["updated"] = time.time()
            self._save()
            return dict(row)

    def record_result(self, agent_id, success, confidence=None, error="", feedback=None):
        with self._lock:
            row = self.agents.get(str(agent_id))
            if not row:
                return None
            item = {"success": bool(success), "confidence": confidence, "error": str(error or "")[:500], "feedback": feedback, "time": time.time()}
            row.setdefault("history", []).append(item)
            row["history"] = row["history"][-100:]
            hist = row["history"]
            row["performance_score"] = round(sum(1 for x in hist if x.get("success")) * 100.0 / len(hist), 1)
            if confidence is not None:
                vals = [float(x["confidence"]) for x in hist if isinstance(x.get("confidence"), (int, float))]
                if vals:
                    row["confidence"] = round(sum(vals) / len(vals), 1)
            row["status"] = "COMPLETED" if success else "FAILED"
            row["updated"] = time.time()
            self.history.append({"event": "result", "agent_id": agent_id, "success": bool(success), "time": time.time()})
            self._save()
            return dict(row)

    def list_agents(self, role=None, status=None):
        with self._lock:
            rows = [dict(a) for a in self.agents.values() if (role is None or a.get("role") == role) and (status is None or a.get("status") == status)]
        rows.sort(key=lambda x: (-float(x.get("performance_score", 0)), x.get("created", 0)))
        return rows

    def remove(self, agent_id):
        return self.update(agent_id, status="REMOVED") is not None

    def status(self):
        rows = self.list_agents()
        return {"agents": rows, "count": len(rows), "active": sum(a.get("status") not in ("REMOVED", "COMPLETED") for a in rows), "roles": sorted(ROLES), "history": self.history[-20:]}

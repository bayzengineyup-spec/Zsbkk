# -*- coding: utf-8 -*-
"""
Mixium — B7: Self Repair Engine

Sistem hata bulunca durmaz: Problem Found → Root Cause Analysis →
Solution Plan → Create Checkpoint → Apply Fix → Run Test → (başarısızsa
tekrar analiz) → başarılıysa devam.

Kurallar:
- checkpoint zorunlu (fix öncesi state kaydı)
- rollback zorunlu (başarısız değişiklik korunmaz)
- max 3 repair cycle (sonsuz döngü yasak)
- her fix ChangeTracker benzeri kayda düşer (opsiyonel on_change)
"""

MAX_CYCLES = 3


class SelfRepairEngine:
    def __init__(self, root=".", checkpoint_fn=None, apply_fn=None,
                 test_fn=None, rollback_fn=None, on_change=None):
        """
        checkpoint_fn() -> state (fix öncesi)
        apply_fn(state, plan) -> True/False
        test_fn() -> bool
        rollback_fn(state) -> None
        """
        self.root = root
        self.checkpoint_fn = checkpoint_fn or (lambda: {})
        self.apply_fn = apply_fn or (lambda s, p: False)
        self.test_fn = test_fn or (lambda: False)
        self.rollback_fn = rollback_fn or (lambda s: None)
        self.on_change = on_change or (lambda record: None)
        self.history = []

    def repair(self, problem, plans=None, max_cycles=MAX_CYCLES):
        """Problem → Analiz → Checkpoint → Fix → Test → Rollback döngüsü."""
        plans = plans or [{"desc": "varsayılan düzeltme", "patch": None}]
        report = {"problem": problem, "cycles": 0, "fixed": False,
                  "rollback": False, "history": []}
        for i in range(min(max_cycles, len(plans))):
            plan = plans[i]
            report["cycles"] = i + 1
            state = self.checkpoint_fn()
            try:
                ok = self.apply_fn(state, plan)
            except Exception as e:
                ok = False
                report["history"].append({"cycle": i + 1, "status": "error",
                                          "error": str(e)[:200]})
            if not ok:
                report["history"].append({"cycle": i + 1, "status": "apply_failed"})
                continue
            try:
                tested = self.test_fn()
            except Exception as e:
                tested = False
                report["history"].append({"cycle": i + 1, "status": "test_error",
                                          "error": str(e)[:200]})
            if tested:
                report["fixed"] = True
                report["history"].append({"cycle": i + 1, "status": "fixed",
                                          "plan": plan.get("desc")})
                try:
                    self.on_change({"problem": problem, "cycle": i + 1,
                                    "plan": plan.get("desc"), "status": "fixed"})
                except Exception:
                    pass
                break
            # test başarısız → rollback + tekrar analiz
            try:
                self.rollback_fn(state)
                report["rollback"] = True
            except Exception:
                pass
            report["history"].append({"cycle": i + 1, "status": "rollback",
                                      "reason": "test_failed"})
        return report

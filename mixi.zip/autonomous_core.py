# -*- coding: utf-8 -*-
"""Mixium A23 — Autonomous Operating Loop.

Central task loop: Observe -> Understand -> Plan -> Delegate -> Execute ->
Verify -> Learn -> Improve. Each task keeps its own state machine. All real
actions are delegated through injected callbacks; this module only tracks.
"""
import json
import threading
import time
import uuid
from pathlib import Path

STATES = ("idle", "planning", "executing", "waiting", "testing", "repairing", "learning", "completed", "failed")


class AutonomousCore:
    def __init__(self, root=".", hooks=None, max_tasks=100):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "autonomous_core.json"
        self.hooks = dict(hooks or {})   # phase name -> fn(task, ctx)
        self.max_tasks = max(1, int(max_tasks))
        self._lock = threading.RLock()
        self.tasks = {}
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.tasks = d if isinstance(d, dict) else {}
        except Exception:
            self.tasks = {}

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.tasks, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def create_task(self, goal):
        goal = str(goal or "").strip()
        if not goal or len(self.tasks) >= self.max_tasks:
            return None
        tid = "task_" + uuid.uuid4().hex[:10]
        self.tasks[tid] = {"id": tid, "goal": goal[:3000], "state": "idle",
                           "phase": "observe", "steps": [], "result": None,
                           "error": "", "created": time.time(), "updated": time.time()}
        self._save()
        return self.get(tid)

    def get(self, tid):
        with self._lock:
            row = self.tasks.get(str(tid))
            return json.loads(json.dumps(row)) if row else None

    def run_cycle(self, tid, ctx=None):
        """Advance one task through the operating loop. Returns updated task."""
        task = self.get(tid)
        if not task:
            return None
        ctx = dict(ctx or {})
        ctx["task"] = task
        order = ("observe", "understand", "plan", "delegate", "execute", "verify", "learn", "improve")
        for phase in order:
            fn = self.hooks.get(phase) or self.hooks.get("default")
            if fn is None:
                continue
            try:
                out = fn(task, ctx) or {}
                if isinstance(out, dict):
                    ctx.update(out)
            except Exception as exc:
                task = self._set_state(tid, "failed", error="%s: %s" % (type(exc).__name__, exc))
                return task
        # after full cycle: learning -> completed
        return self._set_state(tid, "completed", result=ctx.get("result"))

    def _set_state(self, tid, state, result=None, error=""):
        with self._lock:
            row = self.tasks.get(str(tid))
            if not row:
                return None
            row["state"] = state
            row["updated"] = time.time()
            if result is not None:
                row["result"] = result
            if error:
                row["error"] = error
            self._save()
            return json.loads(json.dumps(row))

    def set_state(self, tid, state):
        if state not in STATES:
            return None
        return self._set_state(tid, state)

    def status(self, tid=None):
        with self._lock:
            rows = [self.tasks[str(tid)]] if tid and str(tid) in self.tasks else list(self.tasks.values()) if not tid else []
        return {"tasks": rows, "count": len(rows), "states": list(STATES), "path": str(self.path)}

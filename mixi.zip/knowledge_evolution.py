# -*- coding: utf-8 -*-
"""
Mixium — Knowledge Evolution Engine (Aşama 16B)

Mevcut bilgileri geliştirir:
- eski bilgileri analiz et
- yeni bilgiler ile karşılaştır (semantic similarity)
- duplicate temizle (eski, düşük kalite kopya süperseed edilir)
- eski bilgiyi versiyonla (silme YOK, version history korunur)
- daha iyi bilgiyle güncelle (confidence/quality eşiği)

Sınıflar:
- EvolutionRecord  : bir kaydın versiyon geçmişi
- KnowledgeEvolution: store üzerinde evolve() / history() / dedupe()

MIXIUM'a bağımlı değildir (embed/cosine episodic_memory'den).
Fail-closed: hata olursa hiçbir kayıt değişmez.
"""

import json
import threading
import time
import uuid
from pathlib import Path

from episodic_memory import embed, cosine


class KnowledgeEvolution:
    def __init__(self, root=".", store=None, max_versions=5):
        """store: DNAStore veya ExpertKnowledgeStore benzeri (add/query/rollback API)."""
        self.root = Path(root)
        self.dir = self.root / ".mixium" / "learning"
        self.store = store
        self.max_versions = max_versions
        self._lock = threading.RLock()
        self._history = {}   # record_id -> [versions]
        self._load()

    def _allowed(self, p):
        try:
            p = Path(p).resolve()
            root = self.root.resolve()
            return root in p.parents or p == root
        except Exception:
            return False

    def _load(self):
        try:
            if self._allowed(self.dir / "evolution.json"):
                with open(self.dir / "evolution.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    self._history = data
        except Exception:
            pass

    def _save(self):
        try:
            if not self._allowed(self.dir):
                return False
            self.dir.mkdir(parents=True, exist_ok=True)
            tmp = self.dir / "evolution.json.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._history, f, ensure_ascii=False, indent=1)
            tmp.replace(self.dir / "evolution.json")
            return True
        except Exception:
            return False

    # ── versiyon geçmişi ────────────────────────────────────────────
    def _push_version(self, record_id, content, meta):
        with self._lock:
            versions = self._history.setdefault(record_id, [])
            versions.append({
                "time": time.time(),
                "content": content[:4000],
                "meta": dict(meta or {}),
            })
            # eski versiyonları koru ama sınırla
            self._history[record_id] = versions[-self.max_versions:]
            self._save()

    def history(self, record_id=None, limit=50):
        if record_id:
            return list(self._history.get(record_id, []))
        out = []
        for rid, vers in self._history.items():
            for v in vers:
                out.append({"id": rid, **v})
        out.sort(key=lambda x: x.get("time", 0), reverse=True)
        return out[:limit]

    # ── evolve ──────────────────────────────────────────────────────
    def evolve(self, category, old_text, new_text, source="", confidence=70,
               quality_score=None):
        """Eski bilgiyi yeni bilgiyle karşılaştır.

        - benzerlik çok yüksekse ve yeni bilgi daha güvenilirse -> güncelle
        - benzerlik yüksek ama güven düşükse -> dokunma (poisoning koruması)
        - benzerlik düşükse -> ayrı yeni kayıt
        Dönüş: {"action": "update"|"keep"|"new", "id": ..., "similarity": float}
        """
        if self.store is None:
            return {"action": "keep", "id": None, "similarity": 0.0}
        try:
            sim = 0.0
            matches = self.store.query(new_text, top_k=1,
                                       categories=[category] if category else None,
                                       min_confidence=0)
            best = None
            if matches:
                best = matches[0]
                # query skor döndürmüyorsa similarity'yi kendin hesapla
                if best.get("score") is not None:
                    sim = float(best.get("score") or 0.0)
                else:
                    btext = best.get("content") or best.get("knowledge") or ""
                    if btext:
                        sim = cosine(embed(new_text), embed(btext))
            # güven eşiği: düşük güvenli yeni bilgi eskisini ezemez
            if confidence < 60:
                return {"action": "keep", "id": best.get("id") if best else None,
                        "similarity": sim}
            if best is not None and sim >= 0.72:
                # çok benzer -> güncelle (versiyonla)
                rid = best.get("id")
                old_text_actual = best.get("content") or best.get("knowledge") or old_text
                self._push_version(rid, old_text_actual,
                                   {"category": category, "action": "update"})
                # yeni kayıt olarak ekle (eski korunur), eskiyi süperseed et
                self.store.add(category, new_text, source=source,
                               confidence=confidence)
                return {"action": "update", "id": rid, "similarity": sim}
            if best is not None and sim >= 0.45:
                # orta benzerlik -> yeni kayıt (çelişki ihtimali, ayrı tut)
                rec2 = self.store.add(category, new_text, source=source,
                                      confidence=confidence)
                rid2 = rec2.get("id") if isinstance(rec2, dict) else rec2
                self._push_version(rid2, new_text,
                                   {"category": category, "action": "new",
                                    "related": best.get("id")})
                return {"action": "new", "id": rid2, "similarity": sim}
            # düşük benzerlik -> yeni kayıt
            rec3 = self.store.add(category, new_text, source=source,
                                  confidence=confidence)
            rid3 = rec3.get("id") if isinstance(rec3, dict) else rec3
            self._push_version(rid3, new_text,
                               {"category": category, "action": "new"})
            return {"action": "new", "id": rid3, "similarity": sim}
        except Exception as e:
            return {"action": "keep", "id": None, "similarity": 0.0,
                    "error": str(e)[:200]}

    def dedupe(self, category, threshold=0.88):
        """Kategori içinde duplicate temizle: yüksek benzer kayıtların
        düşük güvenli olanı süperseed edilir (silme yok, versiyonla)."""
        if self.store is None:
            return {"removed": 0, "checked": 0}
        try:
            records = self.store.recent(limit=500) if hasattr(self.store, "recent") else []
            # recent API yoksa query ile dolaş
            checked = 0
            removed = 0
            seen = []
            for r in records:
                text = r.get("content") or r.get("knowledge") or ""
                rid = r.get("id")
                if not text or not rid:
                    continue
                checked += 1
                ev = embed(text)
                dup = None
                for s_id, s_text, s_conf in seen:
                    if cosine(ev, s_text) >= threshold:
                        dup = (s_id, s_conf)
                        break
                if dup is not None:
                    # düşük güvenli olanı süperseed et (versiyon geçmişine ekle)
                    if r.get("confidence", 50) < dup[1]:
                        self._push_version(rid, text,
                                           {"category": category,
                                            "action": "superseded_by", "by": dup[0]})
                        removed += 1
                else:
                    seen.append((rid, ev, r.get("confidence", 50)))
            self._save()
            return {"removed": removed, "checked": checked}
        except Exception as e:
            return {"removed": 0, "checked": 0, "error": str(e)[:200]}

    def status(self):
        return {
            "record_count": len(self._history),
            "versions": sum(len(v) for v in self._history.values()),
            "max_versions": self.max_versions,
            "recent": self.history(limit=10),
        }

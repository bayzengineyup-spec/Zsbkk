# Mixium Web

Mixium'u **tarayicidan** kullan — terminal arayuzu yerine web sohbeti.
`mixium_new.py`'yi **modul olarak** yeniden kullanir: ajan dongusu, arac
sistemi, oturumlar ve model altyapisi birebir aynidir.

## Hiz neden ayni?

Araya **proxy yok**. Akis:

```
Tarayici ──WebSocket (localhost)──▶ mixiweb.py ──dogrudan──▶ Syntx API
```

- Model cagrisi yine `mixium_new.py`'deki `API` sinifiyla, ayni token
  havuzu ve ayni polling/SSE sistemiyle yapilir. Ek bir ag atlama yok.
- Web sunucusu yalnizca tarayici ile ajan arasindaki kanaldir (localhost,
  milisaniyeler). Modelin yanit hizi terminaldeki ile aynidir.

## Kurulum (Termux)

Termux'a **yeni bir sey kurmak gerekmez** — saf Python stdlib kullanir.
Sadece mevcut `requests` + `cloudscraper` (terminal surumunde zaten var).

```bash
cd ~/axio/mixium-web
bash mixiweb_baslat.sh          # 127.0.0.1:8420 + tarayici acilir
```

Alternatif:

```bash
python3 mixiweb.py --port 8420
# tarayicida: http://127.0.0.1:8420
```

**Dizin duzeni:** `mixium-web/` kendi icinde calisir; Mixium motoru
(`mixium_new.py`) bir ust klasordedir ve web onlari
oradan kullanir. Dosya araclari (read/write/bash) uste klasorde
calisir, boylece ajan proje dosyalarina erisir.

Durdurma: `Ctrl+C` veya `bash mixiweb_baslat.sh --durdur`

## Ozellikler

- **Canli akisli sohbet**: yanitlar geldikce yazilir (markdown + kod
  renklendirme)
- **Arac kartlari**: bash/read/write/grep gibi arac cagrilari kart olarak
  gorunur, ciktisi acilir/kapanir
- **Oturumlar**: soldaki listeden gecmise don, sil, yeni oturum ac
- **Model secici**: ustteki listeden 28+ model (claude, gpt, gemini, qwen,
  grok, deepseek...)
- **Izin modu**: oto-duzenleme (varsayilan) / onayli / plan / yolo —
  web'de terminal onayi yok, o yuzden varsayilan `auto`'dur
- **Kisayollar**: `/yeni`, `/model <ad>`, `/dur`

## Notlar

- Varsayilan `127.0.0.1`'e baglanir (yalnizca telefonun kendi tarayicisi).
  Yerel agdan da acmak istersen: `python3 mixiweb.py --host 0.0.0.0`
  (wifi'daki herkes erisebilir — dikkatli kullan).
- Oturumlar `~/.mixium/web_sessions/` altinda saklanir; terminal
  oturumlarindan ayridir.
- Ilk mesajda token/hesap alinir (terminalle ayni sure).

# -*- coding: utf-8 -*-
"""
Mixium — Personal Knowledge Engine (Aşama 14B)

Kullanıcı hakkında uzun süreli, ÖZETLENMİŞ bilgi (ham sohbet YOK):
    tercihler (preferences.json) + öğrenilen olgular (personal_facts.json).
Örnek kayıt: "User prefers incremental architecture with regression testing."

MIXIUM'a bağımlı değildir; yalnızca .dna/ altında fail-closed yazar.
"""

import json
import threading
import time
import uuid
from pathlib import Path


class PersonalKnowledge:
    def __init__(self, root="."):
        self.root = Path(root).expanduser().resolve()
        self.dir = self.root / ".dna"
        self.pref_path = self.dir / "preferences.json"
        self.facts_path = self.dir / "personal_facts.json"
        self.preferences = {}
        self._facts = []
        self._lock = threading.Lock()
        self._load()

    def _allowed(self, p):
        try:
            d = p.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def _load(self):
        try:
            if self.pref_path.exists():
                self.preferences = json.loads(self.pref_path.read_text("utf-8"))
        except Exception:
            self.preferences = {}
        try:
            if self.facts_path.exists():
                self._facts = json.loads(self.facts_path.read_text("utf-8"))
        except Exception:
            self._facts = []
        if not isinstance(self._facts, list):
            self._facts = []

    def _save(self):
        if not self._allowed(self.pref_path):
            return
        try:
            self.dir.mkdir(parents=True, exist_ok=True)
            self.pref_path.write_text(json.dumps(self.preferences, ensure_ascii=False),
                                      "utf-8")
            self.facts_path.write_text(json.dumps(self._facts, ensure_ascii=False),
                                       "utf-8")
        except Exception:
            pass

    # ---- API ----
    def set_preference(self, key, value):
        with self._lock:
            self.preferences[str(key)] = str(value)
            self._save()

    def get_preferences(self):
        return dict(self.preferences)

    def learn_fact(self, content, kind="note"):
        """Özetlenmiş olgu ekler (max 100, LRU)."""
        with self._lock:
            fact = {"id": uuid.uuid4().hex[:8], "kind": str(kind)[:40],
                    "content": str(content)[:2000], "ts": time.time()}
            self._facts.append(fact)
            if len(self._facts) > 100:
                self._facts = self._facts[-100:]
            self._save()
            return fact

    def facts(self, limit=20):
        return list(reversed(self._facts[-limit:]))

    def context_block(self, limit=8):
        """Ana modele enjekte edilecek [KULLANICI DNA] bloğu (boşsa '')."""
        lines = []
        if self.preferences:
            lines.append("[KULLANICI DNA]")
            for k, v in list(self.preferences.items())[:limit]:
                lines.append("- %s: %s" % (k, v))
        for f in self.facts(limit):
            lines.append("- %s" % f["content"])
        return "\n".join(lines) if lines else ""

# -*- coding: utf-8 -*-
"""
Mixium — Knowledge Quality Control (Aşama 15F)

Yanlış bilgi engelleme. Kontroller:
    - kaynak doğrulama (source zorunlu)
    - confidence threshold
    - duplicate detection (semantic benzerlik)
    - çelişki (aynı domain + yüksek benzerlik + farklı kaynak → şüpheli)

Düşük kalite bilgi -> REJECT. Reddedilenler `rejected` listesinde tutulur
(dashboard için). MIXIUM'a bağımlı değildir (store enjekte edilir).
"""

import time
import uuid

from episodic_memory import embed, cosine


class KnowledgeValidator:
    def __init__(self, store=None, min_confidence=40, dup_threshold=0.9):
        self.store = store
        self.min_confidence = min_confidence
        self.dup_threshold = dup_threshold
        self.rejected = []

    def validate(self, candidate):
        """{accepted, reason, confidence, quality_score} döndürür."""
        candidate = candidate or {}
        knowledge = str(candidate.get("knowledge", "")).strip()
        source = str(candidate.get("source", "")).strip()
        domain = str(candidate.get("domain", "advanced_coding"))
        confidence = self._num(candidate.get("confidence"), 50)
        quality = self._num(candidate.get("quality_score"), 50)

        if not knowledge:
            return self._reject(candidate, "boş bilgi")
        if not source:
            return self._reject(candidate, "kaynak doğrulama başarısız")
        if confidence < self.min_confidence:
            return self._reject(candidate, "düşük confidence (%d < %d)"
                                % (confidence, self.min_confidence))
        if quality < 30:
            return self._reject(candidate, "düşük quality_score (%d)" % quality)

        # duplicate + çelişki (store üzerinden semantic karşılaştırma)
        if self.store is not None:
            sims = self.store.similarity(knowledge, top_k=5)
            qv = embed(knowledge)
            for score, rec in sims:
                if score >= self.dup_threshold:
                    return self._reject(candidate, "duplicate: %s" % rec.get("id"))
                if (score >= 0.6 and rec.get("domain") == domain
                        and rec.get("source") and rec.get("source") != source):
                    # aynı konu + farklı kaynak + orta benzerlik → olası çelişki
                    return self._reject(candidate, "çelişki şüphesi: %s" % rec.get("id"))

        return {"accepted": True, "reason": "", "confidence": confidence,
                "quality_score": quality}

    def _reject(self, candidate, reason):
        rec = {"id": uuid.uuid4().hex[:8],
               "knowledge": str(candidate.get("knowledge", ""))[:200],
               "source": str(candidate.get("source", "")),
               "reason": reason, "ts": time.time()}
        self.rejected.append(rec)
        if len(self.rejected) > 100:
            self.rejected = self.rejected[-100:]
        return {"accepted": False, "reason": reason}

    @staticmethod
    def _num(v, default):
        try:
            return max(0, min(100, int(v)))
        except Exception:
            return default

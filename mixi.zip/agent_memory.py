# -*- coding: utf-8 -*-
"""
Mixium — Agent Persistent Memory (Aşama 11F)

Konum: .mixium/agents/memory.json (workspace içi, fail-closed).
Tutar: görev geçmişi, kullanılan çözümler, başarısız denemeler, önemli notlar.
Limit: max 100 kayıt + token sınırı + eski kayıt temizleme (LRU).

MIXIUM'a bağımlı değildir.
"""

import json
import threading
import time
import uuid
from pathlib import Path

MAX_RECORDS = 100
MAX_TOKEN_APPROX = 2000   # karakter bazlı yaklaşık bütçe (kayıt başına)


def _approx_len(s):
    return len(str(s)) // 4


class AgentMemory:
    def __init__(self, root="."):
        self.root = Path(root).expanduser().resolve()
        self.agents_dir = self.root / ".mixium" / "agents"
        self.mem_path = self.agents_dir / "memory.json"
        self.records = []
        self._lock = threading.Lock()
        self._load()

    def _allowed(self):
        try:
            d = self.agents_dir.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def _load(self):
        try:
            if self.mem_path.exists():
                self.records = json.loads(self.mem_path.read_text("utf-8"))
        except Exception:
            self.records = []

    def _save(self):
        if not self._allowed():
            return
        try:
            self.agents_dir.mkdir(parents=True, exist_ok=True)
            self.mem_path.write_text(json.dumps(self.records, ensure_ascii=False),
                                     "utf-8")
        except Exception:
            pass

    def add(self, role, text, kind="note", meta=None):
        with self._lock:
            text = str(text)[:MAX_TOKEN_APPROX * 4]
            rec = {
                "id": uuid.uuid4().hex[:8],
                "role": role,
                "kind": kind,          # note / solution / failure / task
                "text": text,
                "meta": meta or {},
                "ts": time.time(),
            }
            self.records.append(rec)
            # eski kayıt temizleme (LRU: en eski önce)
            if len(self.records) > MAX_RECORDS:
                self.records = self.records[-MAX_RECORDS:]
            self._save()
            return rec

    def history(self, role=None, limit=20):
        with self._lock:
            recs = [r for r in self.records if role is None or r["role"] == role]
            return list(recs[-limit:])

    def recall(self, role=None, query=None, limit=5):
        """Anahtar kelime araması (basit substring)."""
        q = (query or "").lower()
        recs = self.history(role=role, limit=MAX_RECORDS)
        if q:
            recs = [r for r in recs if q in r["text"].lower()
                    or q in json.dumps(r.get("meta", {}), ensure_ascii=False).lower()]
        return list(reversed(recs))[:limit]

    def summary(self, role=None):
        recs = self.history(role=role, limit=20)
        if not recs:
            return "agent hafızası boş"
        lines = []
        for r in recs:
            lines.append("[%s] %s: %s" % (r["role"], r["kind"], r["text"][:80]))
        return "AGENT HAFIZASI:\n" + "\n".join(lines)

    def clear(self):
        with self._lock:
            self.records = []
            self._save()

# -*- coding: utf-8 -*-
"""Mixium A24D — Logic Critic Engine.

Bir cevabı kalite açısından analiz eder: mantık hatası, çelişki, eksik cevap,
yanlış araç kullanımı, gereksiz işlem, kötü planlama, düşük kalite kod, yanlış
varsayım. Her tespit için tür/önem/açıklama/öneri üretir. Model zekasını
kısıtlamaz; yalnızca üretilmiş cevabı değerlendirir.
"""

SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3}


class LogicCritic:
    # (anahtar kelimeler, tür, önem, öneri) kuralları — deterministik ve şeffaf
    RULES = [
        (["her zaman", "asla", "kesinlikle doğru", "garanti"],
         "absolutism", "medium", "Mutlak ifadeler yerine koşullu/kanıtlı ifade kullan."),
        (["TODO", "FIXME", "??", "belirsiz", "emin değilim"],
         "incomplete", "medium", "Eksik/şüpheli kısımları tamamla veya açıkça işaretle."),
        (["daha önce söylediğim", "önceki", "yukarıda"],
         "contradiction_risk", "low", "Önceki ifadeyle tutarlılığı doğrula."),
        (["bu yüzden varsay", "varsayıyorum", "muhtemelen öyle"],
         "assumption", "low", "Varsayımı açıkça belirt; doğrulanmamışsa işaretle."),
    ]

    def __init__(self, rules=None):
        self.rules = list(rules or self.RULES)

    def analyze(self, question, answer, context=None):
        findings = []
        text = str(answer or "")
        for keywords, ftype, severity, suggestion in self.rules:
            hits = [k for k in keywords if k.lower() in text.lower()]
            if hits:
                findings.append({"type": ftype, "severity": severity,
                                 "matched": hits, "description": "kalıp tespit edildi",
                                 "suggestion": suggestion})
        # boş cevap
        if not text.strip():
            findings.append({"type": "empty", "severity": "high",
                             "description": "cevap boş", "suggestion": "anlamlı cevap üret."})
        # çelişki: hem "evet" hem "hayır" cümle başı
        low = text.lower()
        if " ancak " in low or " fakat " in low:
            findings.append({"type": "contradiction_risk", "severity": "low",
                             "description": "çelişki olasılığı (ama/fakat)", "suggestion": "iki tarafı netleştir."})
        findings.sort(key=lambda f: SEVERITY_ORDER.get(f.get("severity"), 0), reverse=True)
        score = self.score(findings)
        return {"findings": findings, "quality_score": score,
                "summary": "%d bulgu" % len(findings)}

    @staticmethod
    def score(findings):
        weights = {"info": 0, "low": 1, "medium": 3, "high": 5}
        penalty = min(40, sum(weights.get(f.get("severity"), 0) for f in findings))
        return max(0, 100 - penalty)

    def status(self):
        return {"rules": len(self.rules)}

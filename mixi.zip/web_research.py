# -*- coding: utf-8 -*-
"""
Mixium — B4: Advanced Web Research Engine

Gerçek araştırmacı sistemi. Browser Agent (Playwright + MCP) ile web
sitelerini açar, doküman okur, GitHub inceler, karşılaştırma yapar.

Akış: Question → Search → Collect Sources → Read → Compare →
      Extract Knowledge → Validate → Store

MIXIUM'a bağımlı değildir; search_fn / browser_fn / validator / store
enjekte edilir. Fail-closed: hata → HATA, sistem düşmez.
"""

import time

MAX_SOURCES = 6
READ_TIMEOUT = 20


class WebResearch:
    def __init__(self, search_fn=None, browser_fn=None, validator=None,
                 store=None, on_knowledge=None):
        self.search_fn = search_fn or (lambda q: [])
        self.browser_fn = browser_fn or (lambda a, args: "HATA: browser yok")
        self.validator = validator or (lambda text, source: 0.6)
        self.store = store
        self.on_knowledge = on_knowledge

    def research(self, question, max_sources=MAX_SOURCES):
        """Question → Search → Collect → Read → Extract → Validate → Store."""
        results = {"question": question, "sources": [], "knowledge": [],
                   "confidence": 0.0, "error": None}
        try:
            hits = self.search_fn(question) or []
            collected = []
            for h in hits[:max_sources]:
                url = h.get("url") if isinstance(h, dict) else str(h)
                title = h.get("title", url) if isinstance(h, dict) else url
                text = self._read(url)
                collected.append({"url": url, "title": title, "text": text})
                results["sources"].append({"url": url, "title": title,
                                           "read": bool(text)})
            if not collected:
                results["error"] = "kaynak bulunamadı"
                return results
            # Extract + Validate
            for c in collected:
                text = c.get("text") or ""
                if not text:
                    continue
                conf = self.validator(text, c["url"])
                if conf >= 0.5:
                    k = {"knowledge": self._summarize(text),
                         "source": c["url"], "title": c["title"],
                         "confidence": conf}
                    results["knowledge"].append(k)
                    if self.on_knowledge:
                        try:
                            self.on_knowledge(k)
                        except Exception:
                            pass
                    if self.store is not None:
                        try:
                            self.store.add(category="research", content=k["knowledge"],
                                           source=c["url"], confidence=conf)
                        except Exception:
                            pass
            results["confidence"] = self._confidence(results)
            return results
        except Exception as e:
            results["error"] = str(e)[:300]
            return results

    def _read(self, url):
        """Browser üzerinden içerik oku (navigate + extract)."""
        nav = self.browser_fn("navigate", {"url": url})
        if str(nav).startswith("HATA"):
            return ""
        txt = self.browser_fn("extract_text", {})
        if str(txt).startswith("HATA"):
            return ""
        return str(txt)[:4000]

    @staticmethod
    def _summarize(text):
        """Basit özet: ilk anlamlı cümleler (LLM değil, token dostu)."""
        t = (text or "").strip()
        if not t:
            return ""
        parts = [p.strip() for p in t.split("\n") if p.strip()]
        keep = []
        for p in parts:
            if len(p) > 40 and not p.startswith("###"):
                keep.append(p)
            if len(keep) >= 3:
                break
        return " ".join(keep)[:600] or t[:300]

    @staticmethod
    def _confidence(results):
        if not results["sources"]:
            return 0.0
        read = sum(1 for s in results["sources"] if s.get("read"))
        confs = [k.get("confidence", 0) for k in results["knowledge"]]
        base = read / len(results["sources"])
        avg = (sum(confs) / len(confs)) if confs else 0.0
        return round(base * 0.4 + avg * 0.6, 2)

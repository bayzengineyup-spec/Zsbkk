# -*- coding: utf-8 -*-
"""Mixium A25A — Autonomous Fix Engine.

Bug Hunter tarafından bulunan sorunları gerçek düzeltme zincirine bağlar:
bug → root cause → dosya analizi → fix planı → checkpoint → CodeEditor değişikliği
→ test → health kontrol → başarılıysa kabul, başarısızsa rollback → yeni çözüm.

Mevcut code_editor.CodeEditor, change_tracker.ChangeTracker, debug_loop.DebugLoop,
project_health.ProjectHealth ve self_repair.SelfRepairEngine yeniden yazılmaz;
bu modül onları enjekte edilen bağımlılıklar üzerinden sarmalar. Güvenlik zinciri
(Permission → hard_gate → approval → checkpoint → rollback) DEĞİŞMEZ.
"""

import time

MAX_CYCLES = 3


class AutonomousFixEngine:
    def __init__(self, editor, test_fn, health_fn=None, change_record_fn=None,
                 max_cycles=MAX_CYCLES):
        """
        editor            : code_editor.CodeEditor (replace_block/insert_*/apply_patch/rollback_change)
        test_fn()         : -> {"passed","failed","errors","summary"}
        health_fn(test)   : -> {"health_score","errors","warnings","recommendations"}
        change_record_fn  : opsiyonel geçmiş kaydı (rec -> None)
        """
        self.editor = editor
        self.test_fn = test_fn
        self.health_fn = health_fn or (lambda t: {"health_score": 50, "errors": [], "warnings": [], "recommendations": []})
        self.change_record_fn = change_record_fn or (lambda rec: None)
        self.max_cycles = max_cycles
        self.history = []

    def _snapshot(self, path):
        """Checkpoint: dosyanın mevcut içeriğini oku (okunamıyorsa None)."""
        try:
            import pathlib
            p = pathlib.Path(str(path))
            if not p.is_absolute():
                p = self.editor.root / p if hasattr(self.editor, "root") else p
            return str(p), p.read_text("utf-8") if p.exists() else None
        except Exception:
            return str(path), None

    def _apply(self, plan):
        op = (plan or {}).get("operation", "replace_block")
        path = (plan or {}).get("file")
        if op == "replace_block":
            return self.editor.replace_block(path, plan["old"], plan["new"],
                                             plan.get("occurrence", 0))
        if op == "insert_after":
            return self.editor.insert_after(path, plan["anchor"], plan["text"])
        if op == "insert_before":
            return self.editor.insert_before(path, plan["anchor"], plan["text"])
        if op == "apply_patch":
            return self.editor.apply_patch(path, plan["diff"])
        return {"ok": False, "diff": "", "error": "bilinmeyen operation: %s" % op}

    def _rollback(self, path):
        try:
            return self.editor.rollback_change(path)
        except Exception as e:
            return {"ok": False, "error": str(e)[:200]}

    def attempt(self, plan):
        """Tek fix planı: checkpoint → apply → test → health → kabul/rollback."""
        path = (plan or {}).get("file")
        rec = {"plan": plan, "started": time.time(), "status": "pending"}
        cp = self._snapshot(path)
        try:
            applied = self._apply(plan)
        except Exception as e:
            rec["status"] = "apply_error"
            rec["error"] = str(e)[:200]
            self._record(rec)
            return rec
        if not (applied and applied.get("ok")):
            rec["status"] = "apply_failed"
            rec["apply"] = applied
            self._record(rec)
            return rec
        rec["apply"] = {"ok": True, "diff_len": len(applied.get("diff", ""))}
        # test
        try:
            test = self.test_fn()
        except Exception as e:
            test = {"failed": 1, "errors": 1, "summary": str(e)[:200]}
        rec["test"] = test
        # health
        try:
            health = self.health_fn(test)
        except Exception as e:
            health = {"health_score": 0, "errors": [str(e)[:200]]}
        rec["health"] = health
        ok = not (test.get("failed") or test.get("errors")) and health.get("health_score", 0) >= 50
        if ok:
            rec["status"] = "accepted"
        else:
            # rollback
            rb = self._rollback(path)
            rec["status"] = "rolled_back"
            rec["rollback"] = rb
        self._record(rec)
        return rec

    def run(self, findings, max_cycles=None):
        """findings: [ {cause, plan} ] — her biri için attempt döngüsü."""
        max_cycles = max_cycles or self.max_cycles
        out = {"cycles": 0, "accepted": 0, "rolled_back": 0, "records": []}
        for i, f in enumerate((findings or [])[:max_cycles]):
            out["cycles"] = i + 1
            rec = self.attempt(f.get("plan") or f)
            out["records"].append(rec)
            if rec.get("status") == "accepted":
                out["accepted"] += 1
            elif rec.get("status") == "rolled_back":
                out["rolled_back"] += 1
        return out

    def _record(self, rec):
        try:
            self.change_record_fn(rec)
        except Exception:
            pass
        self.history.append(rec)

    def status(self):
        return {"history": self.history[-20:], "count": len(self.history)}

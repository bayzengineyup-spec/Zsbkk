# -*- coding: utf-8 -*-
"""Mixium A28 — Autonomous Night Research Evolution (Deep Learning Worker).

Arka planda: yeni teknolojileri araştır, yazılım mimarilerini incele, kaliteli
açık kaynak projeleri analiz et, uzman yöntemlerini öğren, pattern çıkar.
Kod kopyalama YOK; prensip öğrenme VAR. Araştırma/prensip çıkarımı enjekte
edilir; yoksa fail-closed.
"""

import time


class DeepLearningWorker:
    def __init__(self, research_fn=None, extract_fn=None, store_fn=None):
        self.research_fn = research_fn      # (topic) -> [{text, source}]
        self.extract_fn = extract_fn        # (text) -> [principles]
        self.store_fn = store_fn            # (principle) -> record
        self.history = []

    def run(self, topics=None, max_topics=5):
        """Araştır → prensip çıkar → kaydet (kod kopyalama yok)."""
        topics = list(topics or [])
        out = {"topics": 0, "principles": 0, "records": []}
        if self.research_fn is None:
            out["status"] = "unavailable"
            self.history.append(out)
            return out
        for topic in topics[:max_topics]:
            try:
                sources = self.research_fn(topic) or []
            except Exception as e:
                sources = [{"text": "", "source": "error", "error": str(e)[:120]}]
            for s in sources:
                text = s.get("text") if isinstance(s, dict) else str(s)
                principles = []
                if self.extract_fn is not None and text:
                    try:
                        principles = self.extract_fn(text) or []
                    except Exception:
                        principles = []
                for p in principles:
                    rec = {"topic": topic, "principle": p,
                           "source": s.get("source") if isinstance(s, dict) else "?"}
                    if self.store_fn is not None:
                        try:
                            self.store_fn(p)
                        except Exception:
                            pass
                    out["records"].append(rec)
                    out["principles"] += 1
            out["topics"] += 1
        self.history.append(out)
        return out

    def status(self):
        return {"runs": len(self.history), "last": self.history[-1] if self.history else None,
                "available": self.research_fn is not None}

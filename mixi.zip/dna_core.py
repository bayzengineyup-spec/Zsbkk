# -*- coding: utf-8 -*-
"""
Mixium — DNA Intelligence Core (Aşama 14A)

Kategorili bilgi deposu + semantic retrieval. Kategoriler:
    coding / communication / reasoning / strategy / research / security /
    preferences / mistakes / solutions  (her biri ayrı depo dosyası).

Kayıt: {id, category, content, source, confidence, created, updated, embedding}.
Retrieval: episodic_memory.embed + cosine (ağır vector DB YOK). Rollback
(yanlış öğrenme geri alınabilir) + confidence eşiği (memory poisoning koruması).

MIXIUM'a bağımlı değildir (embed/cosine episodic_memory'den yeniden kullanılır).
"""

import json
import threading
import time
import uuid
from pathlib import Path

from episodic_memory import embed, cosine

CATEGORIES = ("coding", "communication", "reasoning", "strategy", "research",
              "security", "preferences", "mistakes", "solutions")


class DNAStore:
    def __init__(self, root="."):
        self.root = Path(root).expanduser().resolve()
        self.dna_dir = self.root / ".dna"
        self.records = {}   # category -> [rec]
        self._lock = threading.Lock()
        self._load()

    # ---- persist (fail-closed) ----
    def _allowed(self, p):
        try:
            d = p.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def _cat_path(self, category):
        return self.dna_dir / (category + ".json")

    def _load(self):
        self.records = {c: [] for c in CATEGORIES}
        if not self.dna_dir.exists():
            return
        for c in CATEGORIES:
            p = self._cat_path(c)
            try:
                if p.exists():
                    data = json.loads(p.read_text("utf-8"))
                    self.records[c] = data if isinstance(data, list) else []
            except Exception:
                self.records[c] = []

    def _save_cat(self, category):
        if not self._allowed(self._cat_path(category)):
            return
        try:
            self.dna_dir.mkdir(parents=True, exist_ok=True)
            self._cat_path(category).write_text(
                json.dumps(self.records.get(category, []), ensure_ascii=False),
                "utf-8")
        except Exception:
            pass

    # ---- API ----
    def add(self, category, content, source="", confidence=50):
        category = category if category in CATEGORIES else "coding"
        content = str(content)[:8000]
        with self._lock:
            rec = {"id": uuid.uuid4().hex[:8],
                   "category": category,
                   "content": content,
                   "source": str(source)[:300],
                   "confidence": max(0, min(100, int(confidence))),
                   "created": time.time(), "updated": time.time(),
                   "embedding": [[int(i), float(x)]
                                 for i, x in embed(content).items()]}
            self.records[category].append(rec)
            self._save_cat(category)
            return rec

    def query(self, text, top_k=8, categories=None, min_confidence=0):
        """Semantic retrieval: cosine skoruna göre en yakın kayıtlar."""
        qv = embed(text)
        cats = [c for c in (categories or []) if c in CATEGORIES] or list(CATEGORIES)
        scored = []
        with self._lock:
            for c in cats:
                for r in self.records.get(c, []):
                    if r.get("confidence", 0) < min_confidence:
                        continue
                    e = {int(i): float(x) for i, x in (r.get("embedding") or [])}
                    scored.append((cosine(qv, e), r))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [r for s, r in scored[:max(1, min(50, top_k))] if s > 0]

    def rollback(self, record_id):
        """Bir kaydı siler (yanlış öğrenme geri alınır)."""
        with self._lock:
            for c in list(self.records):
                before = len(self.records[c])
                self.records[c] = [r for r in self.records[c]
                                   if r.get("id") != record_id]
                if len(self.records[c]) != before:
                    self._save_cat(c)
                    return True
        return False

    def categories(self):
        return {c: len(self.records.get(c, [])) for c in CATEGORIES}

    def count(self):
        return sum(len(v) for v in self.records.values())

    def recent(self, limit=20):
        allr = [r for v in self.records.values() for r in v]
        allr.sort(key=lambda r: r.get("created", 0), reverse=True)
        return allr[:limit]

    def context_block(self, query, top_k=8, min_confidence=0):
        """Ana modele enjekte edilecek [DNA BAĞLAM] bloğu (boşsa '')."""
        hits = self.query(query, top_k=top_k, min_confidence=min_confidence)
        if not hits:
            return ""
        lines = ["[DNA BAĞLAM]"]
        for r in hits:
            lines.append("- [%s] %s" % (r["category"], r["content"][:200]))
        return "\n".join(lines)

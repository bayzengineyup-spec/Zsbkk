"""Minimal patch based file editing helpers."""
from pathlib import Path

def replace_section(file_path, old, new):
    p = Path(file_path)
    text = p.read_text(encoding="utf-8")
    if old not in text:
        raise ValueError("Target section not found")
    p.write_text(text.replace(old, new, 1), encoding="utf-8")
    return True

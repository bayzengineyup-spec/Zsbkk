# -*- coding: utf-8 -*-
"""Mixium A24H — Human Quality Score.

Mixium kalitesini 0-100 aralığında ölçer. Skorlar: zeka, doğruluk, kod
kalitesi, planlama, araç kullanımı, hız, kullanıcı deneyimi, hata oranı.
Sinyaller enjekte edilir; hiçbir sinyal "uydurulmaz" — yoksa 50 (nötr) döner.
"""

DIMENSIONS = ("intelligence", "accuracy", "code_quality", "planning",
              "tool_usage", "speed", "ux", "error_rate")

# error_rate ters çevrilir: yüksek hata oranı düşük skor demektir
INVERTED = {"error_rate"}


class HumanQualityScore:
    def __init__(self, signals=None):
        self.signals = dict(signals or {})

    def _value(self, dim):
        fn = self.signals.get(dim)
        if fn is None:
            return None
        try:
            v = fn() if callable(fn) else fn
            if v is None:
                return None
            v = float(v)
            return max(0.0, min(100.0, v))
        except Exception:
            return None

    def score(self):
        dims = {}
        known = 0
        total = 0.0
        for dim in DIMENSIONS:
            v = self._value(dim)
            if v is None:
                dims[dim] = None
                continue
            if dim in INVERTED:
                v = 100.0 - v
            dims[dim] = round(v, 1)
            known += 1
            total += v
        overall = round(total / known, 1) if known else 50.0
        return {"overall": overall, "dimensions": dims,
                "known": known, "missing": [d for d in DIMENSIONS if dims[d] is None]}

    def status(self):
        return self.score()

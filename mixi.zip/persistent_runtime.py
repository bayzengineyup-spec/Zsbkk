# -*- coding: utf-8 -*-
"""Mixium A29 — Persistent Runtime (Kalıcı görev çalışma sistemi).

Uzun görevler, görev devam ettirme, restart sonrası devam, checkpoint, progress
tracking ve state recovery. Durumlar: CREATED, PLANNING, RUNNING, PAUSED,
FAILED, RECOVERING, COMPLETED. State `.mixium/persistent_runtime.json` altında
workspace-sınırlı saklanır; hiçbir güvenlik çekirdeği değiştirilmez.
"""

import json
import threading
import time
import uuid
from pathlib import Path

STATES = ("CREATED", "PLANNING", "RUNNING", "PAUSED",
          "FAILED", "RECOVERING", "COMPLETED")


class PersistentRuntime:
    def __init__(self, root=".", max_tasks=100):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "persistent_runtime.json"
        self.max_tasks = max(1, int(max_tasks))
        self._lock = threading.RLock()
        self.tasks = {}
        self._load()

    # ── persistence (workspace-sınırlı, fail-closed) ──────────────────
    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.tasks = d if isinstance(d, dict) else {}
        except Exception:
            self.tasks = {}

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.tasks, ensure_ascii=False, indent=1),
                           encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def _row(self, tid):
        return self.tasks.get(str(tid))

    def _touch(self, row):
        row["updated"] = time.time()
        self._save()

    # ── lifecycle ─────────────────────────────────────────────────────
    def start(self, goal):
        if not str(goal or "").strip():
            return None
        with self._lock:
            if len(self.tasks) >= self.max_tasks:
                return None
            tid = "rt_" + uuid.uuid4().hex[:10]
            self.tasks[tid] = {
                "id": tid, "goal": str(goal)[:2000], "state": "CREATED",
                "steps": [], "checkpoint": {}, "progress": 0, "error": "",
                "created": time.time(), "updated": time.time(), "history": [],
            }
            self._save()
            return dict(self.tasks[tid])

    def plan(self, tid, steps):
        row = self._row(tid)
        if not row:
            return None
        with self._lock:
            row["steps"] = list(steps or [])
            row["state"] = "PLANNING"
            row["history"].append({"event": "planned", "t": time.time()})
            self._touch(row)
        return dict(row)

    def run(self, tid):
        row = self._row(tid)
        if not row:
            return None
        with self._lock:
            row["state"] = "RUNNING"
            row["history"].append({"event": "run", "t": time.time()})
            self._touch(row)
        return dict(row)

    def pause(self, tid):
        row = self._row(tid)
        if not row:
            return None
        with self._lock:
            row["state"] = "PAUSED"
            row["history"].append({"event": "paused", "t": time.time()})
            self._touch(row)
        return dict(row)

    def resume(self, tid):
        row = self._row(tid)
        if not row:
            return None
        with self._lock:
            row["state"] = "RUNNING"
            row["history"].append({"event": "resumed", "t": time.time()})
            self._touch(row)
        return dict(row)

    def checkpoint(self, tid, data=None):
        row = self._row(tid)
        if not row:
            return None
        with self._lock:
            if data is not None:
                row["checkpoint"] = data
            row["history"].append({"event": "checkpoint", "t": time.time()})
            self._touch(row)
        return dict(row)

    def progress(self, tid, pct):
        row = self._row(tid)
        if not row:
            return None
        with self._lock:
            row["progress"] = min(100, max(0, int(pct)))
            if row["progress"] >= 100:
                row["state"] = "COMPLETED"
                row["history"].append({"event": "completed", "t": time.time()})
            self._touch(row)
        return dict(row)

    def fail(self, tid, error):
        row = self._row(tid)
        if not row:
            return None
        with self._lock:
            row["state"] = "FAILED"
            row["error"] = str(error)[:300]
            row["history"].append({"event": "failed", "t": time.time()})
            self._touch(row)
        return dict(row)

    def recover(self):
        """Restart sonrası: takılı kalmış RUNNING/PLANNING/PAUSED görevleri RECOVERING'e al."""
        with self._lock:
            recovered = 0
            for row in self.tasks.values():
                if row.get("state") in ("RUNNING", "PLANNING", "PAUSED"):
                    stale = time.time() - row.get("updated", 0) > 900
                    if stale:
                        row["state"] = "RECOVERING"
                        row["history"].append({"event": "recovering", "t": time.time()})
                        recovered += 1
            self._save()
        return {"recovered": recovered, "tasks": len(self.tasks)}

    def status(self, tid=None):
        with self._lock:
            if tid:
                return dict(self.tasks.get(str(tid)) or {})
            rows = list(self.tasks.values())
        active = [r["id"] for r in rows if r["state"] in ("RUNNING", "PLANNING", "RECOVERING")]
        return {"tasks": rows[-50:], "count": len(rows), "active": active,
                "states": {s: sum(1 for r in rows if r["state"] == s) for s in STATES}}

# -*- coding: utf-8 -*-
"""
Mixium — Autonomous Debug Loop (Aşama 12C)

Observe -> Detect error -> Analyze -> Plan -> Generate fix -> code_editor patch
-> Run test -> Verify. Max 3 repair cycle (ReflectionLoop mantığı). Crash -> FAILED.

MIXIUM'a bağımlı değildir; `test_fn`, `fix_fn`, `analyze_fn` enjekte edilir.
- test_fn() -> {"passed": int, "failed": int, "errors": int, "summary": str}
- analyze_fn(error) -> dict (sebep + öneri)  [opsiyonel]
- fix_fn(analysis, iteration) -> {"ok": bool, "diff": str}  [code_editor patch]
"""

MAX_REPAIR = 3


class DebugLoop:
    def __init__(self, test_fn, fix_fn, analyze_fn=None, max_repair=MAX_REPAIR):
        self.test_fn = test_fn
        self.fix_fn = fix_fn
        self.analyze_fn = analyze_fn
        self.max_repair = max_repair
        self.history = []

    def run(self):
        """Döngüyü çalıştırır; {"status", "repairs", "history", "final_test"} döner."""
        status = "OK"
        for i in range(1, self.max_repair + 1):
            try:
                test = self.test_fn()
            except Exception as e:
                self.history.append({"step": "test", "iteration": i,
                                     "error": str(e)})
                return {"status": "FAILED", "repairs": i - 1,
                        "history": self.history, "final_test": None}
            self.history.append({"step": "test", "iteration": i, "test": test})
            if not (test.get("failed") or test.get("errors")):
                return {"status": "OK", "repairs": i - 1,
                        "history": self.history, "final_test": test}
            # hata var -> analiz + düzelt
            if self.analyze_fn:
                analysis = self.analyze_fn(test)
            else:
                analysis = {"cause": test.get("summary", "test hatası")}
            self.history.append({"step": "analyze", "iteration": i,
                                 "analysis": analysis})
            try:
                fix = self.fix_fn(analysis, i)
            except Exception as e:
                self.history.append({"step": "fix", "iteration": i,
                                     "error": str(e)})
                return {"status": "FAILED", "repairs": i - 1,
                        "history": self.history, "final_test": test}
            self.history.append({"step": "fix", "iteration": i, "fix": fix})
            if not fix.get("ok"):
                return {"status": "FAILED", "repairs": i - 1,
                        "history": self.history, "final_test": test}
        # max repair aşıldı
        return {"status": "ITERATION_LIMIT", "repairs": self.max_repair,
                "history": self.history,
                "final_test": self.history[-1].get("test")}

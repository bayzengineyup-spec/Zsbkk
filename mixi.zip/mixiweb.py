#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mixium Web  —  Mixium'u tarayicidan kullan.
============================================
mixium_new.py'yi MODUL olarak yeniden kullanir: Agent / API / Session /
TokenManager ayni kalir, model hizi degismez. Araya proxy girmez;
tarayici -> (localhost websocket) -> mixiweb -> dogrudan Syntx API.

  · Saf Python stdlib  ->  Termux'ta ek paket kurmaya gerek yok
  · Tarayici ac:  http://127.0.0.1:8420
  · Konusma, araclar (bash/read/write/...), oturumlar, model secimi

Calistirma:
    python3 mixiweb.py                 # 127.0.0.1:8420
    python3 mixiweb.py --port 9000
    python3 mixiweb.py --host 0.0.0.0  # yerel agdan da erisim (dikkat)
"""

import os
import re
import sys
import json
import queue
import base64
import shutil
import uuid
import hashlib
import asyncio
import threading
import mimetypes
import io
import zipfile
from pathlib import Path

# Gercek stdout'u modul yuklenirken (herhangi bir agent thread'i sys.stdout'u
# sink ile degistirmeden ONCE) sabitliyoruz. mixium_new.py agent'i "out()"
# yazdirdiginda calisan thread, calisirken sys.stdout'u GLOBAL olarak sink'e
# cevirir (thread-local degil — Python'da sys.stdout tum interpreter icin
# tek bir global). O sirada baska bir istemci baglanip asagidaki gibi ham
# print(...) debug satirlari calisirsa, bunlar yanlislikla o anki agent
# calismasinin sohbet kuyruguna sizip kullanicinin sohbetinde "[WS] istemci
# baglandi" gibi alakasiz satirlar olarak belirip sonra (gecmis yeniden
# yuklendiginde) kayboluyordu. Debug loglari bu yuzden HER ZAMAN gercek
# konsol stdout'una yazilmali, o an sys.stdout neye esitse ona degil.
_REAL_STDOUT = sys.stdout


def _log(*args):
    """Sunucu konsoluna guvenli debug/log yazimi — sys.stdout ne olursa
    olsun (agent calisirken sink'e donusmus olsa bile) daima gercek
    terminale gider, asla bir istemcinin sohbet akisina sizmaz."""
    try:
        _REAL_STDOUT.write(" ".join(str(a) for a in args) + "\n")
        _REAL_STDOUT.flush()
    except Exception:
        pass


# ── Mixium motoru (UST KLASORDE: mixium_new.py) ───────
# mixium-web/ kendi icinde calisir; motor dosyalari bir ust klasorde
# durur. Data (token/oturum) ~/.mixium ortaktir — hiz degismez.
_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE.parent))
import mixium_new as M  # noqa: E402
sys.path.insert(0, str(_HERE))
import panel as PANEL  # noqa: E402  (yonetim paneli arka ucu)

APP = "Mixium Web"
PORT = int(os.environ.get("MIXWEB_PORT", os.environ.get("PORT", 8420)))
HOST = os.environ.get("MIXWEB_HOST", "127.0.0.1")
WEB_DIR = _HERE / "web"
INDEX = WEB_DIR / "index.html"

# Web modu: terminal cikti yerine akis. Renk/yazi-animasyonu kapali,
# Unicode acik (markdown/emojiler icin), genislik sabit.
M.Term.is_tty = False
M.Term.no_color = True
M.Term.width = lambda: 110
M.CONF["mascot_style"] = "off"
M.CONF["mascot"] = False
M.CONF["anim"] = False
# Web'de terminal onayi yok: varsayilan "auto" (dosya duzenlemeleri
# otomatik, kabuk komutlari izin sistemiyle). Kullanici arayuzden
# ask/plan/yolo'ya gecirebilir. CONF'ta acikca secilmis farkli bir
# mod yoksa "auto" kullan.
_saved_mode = M.CONF.get("mode")
# Filtresiz mod — site sahibi kendi kullanımı için
M.PERM.mode = "yolo" if _saved_mode in (None, "ask", "auto") else _saved_mode

# DNA model yöneticisini başlat (Aşama 14F)
try:
    from model_dna import DNAModelManager
    M._model_dna_mgr = DNAModelManager(root=str(M.DATA_DIR))
except Exception:
    M._model_dna_mgr = None

# DNA Store'u başlat (Aşama 14A)
try:
    from dna_core import DNAStore
    M._dna_store = DNAStore(root=str(M.DATA_DIR))
except Exception:
    M._dna_store = None

WEB_CHAT_DIR = M.DATA_DIR / "web_sessions"
WEB_CHAT_DIR.mkdir(parents=True, exist_ok=True)

# ── Tek calisan ajan (cakisma olmasin) ────────────────────────────────
# _lock: birden fazla sekme ayni anda mesaj gonderirse sink/stdout
# yonlendirmesi birbirini ezer; bu yuzden ajan tek seferde bir calisir.
_run_lock = threading.Lock()


# ── cikti yakalama: out() + sys.stdout tek kuyruga ─────────────────────
# Statu/spinner satirlari — sohbete sizmasin. Web'de Term.is_tty=False
# oldugu icin spinner tek satir '⠋ Dusunuyor • · ·' biciminde out()'a
# yazar; bunlar tarayicida asistan metni gibi gorunurdu.
_STATUS_WORDS = ("Dusunuyor", "Planliyor", "Isliyor", "Cozumluyor",
                 "Kuruyor", "Derliyor", "Tariyor", "Birlestiriyor",
                 "Dokuyor", "Hesapliyor", "Kollarini uzatiyor",
                 "Derine iniyor", "Izini suruyor", "Calistiriyor",
                 "Okuyor", "Yaziyor", "Duzenliyor", "Yamaliyor",
                 "Ariyor", "Geziyor", "Getiriyor", "Hatirliyor",
                 "Listeliyor", "Bakiyor")
_STATUS_RE = re.compile(r"^\s*(?:\d+(?:\.\d+)?s\s*(?:·\s*\d+ arac)?\s*)$")


class _Sink:
    """out() ve ham stdout yazimlarini toplar; statu satirlarini eler."""

    def __init__(self, q):
        self.q = q
        self.buf = ""

    def _ok(self, line):
        s = line.strip()
        if not s:
            return False
        # Sayısal zaman satırları: "1.2s" veya "1.2s · 3 araç"
        if _STATUS_RE.match(s):
            return False
        # ANSI kaçış dizisi
        if s.startswith("\x1b[") or "\x1b[" in s[:8]:
            return False
        # Spinner karakterleri (⠋⠙⠹...) — sadece bu karakterlerle başlıyorsa
        if s and s[0] in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏":
            return False
        # Spinner metni: "Dusunuyor • · ·" — SPINNER KELİMESİ + nokta birlikte
        # NOT: Sadece " • " yeterli DEĞİL — markdown listelerde "• " veya " • " çok geçer!
        # Yalnızca bilinen spinner kelimelerinin ardından gelen • örüntüsünü filtrele.
        for sw in _STATUS_WORDS:
            if sw in s and ("• · ·" in s or "· · ·" in s):
                return False
        # ⏵ ▸ » gibi araç yönlendirme sembolleri (satır başında)
        if s.startswith(("⏵", "▸", "»")):
            return False
        return True

    def _is_status_prefix(self, s):
        """Henüz tamamlanmamış spinner/statu öneki mi?"""
        stripped = s.lstrip()
        if not stripped:
            return True
        # spinner glifleri
        if stripped[0] in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏":
            return True
        # Araç yönlendirme (satır başında)
        if stripped.startswith(("⏵", "▸", "»")):
            return True
        # ANSI
        if stripped.startswith("\x1b["):
            return True
        return False

    def push(self, s):
        try:
            _t = str(s)
            if _t.lstrip().startswith(("⏵", "▸", "»", "$")) or \
               ("(" in _t and _t.strip().endswith(")")):
                PANEL.bump("tool_calls")
                PANEL.log("debug", "tool", _t.strip()[:180])
        except Exception:
            pass
        if not s:
            return
        self.buf += s
        # Tamamlanmış satırları işle
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            line = line.rstrip("\r")
            if self._ok(line):
                self.q.put(("out", line + "\n"))
        # Gerçek canlı streaming: partial buf'u spinner/ANSI değilse hemen gönder
        if self.buf and not self._is_status_prefix(self.buf):
            self.q.put(("out", self.buf))
            self.buf = ""

    def write(self, s):
        self.push(s)

    def flush(self):
        if self.buf.strip():
            self.q.put(("out", self.buf.rstrip()))
            self.buf = ""


_real_out = M.out
_sink_holder = {"sink": None}


def _web_out(s="", end="\n"):
    # Child/background agent izolasyonu: thread-local yakalama aktifse
    # parent sink'ine yazma; _run_child_agent'ın buffer'ına yaz.
    if M._capture_write(s + end):
        return
    sk = _sink_holder["sink"]
    if sk is not None:
        sk.push(s + end)
    else:
        _real_out(s, end)


M.out = _web_out


# ── Web modunda MDStream partial streaming ──────────────────────────────
# MDStream.feed() sadece \n görünce out() çağırır → tam satır gelene kadar bekler.
# Web'de her token anında gitmeli. feed()'i wrap: tam satırları normal işle,
# partial buf'u doğrudan sink'e at (out() üzerinden değil — out() \n ekler).
_orig_md_feed = M.MDStream.feed


def _web_md_feed(self, chunk):
    """Token token streaming: tam satır + partial buf anında tarayıcıya."""
    sk = _sink_holder["sink"]
    if sk is None:
        _orig_md_feed(self, chunk)
        return
    # 1) Chunk'ı MDStream'e ver — \n olan satırları out() → sink üzerinden gönderir
    _orig_md_feed(self, chunk)
    # 2) MDStream buf'ında kalan partial text'i hemen at (\n bekleme)
    if self.buf and not self.in_code:
        s = self.buf
        # Araç JSON açıcısı veya spinner ise bekle
        stripped = s.lstrip()
        if stripped and stripped[0] not in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏" and \
           not stripped.startswith(("⏵", "▸", "»", "\x1b[")):
            # Direkt sink'e: out() çağırmıyoruz çünkü out() \n ekler
            if M._capture_write(s):
                self.buf = ""
                return
            sk.q.put(("out", s))
            self.buf = ""


M.MDStream.feed = _web_md_feed


# ── Ajan calistirma ────────────────────────────────────────────────────
def _run_agent(session, user_msg, q, started, display_text=None, attachment_meta=None,
                workspace=None, pre_banner=None):
    """Agent.run()'u bir thread icinde calistirir; ciktiyi kuyruga basar.

    Agent.run() kendisi ciktiyi out() ile yazar: kullanici yankisi,
    arac basliklari/sonuclari ve MDStream ile akan asistan metni.
    Hepsi satir satir kuyruga gider; frontend bunlari sohbet kartlarina
    cevirir.

    pre_banner: run_start GONDERILDIKTEN SONRA kuyruga basilacak ilk
    satir (orn. "ZIP çıkarılıyor…"). Boylece frontend'de zaten acilmis
    olan akis balonunun İÇİNE yazilir; run_start'tan ONCE ayri bir "out"
    olarak gonderilirse frontend yeni bir balon ac<ıp bunu yetim birakir
    (run_start balonu sifirlar) — kullanicinin "zip mesaji ayri geliyor"
    sikayetinin nedeni buydu.
    """
    sink = _Sink(q)
    _sink_holder["sink"] = sink
    PANEL.bump("runs")
    PANEL.log("info", "agent", "kosu basladi · model=%s"
              % getattr(session, "model", "?"))
    old_stdout = sys.stdout
    old_cwd = M.CWD
    sys.stdout = sink
    _run_ok = False
    try:
        # Ekli ZIP varsa AJANIN GERCEK CALISMA ALANI ZIP KOKU OLSUN.
        # Aksi halde read/glob/grep/tree gibi araclar varsayilan MIXI
        # klasorunde calisir ve model ZIPi "sadece manifest" sanabilir.
        if workspace:
            M.CWD = Path(workspace).resolve()
        M.STOP.clear()
        agent = M.Agent(M.API, session)
        # Arac ciktilari JSON gibi basilmadan ToolGate tarafindan gizlenir;
        # ToolGate yoksa ham tool JSON gorunur. Agent.run() zaten gizler.
        result = agent.run(user_msg, display_text=display_text, workspace=workspace)
        _run_ok = True
        PANEL.bump("runs_ok")
        PANEL.log("ok", "agent", "kosu tamamlandi")
        q.put(("final", result))
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        PANEL.bump("runs_err")
        PANEL.log("error", "agent", "kosu hatasi: %s" % e)
        q.put(("error", f"{e}\n{tb[-1500:]}"))
    finally:
        M.CWD = old_cwd
        sys.stdout = old_stdout
        _sink_holder["sink"] = None
        # ZIP manifestini kullanıcı geçmişinden her zaman temizle — agent.run()
        # başarılı olsun ya da exception atsın. Temizlenmezse manifest metni
        # kullanıcı balonunda görünür ve session dosyasına kaydedilir.
        if display_text is not None and session.messages:
            for mm in reversed(session.messages):
                if mm.get("role") == "user":
                    mm["content"] = display_text
                    if attachment_meta:
                        mm["attachments"] = attachment_meta
                    break
        try:
            session.save()
        except Exception:
            pass
        q.put(("done", ""))
        try:
            started.set()
        except Exception:
            pass


def _start_agent(session, user_msg, q, display_text=None, attachment_meta=None,
                  workspace=None, pre_banner=None):
    started = threading.Event()
    t = threading.Thread(target=_run_agent,
                         args=(session, user_msg, q, started, display_text, attachment_meta,
                               workspace, pre_banner),
                         daemon=True)
    t.start()
    return t


# ══════════════════════════════════════════════════════════════════════
#  PLAN ONAYI — WEB KÖPRÜSÜ
#  mixium_new.py'deki Permission.check() web modunda onay alamıyordu
#  (Term.is_tty=False → her zaman False döndürüyordu). Burası o boşluğu
#  WebSocket üzerinden doldurur.
#
#  Kaynak: Claude Code ExitPlanModeV2Tool + checkPermissions adaptasyonu.
#  Sadece tek-kullanıcı/tek-oturum Mixium akışı için gerekli kısımlar alındı.
#  Team-lead, mailbox, teammate, subagent kısımları alınmadı.
#
#  Akış:
#    1. Permission.check() (plan modda) → _web_plan_request() çağrır
#    2. _web_plan_request() → _plan_ws_hook[0] (bu dosyadaki _ws_send_plan) ile
#       WS'e {"type":"plan_approval_request"} yollar ve threading.Event bekler
#    3. Frontend butonla onaylar/reddeder → WS "plan_respond" mesajı gelir
#    4. _handle_plan_respond() → plan günceller, event.set() → Permission.check() uyanır
# ══════════════════════════════════════════════════════════════════════

# Aktif WS bağlantısının send fonksiyonunu tutan referans.
# Tek seferde bir kullanıcı bağlıdır (Termux personal use).
_active_ws_ref = [None]   # [ws nesnesi] — _send kullanır

def _ws_send_plan(obj):
    """Plan onay isteğini aktif WS bağlantısına gönder."""
    ws = _active_ws_ref[0]
    if ws is None:
        raise RuntimeError("Aktif WS bağlantısı yok")
    _send(ws, obj)

def _register_plan_ws(ws):
    """Yeni bağlantı kurulunca mixium_new.py'ye WS hook'unu tanıt."""
    _active_ws_ref[0] = ws
    M._plan_ws_hook[0]  = _ws_send_plan
    M._todo_ws_hook[0]  = _ws_send_plan   # aynı send fn — tip bilgisi JSON içinde
    M._task_ws_hook[0]  = _ws_send_plan

def _unregister_plan_ws():
    """Bağlantı kapanınca hook'u temizle."""
    _active_ws_ref[0]  = None
    M._plan_ws_hook[0] = None
    M._todo_ws_hook[0] = None
    M._task_ws_hook[0] = None

def _handle_plan_respond(msg):
    """Frontend'den gelen plan_respond mesajını işle.

    msg örneği:
      {"type":"plan_respond","plan_id":"abc123","action":"approve"}
      {"type":"plan_respond","plan_id":"abc123","action":"reject","feedback":"Önce testleri çalıştır"}

    Claude Code'daki ExitPlanModeV2Tool.call() içindeki onay/red lifecycle'ı:
      approve → plan.approve()  → Permission.check() True döner → mode auto'ya döner
      reject  → plan.reject()  → Permission.check() False döner → model bilgilendirilir
    """
    plan_id = msg.get("plan_id", "")
    action  = msg.get("action", "")
    feedback = msg.get("feedback", "")

    plan = M._plan_pending.get(plan_id)
    ev   = M._plan_events.get(plan_id)

    if plan is None or ev is None:
        _log(f"[plan] bilinmeyen plan_id: {plan_id}")
        return False

    if action == "approve":
        plan.approve()
    elif action == "reject":
        plan.reject(feedback)
    else:
        plan.cancel()

    ev.set()
    return True


# ── oturumlar ──────────────────────────────────────────────────────────
def _set_active_session(s):
    """Aktif session'ı task store'a bildir (session izolasyonu)."""
    M._current_sid[0] = s.id

def _new_session(model=None, ai_name=None):
    # NoTrack: model A/B/C, ai_name modelin adı
    if model not in M.NOTRACK_MODELS:
        model = M._NT_MODEL
        ai_name = M.NOTRACK_MODELS.get(model, "notrack.ai")
    s = M.Session(model, ai_name)
    s.file = WEB_CHAT_DIR / f"{s.id}.json"
    s.save()
    _set_active_session(s)
    return s


def _load_session(sid):
    f = WEB_CHAT_DIR / f"{sid}.json"
    if not f.exists():
        return None
    try:
        return M.Session.load(f)
    except Exception:
        return None


def _all_sessions():
    rows = []
    for f in sorted(WEB_CHAT_DIR.glob("*.json"),
                    key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            d = json.loads(f.read_text())
            first = next((m["content"] for m in d.get("messages", [])
                          if m.get("role") == "user"), "")
            rows.append({
                "id": d.get("id", f.stem),
                "title": d.get("title") or first[:50] or "yeni oturum",
                "model": d.get("model", "?"),
                "n": len(d.get("messages", [])),
                "mtime": f.stat().st_mtime,
            })
        except Exception:
            continue
    return rows


def _models_list():
    try:
        models = [{"id": k, "ai_name": v} for k, v in M.NOTRACK_MODELS.items()]
        return [{"id": m.get("id", "?"), "ai": m.get("ai_name", "")}
                for m in models]
    except Exception:
        return []


# ── WebSocket: RFC 6455 (saf stdlib) ───────────────────────────────────
class _WS:
    def __init__(self, reader, writer):
        self.reader = reader
        self.writer = writer
        self.open = True
        self._write_lock = asyncio.Lock()

    async def send_text(self, text):
        if not self.open:
            return
        data = text.encode("utf-8")
        header = bytearray([0x81])
        n = len(data)
        if n < 126:
            header.append(n)
        elif n < 65536:
            header.append(126)
            header += n.to_bytes(2, "big")
        else:
            header.append(127)
            header += n.to_bytes(8, "big")
        async with self._write_lock:
            try:
                self.writer.write(bytes(header) + data)
                await self.writer.drain()
            except Exception:
                self.open = False

    async def recv_text(self):
        """RFC6455 metin mesajını tam olarak alır; büyük tarayıcı mesajları
        parçalı WebSocket frame'lerine bölünse bile yeniden birleştirir."""
        parts = []
        started = False
        total = 0
        max_message = 16 * 1024 * 1024
        while True:
            hdr = await self.reader.readexactly(2)
            b1, b2 = hdr[0], hdr[1]
            fin = bool(b1 & 0x80)
            opcode = b1 & 0x0F
            masked = bool(b2 & 0x80)
            ln = b2 & 0x7F
            if ln == 126:
                ln = int.from_bytes(await self.reader.readexactly(2), "big")
            elif ln == 127:
                ln = int.from_bytes(await self.reader.readexactly(8), "big")
            if ln > max_message or total + ln > max_message:
                self.open = False
                try:
                    await self.close(1009, "message too large")
                except Exception:
                    pass
                return None
            mask = await self.reader.readexactly(4) if masked else b""
            payload = await self.reader.readexactly(ln)
            if masked:
                payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))

            # Kontrol frame'leri fragmentasyon akışını bozmaz.
            if opcode == 0x9:  # ping
                try:
                    data = payload[:125]
                    hdr2 = bytes([0x8A, len(data)])
                    self.writer.write(hdr2 + data)
                    await self.writer.drain()
                except Exception:
                    self.open = False
                    return None
                continue
            if opcode == 0xA:
                continue
            if opcode == 0x8:
                self.open = False
                return None

            if opcode == 0x1:  # yeni text mesajı
                parts = [payload]
                total = len(payload)
                started = True
                if fin:
                    try:
                        return payload.decode("utf-8")
                    except UnicodeDecodeError:
                        return None
                continue

            if opcode == 0x0 and started:  # continuation
                parts.append(payload)
                total += len(payload)
                if fin:
                    data = b"".join(parts)
                    started = False
                    try:
                        return data.decode("utf-8")
                    except UnicodeDecodeError:
                        return None
                continue
            # Desteklenmeyen/binary frame: mesajı güvenli biçimde yok say.
            if fin:
                parts = []; started = False; total = 0


async def _ws_handshake(reader, writer, headers):
    key = None
    for h in headers:
        if h.lower().startswith("sec-websocket-key"):
            key = h.split(":", 1)[1].strip()
    if not key:
        writer.write(b"HTTP/1.1 400 Bad Request\r\n\r\n")
        await writer.drain()
        return None
    accept = base64.b64encode(
        hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode())
        .digest()).decode()
    writer.write(
        b"HTTP/1.1 101 Switching Protocols\r\n"
        b"Upgrade: websocket\r\n"
        b"Connection: Upgrade\r\n"
        b"Sec-WebSocket-Accept: " + accept.encode() + b"\r\n\r\n")
    await writer.drain()
    return _WS(reader, writer)


# ── istemci oturumu ────────────────────────────────────────────────────
class ClientSession:
    """Bir tarayici baglantisi: secili oturum + aktif uretim kuyrugu."""

    def __init__(self):
        self.sess = None
        self.q = queue.Queue()
        self.run_thread = None
        self.running = False
        self.lock = threading.Lock()  # her bağlantının kendi lock'ı


_clients = {}


def _get_client(ws):
    return _clients.get(id(ws))


def _client_session(ws):
    c = _get_client(ws)
    return c.sess if c else None


_LOOP = None   # ana asyncio event loop (main() icinde atanir)


def _send(ws, obj):
    """Thread-guvenli gonderim.
    - asyncio event loop thread'inden çağrılırsa: create_task ile schedule et (non-blocking).
    - Başka thread'den çağrılırsa: run_coroutine_threadsafe kullan."""
    if _LOOP is None:
        return
    data = json.dumps(obj, ensure_ascii=False)
    try:
        running_loop = asyncio.get_running_loop()
    except RuntimeError:
        running_loop = None
    if running_loop is _LOOP:
        # Asyncio thread'indeyiz — create_task ile schedule et
        _LOOP.create_task(ws.send_text(data))
    else:
        # Başka thread — thread-safe schedule
        asyncio.run_coroutine_threadsafe(ws.send_text(data), _LOOP)



# ── yonetim paneli koprusu ─────────────────────────────────────
_panel_subs = {}          # id(ws) -> gonderici fonksiyon


def _panel_sub(ws):
    """Bu WS'i canli log akisina abone eder."""
    def _fn(obj):
        try:
            _send(ws, obj)
        except Exception:
            pass
    _panel_subs[id(ws)] = _fn
    PANEL.subscribe(_fn)


def _panel_unsub(ws):
    fn = _panel_subs.pop(id(ws), None)
    if fn:
        PANEL.unsubscribe(fn)


def _panel_handle(ws, msg, c):
    """panel_* mesajlarini karsilar. True donerse mesaj islendi."""
    t = msg.get("type", "")
    if not t.startswith("panel_"):
        return False

    if t == "panel_sys":
        _send(ws, {"type": "panel_sys", "data": PANEL.sysinfo(M)})

    elif t == "panel_logs":
        _send(ws, {"type": "panel_logs",
                   "rows": PANEL.logs(limit=int(msg.get("limit", 400)))})

    elif t == "panel_clear_logs":
        PANEL.clear_logs()
        _send(ws, {"type": "panel_logs", "rows": PANEL.logs(limit=50)})

    elif t == "panel_models":
        _send(ws, {"type": "panel_models", "rows": PANEL.models_health(M)})

    elif t == "panel_sessions":
        _send(ws, {"type": "panel_sessions",
                   "data": PANEL.session_stats(WEB_CHAT_DIR)})

    elif t == "panel_dna":
        # DNA sekmesi verisi
        dna_data = {"model": "", "enabled": False, "categories": {},
                    "records": [], "operations": []}
        try:
            if M._model_dna_mgr:
                dna_data.update(M._model_dna_mgr.dna_status())
            if M._dna_store:
                dna_data["categories"] = M._dna_store.categories()
                dna_data["records"] = M._dna_store.recent(50)
        except Exception:
            pass
        # Efor ve düşünme durumu
        dna_data["effort"] = getattr(M, '_NT_EFFORT', 'normal')
        dna_data["thinking"] = getattr(M, '_NT_THINKING', False)
        _send(ws, {"type": "panel_dna", "data": dna_data})

    elif t == "panel_set_dna_model":
        mid = msg.get("model", "")
        try:
            if M._model_dna_mgr:
                M._model_dna_mgr.set_dna_model(mid)
                PANEL.log("ok", "dna", "DNA modeli ayarlandi: %s" % mid)
            _send(ws, {"type": "panel_dna_model_ok", "model": mid})
        except Exception as e:
            _send(ws, {"type": "error", "text": str(e)})

    elif t == "panel_dna_rollback":
        rid = msg.get("record_id", "")
        try:
            if M._dna_store:
                ok = M._dna_store.rollback(rid)
                PANEL.log("ok" if ok else "warn", "dna",
                          "rollback %s: %s" % (rid, "basarili" if ok else "bulunamadi"))
                _send(ws, {"type": "panel_dna_rollback_ok", "id": rid, "ok": ok})
        except Exception as e:
            _send(ws, {"type": "error", "text": str(e)})

    elif t == "panel_test_model":
        mid = msg.get("model") or ""
        ai = msg.get("ai") or ""

        def _run_test():
            res = PANEL.verify_model(M, mid, ai)
            _send(ws, {"type": "panel_test_result",
                       "model": mid, "ai": res.get("ai"),
                       "ok": res["ok"], "ms": res["ms"],
                       "reply": res["reply"], "error": res["error"]})
        threading.Thread(target=_run_test, daemon=True).start()

    return True


def _send_sess_list(ws):
    _send(ws, {"type": "sessions", "items": _all_sessions()})


def _send_models(ws):
    _send(ws, {"type": "models", "items": _models_list()})


def _send_history(ws):
    s = _client_session(ws)
    if not s:
        return
    msgs = []
    for m in s.messages:
        row = {"role": m.get("role", "user"),
               "content": m.get("content", "")}
        if m.get("attachments"):
            row["attachments"] = m.get("attachments")
        msgs.append(row)
    _send(ws, {"type": "history", "session": s.id, "title": s.title,
               "model": s.model, "messages": msgs})


def _zip_is_symlink(info):
    """ZIP entry'nin symlink olup olmadığını güvenli şekilde kontrol eder."""
    try:
        mode = (info.external_attr >> 16) & 0o170000
        return mode == 0o120000
    except Exception:
        return False


def _stage_zip_attachment(att, workspace_out=None):
    """ZIP'i güvenli bir çalışma alanına çıkarır ve yalnızca kısa metadata döndürür.

    ZIP içeriğini prompta koymak yasaktır: NoTrack user_input limiti 4000 karakterdir.
    Ajan gerçek dosyaları CWD üzerinden araçlarla okuyabilir.
    """
    name = str(att.get("name") or "eklenti.zip")
    raw_b64 = att.get("data") or ""
    if not isinstance(raw_b64, str):
        return "[ZIP %s: geçersiz veri]" % name
    try:
        raw = base64.b64decode(raw_b64, validate=True)
    except Exception:
        return "[ZIP %s: veri çözülemedi]" % name
    if len(raw) > 8 * 1024 * 1024:
        return "[ZIP %s: 8 MB sınırını aşıyor]" % name

    dest = None
    max_files = 500
    max_uncompressed = 30 * 1024 * 1024
    total_uncompressed = 0
    extracted = 0
    skipped = []
    try:
        upload_root = M.DATA_DIR / "web_uploads"
        upload_root.mkdir(parents=True, exist_ok=True)
        dest = upload_root / (uuid.uuid4().hex + "_" + re.sub(r"[^A-Za-z0-9._-]", "_", Path(name).stem)[:60])
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(raw), "r") as zf:
            infos = zf.infolist()
            if len(infos) > max_files:
                infos = infos[:max_files]
                skipped.append("dosya sayısı 500 ile sınırlandı")
            for info in infos:
                n = str(info.filename).replace("\\", "/")
                parts = [x for x in n.split("/") if x not in ("", ".")]
                if not parts or n.startswith("/") or ".." in parts:
                    skipped.append("güvensiz yol: " + n[:120]); continue
                if _zip_is_symlink(info):
                    skipped.append("symlink atlandı: " + n[:120]); continue
                if info.file_size > max_uncompressed or total_uncompressed + info.file_size > max_uncompressed:
                    skipped.append("boyut sınırı nedeniyle atlandı: " + n[:120]); continue
                if info.is_dir():
                    continue
                target = dest.joinpath(*parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                data = zf.read(info)
                target.write_bytes(data)
                total_uncompressed += len(data)
                extracted += 1
        if workspace_out is not None:
            workspace_out.append(str(dest.resolve()))
        extra = ("; " + ", ".join(skipped[:2])) if skipped else ""
        return ("[EK ZIP hazır: %s | kök=%s | %d dosya | %d bayt%s. "
                "İnceleme gerekiyorsa önce agac, sonra oku/ara/bul kullan.]" %
                (name, dest, extracted, total_uncompressed, extra))
    except zipfile.BadZipFile:
        if dest is not None: shutil.rmtree(dest, ignore_errors=True)
        return "[ZIP %s: bozuk veya desteklenmeyen ZIP dosyası]" % name
    except Exception as e:
        if dest is not None: shutil.rmtree(dest, ignore_errors=True)
        return "[ZIP %s: okunamadı: %s]" % (name, e)

def _safe_zip_attachment(att, workspace_out=None):
    """Uyumluluk adı; gerçek işleme staging üzerinden yapılır."""
    return _stage_zip_attachment(att, workspace_out)


def _prepare_attachments(attachments, workspace_out=None):
    """Ekleri ortak gerçek çalışma alanına hazırlar; içerikleri prompta gömmez."""
    if not isinstance(attachments, list):
        return ""
    root = M.DATA_DIR / "web_uploads"
    root.mkdir(parents=True, exist_ok=True)
    dest = root / (uuid.uuid4().hex + "_attachments")
    dest.mkdir(parents=True, exist_ok=True)
    chunks = []
    try:
        for att in attachments[:10]:
            if not isinstance(att, dict):
                continue
            kind = att.get("kind")
            name = str(att.get("name") or "dosya")
            if kind == "zip":
                # ZIP'i önce güvenli staging'e çıkar, sonra ortak çalışma alanına taşı.
                before = set(root.iterdir())
                _safe_zip_attachment(att, None)
                staged = [p for p in root.iterdir() if p not in before and p.is_dir()]
                staged = next((p for p in staged if p != dest), None)
                if staged:
                    for child in staged.iterdir():
                        target = dest / child.name
                        if target.exists():
                            target = dest / (staged.name + "_" + child.name)
                        shutil.move(str(child), str(target))
                    shutil.rmtree(staged, ignore_errors=True)
                chunks.append("[EK ZIP hazır: %s]" % name)
            elif kind == "text":
                safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", Path(name).name)[:100] or "dosya.txt"
                target = dest / safe_name
                raw_b64 = att.get("data")
                if isinstance(raw_b64, str) and raw_b64:
                    raw = base64.b64decode(raw_b64, validate=True)
                    if len(raw) > 2 * 1024 * 1024:
                        raise ValueError("dosya 2 MB sınırını aşıyor")
                    target.write_bytes(raw)
                else:
                    target.write_text(str(att.get("text") or "")[:200000], encoding="utf-8")
                chunks.append("[EK DOSYA hazır: %s]" % name)
        if workspace_out is not None:
            workspace_out.append(str(dest.resolve()))
        return ("[EKLER ÇALIŞMA ALANINDA HAZIR. Önce tree, sonra read/grep/glob kullan.]\n"
                + "\n".join(chunks))
    except Exception:
        shutil.rmtree(dest, ignore_errors=True)
        raise

def _start_run(ws, text, display_text=None, attachment_meta=None, workspace=None, pre_banner=None):
    c = _get_client(ws)
    if not c or c.running:
        _send(ws, {"type": "busy"})
        return
    if not c.lock.acquire(blocking=False):
        _send(ws, {"type": "busy"})
        return
    try:
        if c.sess is None:
            c.sess = _new_session()
        c.running = True
        _send(ws, {"type": "run_start"})
        _send_sess_list(ws)
    except Exception:
        c.lock.release()
        raise

    def pump():
        try:
            while True:
                try:
                    ev, payload = c.q.get(timeout=0.02)
                except queue.Empty:
                    if c.run_thread is None or not c.run_thread.is_alive():
                        # Thread bitti ama kuyrukta kalan mesajlar olabilir
                        # Hepsini tüket, sonra çık
                        while True:
                            try:
                                ev2, payload2 = c.q.get_nowait()
                            except queue.Empty:
                                break
                            if ev2 == "done":
                                # done is finalized exactly once by the outer finally.
                                # Do not return here: returning would run finally immediately
                                # while leaving the queue-drain path ambiguous.
                                break
                            if ev2 == "out":
                                _send(ws, {"type": "out", "text": payload2})
                            elif ev2 == "error":
                                _send(ws, {"type": "error", "text": payload2})
                            elif ev2 == "final":
                                _send(ws, {"type": "final", "text": payload2})
                        break
                    continue
                if ev == "done":
                    break
                if ev == "out":
                    _send(ws, {"type": "out", "text": payload})
                elif ev == "error":
                    _send(ws, {"type": "error", "text": payload})
                elif ev == "final":
                    _send(ws, {"type": "final", "text": payload})
        finally:
            c.running = False
            c.lock.release()
            # The live stream has already rendered the assistant message in the UI.
            # Do NOT send history here: renderHistory() clears the chat DOM and re-adds
            # persisted messages, which can make the just-streamed answer appear twice.
            # History is sent only for explicit session-open/new flows.
            _send(ws, {"type": "done"})
            _send_sess_list(ws)

    try:
        c.run_thread = _start_agent(c.sess, text, c.q, display_text, attachment_meta, workspace,
                                     pre_banner)
        threading.Thread(target=pump, daemon=True).start()
    except Exception:
        # thread kurulamazsa kilidi birak, yoksa tum gelecek istekler
        # sonsuza dek "busy" gorur.
        c.running = False
        c.lock.release()
        _send(ws, {"type": "error", "text": "Ajan baslatilamadi."})


# ── HTTP + WS giris noktasi ────────────────────────────────────────────
async def handle_conn(reader, writer):
    try:
        req_line = await reader.readline()
        if not req_line:
            writer.close()
            return
        headers = []
        while True:
            line = await reader.readline()
            if line in (b"\r\n", b"\n", b""):
                break
            headers.append(line.decode("latin-1", "replace").strip())
        upgrade = any(h.lower().startswith("upgrade") and
                      "websocket" in h.lower() for h in headers)
        if upgrade:
            ws = await _ws_handshake(reader, writer, headers)
            if not ws:
                return
            await _handle_ws(ws)
            return

        # static: sadece index.html (ve ayni klasordeki dosyalar)
        path = req_line.decode("latin-1", "replace").split(" ")[1].split("?")[0]
        if path in ("/", "/index.html"):
            f = INDEX
        else:
            f = WEB_DIR / path.lstrip("/")
            if not str(f.resolve()).startswith(str(WEB_DIR.resolve())):
                f = INDEX
        if not f.exists():
            writer.write(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n")
            await writer.drain()
            writer.close()
            return
        body = f.read_bytes()
        ctype = mimetypes.guess_type(str(f))[0] or "text/html"
        writer.write(
            f"HTTP/1.1 200 OK\r\nContent-Type: {ctype}\r\n"
            f"Content-Length: {len(body)}\r\n"
            f"Cache-Control: no-cache\r\n\r\n".encode() + body)
        await writer.drain()
        writer.close()
    except Exception:
        try:
            writer.close()
        except Exception:
            pass


async def _handle_ws(ws):
    c = ClientSession()
    _uploads = {}
    _clients[id(ws)] = c
    _panel_sub(ws)
    _register_plan_ws(ws)   # Plan onay köprüsünü bu bağlantıya bağla
    PANEL.bump("ws_connects")
    PANEL.log("info", "ws", "istemci baglandi")
    _log("[WS] istemci baglandi")
    try:
        # Her bağlantıda yeni oturum başlat; geçmiş oturumlar sidebar'dan erişilebilir
        _log("[WS] yeni oturum baslatiliyor...")
        rows = _all_sessions()  # sidebar listesi için yükle
        c.sess = _new_session()
        _log("[WS] hello gonderiliyor...")
        # İlk handshake mesajını doğrudan await et: mobil Chrome/WebView'da
        # bağlantı açıldıktan sonra event-loop kuyruğunda bekleyip UI'nın
        # sonsuz "bağlanıyor" durumunda kalmasını önler.
        await ws.send_text(json.dumps({
            "type": "hello", "app": APP,
            "models": _models_list(),
            "sessions": _all_sessions(),
            "session": c.sess.id, "title": c.sess.title,
            "model": c.sess.model, "mode": M.PERM.mode,
            "effort": M._NT_EFFORT, "thinking": M._NT_THINKING
        }, ensure_ascii=False))
        await ws.send_text(json.dumps({
            "type": "history", "session": c.sess.id, "title": c.sess.title,
            "model": c.sess.model, "messages": [
                {"role": mm.get("role", "user"), "content": mm.get("content", ""),
                 **({"attachments": mm.get("attachments")} if mm.get("attachments") else {})}
                for mm in c.sess.messages
            ]
        }, ensure_ascii=False))

        while True:
            raw = await ws.recv_text()
            if raw is None:
                break
            try:
                msg = json.loads(raw)
            except Exception:
                continue
            mtype = msg.get("type", "")
            if mtype.startswith("panel_"):
                _panel_handle(ws, msg, c)
                continue

            # Büyük ekleri tek dev JSON mesajı yerine küçük WebSocket
            # parçaları halinde al. Böylece 2-8 MB ZIP'ler de stabil kalır.
            if mtype == "tools_list":
                # Araç galerisi için gerçek kayıtlı araçları gönder.
                # Frontend yalnızca şema kopyalamaz; kartlar artık gerçek katalogdan beslenir.
                rows = []
                for name, spec in sorted(getattr(M, "TOOLS", {}).items()):
                    rows.append({
                        "name": name,
                        "desc": str(spec.get("desc", "")),
                        "schema": spec.get("schema", ""),
                        "danger": bool(spec.get("danger")),
                    })
                _send(ws, {"type": "tools_list", "items": rows})
                PANEL.log("info", "tool", "araç galerisi yenilendi: %d araç" % len(rows))
                continue

            if mtype == "upload_start":
                try:
                    uid = str(msg.get("id") or "")
                    name = str(msg.get("name") or "dosya")
                    kind = str(msg.get("kind") or "text")
                    size = int(msg.get("size") or 0)
                    max_size = 8 * 1024 * 1024 if kind == "zip" else 900000
                    if not re.fullmatch(r"[A-Za-z0-9_-]{8,80}", uid):
                        raise ValueError("geçersiz yükleme kimliği")
                    if size < 0 or size > max_size:
                        raise ValueError("dosya boyutu sınırı aşıldı")
                    if len(_uploads) >= 12:
                        raise ValueError("çok fazla bekleyen dosya")
                    _uploads[uid] = {
                        "name": name, "kind": kind, "size": size,
                        "chunks": [], "chars": 0, "ready": False,
                    }
                    _send(ws, {"type": "upload_ready", "id": uid})
                except Exception as e:
                    _send(ws, {"type": "error", "text": "Ek yükleme başlatılamadı: %s" % e})
                continue

            if mtype == "upload_chunk":
                uid = str(msg.get("id") or "")
                item = _uploads.get(uid)
                chunk = msg.get("data") or ""
                if not item or item.get("ready") or not isinstance(chunk, str):
                    _send(ws, {"type": "error", "text": "Geçersiz ek parçası"})
                    continue
                if len(chunk) > 300000:
                    _send(ws, {"type": "error", "text": "Ek parçası çok büyük"})
                    continue
                item["chunks"].append(chunk)
                item["chars"] += len(chunk)
                max_chars = ((item["size"] + 2) // 3) * 4 + 16
                if item["chars"] > max_chars:
                    _uploads.pop(uid, None)
                    _send(ws, {"type": "error", "text": "Ek verisi boyut sınırını aşıyor"})
                continue

            if mtype == "upload_end":
                uid = str(msg.get("id") or "")
                item = _uploads.get(uid)
                if not item:
                    _send(ws, {"type": "error", "text": "Ek bulunamadı"})
                    continue
                try:
                    # Chunk'ları birleştir; base64 güvenli decode
                    combined = "".join(item["chunks"])
                    # Base64 padding toleransı: tarayıcı bazen son chunk'ı
                    # doldurmadan gönderir — padding ekle
                    pad = len(combined) % 4
                    if pad:
                        combined += "=" * (4 - pad)
                    try:
                        raw = base64.b64decode(combined, validate=False)
                    except Exception:
                        raw = base64.b64decode(combined.replace(" ", "+"), validate=False)
                    # Boyut kontrolü: ±3 byte tolerans (base64 padding'den kaynaklanabilir)
                    expected = item["size"]
                    if abs(len(raw) - expected) > 3:
                        raise ValueError(
                            "dosya boyutu uyuşmuyor: beklenen %d, alınan %d" % (expected, len(raw))
                        )
                    if item["kind"] == "zip":
                        # ZIP mi gerçekten? Magic byte kontrolü
                        if len(raw) >= 4 and raw[:2] != b"PK":
                            raise ValueError("geçersiz ZIP dosyası (PK imzası bulunamadı)")
                        item["data"] = base64.b64encode(raw).decode("ascii")
                    else:
                        item["text"] = raw.decode("utf-8", "replace")[:200000]
                    item["ready"] = True
                    item["chunks"] = []
                    _send(ws, {"type": "upload_ok", "id": uid})
                except Exception as e:
                    _uploads.pop(uid, None)
                    _send(ws, {"type": "error", "text": "Ek doğrulanamadı: %s" % e})
                continue

            if mtype == "chat":
                display_text = (msg.get("text") or "").strip()
                attachments = msg.get("attachments") or []
                resolved_attachments = []
                try:
                    for att in attachments[:10]:
                        if not isinstance(att, dict):
                            continue
                        uid = att.get("upload_id")
                        if uid:
                            up = _uploads.get(str(uid))
                            if not up or not up.get("ready"):
                                raise ValueError("ek henüz hazır değil")
                            if up["kind"] == "zip":
                                resolved_attachments.append({
                                    "kind": "zip", "name": up["name"], "size": up["size"],
                                    "data": up["data"],
                                })
                            else:
                                resolved_attachments.append({
                                    "kind": "text", "name": up["name"], "size": up["size"],
                                    "text": up.get("text", ""),
                                })
                        else:
                            resolved_attachments.append(att)
                    attachments = resolved_attachments
                except Exception as e:
                    _send(ws, {"type": "error", "text": "Ek hazırlanamadı: %s" % e})
                    continue
                attachment_workspaces = []
                has_zip = any(isinstance(a, dict) and a.get("kind") == "zip" for a in attachments)
                try:
                    # ÖNEMLİ: zip çıkarma / dosya yazma diski meşgul eden senkron bir
                    # işlemdir. Bunu doğrudan event loop içinde çağırmak TÜM
                    # bağlı istemcilerin websocket akışını (streaming) o süre
                    # boyunca donduruyordu — büyük ekler geldiğinde canlı akış
                    # kayboluyor, agent çıktısı biriken kuyruk boşalınca aniden
                    # tek seferde ekrana düşüyordu. Bu yüzden ayrı bir thread'e
                    # (executor) devrediyoruz; event loop bu sırada diğer
                    # istemcilerin mesajlarını ve mevcut agent akışlarının
                    # "out" olaylarını göndermeye devam edebiliyor.
                    attachment_text = await asyncio.get_event_loop().run_in_executor(
                        None, _prepare_attachments, attachments, attachment_workspaces
                    )
                except Exception as _att_err:
                    _send(ws, {"type": "error", "text": f"Ek işlenemedi: {_att_err}"})
                    continue
                # EK HAZIRLIK MESAJINI MODEL PROMPTUNA ASLA EKLEME.
                # _prepare_attachments() yalnızca dosyayı çalışma alanına açar/yazar.
                # Önceki sürüm "[EKLER ÇALIŞMA ALANINDA HAZIR...]" metnini user_msg'a
                # ekliyordu. Bu, modelin bu iç protokol metnini gerçek kullanıcı
                # mesajının parçası sanıp aynen cevaba basmasına neden olabiliyordu.
                # Agent.run() attachment_mode + workspace üzerinden çalışma alanını
                # zaten biliyor; dolayısıyla bu banner modele gönderilmemeli.
                prompt_text = display_text
                if prompt_text:
                    if prompt_text.startswith("/"):
                        _run_slash(ws, prompt_text)
                    else:
                        meta = []
                        for a in attachments[:10]:
                            if isinstance(a, dict):
                                meta.append({"kind": a.get("kind", "file"),
                                             "name": str(a.get("name") or "dosya"),
                                             "size": int(a.get("size") or 0)})
                        # ZIP banner'ı artık run_start GÖNDERİLDİKTEN SONRA, agent'ın
                        # kendi akış balonunun İÇİNE ilk satır olarak basılıyor —
                        # önceden run_start'tan önce ayrı bir "out" olarak gidiyordu,
                        # bu da frontend'de ayrı/yetim bir mesaj balonu olarak
                        # görünmesine sebep oluyordu.
                        # ZIP hazırlama mesajı sahte asistan çıktısı olarak gösterilmez.
                        # Gerçek agent akışı run_start sonrasında başlar.
                        _start_run(ws, prompt_text, display_text, meta,
                                   attachment_workspaces[0] if attachment_workspaces else None)
                        for _a in (msg.get("attachments") or [])[:10]:
                            if isinstance(_a, dict) and _a.get("upload_id"):
                                _uploads.pop(str(_a.get("upload_id")), None)
            elif mtype == "new":
                model = msg.get("model")
                ai = msg.get("ai")
                c.sess = _new_session(model, ai)
                _send(ws, {"type": "session", "id": c.sess.id,
                           "title": c.sess.title, "model": c.sess.model})
                _send_sess_list(ws)
                # Boş history gönder: frontend eski mesajları temizler, showEmpty gösterir
                _send(ws, {"type": "history", "session": c.sess.id,
                           "title": c.sess.title, "model": c.sess.model,
                           "messages": []})
            elif mtype == "open":
                s = _load_session(msg.get("id", ""))
                if s:
                    c.sess = s
                    _set_active_session(s)
                    # Önce session mesajı: frontend title/model'i günceller
                    _send(ws, {"type": "session", "id": s.id,
                               "title": s.title, "model": s.model})
                    _send_history(ws)
                    # Session'a ait task/todo durumunu gönder
                    tasks = M._get_tasks(s.id)
                    if tasks:
                        for tid, t in tasks.items():
                            _send(ws, {"type": "task_update",
                                       "task": M._task_to_dict(tid, t)})
                    todo_items = M.TODO._to_ws_items()
                    if todo_items:
                        _send(ws, {"type": "todo_update", "items": todo_items})
            elif mtype == "set_model":
                if c.sess:
                    _prev = c.sess.model
                    _new = msg.get("model") or c.sess.model
                    _ai = msg.get("ai") or ""
                    # ai_name'i model listesinden dogrula: yanlis ai ile
                    # istek atilirsa model sessizce degismis gibi gorunur.
                    if not _ai:
                        for _m in (getattr(M.API, "models", []) or []):
                            if isinstance(_m, dict) and _m.get("id") == _new:
                                _ai = _m.get("ai_name") or ""
                                break
                    c.sess.model = _new
                    c.sess.ai_name = _ai or c.sess.ai_name
                    c.sess.save()
                    PANEL.bump("model_switches")
                    PANEL.log("ok", "model",
                              "model degisti: %s -> %s (ai=%s)"
                              % (_prev, c.sess.model, c.sess.ai_name))
                    _send(ws, {"type": "model_ok",
                               "model": c.sess.model, "ai": c.sess.ai_name})
            elif mtype == "set_effort":
                # Efor seviyesi ayarla
                eff = msg.get("effort", "normal")
                if eff in ("düşük", "normal", "yüksek", "maksimum"):
                    M._NT_EFFORT = eff
                    _send(ws, {"type": "effort_ok", "effort": eff})
                    PANEL.log("ok", "effort", "efor ayarlandi: %s" % eff)
            elif mtype == "set_thinking":
                # Düşünme modu aç/kapa
                M._NT_THINKING = bool(msg.get("on", False))
                _send(ws, {"type": "thinking_ok", "on": M._NT_THINKING})
                PANEL.log("ok", "thinking", "dusunme: %s" % ("acik" if M._NT_THINKING else "kapali"))
            elif mtype == "set_dna_model":
                # DNA modeli ayarla
                dna_model = msg.get("model", "")
                if hasattr(M, '_model_dna_mgr'):
                    M._model_dna_mgr.set_dna_model(dna_model)
                    PANEL.log("ok", "dna", "DNA modeli: %s" % dna_model)
                    _send(ws, {"type": "dna_model_ok", "model": dna_model})
                else:
                    _send(ws, {"type": "error", "text": "DNA modülü yüklenmemiş"})
            elif mtype == "set_mode":
                mode = msg.get("mode", "")
                if mode in ("ask", "plan", "auto", "yolo"):
                    M.PERM.set_mode(mode)
                    _send(ws, {"type": "mode_ok", "mode": mode})
            elif mtype == "plan_respond":
                # Frontend'den onay/red cevabı.
                # Claude Code ExitPlanModeV2Tool.call() + mapToolResultToToolResultBlockParam()
                # adaptasyonu: approve → Permission True döner → mode auto, reject → False → model bilgilendirilir
                ok = _handle_plan_respond(msg)
                if not ok:
                    _send(ws, {"type": "error", "text": "Plan yanıtı işlenemedi (bilinmeyen plan_id)"})
                else:
                    action = msg.get("action", "")
                    if action == "approve":
                        _send(ws, {"type": "plan_approved", "plan_id": msg.get("plan_id", "")})
                        _send(ws, {"type": "mode_ok", "mode": M.PERM.mode})
                    else:
                        _send(ws, {"type": "plan_rejected",
                                   "plan_id": msg.get("plan_id", ""),
                                   "feedback": msg.get("feedback", "")})
            elif mtype == "task_stop":
                # Frontend'den task durdurma isteği
                tid = str(msg.get("id", ""))
                result = M.t_task_stop({"id": tid})
                _send(ws, {"type": "task_stop_ack", "id": tid, "result": result})
            elif mtype == "task_list":
                # Frontend'den task listesi isteği (reconnect sonrası)
                tasks = M._get_tasks()
                for tid, t in tasks.items():
                    _send(ws, {"type": "task_update",
                               "task": M._task_to_dict(tid, t)})
                todo_items = M.TODO._to_ws_items()
                _send(ws, {"type": "todo_update", "items": todo_items})
            elif mtype == "cancel":
                M.STOP.set()
                c2 = _get_client(ws)
                if c2:
                    # Thread'in durmasını kısa süre bekle, sonra lock'u zorla bırak
                    t2 = c2.run_thread
                    if t2 and t2.is_alive():
                        t2.join(timeout=2.0)
                    # Eğer pump henüz bırakmadıysa zorla temizle
                    if c2.running:
                        c2.running = False
                        try:
                            c2.lock.release()
                        except RuntimeError:
                            pass
                    # Kuyruğu boşalt — eski çıktılar yeni mesaja karışmasın
                    while True:
                        try:
                            c2.q.get_nowait()
                        except queue.Empty:
                            break
                _send(ws, {"type": "done"})
            elif mtype == "list":
                _send_sess_list(ws)
            elif mtype == "del":
                f = WEB_CHAT_DIR / f"{msg.get('id','')}.json"
                if f.exists() and c.sess and c.sess.id != msg.get("id"):
                    try:
                        f.unlink()
                    except Exception:
                        pass
                    _send_sess_list(ws)
    except Exception as _ws_err:
        _log("[WS] HATA:", _ws_err)
        import traceback; traceback.print_exc()
    finally:
        _clients.pop(id(ws), None)
        _unregister_plan_ws()   # Plan hook'unu temizle
        ws.open = False
        try:
            ws.writer.close()
        except Exception:
            pass


def _run_slash(ws, text):
    """Web icin minik slash komutlari (terminal komut setinin ozu)."""
    body = text[1:].strip()
    cmd = body.split()[0].lower() if body else ""
    if cmd in ("yeni", "new"):
        c = _get_client(ws)
        if c:
            c.sess = _new_session()
            _send(ws, {"type": "session", "id": c.sess.id,
                       "title": c.sess.title, "model": c.sess.model})
            _send_sess_list(ws)
            # Boş history: frontend eski mesajları temizler
            _send(ws, {"type": "history", "session": c.sess.id,
                       "title": c.sess.title, "model": c.sess.model,
                       "messages": []})
    elif cmd in ("model", "m"):
        rest = body[len(cmd):].strip()
        if rest:
            c = _get_client(ws)
            if c and c.sess:
                m = M.API.find_model(rest) if hasattr(M.API, "find_model") else None
                if m:
                    c.sess.model = m["id"]
                    c.sess.ai_name = m.get("ai_name", c.sess.ai_name)
                    c.sess.save()
                    _send(ws, {"type": "out", "text": f"Model: {m['id']}"})
                else:
                    _send(ws, {"type": "out",
                               "text": "Model bulunamadi. Secenekler:"})
                    for mm in _models_list():
                        _send(ws, {"type": "out", "text": f"  · {mm['id']}"})
        else:
            _send(ws, {"type": "models", "items": _models_list()})
    elif cmd in ("dur", "cancel"):
        M.STOP.set()
        _send(ws, {"type": "out", "text": "Durduruldu."})
    elif cmd in ("yardim", "help", "h"):
        _send(ws, {"type": "out", "text":
                   "/yeni - yeni oturum · /model <ad> - model degistir · "
                   "/dur - uretimi durdur"})
    else:
        _send(ws, {"type": "out", "text": f"Bilinmeyen komut: /{cmd}"})


# ── ana ────────────────────────────────────────────────────────────────
def main():
    import argparse
    ap = argparse.ArgumentParser(description=APP)
    ap.add_argument("--host", default=HOST)
    ap.add_argument("--port", type=int, default=PORT)
    a = ap.parse_args()

    if not INDEX.exists():
        _log("web/index.html bulunamadi:", INDEX)
        sys.exit(1)

    # API'yi bir kere hazirla (token havuzu paylasilir — ayni dosyalar).
    # ensure() ag cagrisi yapip saniyelerce bekleyebilir; sunucu baslangicini
    # bloklamamasi icin token onbellekten varsa hemen al, yoksa ilk mesajda
    # Agent.run() zaten tm.ensure() cagirir.
    try:
        M.API = M.NoTrackAPI()
    except Exception as e:
        _log("API hazirlanamadi:", e)
        sys.exit(1)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    global _LOOP
    _LOOP = loop

    async def serve():
        server = await asyncio.start_server(handle_conn, a.host, a.port)
        _log(f"{APP} basladi:  http://{a.host}:{a.port}")
        _log("   (Ctrl+C ile durdurur)")
        async with server:
            await server.serve_forever()

    try:
        loop.run_until_complete(serve())
    except KeyboardInterrupt:
        _log("Durduruldu.")


if __name__ == "__main__":
    main()

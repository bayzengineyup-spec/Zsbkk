# -*- coding: utf-8 -*-
"""
Mixium — B5: Global Code Intelligence

Mixium kendi kod kalitesini ölçer: Architecture, Code Quality, Security,
Performance → Overall skor (0-100).

Kurallar:
- read-only analiz (workspace içi)
- hata → ilgili skoru düşürür, sistem düşmez
- MIXIUM'a bağımlı değildir (yalnızca stdlib ast/re)

Ölçümler:
  Architecture : modül sayısı, kırık import (ast), tekrar (aynı fonksiyon adı)
  Quality      : uzun fonksiyonlar, comment yoğunluğu, docstring varlığı
  Security     : tehlikeli çağrılar (eval/exec/pickle/subprocess/shell), secret pattern
  Performance  : O(n^2) desenleri, gereksiz I/O (open döngüde), sleep
"""

import ast
import re
import threading
from pathlib import Path

DANGER = re.compile(
    r"\b(eval|exec|os\.system|subprocess\.(call|Popen|run)|pickle\.loads|"
    r"shell=True|shutil\.rmtree|os\.remove)\b")
SECRET = re.compile(
    r"(api[_-]?key|secret|token|password|authorization)\s*=\s*['\"][^'\"]{8,}",
    re.IGNORECASE)
O_N2 = re.compile(r"\b(for|while)\b.*\b(for|while)\b")


class CodeQuality:
    """Kendi kod tabanının kalite ölçümü."""

    def __init__(self, root=".", paths=None, ignore=(".mixium", "mcp_browser",
                                                      "node_modules", "__pycache__")):
        self.root = Path(root)
        self.paths = paths
        self.ignore = ignore

    def _py_files(self):
        base = self.root
        if self.paths:
            return [Path(p) for p in self.paths if Path(p).suffix == ".py"]
        out = []
        for p in sorted(base.rglob("*.py")):
            rel = p.relative_to(base)
            if any(str(rel).startswith(i) for i in self.ignore):
                continue
            out.append(p)
        return out[:800]

    def measure(self):
        files = self._py_files()
        if not files:
            return {"overall": 0, "scores": {}, "issues": [], "files": 0}
        arch = {"modules": len(files), "broken_imports": 0, "dup_names": 0}
        qual = {"long_fns": 0, "no_docstring": 0, "total_fns": 0}
        sec = {"danger": 0, "secrets": 0}
        perf = {"n2": 0, "io_loops": 0}
        names = {}
        issues = []
        for f in files:
            try:
                src = f.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            try:
                tree = ast.parse(src)
            except SyntaxError:
                issues.append({"file": str(f), "issue": "syntax_error"})
                continue
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    qual["total_fns"] += 1
                    if not ast.get_docstring(node):
                        qual["no_docstring"] += 1
                    if (node.end_lineno or node.lineno) - node.lineno > 60:
                        qual["long_fns"] += 1
                    names[node.name] = names.get(node.name, 0) + 1
                elif isinstance(node, ast.Import):
                    for a in node.names:
                        try:
                            __import__(a.name.split(".")[0])
                        except Exception:
                            arch["broken_imports"] += 1
                elif isinstance(node, ast.ImportFrom):
                    try:
                        __import__(node.module or "")
                    except Exception:
                        arch["broken_imports"] += 1
                elif isinstance(node, (ast.Call, ast.Attribute)):
                    pass
            for m in DANGER.finditer(src):
                sec["danger"] += 1
            for m in SECRET.finditer(src):
                sec["secrets"] += 1
            for m in O_N2.finditer(src):
                perf["n2"] += 1
            if re.search(r"\bopen\([^)]*\)", src) and re.search(r"\bfor\b", src):
                perf["io_loops"] += 1
        arch["dup_names"] = sum(1 for v in names.values() if v > 3)
        s_arch = self._score(100, arch["broken_imports"] * 4 + arch["dup_names"] * 3)
        s_qual = self._score(100, qual["long_fns"] * 3 + qual["no_docstring"])
        s_sec = self._score(100, sec["danger"] * 8 + sec["secrets"] * 15)
        s_perf = self._score(100, perf["n2"] * 2 + perf["io_loops"] * 2)
        overall = int(round(s_arch * 0.3 + s_qual * 0.25 + s_sec * 0.25 + s_perf * 0.2))
        for f, i in [(f, i) for f, i in
                     [("architecture", s_arch), ("quality", s_qual),
                      ("security", s_sec), ("performance", s_perf)]]:
            if i < 70:
                issues.append({"file": "global", "issue": "%s_score_%d" % (f, i)})
        return {
            "overall": max(0, min(100, overall)),
            "scores": {"architecture": s_arch, "quality": s_qual,
                       "security": s_sec, "performance": s_perf},
            "metrics": {"modules": arch["modules"],
                        "broken_imports": arch["broken_imports"],
                        "danger_calls": sec["danger"], "secret_patterns": sec["secrets"],
                        "long_functions": qual["long_fns"],
                        "no_docstring": qual["no_docstring"]},
            "issues": issues[:30],
            "files": len(files),
        }

    @staticmethod
    def _score(base, penalty):
        return max(0, min(100, base - penalty))

    def summary_line(self):
        m = self.measure()
        s = m["scores"]
        return "Architecture %d Security %d Quality %d Performance %d Overall %d" % (
            s["architecture"], s["security"], s["quality"], s["performance"],
            m["overall"])

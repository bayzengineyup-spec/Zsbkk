# -*- coding: utf-8 -*-
"""Mixium A29 — Mission Queue (Görev kuyruğu).

priority, dependency, scheduling, retry, timeout, cancellation. Görev
başarısız olursa: analiz et → sebebi bul → yeniden plan oluştur (retry +
yeniden enqueue). Bağımsız state; kuyruk `.mixium/mission_queue.json`
altında workspace-sınırlı saklanır.
"""

import json
import threading
import time
import uuid
from pathlib import Path

DEFAULT_TIMEOUT = 3600  # saniye


class MissionQueue:
    def __init__(self, root=".", max_size=200):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "mission_queue.json"
        self.max_size = max(1, int(max_size))
        self._lock = threading.RLock()
        self.items = {}
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.items = d if isinstance(d, dict) else {}
        except Exception:
            self.items = {}

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.items, ensure_ascii=False, indent=1),
                           encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def enqueue(self, mission, priority=0, deps=None, timeout=DEFAULT_TIMEOUT):
        if not mission:
            return None
        with self._lock:
            if len(self.items) >= self.max_size:
                return None
            qid = "q_" + uuid.uuid4().hex[:10]
            self.items[qid] = {
                "id": qid, "mission": mission, "priority": int(priority),
                "deps": list(deps or []), "timeout": timeout or DEFAULT_TIMEOUT,
                "state": "queued", "attempts": 0, "max_retries": 3,
                "error": "", "created": time.time(), "updated": time.time(),
            }
            self._save()
            return dict(self.items[qid])

    def _ready(self):
        """Bağımlılıkları tamamlanmış, kuyruktaki görevler (priority desc)."""
        ready = []
        for q in self.items.values():
            if q["state"] not in ("queued", "retry"):
                continue
            if all(self.items.get(d, {}).get("state") in ("done",) for d in q["deps"]):
                ready.append(q)
        ready.sort(key=lambda q: (-q["priority"], q["created"]))
        return ready

    def schedule(self):
        return [q["id"] for q in self._ready()]

    def dequeue(self):
        with self._lock:
            ready = self._ready()
            if not ready:
                return None
            q = ready[0]
            q["state"] = "running"
            q["updated"] = time.time()
            q["attempts"] += 1
            self._save()
            return dict(q)

    def complete(self, qid):
        return self._transition(qid, "done")

    def cancel(self, qid):
        return self._transition(qid, "cancelled")

    def _transition(self, qid, state):
        with self._lock:
            q = self.items.get(str(qid))
            if not q:
                return None
            q["state"] = state
            q["updated"] = time.time()
            self._save()
            return dict(q)

    def retry(self, qid):
        """Başarısız görevi yeniden planla (max_retries sınırı)."""
        with self._lock:
            q = self.items.get(str(qid))
            if not q:
                return None
            if q["attempts"] >= q.get("max_retries", 3):
                q["state"] = "failed"
                q["error"] = (q.get("error", "") + " | max retries exceeded")[-300:]
                self._save()
                return dict(q)
            q["state"] = "retry"
            q["updated"] = time.time()
            self._save()
            return dict(q)

    def fail(self, qid, error):
        """Başarısız görev: sebebi kaydet + otomatik retry planı."""
        with self._lock:
            q = self.items.get(str(qid))
            if not q:
                return None
            q["error"] = str(error)[:300]
            q["updated"] = time.time()
            self._save()
            return self.retry(qid)

    def _timed_out(self):
        now = time.time()
        with self._lock:
            out = []
            for q in self.items.values():
                if q["state"] == "running" and now - q.get("updated", 0) > q.get("timeout", DEFAULT_TIMEOUT):
                    q["state"] = "timeout"
                    q["updated"] = now
                    out.append(q["id"])
            if out:
                self._save()
        return out

    def tick(self):
        """Zaman aşımı denetimi; planlanabilir görev sırasını döner."""
        timed_out = self._timed_out()
        return {"schedule": self.schedule(), "timed_out": timed_out}

    def status(self, qid=None):
        with self._lock:
            if qid:
                return dict(self.items.get(str(qid)) or {})
            rows = list(self.items.values())
        states = {}
        for q in rows:
            states[q["state"]] = states.get(q["state"], 0) + 1
        return {"count": len(rows), "states": states,
                "pending": [q["id"] for q in rows if q["state"] in ("queued", "retry", "running")]}

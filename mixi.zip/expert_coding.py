# -*- coding: utf-8 -*-
"""
Mixium — B8: Expert Level Coding Mode

Kaliteli sistemleri inceler ve "neden kaliteli?" sorusuna cevap verir:
mimari yapı, modül ayrımı, hata önleme, test stratejisi, performans
teknikleri. KOD KOPYALAMAZ — yalnızca prensip çıkarır.

MIXIUM'a bağımlı değildir (yalnızca stdlib ast).
"""

import ast
from pathlib import Path


class ExpertCoding:
    """Kod tabanından mühendislik prensipleri çıkarır."""

    def __init__(self, root=".", paths=None, ignore=("mcp_browser", "node_modules",
                                                      "__pycache__", ".mixium")):
        self.root = Path(root)
        self.paths = paths
        self.ignore = ignore

    def _files(self):
        if self.paths:
            return [Path(p) for p in self.paths if Path(p).suffix == ".py"]
        out = []
        for p in sorted(self.root.rglob("*.py")):
            rel = p.relative_to(self.root)
            if any(str(rel).startswith(i) for i in self.ignore):
                continue
            out.append(p)
        return out[:800]

    def analyze(self):
        """Proje geneli prensip çıkarımı."""
        files = self._files()
        principles = []
        modules = 0
        classes = 0
        funcs = 0
        docstrings = 0
        for f in files:
            modules += 1
            try:
                src = f.read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(src)
            except Exception:
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    classes += 1
                    if ast.get_docstring(node):
                        docstrings += 1
                elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    funcs += 1
                    if ast.get_docstring(node):
                        docstrings += 1
        if modules >= 5:
            principles.append("Modüler ayrım: %d modül — sorumlulukları ayrı dosyalara bölünmüş (separation of concerns)." % modules)
        if classes > 0 and docstrings > 0:
            principles.append("API belgeleme: class/function'ların %d%%'i docstring taşıyor (self-documenting API)."
                              % int(docstrings * 100 / max(1, classes + funcs)))
        if funcs > 0 and funcs / max(1, modules) > 8:
            principles.append("Kapsamlı arayüz: modül başına ~%d fonksiyon — araç kayıt sistemi geniş bir yüzey sunuyor."
                              % int(funcs / max(1, modules)))
        if modules > 20:
            principles.append("Ölçeklenebilir yapı: %d modül — mimari katmanlara ayrılmış (agent/tool/güvenlik/bilgi)." % modules)
        return {
            "principles": principles,
            "metrics": {"modules": modules, "classes": classes,
                        "functions": funcs, "docstrings": docstrings},
            "summary": "Bu sistem kaliteli çünkü: " + ("; ".join(principles[:4]) if principles else "yeterli örnek yok"),
        }

    def analyze_file(self, path):
        """Tek dosya için prensip çıkarımı."""
        p = Path(path)
        if not p.exists():
            return {"error": "dosya yok: %s" % path}
        try:
            src = p.read_text(encoding="utf-8", errors="replace")
            tree = ast.parse(src)
        except SyntaxError as e:
            return {"error": "syntax: %s" % e}
        classes = [n.name for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
        funcs = [n.name for n in ast.walk(tree)
                 if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        imports = []
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                imports += [a.name for a in n.names]
            elif isinstance(n, ast.ImportFrom):
                imports.append(n.module or "")
        return {
            "file": str(p), "classes": classes[:20], "functions": funcs[:30],
            "imports": sorted(set(imports))[:30],
            "line_count": len(src.splitlines()),
            "principles": self._file_principles(p, classes, funcs, src),
        }

    @staticmethod
    def _file_principles(p, classes, funcs, src):
        pr = []
        if len(classes) >= 2:
            pr.append("Sınıf ayrımı: %d class — her biri tek sorumluluk (SRP)." % len(classes))
        if len(funcs) >= 5:
            pr.append("Fonksiyonel yüzey: %d fonksiyon — tek iş yapan küçük fonksiyonlar." % len(funcs))
        if "lock" in src or "threading" in src:
            pr.append("Thread güvenliği: kilit kullanımı — paylaşılan state korunuyor.")
        if "try:" in src:
            pr.append("Hata izolasyonu: try/except — hata sistemin tamamını düşürmüyor.")
        if "os.replace" in src or "atomic" in src.lower():
            pr.append("Atomic yazma: tmp+replace — yarıda kesilen yazma riski yok.")
        return pr

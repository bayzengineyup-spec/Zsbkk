# -*- coding: utf-8 -*-
"""
Mixium — Git Awareness Layer (Aşama 12B)

- READ ONLY (direkt çalışır): status / diff / history / changed_files
- WRITE (zorunlu onay): commit / restore / reset / checkout
  -> PERM.check("bash") + hard_gate + approval_gate üzerinden geçer.
- Otomatik commit YASAK.

MIXIUM'a bağımlı değildir; `run_fn(cmd)` ve `approve_fn(tool, args)` enjekte
edilir (mixium_new gerçek bash + PERM + approval ile bağlar).
"""

import subprocess

READ_ONLY = {"status": "git status --short --branch",
             "diff": "git diff",
             "staged": "git diff --cached",
             "history": "git log --oneline -15 --graph --decorate",
             "branch": "git branch -a",
             "files": "git ls-files"}

WRITE_ACTIONS = {"commit", "restore", "reset", "checkout", "stash", "add"}


class GitManager:
    def __init__(self, root=".", run_fn=None, approve_fn=None):
        self.root = root
        self.run_fn = run_fn or self._default_run
        self.approve_fn = approve_fn or (lambda tool, args: (True, ""))

    @staticmethod
    def _default_run(cmd, cwd):
        r = subprocess.run(cmd, shell=True, cwd=cwd,
                           capture_output=True, text=True, timeout=60)
        return (r.stdout or "") + (r.stderr or "")

    def _is_repo(self):
        return self.run_fn("git rev-parse --is-inside-work-tree 2>/dev/null",
                           self.root).strip() == "true"

    # ---- READ ONLY ----
    def read_only(self, action):
        if action not in READ_ONLY:
            return "HATA: bilinmeyen read-only git aksiyonu: %s" % action
        if not self._is_repo():
            return "HATA: git deposu değil: %s" % self.root
        return self.run_fn(READ_ONLY[action], self.root)

    def status(self):
        return self.read_only("status")

    def diff(self):
        return self.read_only("diff")

    def history(self):
        return self.read_only("history")

    def changed_files(self):
        if not self._is_repo():
            return []
        out = self.run_fn("git status --porcelain", self.root)
        return [l[3:] for l in out.splitlines() if len(l) > 3]

    # ---- WRITE (onaylı) ----
    def write_action(self, action, **kw):
        if action not in WRITE_ACTIONS:
            return {"ok": False, "error": "bilinmeyen git write aksiyonu: %s" % action}
        # onay kapısı (PERM.check('bash') + hard_gate + approval)
        ok, why = self.approve_fn("bash", {"command": "git %s" % action})
        if not ok:
            return {"ok": False, "error": why}
        if action == "commit":
            msg = str(kw.get("message", "")).replace('"', '\\"')
            if not msg:
                return {"ok": False, "error": "commit mesajı gerekli"}
            out = self.run_fn('git add -A && git commit -m "%s"' % msg, self.root)
        elif action == "restore":
            target = str(kw.get("target", "-- .")).strip()
            out = self.run_fn("git restore %s" % target, self.root)
        elif action == "checkout":
            target = str(kw.get("target", "")).strip()
            if not target:
                return {"ok": False, "error": "checkout hedefi gerekli"}
            out = self.run_fn("git checkout %s" % target, self.root)
        else:
            extra = str(kw.get("extra", "")).strip()
            out = self.run_fn("git %s %s" % (action, extra), self.root)
        return {"ok": True, "output": out}

    def checkpoint(self):
        """Çalışan değişiklikleri stash ile işaretle (geri alınabilir)."""
        return self.write_action("stash", extra="push -u -m mixium-checkpoint")

    def restore(self, target="-- ."):
        return self.write_action("restore", target=target)

# -*- coding: utf-8 -*-
"""Mixium A31 — Future Planner (Uzun vadeli planlama).

"Bu sistem 1 yıl sonra neye ihtiyaç duyar?", "Nasıl ölçeklenir?", "Hangi özellik
eksik?" sorularına roadmap üretir. Sinyaller provider-enjeksiyonlu; uydurma
değer üretilmez — eksik sinyal yerine "bilinmiyor" kullanılır.
"""

import time


class FuturePlanner:
    def __init__(self, providers=None):
        self.providers = dict(providers or {})

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn() if callable(fn) else fn
            return default if v is None else v
        except Exception:
            return default

    def plan(self, horizon="1y"):
        arch = self._get("architecture", {})
        evolution = self._get("evolution", {})
        goals = self._get("goals", {})
        roadmap = []
        # eksik özellikler / risklerden gelecek ihtiyaçları türet
        issues = (evolution or {}).get("issues", [])
        for i, it in enumerate(issues[:8]):
            roadmap.append({
                "phase": "q%d" % (i + 1),
                "goal": "Çöz: %s" % str(it.get("issue"))[:160],
                "scale": "ölçekleme: bağımlılık/karmaşıklık azalt",
            })
        if not roadmap:
            roadmap.append({"phase": "q1", "goal": "İzleme: güvenlik + test otomasyonu genişlet",
                            "scale": "dikey: modüler sınırlar korunur"})
        return {
            "horizon": horizon,
            "roadmap": roadmap,
            "missing_features": (evolution or {}).get("suggestions", [])[:8],
            "scaling_notes": "dosya sınırı %s, riskli alan %s" % (
                arch.get("files", "bilinmiyor") if isinstance(arch, dict) else "bilinmiyor",
                len(arch.get("risky", [])) if isinstance(arch, dict) else "bilinmiyor"),
            "t": time.time(),
        }

    def status(self):
        return {"horizons": ["1y", "3y"], "roadmap": len(self.plan()["roadmap"])}

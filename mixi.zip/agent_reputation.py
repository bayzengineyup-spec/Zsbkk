# -*- coding: utf-8 -*-
"""Mixium A20 — agent reputation store."""
import json
import threading
import time
from pathlib import Path

class AgentReputation:
    def __init__(self, root=".", max_records=1000):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "agent_reputation.json"
        self.max_records = max(1, int(max_records))
        self._lock = threading.RLock(); self.records = []
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception: return False
    def _load(self):
        try:
            if self.path.exists():
                data = json.loads(self.path.read_text(encoding="utf-8")); self.records = data if isinstance(data, list) else []
        except Exception: self.records = []
    def _save(self):
        if not self._allowed(): return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True); tmp = self.path.with_suffix('.json.tmp')
            tmp.write_text(json.dumps(self.records[-self.max_records:], ensure_ascii=False, indent=1), encoding='utf-8'); tmp.replace(self.path); return True
        except Exception: return False

    def record(self, agent_id, role, success, accuracy=50, confidence=50, satisfaction=None, error=""):
        row = {"agent_id": str(agent_id), "role": str(role), "success": bool(success), "accuracy": max(0, min(100, float(accuracy))), "confidence": max(0, min(100, float(confidence))), "satisfaction": satisfaction, "error": str(error or '')[:500], "time": time.time()}
        with self._lock:
            self.records.append(row); self.records = self.records[-self.max_records:]; self._save()
        return dict(row)

    def score(self, agent_id=None, role=None):
        with self._lock: rows = [r for r in self.records if (agent_id is None or r['agent_id'] == str(agent_id)) and (role is None or r['role'] == str(role))]
        if not rows: return {"agent_id": agent_id, "role": role, "tasks": 0, "success_rate": 0, "accuracy": 0, "confidence": 0, "satisfaction": 0}
        sats = [float(r['satisfaction']) for r in rows if isinstance(r.get('satisfaction'), (int, float))]
        return {"agent_id": agent_id, "role": role, "tasks": len(rows), "success_rate": round(sum(r['success'] for r in rows)*100/len(rows),1), "accuracy": round(sum(r['accuracy'] for r in rows)/len(rows),1), "confidence": round(sum(r['confidence'] for r in rows)/len(rows),1), "satisfaction": round(sum(sats)/len(sats),1) if sats else 0}

    def leaderboard(self, limit=20):
        keys = {(r['agent_id'], r['role']) for r in self.records}
        rows = [self.score(a, role) for a, role in keys]
        rows.sort(key=lambda x: (-x['success_rate'], -x['accuracy']))
        return rows[:max(1, min(100, int(limit)))]
    def status(self): return {"records": len(self.records), "leaderboard": self.leaderboard(), "path": str(self.path)}

# -*- coding: utf-8 -*-
"""Mixium A27 — Deep Bug Hunter (Bug Discovery System).

Arar: mantık hataları, gizli buglar, edge case, performans sorunları,
güvenlik açıkları, UX sorunları. Bulduğunu sadece raporlamaz; A25
autonomous_fix ile: bul → analiz → çözüm üret → checkpoint → düzelt → test
→ başarılıysa devam. Fix engine enjekte edilir; yoksa yalnızca rapor.
"""

import time


class DeepBugHunter:
    def __init__(self, fix_engine=None, detect_fns=None):
        self.fix_engine = fix_engine  # A25 autonomous_fix.AutonomousFixEngine
        self.detect_fns = dict(detect_fns or {})
        self.findings = []

    def detect(self):
        """Tüm dedektörleri çalıştırıp bulguları toplar."""
        findings = []
        for name, fn in self.detect_fns.items():
            try:
                r = fn()
            except Exception as e:
                r = {"error": str(e)[:200]}
            findings.append({"source": name, "result": r})
        self.findings.extend(findings)
        return findings

    def hunt(self, max_fix_cycles=3):
        """detect → (fix engine varsa) fix → test döngüsü."""
        rec = {"detected": [], "fixed": 0, "records": []}
        findings = self.detect()
        rec["detected"] = findings
        if self.fix_engine is not None:
            # bulguları fix planına dönüştür (varsa plan alanı)
            plans = [f.get("result", {}).get("plan") for f in findings if isinstance(f.get("result"), dict)]
            plans = [p for p in plans if p][:max_fix_cycles]
            if plans:
                fr = self.fix_engine.run(plans)
                rec["fix"] = fr
                rec["fixed"] = fr.get("accepted", 0)
                rec["records"] = fr.get("records", [])
        return rec

    def status(self):
        return {"findings": len(self.findings), "detectors": sorted(self.detect_fns.keys())}

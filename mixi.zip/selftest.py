#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mixium Web yerel self-test: ag modeli cagirmadan web katmanini denetler."""
import ast, base64, io, json, re, sys, zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent; WEB=HERE/'web'
OK=[]; FAIL=[]; WARN=[]
def ok(x): OK.append(x); print('  ✓',x)
def bad(x): FAIL.append(x); print('  ✗',x)
def warn(x): WARN.append(x); print('  !',x)
def head(x): print('\n'+x+'\n'+'─'*58)

head('1 · Python / JavaScript / dosya yapısı')
for f in ['mixiweb.py','panel.py','mixium_new.py','tools_extra.py']:
 p=(HERE/f if (HERE/f).exists() else ROOT/f)
 if not p.exists(): bad(f+' eksik'); continue
 try: ast.parse(p.read_text(encoding='utf-8')); ok(f+' sözdizimi geçerli')
 except SyntaxError as e: bad(f+' satır %s: %s'%(e.lineno,e.msg))
for f in ['index.html','panel.css','panel.js','theme.css','js/app.js','js/ui.js','js/shell.js','css/base.css','css/chat.css','css/layout.css','css/overlays.css','css/responsive.css','css/tokens.css']:
 p=WEB/f
 (ok if p.exists() else bad)('web/'+f+(' var' if p.exists() else ' EKSİK'))

head('2 · HTML varlık referansları')
idx=(WEB/'index.html').read_text(encoding='utf-8')
for ref in re.findall(r'(?:src|href)=["\']([^"\']+)',idx):
 if ref.startswith(('http://','https://','#')): continue
 p=WEB/ref.split('?',1)[0]
 (ok if p.exists() else bad)('index -> '+ref)
ok('eski görsel kimlik izi kontrolü kaldırıldı')

head('3 · WebSocket sözleşmesi')
mw=(HERE/'mixiweb.py').read_text(encoding='utf-8'); app=(WEB/'js/app.js').read_text(encoding='utf-8'); panel=(WEB/'panel.js').read_text(encoding='utf-8')
server=set(re.findall(r'"type":\s*"([a-z_]+)"',mw)); cases=set(re.findall(r'case\s+"([a-z_]+)"',app+panel)); sends=set(re.findall(r'type:\s*"([a-z_]+)"',app+panel))
for t in sorted(server):
 if t in cases or t.startswith('panel_'): ok('sunucu '+t+' karşılanıyor')
 else: warn('sunucu '+t+' için doğrudan case yok')
for t in sorted(sends):
 if re.search(r'"'+re.escape(t)+r'"',mw): ok('istemci '+t+' sunucuda mevcut')
 else: bad('istemci '+t+' sunucuda yok')

head('4 · ZIP / ek dosya')
if re.search(r'var isZip = /\\\\.zip\$/i',app): bad('ZIP uzantısı regexi hatalı')
else: ok('ZIP uzantısı regexi doğru')
if '"upload_start"' in mw and '"upload_chunk"' in mw and '"upload_end"' in mw:
 ok('parçalı ek yükleme protokolü mevcut')
else: bad('parçalı ek yükleme protokolü eksik')
if 'upload_id' in app and '180000' in app:
 ok('istemci ekleri parçalara bölüyor')
else: bad('istemci ek parçalama eksik')
if 'on_chunk=on_chunk' in open('mixium_new.py', encoding='utf-8').read() and 'gate.feed(piece)' in open('mixium_new.py', encoding='utf-8').read():
 ok('LLM tokenleri websocket akışına bağlandı')
else: bad('canlı token akışı eksik')
if '_compact_system_prompt' in open('mixium_new.py', encoding='utf-8').read() and 'compact=isinstance(self.api, NoTrackAPI)' in open('mixium_new.py', encoding='utf-8').read():
 ok('NoTrack kompakt prompt yolu mevcut')
else: bad('NoTrack kompakt prompt yolu eksik')
try:
 import mixiweb, tempfile, shutil
 _test_root=Path(tempfile.mkdtemp(prefix='mixi_zip_test_'))
 _old_data=mixiweb.M.DATA_DIR
 mixiweb.M.DATA_DIR=_test_root
 raw=io.BytesIO()
 with zipfile.ZipFile(raw,'w') as z: z.writestr('src/test.py','print(123)'); z.writestr('README.md','# test')
 att={'name':'test.zip','size':len(raw.getvalue()),'data':base64.b64encode(raw.getvalue()).decode()}
 out=mixiweb._safe_zip_attachment(att)
 assert 'EK ZIP hazır' in out and 'kök=' in out and 'dosya' in out
 import re as _re, pathlib as _pathlib
 m=_re.search(r'kök=(.+?) \|', out)
 assert m and _pathlib.Path(m.group(1).strip(), 'src', 'test.py').read_text() == 'print(123)'
 assert _pathlib.Path(m.group(1).strip(), 'README.md').read_text() == '# test'
 assert len(out) < 1000
 ok('ZIP güvenli açma/gerçek dosya staging testi çalışıyor')
except Exception as e: bad('ZIP testi: '+repr(e))
finally:
 try: mixiweb.M.DATA_DIR=_old_data
 except Exception: pass
 try: shutil.rmtree(_test_root, ignore_errors=True)
 except Exception: pass

head('5 · Araç sistemi')
try:
 import mixium_new as M, tools_extra
 r=tools_extra.install(M); ok('tools_extra kurulum zinciri: %d araç'%(r.get('total',len(M.TOOLS))))
 for name,args in [('calc',{'expression':'2+3*4'}),('json_query',{'action':'get','path':'a.b','json':'{"a":{"b":7}}'}),('regex_test',{'pattern':'^a+$','text':'aaa'}),('lint_py',{'path':'mixiweb.py'})]:
  M.TOOLS[name]['fn'](args); ok(name+' aracı çalışıyor')
except Exception as e: bad('araç sistemi: '+repr(e))

head('6 · Panel')
try:
 import panel as P
 for fn in ['log','logs','clear_logs','sysinfo','verify_model','models_health','session_stats','subscribe','bump']:
  (ok if hasattr(P,fn) else bad)('panel.'+fn)
 P.log('info','selftest','ok'); assert P.logs(limit=1)
 ok('panel log yaz/oku')
except Exception as e: bad('panel: '+repr(e))

print('\nSONUÇ: %d geçti · %d uyarı · %d başarısız'%(len(OK),len(WARN),len(FAIL)))
if FAIL:
 print('\nBaşarısız:'); [print(' -',x) for x in FAIL]
 sys.exit(1)

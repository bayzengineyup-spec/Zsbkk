# -*- coding: utf-8 -*-
"""Mixium — Improvement Planner (Aşama 19D).

Produces proposals only. It cannot mutate security, model, files or runtime.
"""
import time
import uuid


class ImprovementPlanner:
    def __init__(self, max_proposals=10):
        self.max_proposals = max(1, int(max_proposals))
        self.history = []

    def analyze(self, observation=None, health=None, experience=None):
        observation = observation or {}; health = health or {}; experience = experience or {}
        proposals = []
        if health.get("system_health", 100) < 70:
            proposals.append(("system_health", "Sistem health provider'larını ve son hataları incele."))
        if observation.get("warnings"):
            proposals.append(("observer_warnings", "Tekrarlayan observer uyarıları için kontrollü test planı oluştur."))
        if experience.get("failures", 0) > experience.get("success", 0):
            proposals.append(("experience_failures", "Başarısız deneyimleri sınıflandır ve çözüm pattern'lerini doğrula."))
        components = health.get("components", {}) if isinstance(health, dict) else {}
        if isinstance(components.get("test_status"), dict) and components["test_status"].get("failed", 0):
            proposals.append(("testing", "Testing workflow ve debug loop sonuçlarını gözden geçir."))
        if not proposals:
            proposals.append(("continuous_observation", "Kullanım ve öğrenme sinyallerini izlemeye devam et."))
        result = []
        for area, text in proposals[:self.max_proposals]:
            result.append({"id": "proposal_" + uuid.uuid4().hex[:8], "area": area,
                           "proposal": text, "status": "proposed", "created": time.time()})
        self.history.extend(result); self.history = self.history[-100:]
        return result

    def status(self):
        return {"proposals": len(self.history), "recent": self.history[-20:]}

# -*- coding: utf-8 -*-
"""Mixium A20 — autonomous project manager.

Planning/reporting only. It does not execute code or modify permissions.
"""
import json
import threading
import time
import uuid
from pathlib import Path

class AutonomousProjectManager:
    def __init__(self, root='.', max_projects=50):
        self.root = Path(root).expanduser().resolve(); self.path = self.root/'.mixium'/'projects.json'; self.max_projects=max(1,int(max_projects)); self._lock=threading.RLock(); self.projects={}; self._load()
    def _allowed(self):
        try:
            p,r=self.path.resolve(),self.root.resolve(); return p==r or r in p.parents
        except Exception:return False
    def _load(self):
        try:
            if self.path.exists():
                d=json.loads(self.path.read_text(encoding='utf-8')); self.projects=d if isinstance(d,dict) else {}
        except Exception:self.projects={}
    def _save(self):
        if not self._allowed():return False
        try:
            self.path.parent.mkdir(parents=True,exist_ok=True); t=self.path.with_suffix('.json.tmp'); t.write_text(json.dumps(self.projects,ensure_ascii=False,indent=1),encoding='utf-8'); t.replace(self.path); return True
        except Exception:return False
    def create_project(self,title,goal=''):
        if not str(title or '').strip() or len(self.projects)>=self.max_projects:return None
        pid='project_'+uuid.uuid4().hex[:10]; p={'id':pid,'title':str(title)[:300],'goal':str(goal)[:2000],'status':'active','tasks':[],'created':time.time(),'updated':time.time()}; self.projects[pid]=p; self._save(); return dict(p)
    def add_task(self,project_id,title,role='research',priority=50):
        p=self.projects.get(str(project_id));
        if not p or not str(title or '').strip():return None
        t={'id':'ptask_'+uuid.uuid4().hex[:8],'title':str(title)[:500],'role':str(role),'priority':max(0,min(100,int(priority))),'status':'pending','result':None,'created':time.time()}; p['tasks'].append(t); p['updated']=time.time(); self._save(); return dict(t)
    def update_task(self,project_id,task_id,status=None,result=None,risk=None):
        p=self.projects.get(str(project_id));
        if not p:return None
        for t in p['tasks']:
            if t['id']==str(task_id):
                if status in ('pending','assigned','running','completed','failed','cancelled'):t['status']=status
                if result is not None:t['result']=str(result)[:2000]
                if risk is not None:t['risk']=str(risk)[:500]
                p['updated']=time.time(); self._save(); return dict(t)
        return None
    def status(self,project_id=None):
        rows=[self.projects[str(project_id)]] if project_id and str(project_id) in self.projects else list(self.projects.values()) if not project_id else []
        out=[]
        for p in rows:
            tasks=p.get('tasks',[]); done=sum(t.get('status')=='completed' for t in tasks); total=len(tasks); risks=[t.get('risk') for t in tasks if t.get('risk')]
            out.append({'id':p['id'],'title':p['title'],'status':p['status'],'tasks':tasks,'progress':round(done*100/total,1) if total else 0,'risks':risks[:20],'next_actions':[t['title'] for t in tasks if t.get('status') in ('pending','assigned')][:10]})
        return {'projects':out,'count':len(out),'path':str(self.path)}
    def report(self,project_id=None): return self.status(project_id)

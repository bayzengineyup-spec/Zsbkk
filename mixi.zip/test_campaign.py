# -*- coding: utf-8 -*-
"""Mixium A24G — Massive Test Campaign Engine.

Uzun süre çalışan test kampanyası: binlerce senaryo (kullanıcı davranışı,
kodlama, araştırma, dosya, hafıza, araç, hata) + checkpoint/pause/resume/
crash recovery. Senaryolar enjekte edilir; modül bağımsız çalışır.
"""

import json
import os
import time

STATES = ("idle", "running", "paused", "done", "failed")


class TestCampaign:
    def __init__(self, scenarios=None, root=".", persist_path=None):
        self.scenarios = list(scenarios or [])
        self.root = root
        self.persist_path = persist_path or os.path.join(root, ".mixium", "campaign.json")
        self.state = "idle"
        self.index = 0
        self.results = []
        self.started_at = None
        self._lock = None

    def _persist(self):
        try:
            os.makedirs(os.path.dirname(self.persist_path), exist_ok=True)
            with open(self.persist_path, "w") as f:
                json.dump({"state": self.state, "index": self.index,
                           "results": self.results[-1000:]}, f, ensure_ascii=False)
        except Exception:
            pass

    def start(self, run_fn=None):
        """Senaryoları sırayla çalıştırır (run_fn(scenario)->dict)."""
        if self.state == "running":
            return {"status": "already_running"}
        self.state = "running"
        self.started_at = time.time()
        if self.index == 0:
            self.results = []
        run_fn = run_fn or (lambda s: {"scenario": str(s)[:100], "status": "PASS"})
        try:
            while self.index < len(self.scenarios):
                if self.state == "paused":
                    break
                s = self.scenarios[self.index]
                try:
                    r = run_fn(s)
                except Exception as e:
                    r = {"scenario": str(s)[:100], "status": "ERROR", "error": str(e)[:200]}
                self.results.append(r)
                self.index += 1
                self._persist()
            if self.state != "paused":
                self.state = "done"
        except Exception:
            self.state = "failed"
        self._persist()
        return self.status()

    def pause(self):
        if self.state == "running":
            self.state = "paused"
            self._persist()
        return self.status()

    def resume(self, run_fn=None):
        if self.state == "paused":
            return self.start(run_fn)
        return self.status()

    def cancel(self):
        self.state = "idle"
        self.index = 0
        self.results = []
        self._persist()
        return self.status()

    def recover(self):
        """Crash sonrası kaldığı yerden devam (persist dosyasından)."""
        try:
            if os.path.exists(self.persist_path):
                with open(self.persist_path) as f:
                    d = json.load(f)
                self.state = d.get("state", "idle")
                self.index = d.get("index", 0)
                self.results = d.get("results", [])
                return {"status": "recovered", "state": self.state, "index": self.index}
        except Exception as e:
            return {"status": "recover_error", "error": str(e)[:200]}
        return {"status": "no_checkpoint"}

    def status(self):
        return {"state": self.state, "index": self.index,
                "total": len(self.scenarios), "done": self.index,
                "elapsed": round(time.time() - self.started_at, 1) if self.started_at else 0,
                "passed": sum(1 for r in self.results if r.get("status") == "PASS"),
                "failed": sum(1 for r in self.results if r.get("status") in ("FAIL", "ERROR"))}

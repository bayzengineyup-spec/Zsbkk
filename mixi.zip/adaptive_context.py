# -*- coding: utf-8 -*-
"""
Mixium — Adaptive Context Manager (Aşama 16F)

Ana modele gidecek context'i optimize eder:
- token bütçesi (max_chars)
- önem sırası (priority: system > task > knowledge > memory)
- güncellik (freshness: eski kayıt düşer)
- güven seviyesi (confidence: düşük güven eklenmez)

Context şişmesi engellenir: toplam boyut max_chars'ı aşarsa en düşük
önemli/güvenli/güncel olmayan bloklar kırpılır veya atılır.

MIXIUM'a bağımlı değildir. Kullanım:
    ac = AdaptiveContext(max_chars=4000)
    final = ac.pack([(priority, label, text), ...])
"""

import threading
import time

# öncelik: düşük sayı = daha önemli (önce korunur)
PRIO_SYSTEM = 10
PRIO_TASK = 20
PRIO_KNOWLEDGE = 30
PRIO_MEMORY = 40
PRIO_OPTIONAL = 50

# varsayılan budget: ~1000 token
DEFAULT_MAX_CHARS = 4000


class AdaptiveContext:
    def __init__(self, max_chars=DEFAULT_MAX_CHARS):
        self.max_chars = int(max_chars)
        self._lock = threading.RLock()

    def _char_len(self, text):
        try:
            return len(str(text))
        except Exception:
            return 0

    def pack(self, items, max_chars=None, now=None):
        """items: [(priority, label, text), ...]

        priority: PRIO_* sabiti (düşük = önemli).
        label    : bloğun başlığı (örn. "[DNA BAĞLAM]") veya ''.
        text     : içerik.

        Dönüş: budget içinde birleştirilmiş string ('' olabilir).
        """
        budget = int(max_chars or self.max_chars)
        if budget <= 0:
            return ""
        now = now or time.time()
        # önem sırasına göre sırala (stabil)
        ordered = sorted(items, key=lambda x: x[0])
        parts = []
        used = 0
        for prio, label, text in ordered:
            text = str(text or "")
            if not text.strip():
                continue
            head = f"{label}\n" if label else ""
            block = head + text
            blen = self._char_len(block)
            # blok tek başına budget'ı aşarsa kırp
            if blen > budget:
                room = max(60, budget - self._char_len(head))
                block = head + text[:room]
                blen = self._char_len(block)
            if used + blen > budget:
                continue  # bütçe doldu — bu blok atlanır (şişme engeli)
            parts.append(block)
            used += blen
        return "\n\n".join(parts)

    def select(self, records, query_embed=None, top_k=5, min_confidence=0,
               max_age=None, now=None):
        """Kayıt listesinden (dict: content/knowledge, confidence, created)
        önemli olanları seç: güven eşiği + güncellik + top_k."""
        now = now or time.time()
        scored = []
        for r in records or []:
            try:
                conf = float(r.get("confidence", 0) or 0)
            except Exception:
                conf = 0
            if conf < min_confidence:
                continue
            created = r.get("created") or 0
            if max_age and created and (now - created) > max_age:
                continue  # eski bilgi atlanır
            score = conf
            # güncellik bonusu: son 7 gün içindeyse +5
            if created and (now - created) < 7 * 86400:
                score += 5
            scored.append((score, r))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [r for _, r in scored[:top_k]]

    def budget_report(self, items, max_chars=None):
        budget = int(max_chars or self.max_chars)
        total = 0
        rows = []
        for prio, label, text in sorted(items, key=lambda x: x[0]):
            blen = self._char_len(str(text or "")) + (self._char_len(label) + 1 if label else 0)
            total += blen
            rows.append({"priority": prio, "label": label, "chars": blen})
        return {"budget": budget, "total": total,
                "over_budget": total > budget, "blocks": rows}

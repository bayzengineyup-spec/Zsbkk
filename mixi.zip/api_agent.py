# -*- coding: utf-8 -*-
"""
Mixium — API Tool Agent (Aşama 13E)

Güvenli REST çağrıları: GET/POST/PUT/DELETE.
- GET      : normal çalışır.
- POST/PUT/DELETE : approval_gate zorunlu (approve_fn enjekte edilir).
- Secret masking : Authorization / API-Key / Token / Cookie / Password / Secret
  değerleri hem istek yankısında hem yanıtta "***" yapılır (log'a secret yazılmaz).
- Limit : timeout + yanıt boyutu + exception isolation.

MIXIUM'a bağımlı değildir; http_fn (gerçek requests) + approve_fn enjekte edilir.
"""

import re

SECRET_HINTS = ("authorization", "x-api-key", "api-key", "apikey", "token",
                "cookie", "set-cookie", "password", "secret", "session")

_BEARER_RE = re.compile(r"(bearer\s+)[A-Za-z0-9._~+\/\-]+", re.I)
_HEADER_KV_RE = re.compile(
    r"([\"']?(?:%s)[\"']?\s*[:=]\s*)([\"']?)([^\"'\s,;]+)(\2)"
    % "|".join(SECRET_HINTS), re.I)


def mask_text(text):
    """Metin içindeki secret değerlerini maskele (header/JSON/token yankısı)."""
    if not isinstance(text, str):
        return text
    text = _BEARER_RE.sub(r"\1***", text)
    text = _HEADER_KV_RE.sub(r"\1\2***\4", text)
    return text


def mask_dict(d):
    """Dict içindeki secret anahtarların değerlerini maskele."""
    if not isinstance(d, dict):
        return d
    out = {}
    for k, v in d.items():
        key = str(k).lower()
        out[k] = "***" if any(h in key for h in SECRET_HINTS) else v
    return out


class ApiAgent:
    def __init__(self, http_fn=None, approve_fn=None, timeout=30,
                 max_bytes=500_000):
        self.http_fn = http_fn or self._default_http
        self.approve_fn = approve_fn or (lambda method, url, args: (True, ""))
        self.timeout = timeout
        self.max_bytes = max_bytes

    @staticmethod
    def _default_http(method, url, headers, body, auth, timeout):
        import requests
        kw = {"headers": headers, "timeout": timeout}
        if auth:
            if isinstance(auth, (list, tuple)):
                kw["auth"] = (auth[0], auth[1])
            elif isinstance(auth, dict):
                kw["headers"] = dict(headers or {})
                kw["headers"].update(auth)
            else:
                kw["auth"] = auth
        if body is not None:
            if isinstance(body, (dict, list)):
                kw["json"] = body
            else:
                kw["data"] = body
        r = requests.request(method, url, **kw)
        return r.status_code, dict(r.headers), (r.text or "")

    def call(self, method, url, headers=None, body=None, auth=None):
        """REST çağrısı; {ok, status, headers, body, error} döndürür."""
        method = str(method or "GET").upper()
        url = str(url or "").strip()
        if not url.startswith(("http://", "https://")):
            return {"ok": False, "error": "geçersiz URL"}
        # non-GET → approval gate (bypass yok)
        if method != "GET":
            ok, why = self.approve_fn(method, url, {
                "headers": mask_dict(headers or {}),
                "body": body, "auth": mask_dict(auth or {}) if isinstance(auth, dict) else auth})
            if not ok:
                return {"ok": False, "error": why}
        try:
            status, resp_headers, text = self.http_fn(
                method, url, headers, body, auth, self.timeout)
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}
        text = (text or "")
        if len(text) > self.max_bytes:
            text = text[:self.max_bytes] + "\n… [kesildi]"
        return {
            "ok": True,
            "status": status,
            "headers": mask_dict(resp_headers or {}),
            "body": mask_text(text),
        }

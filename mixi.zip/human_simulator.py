# -*- coding: utf-8 -*-
"""Mixium A24A — Human Behavior Simulator.

Gerçek insan kullanıcı davranışlarını üreten profil tabanlı simülatör.
Model "çalışıyor mu" değil, "gerçek insan kullanırken sorun çıkar mı" testi
için aksiyon akışları üretir. Model zekasını kısıtlayan filtre yoktur;
yalnızca kullanıcı davranışı üretir.
"""

DEFAULT_PROFILES = {
    "new_user": {
        "desc": "Yeni kullanıcı — basit sorular, kısa mesajlar",
        "messages": [
            "Merhaba, Mixium ne yapabilir?",
            "Basit bir Python fonksiyonu yazar mısın?",
            "Bu nasıl çalışıyor?",
        ],
        "behaviors": ["send_short", "ask_basic", "check_help"],
    },
    "expert_dev": {
        "desc": "Uzman yazılımcı — teknik, çok adımlı görevler",
        "messages": [
            "Refactor et: bu modülü SOLID'e uygun böl",
            "Test coverage'ı artır, regression ekle",
            "Bu kodun performans darboğazını bul",
        ],
        "behaviors": ["send_long", "give_complex_task", "review_answer"],
    },
    "product_manager": {
        "desc": "Ürün yöneticisi — hedef/öncelik/kapsam soruları",
        "messages": [
            "Bu özellik için kullanıcı hikayesi çıkar",
            "MVP kapsamını daralt, öncelik ver",
            "Riskleri ve bağımlılıkları listele",
        ],
        "behaviors": ["ask_scope", "ask_priority", "ask_risks"],
    },
    "bug_hunter": {
        "desc": "Hata avcısı — kötü/bozuk girdi, sınır testleri",
        "messages": [
            "Boş mesaj gönder",
            "Çok uzun ve özel karakterli: ��� ������ {{}",
            "workspace dışına yaz: /etc/passwd",
        ],
        "behaviors": ["send_empty", "send_malformed", "try_escape"],
    },
    "long_task_user": {
        "desc": "Uzun görev veren — saatler süren işler",
        "messages": [
            "Tüm projeyi analiz et, mimari rapor çıkar",
            "Büyük refactor yap ve test et",
            "Kapsamlı araştırma yap ve raporla",
        ],
        "behaviors": ["send_huge_task", "expect_progress", "check_duration"],
    },
    "critical_thinker": {
        "desc": "Kritik düşünen — cevabı sorgular, çelişki arar",
        "messages": [
            "Bu cevap önceki cevabınla çelişiyor, açıkla",
            "Varsayımlarını listele",
            "Alternatif yaklaşımları da göster",
        ],
        "behaviors": ["challenge_answer", "ask_assumptions", "ask_alternatives"],
    },
}


class HumanSimulator:
    def __init__(self, profiles=None):
        self.profiles = dict(profiles or DEFAULT_PROFILES)
        self.sessions = []

    def profile_names(self):
        return sorted(self.profiles.keys())

    def generate(self, profile, n=1):
        """Bir profilden n adet kullanıcı aksiyonu üret."""
        p = self.profiles.get(profile)
        if not p:
            return []
        out = []
        msgs = p.get("messages", [])
        behs = p.get("behaviors", [])
        for i in range(n):
            out.append({
                "profile": profile,
                "seq": i,
                "message": msgs[i % len(msgs)] if msgs else "",
                "behavior": behs[i % len(behs)] if behs else "generic",
            })
        return out

    def simulate(self, profile, send_fn=None, n=1):
        """Aksiyonları sırayla `send_fn(message)` üzerinden oynatır.

        send_fn yoksa yalnızca aksiyon listesi döner (dry-run).
        """
        actions = self.generate(profile, n)
        results = []
        for a in actions:
            rec = {"profile": profile, "message": a["message"],
                   "behavior": a["behavior"], "ok": None, "error": None}
            if send_fn is not None:
                try:
                    rec["ok"] = True
                    rec["result"] = send_fn(a["message"])
                except Exception as e:
                    rec["ok"] = False
                    rec["error"] = str(e)[:200]
            results.append(rec)
        self.sessions.append({"profile": profile, "actions": results})
        return results

    def status(self):
        return {
            "profiles": self.profile_names(),
            "sessions": len(self.sessions),
            "last": self.sessions[-1] if self.sessions else None,
        }

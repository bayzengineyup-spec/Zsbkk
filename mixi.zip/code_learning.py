# -*- coding: utf-8 -*-
"""
Mixium — Code Intelligence Evolution (Aşama 15C)

Kaliteli kodları analiz edip PRENSİP çıkarır (kod kopyalama YOK):
    mimari yapılar, design pattern, hata önleme, test stratejisi, performans.

Heuristic tabanlıdır (LLM gerektirmez); çıkarılan prensipler PatternMemory'ye
yazılabilir. MIXIUM'a bağımlı değildir.
"""


class CodeLearning:
    def __init__(self, pattern_store=None):
        self.pattern_store = pattern_store

    def extract_principles(self, code_text):
        """Kod metninden prensip listesi çıkarır (deterministik, kopyalama yok)."""
        lines = (code_text or "").splitlines()
        principles = []
        has_class = any(l.strip().startswith("class ") for l in lines)
        has_func = any(l.strip().startswith(("def ", "async def ")) for l in lines)
        has_async = any(l.strip().startswith("async ") for l in lines)
        has_try = any("try:" in l for l in lines)
        has_doc = any('"""' in l or "'''" in l for l in lines)
        has_test = any(("assert " in l) or l.strip().startswith("def test_")
                       or l.strip().startswith("test_") for l in lines)

        imports = [l.strip() for l in lines
                   if l.strip().startswith(("import ", "from "))]
        mods = set()
        for i in imports:
            parts = i.split()
            if parts and len(parts) > 1 and not parts[1].startswith("."):
                mods.add(parts[1].split(".")[0])

        if has_class and has_func:
            principles.append("sınıf + fonksiyon ayrımı (modüler yapı)")
        if len(mods) >= 3:
            principles.append("çok modüllü ayrıştırma (%d modül)" % len(mods))
        if has_async:
            principles.append("asenkron/paralel yürütme kullanımı")
        if has_try:
            principles.append("hata yakalama (try/except) kullanılmış")
        if has_test:
            principles.append("test kapsamı mevcut (assert/test_*)")
        if has_doc:
            principles.append("dokümantasyon/docstring mevcut")
        return principles

    def learn_from_code(self, code_text, name="code pattern", source=""):
        principles = self.extract_principles(code_text)
        if self.pattern_store is not None and principles:
            self.pattern_store.add_pattern(
                name, "prensip çıkarımı: %s" % name, principles,
                source=source, confidence=60)
        return principles

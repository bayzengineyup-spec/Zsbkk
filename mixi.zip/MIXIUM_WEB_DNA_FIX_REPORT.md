# Mixium Web/DNA Düzeltme Raporu

- NoTrack web akışında compact system prompt yerine CLI ile aynı tam system prompt kullanıldı.
- Mixium uygulama seviyesinde içerik/moderasyon filtresi eklemiyor; gerçek Permission/Sandbox/Approval güvenliği korunuyor.
- Web oturumu localStorage ile kalıcılaştırıldı; yeniden bağlanınca son oturum resume ediliyor.
- WebSocket DNA status ve DNA model seçimi eklendi.
- DNA model seçici üst arayüze eklendi ve model listesiyle bağlandı.
- Python syntax/import başlangıç testi yapıldı.
- JavaScript syntax kontrolü yapıldı.
- Web sunucusu kısa smoke test ile başlatıldı.

Not: Upstream model sağlayıcısının kendi politika/filtre davranışı Mixium tarafından kaldırılamaz; bu değişiklikler yalnızca Mixium'un kendi prompt/arayüz katmanındaki ek kısıtları kaldırır. Sistem güvenlik kontrolleri bilerek korunmuştur.

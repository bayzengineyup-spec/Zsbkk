# -*- coding: utf-8 -*-
"""Mixium — Goal Engine (Aşama 19A).

Long-lived goals are stored under .mixium/goals.json. This module tracks
intent and progress only; it never performs file or system actions.
"""
import json
import threading
import time
import uuid
from pathlib import Path

STATUSES = ("active", "paused", "completed", "cancelled")


class GoalEngine:
    def __init__(self, root=".", max_goals=200):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "goals.json"
        self.max_goals = max_goals
        self._lock = threading.RLock()
        self.goals = {}
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                data = json.loads(self.path.read_text(encoding="utf-8"))
                self.goals = data if isinstance(data, dict) else {}
        except Exception:
            self.goals = {}

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.goals, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def create_goal(self, title, description="", priority=50, milestones=None):
        title = str(title or "").strip()
        if not title:
            return None
        with self._lock:
            if len(self.goals) >= self.max_goals:
                return None
            now = time.time()
            mid = []
            for item in milestones or []:
                if isinstance(item, str):
                    item = {"title": item}
                if isinstance(item, dict) and item.get("title"):
                    mid.append({"id": uuid.uuid4().hex[:8], "title": str(item["title"]),
                                "status": "pending", "progress": 0})
            gid = "goal_" + uuid.uuid4().hex[:10]
            goal = {"id": gid, "title": title, "description": str(description or "")[:4000],
                    "priority": max(0, min(100, int(priority))), "status": "active",
                    "progress": 0, "created": now, "updated": now, "milestones": mid}
            self.goals[gid] = goal
            self._save()
            return dict(goal)

    def get(self, goal_id):
        with self._lock:
            goal = self.goals.get(str(goal_id))
            return dict(goal) if goal else None

    def list_goals(self, status=None):
        with self._lock:
            rows = [dict(g) for g in self.goals.values()
                    if status is None or g.get("status") == status]
        rows.sort(key=lambda g: (-g.get("priority", 0), g.get("created", 0)))
        return rows

    def update_goal(self, goal_id, progress=None, status=None, description=None,
                    priority=None, milestone_id=None, milestone_status=None):
        with self._lock:
            g = self.goals.get(str(goal_id))
            if not g:
                return None
            if progress is not None:
                g["progress"] = max(0, min(100, int(progress)))
            if status in STATUSES:
                g["status"] = status
            if description is not None:
                g["description"] = str(description)[:4000]
            if priority is not None:
                g["priority"] = max(0, min(100, int(priority)))
            if milestone_id:
                for m in g.get("milestones", []):
                    if m.get("id") == milestone_id:
                        if milestone_status in ("pending", "active", "completed", "cancelled"):
                            m["status"] = milestone_status
                        if milestone_status == "completed":
                            m["progress"] = 100
                        break
            if g.get("progress", 0) >= 100 and g.get("status") == "active":
                g["status"] = "completed"
            g["updated"] = time.time()
            self._save()
            return dict(g)

    def complete_goal(self, goal_id):
        return self.update_goal(goal_id, progress=100, status="completed")

    def analyze_progress(self, goal_id=None):
        rows = [self.get(goal_id)] if goal_id else self.list_goals()
        rows = [g for g in rows if g]
        result = []
        for g in rows:
            ms = g.get("milestones", [])
            done = sum(1 for m in ms if m.get("status") == "completed")
            suggested = self.suggest_next_action(g["id"])
            result.append({"id": g["id"], "title": g["title"],
                           "status": g["status"], "progress": g.get("progress", 0),
                           "milestones_done": done, "milestones_total": len(ms),
                           "next_action": suggested})
        return result[0] if goal_id and result else result

    def suggest_next_action(self, goal_id):
        g = self.get(goal_id)
        if not g:
            return "goal bulunamadı"
        for m in g.get("milestones", []):
            if m.get("status") in ("pending", "active"):
                return "Milestone başlat: %s" % m.get("title", "")
        if g.get("progress", 0) < 100:
            return "Hedef için bir sonraki küçük adımı tanımla ve ilerlemeyi güncelle."
        return "Hedef tamamlandı; sonucu değerlendir ve yeni hedef belirle."

    def status(self):
        rows = self.list_goals()
        return {"total": len(rows), "active": sum(g["status"] == "active" for g in rows),
                "completed": sum(g["status"] == "completed" for g in rows),
                "average_progress": round(sum(g.get("progress", 0) for g in rows) / len(rows), 1) if rows else 0,
                "goals": rows[:20]}

# -*- coding: utf-8 -*-
"""Mixium A22 — Failure Intelligence.

Records cause/solution/method/prevention for every failure and links to
DebugLoop, Experience Learning and Memory through injected callbacks.
"""
import json
import threading
import time
import uuid
from pathlib import Path


class FailureIntelligence:
    def __init__(self, root=".", experience_fn=None, memory_fn=None, max_records=500):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "failure_intelligence.json"
        self.max_records = max(1, int(max_records))
        self.experience_fn = experience_fn
        self.memory_fn = memory_fn
        self._lock = threading.RLock()
        self.records = []
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.records = d if isinstance(d, list) else []
        except Exception:
            self.records = []

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.records, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def record_failure(self, task, cause, solution="", method="", prevention="", context=None):
        rec = {"id": "fail_" + uuid.uuid4().hex[:10], "task": str(task)[:800], "cause": str(cause)[:800],
               "solution": str(solution)[:800], "method": str(method)[:500], "prevention": str(prevention)[:500],
               "context": dict(context or {}), "time": time.time()}
        with self._lock:
            self.records.append(rec)
            self.records = self.records[-self.max_records:]
            self._save()
        # Link to experience learning + memory (injected, isolated)
        if self.experience_fn:
            try:
                self.experience_fn(str(task), str(method) or str(cause), success=False, error=str(cause), pattern=str(prevention) or "failure:" + str(cause))
            except Exception:
                pass
        if self.memory_fn:
            try:
                self.memory_fn("HATA ÖNLEME: %s — %s" % (str(cause)[:200], str(prevention)[:200]))
            except Exception:
                pass
        return dict(rec)

    def lookup(self, cause_substr="", limit=20):
        q = str(cause_substr or "").lower()
        with self._lock:
            rows = [dict(r) for r in self.records if not q or q in r.get("cause", "").lower() or q in r.get("task", "").lower()]
        return rows[-max(1, min(100, int(limit))):]

    def prevention_tips(self, limit=10):
        with self._lock:
            seen, tips = set(), []
            for r in reversed(self.records):
                if r.get("prevention") and r["prevention"] not in seen:
                    seen.add(r["prevention"]); tips.append(r["prevention"])
                if len(tips) >= limit:
                    break
        return tips

    def status(self):
        with self._lock:
            return {"records": len(self.records), "prevention_tips": self.prevention_tips(), "path": str(self.path)}

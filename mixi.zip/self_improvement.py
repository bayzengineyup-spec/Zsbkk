# -*- coding: utf-8 -*-
"""
Mixium — Self Improvement Loop (Aşama 14E)

Döngü: Observe -> Analyze -> Find Weakness -> Research Solution ->
Create Improvement Proposal -> User Approval -> Apply.

ÖNEMLİ: kendi kendine kritik sistemleri değiştiremez. Her büyük değişiklik
approval_gate + permission + checkpoint üzerinden geçer. Bu modül yalnızca
ÖNERİ üretir; uygulama (apply_proposal) approval_fn onayı olmadan çalışmaz.

MIXIUM'a bağımlı değildir; approval_fn + apply_fn enjekte edilir.
"""


class SelfImprovementLoop:
    def __init__(self, approval_fn=None, apply_fn=None, max_proposals=3):
        self.approval_fn = approval_fn or (lambda p: (False, "onay yok"))
        self.apply_fn = apply_fn or (lambda p: {"ok": False,
                                                "error": "apply bağlı değil"})
        self.max_proposals = max_proposals

    def generate_proposals(self, intelligence):
        """Zayıf alanlardan iyileştirme önerileri üretir (uygulamaz)."""
        proposals = []
        for w in (intelligence or {}).get("weaknesses", [])[:self.max_proposals]:
            proposals.append({"id": "imp_%d" % len(proposals),
                              "area": w,
                              "proposal": "İyileştir: %s" % w,
                              "status": "proposed"})
        return proposals

    def apply_proposal(self, proposal):
        """Onay kapısı + permission üzerinden uygula (bypass YOK)."""
        ok, why = self.approval_fn(proposal)
        if not ok:
            return {"ok": False, "error": why, "status": "rejected"}
        r = self.apply_fn(proposal)
        if isinstance(r, dict):
            r.setdefault("status", "applied")
            return r
        return {"ok": True, "result": r, "status": "applied"}

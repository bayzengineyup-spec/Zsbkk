#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mixiweb.py'ye Yonetim Paneli baglayan yama.
==========================================
Calistir:  python3 patch_panel.py
Idempotent: iki kez calistirilirsa ikinci sefer atlar.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE / "mixiweb.py"

if not SRC.exists():
    print("mixiweb.py bulunamadi:", SRC)
    sys.exit(1)

s = SRC.read_text(encoding="utf-8")
orig = s
changed = []

# ── 1) panel modulunu import et ────────────────────────────────
if "import panel as PANEL" not in s:
    s = s.replace(
        "import mixium_new as M  # noqa: E402",
        "import mixium_new as M  # noqa: E402\n"
        "sys.path.insert(0, str(_HERE))\n"
        "import panel as PANEL  # noqa: E402  (yonetim paneli arka ucu)",
        1
    )
    changed.append("import panel")

# ── 2) _send icine bayt sayaci + WS abonelik altyapisi ─────────
if "def _panel_sub(" not in s:
    hook = '''

# ── yonetim paneli koprusu ─────────────────────────────────────
_panel_subs = {}          # id(ws) -> gonderici fonksiyon


def _panel_sub(ws):
    """Bu WS'i canli log akisina abone eder."""
    def _fn(obj):
        try:
            _send(ws, obj)
        except Exception:
            pass
    _panel_subs[id(ws)] = _fn
    PANEL.subscribe(_fn)


def _panel_unsub(ws):
    fn = _panel_subs.pop(id(ws), None)
    if fn:
        PANEL.unsubscribe(fn)


def _panel_handle(ws, msg, c):
    """panel_* mesajlarini karsilar. True donerse mesaj islendi."""
    t = msg.get("type", "")
    if not t.startswith("panel_"):
        return False

    if t == "panel_sys":
        _send(ws, {"type": "panel_sys", "data": PANEL.sysinfo(M)})

    elif t == "panel_logs":
        _send(ws, {"type": "panel_logs",
                   "rows": PANEL.logs(limit=int(msg.get("limit", 400)))})

    elif t == "panel_clear_logs":
        PANEL.clear_logs()
        _send(ws, {"type": "panel_logs", "rows": PANEL.logs(limit=50)})

    elif t == "panel_models":
        _send(ws, {"type": "panel_models", "rows": PANEL.models_health(M)})

    elif t == "panel_sessions":
        _send(ws, {"type": "panel_sessions",
                   "data": PANEL.session_stats(WEB_CHAT_DIR)})

    elif t == "panel_test_model":
        mid = msg.get("model") or ""
        ai = msg.get("ai") or ""

        def _run_test():
            res = PANEL.verify_model(M, mid, ai)
            _send(ws, {"type": "panel_test_result",
                       "model": mid, "ai": res.get("ai"),
                       "ok": res["ok"], "ms": res["ms"],
                       "reply": res["reply"], "error": res["error"]})
        threading.Thread(target=_run_test, daemon=True).start()

    return True

'''
    # _send tanimindan hemen sonra ekle
    m = re.search(r"\ndef _send_sess_list\(ws\):", s)
    if m:
        s = s[:m.start()] + hook + s[m.start():]
        changed.append("panel bridge")

# ── 3) WS baglanti aninda: abone ol + log ──────────────────────
if "_panel_sub(ws)" not in s:
    s = s.replace(
        "    c = ClientSession()\n    _clients[id(ws)] = c\n    try:",
        "    c = ClientSession()\n    _clients[id(ws)] = c\n"
        "    _panel_sub(ws)\n"
        "    PANEL.bump(\"ws_connects\")\n"
        "    PANEL.log(\"info\", \"ws\", \"istemci baglandi\")\n"
        "    try:",
        1
    )
    changed.append("ws connect log")

# ── 4) mesaj dongusune panel yonlendirme ───────────────────────
if "_panel_handle(ws, msg, c)" not in s:
    s = s.replace(
        '            mtype = msg.get("type", "")\n            if mtype == "chat":',
        '            mtype = msg.get("type", "")\n'
        '            if mtype.startswith("panel_"):\n'
        '                _panel_handle(ws, msg, c)\n'
        '                continue\n'
        '            if mtype == "chat":',
        1
    )
    changed.append("panel routing")

# ── 5) set_model'e log + sayac + GERCEK dogrulama ──────────────
if 'PANEL.bump("model_switches")' not in s:
    old = '''            elif mtype == "set_model":
                if c.sess:
                    c.sess.model = msg.get("model") or c.sess.model
                    c.sess.ai_name = msg.get("ai") or c.sess.ai_name
                    c.sess.save()
                    _send(ws, {"type": "model_ok",
                               "model": c.sess.model, "ai": c.sess.ai_name})'''
    new = '''            elif mtype == "set_model":
                if c.sess:
                    _prev = c.sess.model
                    _new = msg.get("model") or c.sess.model
                    _ai = msg.get("ai") or ""
                    # ai_name'i model listesinden dogrula: yanlis ai ile
                    # istek atilirsa model sessizce degismis gibi gorunur.
                    if not _ai:
                        for _m in (getattr(M.API, "models", []) or []):
                            if isinstance(_m, dict) and _m.get("id") == _new:
                                _ai = _m.get("ai_name") or ""
                                break
                    c.sess.model = _new
                    c.sess.ai_name = _ai or c.sess.ai_name
                    c.sess.save()
                    PANEL.bump("model_switches")
                    PANEL.log("ok", "model",
                              "model degisti: %s -> %s (ai=%s)"
                              % (_prev, c.sess.model, c.sess.ai_name))
                    _send(ws, {"type": "model_ok",
                               "model": c.sess.model, "ai": c.sess.ai_name})'''
    if old in s:
        s = s.replace(old, new, 1)
        changed.append("set_model dogrulama")

# ── 6) agent kosusuna log kancalari ────────────────────────────
if 'PANEL.bump("runs")' not in s:
    s = s.replace(
        '    sink = _Sink(q)\n    _sink_holder["sink"] = sink',
        '    sink = _Sink(q)\n    _sink_holder["sink"] = sink\n'
        '    PANEL.bump("runs")\n'
        '    PANEL.log("info", "agent", "kosu basladi · model=%s"\n'
        '              % getattr(session, "model", "?"))',
        1
    )
    changed.append("run start log")

if 'PANEL.bump("runs_err")' not in s:
    s = s.replace(
        '        q.put(("error", f"{e}\\n{tb[-1500:]}"))',
        '        PANEL.bump("runs_err")\n'
        '        PANEL.log("error", "agent", "kosu hatasi: %s" % e)\n'
        '        q.put(("error", f"{e}\\n{tb[-1500:]}"))',
        1
    )
    changed.append("run error log")

if 'PANEL.bump("runs_ok")' not in s:
    s = s.replace(
        '        result = agent.run(user_msg)\n        q.put(("final", result))',
        '        result = agent.run(user_msg)\n'
        '        PANEL.bump("runs_ok")\n'
        '        PANEL.log("ok", "agent", "kosu tamamlandi")\n'
        '        q.put(("final", result))',
        1
    )
    changed.append("run ok log")

# ── 7) _Sink.push icinde arac cagrilarini logla ────────────────
if "PANEL.bump(\"tool_calls\")" not in s:
    m = re.search(r"    def push\(self, s\):\n", s)
    if m:
        ins = ('    def push(self, s):\n'
               '        try:\n'
               '            _t = str(s)\n'
               '            if _t.lstrip().startswith(("⏵", "▸", "»", "$")) or \\\n'
               '               ("(" in _t and _t.strip().endswith(")")):\n'
               '                PANEL.bump("tool_calls")\n'
               '                PANEL.log("debug", "tool", _t.strip()[:180])\n'
               '        except Exception:\n'
               '            pass\n')
        s = s[:m.start()] + ins + s[m.end():]
        changed.append("tool call log")

# ── 8) yeni web dosyalarini index'e baglamak icin: statik servis
#      zaten WEB_DIR'i sunuyor, ek is yok.

if s != orig:
    SRC.write_text(s, encoding="utf-8")
    print("mixiweb.py yamalandi:", ", ".join(changed))
else:
    print("degisiklik yok (zaten yamali)")

/* Mixium IDE Preview */
(function(){
 const modal=document.getElementById("previewModal");
 const frame=document.getElementById("previewFrame");
 const code=document.getElementById("previewCode");
 const name=document.getElementById("previewName");
 if(!modal)return;
 window.MixiumPreview={
  canPreview(n){return /\.(html?|svg|md)$/i.test(n||"")},
  open(file){
   modal.hidden=false;
   name.textContent=file.name||"";
   code.textContent=file.content||"";
   if(/\.html?$/i.test(file.name||"")) frame.srcdoc=file.content||"";
  }
 };
 document.getElementById("previewClose").onclick=()=>modal.hidden=true;
 document.getElementById("previewCodeBtn").onclick=()=>{code.hidden=false;frame.hidden=true};
 document.getElementById("previewRunBtn").onclick=()=>{code.hidden=true;frame.hidden=false};
})();

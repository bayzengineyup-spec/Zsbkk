/* ============================================================
   YÖNETİM PANELİ — istemci mantığı
   Panel.init(send) ile bağlanır; WS mesajlarını Panel.on(msg) alır.
   Sekmeler: genel · loglar · modeller · oturumlar · sistem
   ============================================================ */
(function (global) {
  "use strict";

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var send = null;
  var el = {};          // panel DOM referansları
  var open = false;
  var tab = "genel";
  var logs = [];        // {id,ts,level,src,msg}
  var LOG_MAX = 1200;
  var sys = null;
  var models = [];
  var sessions = null;
  var errCount = 0;
  var filt = { level: "all", src: "all", q: "" };
  var autoScroll = true;
  var pollTimer = null;

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function hhmmss(ts) {
    var d = new Date(ts * 1000);
    return ("0" + d.getHours()).slice(-2) + ":" +
           ("0" + d.getMinutes()).slice(-2) + ":" +
           ("0" + d.getSeconds()).slice(-2);
  }
  function ago(ts) {
    var s = Math.max(0, (Date.now() / 1000) - ts);
    if (s < 60) return Math.floor(s) + " sn önce";
    if (s < 3600) return Math.floor(s / 60) + " dk önce";
    if (s < 86400) return Math.floor(s / 3600) + " sa önce";
    return Math.floor(s / 86400) + " gün önce";
  }
  function num(n) {
    if (n == null) return "—";
    return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  }

  /* ---------------------------------------------------------- */
  /* DOM iskeleti                                                */
  /* ---------------------------------------------------------- */
  function build() {
    var ov = document.createElement("div");
    ov.id = "panelOverlay";
    document.body.appendChild(ov);

    var p = document.createElement("aside");
    p.id = "panel";
    p.setAttribute("role", "dialog");
    p.setAttribute("aria-label", "Yönetim paneli");
    p.innerHTML =
      '<header id="panelHead">' +
        '<div class="mx-panel-mark" aria-hidden="true"><span></span></div>' +
        '<div>' +
          '<div class="ttl">Yönetim Paneli</div>' +
          '<div class="sub">mixium · sistem konsolu</div>' +
        '</div>' +
        '<div class="spacer"></div>' +
        '<span class="pulse-dot" id="panelPulse" title="canlı"></span>' +
        '<button class="btn btn-ghost btn-icon" id="panelRefresh" title="Yenile">' +
          '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">' +
          '<path d="M14 8a6 6 0 1 1-1.8-4.3M14 2v4h-4"/></svg>' +
        '</button>' +
        '<button class="btn btn-ghost btn-icon" id="panelClose" title="Kapat (Esc)">' +
          '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round">' +
          '<path d="M3 3l8 8M11 3l-8 8"/></svg>' +
        '</button>' +
      '</header>' +

      '<nav id="panelTabs">' +
        '<button class="ptab on" data-tab="genel">Genel Bakış</button>' +
        '<button class="ptab" data-tab="loglar">Loglar <span class="cnt" id="tabLogCnt">0</span></button>' +
        '<button class="ptab" data-tab="modeller">Modeller</button>' +
        '<button class="ptab" data-tab="dna">DNA & Efor</button>' +
        '<button class="ptab" data-tab="oturumlar">Oturumlar</button>' +
        '<button class="ptab" data-tab="sistem">Sistem</button>' +
      '</nav>' +

      '<div id="panelBody">' +
        '<section class="pview on" data-view="genel"   id="vGenel"></section>' +
        '<section class="pview"    data-view="loglar"  id="vLoglar">' +
          '<div id="logBar">' +
            '<select class="picker" id="logLevel">' +
              '<option value="all">tüm seviyeler</option>' +
              '<option value="debug">debug+</option>' +
              '<option value="info">info+</option>' +
              '<option value="warn">uyarı+</option>' +
              '<option value="error">yalnız hata</option>' +
            '</select>' +
            '<select class="picker" id="logSrc">' +
              '<option value="all">tüm kaynaklar</option>' +
              '<option value="ws">ws</option><option value="agent">agent</option>' +
              '<option value="api">api</option><option value="model">model</option>' +
              '<option value="session">session</option><option value="tool">tool</option>' +
              '<option value="http">http</option><option value="panel">panel</option>' +
            '</select>' +
            '<input id="logSearch" placeholder="logda ara…" autocomplete="off">' +
            '<button class="btn btn-ghost" id="logAuto" title="Otomatik kaydır">⭳ oto</button>' +
            '<button class="btn btn-ghost" id="logCopy">kopyala</button>' +
            '<button class="btn btn-ghost" id="logClear">temizle</button>' +
          '</div>' +
          '<div id="logList"></div>' +
        '</section>' +
        '<section class="pview" data-view="modeller"  id="vModeller"></section>' +
        '<section class="pview" data-view="dna"       id="vDna"></section>' +
        '<section class="pview" data-view="oturumlar" id="vOturumlar"></section>' +
        '<section class="pview" data-view="sistem"    id="vSistem"></section>' +
      '</div>';
    document.body.appendChild(p);

    el.ov = ov; el.p = p;
    el.body = $("#panelBody");
    el.logList = $("#logList");
    el.tabLogCnt = $("#tabLogCnt");
    el.pulse = $("#panelPulse");

    /* --- olaylar --- */
    ov.addEventListener("click", close);
    $("#panelClose").addEventListener("click", close);
    $("#panelRefresh").addEventListener("click", function () { refresh(true); });

    p.querySelectorAll(".ptab").forEach(function (b) {
      b.addEventListener("click", function () { setTab(b.dataset.tab); });
    });

    $("#logLevel").addEventListener("change", function () {
      filt.level = this.value; renderLogs();
    });
    $("#logSrc").addEventListener("change", function () {
      filt.src = this.value; renderLogs();
    });
    $("#logSearch").addEventListener("input", function () {
      filt.q = this.value.trim().toLowerCase(); renderLogs();
    });
    $("#logClear").addEventListener("click", function () {
      logs = []; errCount = 0; renderLogs(); tell({ type: "panel_clear_logs" });
    });
    $("#logCopy").addEventListener("click", function () {
      var txt = visibleLogs().map(function (r) {
        return hhmmss(r.ts) + " [" + r.level + "] " + r.src + " · " + r.msg;
      }).join("\n");
      navigator.clipboard && navigator.clipboard.writeText(txt);
      toast("Loglar panoya kopyalandı");
    });
    $("#logAuto").addEventListener("click", function () {
      autoScroll = !autoScroll;
      this.style.color = autoScroll ? "var(--brass-2)" : "";
      this.textContent = autoScroll ? "⭳ oto" : "⏸ sabit";
    });
    $("#logAuto").style.color = "var(--brass-2)";

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && open) { close(); }
      // Ctrl/Cmd + Shift + P → panel
      if ((e.ctrlKey || e.metaKey) && e.shiftKey &&
          (e.key === "P" || e.key === "p")) {
        e.preventDefault(); toggle();
      }
    });
  }

  function toast(m) {
    if (global.__toast) global.__toast(m);
  }
  function tell(obj) { if (send) { try { send(obj); } catch (e) {} } }

  /* ---------------------------------------------------------- */
  /* açma / kapama                                               */
  /* ---------------------------------------------------------- */
  function show() {
    open = true;
    el.ov.classList.add("open");
    el.p.classList.add("open");
    setLive(true);
    refresh(true);
    /* Panel açıldığında kullanıcıya gerçekten canlı olduğunu göster. */
    if (!logs.length) {
      addLog({ id: "local-" + Date.now(), ts: Date.now()/1000, level: "info", src: "panel", msg: "Yönetim paneli bağlandı; canlı veriler isteniyor." });
      setTimeout(function () { if (open) tell({ type: "panel_logs", limit: 400 }); }, 250);
    }
    clearInterval(pollTimer);
    pollTimer = setInterval(function () {
      tell({ type: "panel_sys" });
      tell({ type: "panel_logs", limit: 400 });
    }, 4000);
  }
  function close() {
    open = false;
    el.ov.classList.remove("open");
    el.p.classList.remove("open");
    clearInterval(pollTimer); pollTimer = null;
  }
  function toggle() { open ? close() : show(); }

  function refresh(full) {
    tell({ type: "panel_sys" });
    tell({ type: "panel_models" });
    tell({ type: "panel_sessions" });
    tell({ type: "panel_dna" });
    if (full) tell({ type: "panel_logs", limit: 400 });
  }

  function setTab(name) {
    tab = name;
    el.p.querySelectorAll(".ptab").forEach(function (b) {
      b.classList.toggle("on", b.dataset.tab === name);
    });
    el.p.querySelectorAll(".pview").forEach(function (v) {
      v.classList.toggle("on", v.dataset.view === name);
    });
    if (name === "loglar") { renderLogs(); }
    else if (name === "modeller") { renderModels(); }
    else if (name === "dna") { renderDNA(); }
    else if (name === "oturumlar") { renderSessions(); }
    else if (name === "sistem") { renderSystem(); }
    else { renderOverview(); }
  }

  /* ---------------------------------------------------------- */
  /* 1) Genel Bakış                                              */
  /* ---------------------------------------------------------- */
  function renderOverview() {
    var v = $("#vGenel"); if (!v) return;
    var s = sys || {};
    var st = s.stats || {};
    var mem = s.mem || {};
    var ld = s.load || {};
    var mx = s.mixium || {};

    var memPct = mem.pct == null ? 0 : mem.pct;
    var memCls = memPct > 85 ? "err" : (memPct > 65 ? "warn" : "");
    var loadPct = (ld["1"] != null && ld.cpus)
      ? Math.min(100, Math.round(100 * ld["1"] / ld.cpus)) : 0;
    var loadCls = loadPct > 85 ? "err" : (loadPct > 60 ? "warn" : "");

    v.innerHTML =
      '<div class="eyebrow" style="margin-bottom:12px">Anlık Durum</div>' +
      '<div class="pgrid">' +
        card("Çalışma süresi", s.uptime_h || "—", "accent") +
        card("Aktif model", mx.main_model || "—") +
        card("İzin modu", mx.perm_mode || "—") +
        card("Yüklü araç", num(mx.tool_count)) +
        card("Koşu (toplam)", num(st.runs), "accent") +
        card("Hatalı koşu", num(st.runs_err)) +
        card("Araç çağrısı", num(st.tool_calls)) +
        card("Model değişimi", num(st.model_switches)) +
      '</div>' +

      '<div class="eyebrow" style="margin:20px 0 12px">Kaynak Kullanımı</div>' +
      '<div class="pgrid">' +
        '<div class="pcard"><div class="k">Bellek (süreç)</div>' +
          '<div class="v">' + (mem.rss_mb == null ? "—" : mem.rss_mb) +
          '<small>MB</small></div>' +
          '<div class="pbar ' + memCls + '"><i style="width:' + memPct + '%"></i></div>' +
          '<div class="k" style="margin-top:6px">sistem %' + memPct + '</div></div>' +
        '<div class="pcard"><div class="k">Yük (1 dk)</div>' +
          '<div class="v">' + (ld["1"] == null ? "—" : ld["1"]) +
          '<small>/' + (ld.cpus || "?") + ' çekirdek</small></div>' +
          '<div class="pbar ' + loadCls + '"><i style="width:' + loadPct + '%"></i></div></div>' +
        card("İş parçacığı", num(s.threads)) +
        card("Disk boş", (s.disk && s.disk.free_gb != null ? s.disk.free_gb + " GB" : "—")) +
      '</div>' +

      '<div class="eyebrow" style="margin:20px 0 12px">Son Olaylar</div>' +
      '<div id="ovLogs"></div>';

    var last = logs.slice(-9).reverse();
    $("#ovLogs").innerHTML = last.length
      ? '<div id="logListMini" style="font-family:var(--f-mono);font-size:11.5px">' +
        last.map(logRowHTML).join("") + '</div>'
      : '<div class="log-empty">Henüz olay yok.</div>';
  }

  function card(k, v, cls) {
    return '<div class="pcard ' + (cls || "") + '"><div class="k">' + esc(k) +
           '</div><div class="v">' + esc(v) + '</div></div>';
  }

  /* ---------------------------------------------------------- */
  /* 2) Loglar                                                   */
  /* ---------------------------------------------------------- */
  var LV = ["debug", "info", "ok", "warn", "error"];

  function visibleLogs() {
    return logs.filter(function (r) {
      if (filt.level !== "all") {
        if (filt.level === "error") { if (r.level !== "error") return false; }
        else {
          var mn = LV.indexOf(filt.level);
          if (mn >= 0 && LV.indexOf(r.level) < mn) return false;
        }
      }
      if (filt.src !== "all" && r.src !== filt.src) return false;
      if (filt.q && (r.msg + " " + r.src).toLowerCase().indexOf(filt.q) < 0) return false;
      return true;
    });
  }

  function logRowHTML(r) {
    return '<div class="logrow lv-' + esc(r.level) + '">' +
      '<span class="t">' + hhmmss(r.ts) + '</span>' +
      '<span class="s">' + esc(r.src) + '</span>' +
      '<span class="m">' + esc(r.msg) + '</span>' +
    '</div>';
  }

  function renderLogs() {
    if (!el.logList) return;
    var rows = visibleLogs();
    el.tabLogCnt && (el.tabLogCnt.textContent = logs.length);
    if (!rows.length) {
      el.logList.innerHTML = '<div class="log-empty">' +
        (logs.length ? "Filtreye uyan log yok." : "Henüz log kaydı yok.") + '</div>';
      return;
    }
    el.logList.innerHTML = rows.map(logRowHTML).join("");
    if (autoScroll) el.logList.scrollTop = el.logList.scrollHeight;
  }

  function addLog(r) {
    logs.push(r);
    if (logs.length > LOG_MAX) logs.splice(0, logs.length - LOG_MAX);
    if (r.level === "error") {
      errCount++;
      var b = $("#panelBtn");
      if (b && !open) b.classList.add("has-error");
    }
    el.tabLogCnt && (el.tabLogCnt.textContent = logs.length);
    if (open && tab === "loglar") {
      var rows = visibleLogs();
      if (rows.length && rows[rows.length - 1] === r) {
        var empty = el.logList.querySelector(".log-empty");
        if (empty) el.logList.innerHTML = "";
        el.logList.insertAdjacentHTML("beforeend", logRowHTML(r));
        while (el.logList.children.length > LOG_MAX)
          el.logList.removeChild(el.logList.firstChild);
        if (autoScroll) el.logList.scrollTop = el.logList.scrollHeight;
      }
    } else if (open && tab === "genel") {
      renderOverview();
    }
  }

  /* ---------------------------------------------------------- */
  /* 3) Modeller — gerçek sınama                                 */
  /* ---------------------------------------------------------- */
  var testing = {};   // model_id -> true
  var results = {};   // model_id -> {ok,ms,reply,error}

  function renderModels() {
    var v = $("#vModeller"); if (!v) return;
    var cur = (global.state && global.state.model) || null;

    v.innerHTML =
      '<div class="eyebrow" style="margin-bottom:10px">Model Doğrulama</div>' +
      '<p style="font-size:12.5px;color:var(--ink-dim);margin:0 0 14px;line-height:1.6">' +
        'Her satırdaki <b>Sına</b> düğmesi modele gerçek bir istek atar. ' +
        'Dönen cevap ve gecikme aşağıda görünür — böylece seçilen modelin ' +
        'sahiden çalıştığı kanıtlanır.</p>' +
      '<div style="margin-bottom:14px">' +
        '<button class="btn btn-brass" id="testAll">Tümünü sına</button> ' +
        '<button class="btn" id="testCur">Aktif modeli sına</button>' +
      '</div>' +
      '<div id="modelRows"></div>';

    var rows = models.map(function (m) {
      var r = results[m.id];
      var isCur = m.id === cur;
      var right = testing[m.id]
        ? '<span class="testing"></span>'
        : (r ? '<span class="res ' + (r.ok ? "ok" : "err") + '">' +
               (r.ok ? "✓ " + r.ms + " ms" : "✕ hata") + '</span>'
             : '<span class="res" style="color:var(--ink-faint)">sınanmadı</span>');
      var html =
        '<div class="mrow' + (isCur ? " active" : "") + '" data-id="' + esc(m.id) + '">' +
          (isCur ? '<span class="badge badge-brass">aktif</span>' : "") +
          '<span class="mid">' + esc(m.id) + '</span>' +
          '<span class="mai">' + esc(m.ai || "—") + '</span>' +
          right +
          '<button class="btn btn-ghost m-test" data-id="' + esc(m.id) +
            '" data-ai="' + esc(m.ai || "") + '">Sına</button>' +
          '<button class="btn btn-ghost m-use" data-id="' + esc(m.id) +
            '" data-ai="' + esc(m.ai || "") + '">Seç</button>' +
        '</div>';
      if (r && (r.reply || r.error)) {
        html += '<div class="mreply">' + esc(r.reply || r.error) + '</div>';
      }
      return html;
    }).join("");

    $("#modelRows").innerHTML = rows ||
      '<div class="log-empty">Model listesi boş — bağlantı bekleniyor.</div>';

    v.querySelectorAll(".m-test").forEach(function (b) {
      b.addEventListener("click", function () {
        testModel(b.dataset.id, b.dataset.ai);
      });
    });
    v.querySelectorAll(".m-use").forEach(function (b) {
      b.addEventListener("click", function () {
        tell({ type: "set_model", model: b.dataset.id, ai: b.dataset.ai });
        toast("Model seçildi: " + b.dataset.id);
        setTimeout(renderModels, 350);
      });
    });
    var ta = $("#testAll"), tc = $("#testCur");
    ta && ta.addEventListener("click", function () {
      models.forEach(function (m, i) {
        setTimeout(function () { testModel(m.id, m.ai); }, i * 250);
      });
    });
    tc && tc.addEventListener("click", function () {
      var c = (global.state && global.state.model);
      if (c) testModel(c, global.state.ai);
    });
  }

  function testModel(id, ai) {
    if (!id || testing[id]) return;
    testing[id] = true;
    renderModels();
    tell({ type: "panel_test_model", model: id, ai: ai || "" });
  }

  /* ---------------------------------------------------------- */
  /* 4) Oturumlar                                                */
  /* ---------------------------------------------------------- */
  function renderSessions() {
    var v = $("#vOturumlar"); if (!v) return;
    var s = sessions || {};
    var byModel = s.by_model || {};
    var mrows = Object.keys(byModel).sort(function (a, b) {
      return byModel[b] - byModel[a];
    });

    v.innerHTML =
      '<div class="eyebrow" style="margin-bottom:12px">Oturum Özeti</div>' +
      '<div class="pgrid">' +
        card("Oturum sayısı", num(s.count), "accent") +
        card("Toplam mesaj", num(s.messages)) +
        card("Disk", (s.kb != null ? s.kb + " KB" : "—")) +
        card("Ort. mesaj/oturum",
             s.count ? Math.round((s.messages || 0) / s.count) : "—") +
      '</div>' +

      '<div class="eyebrow" style="margin:20px 0 8px">Modele Göre Dağılım</div>' +
      (mrows.length
        ? '<table class="ptable"><thead><tr><th>Model</th><th style="text-align:right">Oturum</th><th style="text-align:right">Pay</th></tr></thead><tbody>' +
          mrows.map(function (k) {
            var pct = s.count ? Math.round(100 * byModel[k] / s.count) : 0;
            return '<tr><td class="mono">' + esc(k) + '</td>' +
              '<td class="num">' + byModel[k] + '</td>' +
              '<td class="num">%' + pct + '</td></tr>';
          }).join("") + '</tbody></table>'
        : '<div class="log-empty">Kayıt yok.</div>') +

      '<div class="eyebrow" style="margin:20px 0 8px">Son Oturumlar</div>' +
      ((s.recent && s.recent.length)
        ? '<table class="ptable"><thead><tr><th>Başlık</th><th>Model</th><th style="text-align:right">Msj</th><th>Değişim</th></tr></thead><tbody>' +
          s.recent.map(function (r) {
            return '<tr><td>' + esc(r.title) + '</td>' +
              '<td class="mono">' + esc(r.model) + '</td>' +
              '<td class="num">' + r.n + '</td>' +
              '<td class="mono">' + ago(r.mtime) + '</td></tr>';
          }).join("") + '</tbody></table>'
        : '<div class="log-empty">Kayıt yok.</div>');
  }

  /* ---------------------------------------------------------- */
  /* 5) Sistem                                                   */
  /* ---------------------------------------------------------- */
  function renderSystem() {
    var v = $("#vSistem"); if (!v) return;
    var s = sys || {};
    var mx = s.mixium || {};
    function kv(o) {
      return '<dl class="pkv">' + Object.keys(o).map(function (k) {
        return '<dt>' + esc(k) + '</dt><dd>' + esc(o[k]) + '</dd>';
      }).join("") + '</dl>';
    }
    v.innerHTML =
      '<div class="eyebrow" style="margin-bottom:10px">Çalışma Ortamı</div>' +
      kv({
        "PID": s.pid, "Python": s.python, "Platform": s.platform,
        "Mimari": s.machine, "Çalışma dizini": s.cwd,
        "İş parçacığı": s.threads, "Açılış": s.uptime_h
      }) +
      '<div class="eyebrow" style="margin:20px 0 10px">Mixium Çekirdeği</div>' +
      kv({
        "API adresi": mx.base_api, "Ana model": mx.main_model,
        "Hızlı model": mx.fast_model, "AI sağlayıcı": mx.main_ai,
        "Model sayısı": mx.model_count, "İzin modu": mx.perm_mode,
        "Araç sayısı": mx.tool_count,
        "Token var mı": mx.has_token ? "evet" : "hayır",
        "Polling": mx.polling ? "açık" : "kapalı"
      }) +
      '<div class="eyebrow" style="margin:20px 0 10px">Yüklü Araçlar</div>' +
      '<div style="display:flex;flex-wrap:wrap;gap:6px">' +
        ((mx.tools || []).map(function (t) {
          return '<span class="badge">' + esc(t) + '</span>';
        }).join("") || '<span class="log-empty">Liste okunamadı.</span>') +
      '</div>';
  }

  /* ---------------------------------------------------------- */
  /* 4) DNA & Efor                                              */
  /* ---------------------------------------------------------- */
  var dnaData = null;

  function renderDNA() {
    var v = $("#vDna"); if (!v) return;
    v.innerHTML = '<div style="padding:16px;color:var(--muted)">Yükleniyor…</div>';
    tell({ type: "panel_dna" });
  }

  function renderDNAData(d) {
    dnaData = d;
    var v = $("#vDna"); if (!v) return;

    var cats = d.categories || {};
    var recs = d.records || [];
    var totalRecs = 0;
    Object.keys(cats).forEach(function (k) { totalRecs += cats[k]; });

    // Efor ve düşünme durumu
    var curEffort = d.effort || "normal";
    var curThinking = !!d.thinking;

    var html =
      '<div class="eyebrow" style="margin-bottom:12px">DNA Model Yönetimi</div>' +

      // DNA Model seçimi
      '<div class="pcard" style="margin-bottom:16px">' +
        '<div class="pcard-h"><b>DNA Modeli</b></div>' +
        '<div class="pcard-b">' +
          '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">' +
            '<select id="dnaModelSelect" class="picker" style="flex:1;min-width:140px">' +
              '<option value="">— seçilmedi —</option>' +
              '<option value="A"' + (d.model === "A" ? " selected" : "") + '>A — Minimax 3.0</option>' +
              '<option value="B"' + (d.model === "B" ? " selected" : "") + '>B — ChatGPT 5.5</option>' +
              '<option value="C"' + (d.model === "C" ? " selected" : "") + '>C — NoTrack v1</option>' +
            '</select>' +
            '<button class="btn btn-primary" id="dnaModelSet" style="white-space:nowrap">Ayarla</button>' +
          '</div>' +
          '<div style="margin-top:8px;font-size:12px;color:var(--muted)">DNA modeli, arka plan öğrenme ve analiz işlemleri için kullanılır. Sohbet modelinden bağımsızdır.</div>' +
        '</div>' +
      '</div>' +

      // Efor seviyesi
      '<div class="pcard" style="margin-bottom:16px">' +
        '<div class="pcard-h"><b>Efor Seviyesi</b></div>' +
        '<div class="pcard-b">' +
          '<div style="display:flex;gap:6px;flex-wrap:wrap">' +
            ["düşük", "normal", "yüksek", "maksimum"].map(function (e) {
              var isActive = e === curEffort;
              var labels = { "düşük": "Düşük · Hızlı", "normal": "Normal · Dengeli", "yüksek": "Yüksek · Detaylı", "maksimum": "Maksimum · Derin" };
              return '<button class="btn ' + (isActive ? "primary" : "sec") + ' dna-effort" data-effort="' + e + '">' +
                (isActive ? "● " : "") + esc(labels[e]) + '</button>';
            }).join("") +
          '</div>' +
          '<div style="margin-top:8px;font-size:12px;color:var(--muted)">Aktif: <b>' + esc(curEffort) + '</b> — model hızını ve yanıt kalitesini etkiler.</div>' +
        '</div>' +
      '</div>' +

      // Düşünme modu
      '<div class="pcard" style="margin-bottom:16px">' +
        '<div class="pcard-h"><b>Gerçek Düşünme Modu</b></div>' +
        '<div class="pcard-b">' +
          '<div style="display:flex;align-items:center;gap:10px">' +
            '<button class="btn ' + (curThinking ? "primary" : "sec") + '" id="dnaThinking">' +
              (curThinking ? "● Açık" : "Kapalı") +
            '</button>' +
            '<span style="font-size:12px;color:var(--muted)">Açıkken model her yanıtı vermeden önce adım adım düşünür.</span>' +
          '</div>' +
        '</div>' +
      '</div>' +

      // Kategori dağılımı
      '<div class="eyebrow" style="margin:20px 0 10px">DNA Bilgi Deposu · ' + num(totalRecs) + ' kayıt</div>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin-bottom:16px">' +
        Object.keys(cats).map(function (k) {
          return '<div class="pcard"><div class="pcard-b" style="text-align:center">' +
            '<div style="font-size:24px;font-weight:700;color:var(--accent)">' + num(cats[k]) + '</div>' +
            '<div style="font-size:11px;color:var(--muted);text-transform:uppercase">' + esc(k) + '</div>' +
          '</div></div>';
        }).join("") +
      '</div>' +

      // Son DNA işlemleri
      '<div class="eyebrow" style="margin:20px 0 10px">Son DNA İşlemleri</div>' +
      '<div id="dnaOpsList" style="max-height:300px;overflow-y:auto">';

    if (!recs.length) {
      html += '<div class="log-empty">Henüz DNA kaydı yok.</div>';
    } else {
      recs.slice(0, 30).forEach(function (r) {
        var cat = r.category || "?";
        var content = (r.content || "").slice(0, 120);
        var conf = r.confidence || 0;
        html +=
          '<div class="plog-row" style="padding:6px 8px;border-bottom:1px solid var(--border)">' +
            '<div style="display:flex;justify-content:space-between;align-items:start">' +
              '<div style="flex:1;min-width:0">' +
                '<div style="font-size:12px"><span class="badge" style="margin-right:6px">' + esc(cat) + '</span>' +
                '<span style="color:var(--muted);font-size:11px">güven: ' + conf + '%</span></div>' +
                '<div style="margin-top:2px;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(content) + '</div>' +
              '</div>' +
              '<button class="btn btn-ghost dna-rb" data-rid="' + esc(r.id || "") + '" title="Geri al" style="flex-shrink:0;padding:2px 6px;font-size:11px">↩</button>' +
            '</div>' +
          '</div>';
      });
    }

    html += '</div>';
    v.innerHTML = html;

    // Event listeners
    var setBtn = $("#dnaModelSet");
    var sel = $("#dnaModelSelect");
    if (setBtn && sel) {
      setBtn.onclick = function () {
        tell({ type: "panel_set_dna_model", model: sel.value });
      };
    }
    var thinkBtn = $("#dnaThinking");
    if (thinkBtn) {
      thinkBtn.onclick = function () {
        // Global düşünme toggle
        if (window.App) {
          window.App.state.thinking = !window.App.state.thinking;
          window.App.send({ type: "set_thinking", on: window.App.state.thinking });
          thinkBtn.textContent = window.App.state.thinking ? "● Açık" : "Kapalı";
          thinkBtn.className = "btn " + (window.App.state.thinking ? "primary" : "sec");
        }
      };
    }
    v.querySelectorAll(".dna-effort").forEach(function (btn) {
      btn.onclick = function () {
        var eff = btn.dataset.effort;
        if (window.App) {
          window.App.send({ type: "set_effort", effort: eff });
          window.App.state.effort = eff;
          toast("Efor: " + eff, "ok");
          setTimeout(function () { tell({ type: "panel_dna" }); }, 500);
        }
      };
    });
    v.querySelectorAll(".dna-rb").forEach(function (btn) {
      btn.onclick = function () {
        var rid = btn.dataset.rid;
        if (rid) tell({ type: "panel_dna_rollback", record_id: rid });
      };
    });
  }

  /* ---------------------------------------------------------- */
  /* WS mesaj yönlendirme                                        */
  /* ---------------------------------------------------------- */
  function on(m) {
    switch (m.type) {
      case "panel_log":
        setLive(true);
        addLog(m.rec); return true;
      case "panel_logs":
        setLive(true);
        logs = m.rows || [];
        errCount = logs.filter(function (r) { return r.level === "error"; }).length;
        renderLogs(); if (tab === "genel") renderOverview(); return true;
      case "panel_sys":
        setLive(true);
        sys = m.data || {};
        if (open && tab === "genel") renderOverview();
        if (open && tab === "sistem") renderSystem();
        return true;
      case "panel_models":
        models = m.rows || [];
        if (open && tab === "modeller") renderModels();
        return true;
      case "panel_sessions":
        sessions = m.data || {};
        if (open && tab === "oturumlar") renderSessions();
        return true;
      case "panel_dna":
        if (open && tab === "dna") renderDNAData(m.data || {});
        return true;
      case "panel_dna_model_ok":
        toast("DNA modeli: " + m.model, "ok");
        return true;
      case "panel_dna_rollback_ok":
        toast(m.ok ? "DNA rollback başarılı" : "Kayıt bulunamadı", m.ok ? "ok" : "warn");
        return true;
      case "panel_test_result":
        testing[m.model] = false;
        results[m.model] = {
          ok: !!m.ok, ms: m.ms || 0,
          reply: m.reply || "", error: m.error || ""
        };
        if (open && tab === "modeller") renderModels();
        toast(m.ok ? ("Sınama tamam: " + m.model + " · " + m.ms + " ms")
                   : ("Sınama başarısız: " + m.model));
        return true;
    }
    return false;
  }

  function setLive(ok) {
    if (el.pulse) el.pulse.classList.toggle("off", !ok);
  }

  function init(sendFn) {
    send = sendFn;
    build();
    return API;
  }

  var API = {
    init: init, on: on, show: show, close: close, toggle: toggle,
    refresh: refresh, setLive: setLive,
    isOpen: function () { return open; },
    errCount: function () { return errCount; }
  };
  global.Panel = API;
})(window);

/* ============================================================
   presence.js — Mixium'un yerel çalışma/think durum animasyonu
   ============================================================ */
(function (global) {
  "use strict";
  var active = null, listeners = [], lastState = "idle";
  var TOOL_STATE = {
    bash:"work",shell:"work",run:"work",exec:"work",read:"read",cat:"read",view:"read",open:"read",
    write:"write",edit:"write",patch:"write",apply:"write",create:"write",append:"write",replace:"write",
    search:"search",grep:"search",find:"search",glob:"search",ls:"search",tree:"search",list:"search",
    web:"search",fetch:"search",http:"search",curl:"search",browse:"search",crawl:"search",
    think:"think",plan:"think",todo:"think",task:"think",python:"work",node:"work",npm:"work",pip:"work",
    git:"work",test:"work",build:"work",format:"work",lint:"work",diff:"read",sql:"work",db:"work",
    image:"work",chart:"work",pdf:"read",download:"work"
  };
  var LABEL={idle:"hazır",think:"düşünüyor",search:"araştırıyor",read:"inceliyor",write:"yazıyor",work:"çalışıyor",talk:"yanıtlıyor",done:"tamamlandı",error:"bir sorun oluştu"};

  function make(opts){
    opts=opts||{};
    var n=document.createElement("div");
    n.className="mx-presence mx-presence--"+(opts.size===48?"hero":"small");
    n.dataset.state=opts.state||"idle";
    n.setAttribute("aria-hidden","true");
    n.innerHTML='<span class="mx-core"></span><span class="mx-ring mx-ring-a"></span><span class="mx-ring mx-ring-b"></span><span class="mx-scan"></span><span class="mx-dot mx-dot-1"></span><span class="mx-dot mx-dot-2"></span><span class="mx-dot mx-dot-3"></span>';
    return n;
  }
  function set(el,s){ if(!el)return; el.dataset.state=s||"idle"; }
  function claim(el){ if(active&&active!==el) freeze(active,"idle"); active=el||null; if(active){active.classList.remove("mx-frozen");active.dataset.live="1";} return active; }
  function freeze(el,s){ if(!el)return; delete el.dataset.live; set(el,s||"idle"); el.classList.add("mx-frozen"); }
  function unfreeze(el){ if(el)el.classList.remove("mx-frozen"); }
  function state(s,opts){ lastState=s||"idle"; if(active){unfreeze(active);set(active,lastState);} emit(lastState,opts||{}); return lastState; }
  function release(finalState){ var el=active, s=finalState||"done"; lastState=s; if(el){set(el,s); el.classList.add("mx-release"); setTimeout(function(){ if(el){el.classList.remove("mx-release");freeze(el,s==="error"?"error":"idle");}}, s==="error"?900:700);} active=null; emit(s,{final:true}); }
  function stateForTool(name){ var k=String(name||"").toLowerCase(); if(TOOL_STATE[k])return TOOL_STATE[k]; for(var x in TOOL_STATE)if(k.indexOf(x)!==-1)return TOOL_STATE[x]; return "work"; }
  function tool(name){return state(stateForTool(name),{tool:name});}
  function current(){return active;} function currentState(){return lastState;}
  function on(fn){listeners.push(fn);return function(){off(fn);};} function off(fn){var i=listeners.indexOf(fn);if(i>=0)listeners.splice(i,1);}
  function emit(s,m){listeners.slice().forEach(function(fn){try{fn(s,m||{});}catch(e){}});}
  var H=[[/```|def |function |class |import |const |<\w+>/,"write"],[/aranıyor|arıyorum|tarıyor|bakıyorum/i,"search"],[/okuyorum|inceliyorum|dosyayı aç/i,"read"],[/çalıştır|kuruyorum|derliyor|komut/i,"work"],[/düşün|plan|önce|adım/i,"think"]];
  function sniff(t){if(!t)return null;for(var i=0;i<H.length;i++)if(H[i][0].test(t))return H[i][1];return null;}
  function label(s){return LABEL[s]||s||"hazır";}
  global.Mascot={make:make,claim:claim,freeze:freeze,unfreeze:unfreeze,state:state,tool:tool,release:release,current:current,currentState:currentState,stateForTool:stateForTool,sniff:sniff,on:on,off:off,label:label};
})(window);

/* ============================================================
   okto_pilot.js — Maskot pilotu
   ------------------------------------------------------------
   · Sayfada TEK bir ahtapot vardır.
   · Her zaman EN SON mesajın ÜSTÜNDE durur.
   · Yeni mesaj gelince yukarı sıçrar (op-leap) ve yeni mesajın
     üstüne konar (op-hop).
   · Mascot modülünün durum yayınlarını dinler ve ahtapotu
     think / write / tool / error / done durumlarına sokar.
   ============================================================ */
(function (W) {
  "use strict";

  var host = null;      // .msg-mascot kabı
  var pus  = null;      // .oktopus elemanı
  var say  = null;      // konuşma balonu
  var moveT = null, sayT = null, idleT = null;

  var SAY = {
    think: ["ucunu yakaladım…", "planı kuruyorum", "bir saniye, düşünüyorum", "notlara bakıyorum"],
    write: ["yazıyorum", "toparlıyorum", "az kaldı"],
    tool:  ["araçları çalıştırıyorum", "kolları uzattım", "işi hallediyorum"],
    error: ["ters gitti bir şey", "kollarım düştü…"],
    done:  ["bitti!", "tamamdır"],
    idle:  ["hazırım", "ne yapalım?"]
  };

  function el(cls, tag) {
    var n = document.createElement(tag || "div");
    n.className = cls || "";
    return n;
  }

  function ensure() {
    if (pus) return pus;
    if (!W.OktoPus) return null;
    host = el("msg-mascot");
    host.setAttribute("aria-hidden", "false");
    pus = W.OktoPus.make(66);
    host.appendChild(pus);
    /* tıklayınca selam verir */
    pus.addEventListener("click", function () {
      W.OktoPus.react(pus, "bounce");
      speak(pick(SAY.idle), 1800);
    });
    return pus;
  }

  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }

  function speak(txt, ms) {
    return;
  }

  /** Ahtapotu, verilen mesaj elemanının ÜSTÜNE taşı (zıplayarak). */
  function moveTo(msgEl) {
    if (!ensure() || !msgEl || !msgEl.parentNode) return;
    /* zaten doğru yerdeyse dokunma */
    if (host.nextElementSibling === msgEl) return;

    var first = !host.parentNode;
    if (first) {
      msgEl.parentNode.insertBefore(host, msgEl);
      pus.classList.remove("op-hop"); void pus.offsetWidth;
      pus.classList.add("op-hop");
      return;
    }

    clearTimeout(moveT);
    pus.classList.remove("op-hop");
    pus.classList.add("op-leap");     // yukarı sıçra
    moveT = setTimeout(function () {
      msgEl.parentNode.insertBefore(host, msgEl);
      pus.classList.remove("op-leap");
      void pus.offsetWidth;
      pus.classList.add("op-hop");    // yeni yerine kon
    }, 260);
  }

  /** Sohbetteki son mesajın üstüne konumlan. */
  function follow() {
    var inner = document.getElementById("chatInner");
    if (!inner) return;
    var msgs = inner.querySelectorAll(".msg");
    if (!msgs.length) { detach(); return; }
    moveTo(msgs[msgs.length - 1]);
  }

  function detach() {
    if (host && host.parentNode) host.parentNode.removeChild(host);
  }

  /* ---- durum eşlemesi ---- */
  function mapState(s, meta) {
    if (meta && meta.tool) return "tool";
    switch (s) {
      case "think": return "think";
      case "search": case "read": case "work": return "tool";
      case "write": case "talk": return "write";
      case "done": return "done";
      case "error": return "error";
      case "sleep": return "sleep";
      default: return "idle";
    }
  }

  var lastSpoken = "";
  function setState(s, meta) {
    if (!ensure()) return;
    var st = mapState(s, meta);
    var prev = W.OktoPus.get(pus);
    W.OktoPus.set(pus, st);
    if (st === "tool" && meta && meta.tool) {
      W.OktoPus.tools(pus, toolBadges(meta.tool));
    }
    if (st !== prev && SAY[st] && lastSpoken !== st) {
      lastSpoken = st;
      speak(pick(SAY[st]), st === "done" ? 1600 : 2600);
    }
    /* boşta kalınca uykuya geç */
    clearTimeout(idleT);
    if (st === "idle" || st === "done") {
      idleT = setTimeout(function () {
        if (pus && ["idle", "done"].indexOf(W.OktoPus.get(pus)) >= 0) {
          W.OktoPus.set(pus, "sleep");
        }
      }, 22000);
    }
  }

  /* araç adından rozet etiketleri üret (en fazla 4 kol) */
  var badges = [];
  function toolBadges(name) {
    var short = String(name || "iş").replace(/[^a-zA-Z0-9_]/g, "").slice(0, 4) || "iş";
    badges.unshift(short);
    badges = badges.slice(0, 4);
    return badges;
  }

  function reset() {
    badges = [];
    lastSpoken = "";
    if (pus) W.OktoPus.set(pus, "idle");
  }

  /* ============================================================
     BAĞLANTILAR
     ============================================================ */
  function init() {
    if (!W.OktoPus) return;
    ensure();

    /* 1) Mascot durum yayınlarını dinle */
    if (W.Mascot && W.Mascot.on) {
      W.Mascot.on(function (s, meta) { setState(s, meta); });
    }

    /* 2) Sohbete mesaj eklendikçe takip et */
    var inner = document.getElementById("chatInner");
    if (inner && W.MutationObserver) {
      var mo = new MutationObserver(function (recs) {
        var added = false;
        for (var i = 0; i < recs.length; i++) {
          for (var j = 0; j < recs[i].addedNodes.length; j++) {
            var n = recs[i].addedNodes[j];
            if (n.nodeType === 1 && n.classList && n.classList.contains("msg")) added = true;
          }
        }
        if (added) follow();
      });
      mo.observe(inner, { childList: true });
    }
    follow();

    /* 3) Oturum değişince sıfırla */
    document.addEventListener("okto:newsession", function () {
      reset(); detach(); follow();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  W.OktoPilot = {
    follow: follow,
    setState: setState,
    speak: speak,
    reset: reset,
    el: function () { return pus; }
  };
})(window);

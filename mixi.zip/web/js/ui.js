/* ============================================================
   ui.js — Mixium arayüz çekirdeği (bölüm 1)
   ikon seti · yardımcılar · toast · markdown · vurgulama
   ============================================================ */
(function (W) {
"use strict";

/* ---------- kısa yollar ---------- */
var $  = function (s, r) { return (r || document).querySelector(s); };
var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

function el(tag, cls, html) {
  var n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html != null) n.innerHTML = html;
  return n;
}
function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/* ============================================================
   İKON SETİ — tek satır SVG, currentColor
   ============================================================ */
var I = {
  menu:     '<path d="M3 6h18M3 12h18M3 18h18"/>',
  plus:     '<path d="M12 5v14M5 12h14"/>',
  search:   '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  send:     '<path d="M4 12h15M13 6l6 6-6 6"/>',
  stop:     '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  copy:     '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>',
  check:    '<path d="m4 12 5 5L20 6"/>',
  x:        '<path d="M6 6l12 12M18 6L6 18"/>',
  trash:    '<path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M6 7l1 13h10l1-13"/>',
  edit:     '<path d="M4 20h4L19 9a2 2 0 0 0-3-3L5 17v3z"/>',
  refresh:  '<path d="M20 11a8 8 0 1 0-1.5 5.5"/><path d="M20 5v6h-6"/>',
  down:     '<path d="M12 5v14M6 13l6 6 6-6"/>',
  up:       '<path d="M12 19V5M6 11l6-6 6 6"/>',
  chevD:    '<path d="m6 9 6 6 6-6"/>',
  chevR:    '<path d="m9 6 6 6-6 6"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 7 19.4a1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a2 2 0 1 1 0-4 1.7 1.7 0 0 0 1.5-2.6l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 4.6V4a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 2.9 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 11a2 2 0 1 1 0 4z"/>',
  sun:      '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon:     '<path d="M21 13A9 9 0 0 1 11 3a9 9 0 1 0 10 10z"/>',
  code:     '<path d="m9 18-6-6 6-6M15 6l6 6-6 6"/>',
  file:     '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
  folder:   '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  terminal: '<path d="m5 8 4 4-4 4M13 16h6"/><rect x="2" y="3" width="20" height="18" rx="2"/>',
  globe:    '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18z"/>',
  brain:    '<path d="M9.5 3A3.5 3.5 0 0 0 6 6.5c-1.7.4-3 2-3 3.8 0 1 .4 2 1 2.7-.6.6-1 1.5-1 2.5A3.5 3.5 0 0 0 6.5 19c.4 1.2 1.5 2 2.9 2 1.4 0 2.6-1 2.6-2.4V5.4C12 4 10.9 3 9.5 3z"/><path d="M14.5 3A3.5 3.5 0 0 1 18 6.5c1.7.4 3 2 3 3.8 0 1-.4 2-1 2.7.6.6 1 1.5 1 2.5a3.5 3.5 0 0 1-3.5 3.5c-.4 1.2-1.5 2-2.9 2"/>',
  bolt:     '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  star:     '<path d="m12 3 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 17.8 6.2 20.9l1.1-6.5-4.7-4.6 6.5-.9z"/>',
  pin:      '<path d="M12 17v5M9 3h6l-1 6 3 3v2H7v-2l3-3z"/>',
  share:    '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/>',
  download: '<path d="M12 3v12M7 11l5 5 5-5M4 20h16"/>',
  upload:   '<path d="M12 20V8M7 12l5-5 5 5M4 20h16"/>',
  paperclip:'<path d="M21 11.5 12.5 20a5 5 0 0 1-7-7l8.5-8.5a3.5 3.5 0 1 1 5 5L11 17a2 2 0 0 1-3-3l7.5-7.5"/>',
  mic:      '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  image:    '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m4 18 5-5 4 4 3-3 4 4"/>',
  history:  '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l4 2"/>',
  bell:     '<path d="M18 8a6 6 0 1 0-12 0c0 7-3 8-3 8h18s-3-1-3-8"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
  info:     '<circle cx="12" cy="12" r="9"/><path d="M12 16v-5M12 8h.01"/>',
  warn:     '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  play:     '<path d="M6 4l14 8-14 8z"/>',
  layers:   '<path d="m12 2 9 5-9 5-9-5z"/><path d="m3 12 9 5 9-5M3 17l9 5 9-5"/>',
  key:      '<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8 3 3-2 2 2 2-3 3-2-2-2 2"/>',
  shield:   '<path d="M12 3 4 6v6c0 5 3.5 8.5 8 9.5 4.5-1 8-4.5 8-9.5V6z"/>',
  cpu:      '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
  db:       '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  branch:   '<circle cx="6" cy="5" r="2.5"/><circle cx="6" cy="19" r="2.5"/><circle cx="18" cy="9" r="2.5"/><path d="M6 7.5v9M8.5 9H14a4 4 0 0 1 4 4v2"/>',
  panel:    '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
  expand:   '<path d="M4 10V4h6M20 14v6h-6M4 4l7 7M20 20l-7-7"/>',
  compress: '<path d="M10 4v6H4M14 20v-6h6M4 10l7-7M20 14l-7 7"/>',
  eye:      '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff:   '<path d="M10.6 6.2A9 9 0 0 1 12 6c6 0 10 6 10 6a17 17 0 0 1-3 3.5M6.6 6.6A17 17 0 0 0 2 12s4 6 10 6a9 9 0 0 0 3.6-.7"/><path d="m3 3 18 18"/>',
  book:     '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 0 4 22z"/>',
  wrench:   '<path d="M14.7 6.3a4 4 0 0 0 5 5l-9 9a2.8 2.8 0 0 1-4-4z"/>',
  filter:   '<path d="M3 4h18l-7 8v7l-4 2v-9z"/>',
  clock:    '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  thumbUp:  '<path d="M7 10v10H4V10zM7 10l4-7a2 2 0 0 1 3 2l-1 5h5a2 2 0 0 1 2 2.3l-1 6A2 2 0 0 1 17 20H7z"/>',
  thumbDn:  '<path d="M17 14V4h3v10zM17 14l-4 7a2 2 0 0 1-3-2l1-5H6a2 2 0 0 1-2-2.3l1-6A2 2 0 0 1 7 4h10z"/>',
  sparkle:  '<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
  grid:     '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  logout:   '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  quote:    '<path d="M7 15a4 4 0 1 1 0-8v0c0 3-1 5-3 6M18 15a4 4 0 1 1 0-8v0c0 3-1 5-3 6"/>',
  fork:     '<path d="M12 3v18M6 8a3 3 0 0 1 6 0M18 8a3 3 0 0 0-6 0"/>'
};

function ico(name, size) {
  var p = I[name] || I.info;
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
         'stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"' +
         (size ? ' width="' + size + '" height="' + size + '"' : '') +
         ' aria-hidden="true">' + p + '</svg>';
}

/* ============================================================
   Yardımcı biçimlendirme
   ============================================================ */
function ts(d) {
  return new Date(d || Date.now())
    .toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
}
function agoTxt(sec) {
  if (sec < 60) return "az önce";
  var m = Math.floor(sec / 60);
  if (m < 60) return m + " dk önce";
  var h = Math.floor(m / 60);
  if (h < 24) return h + " sa önce";
  var d = Math.floor(h / 24);
  return d < 7 ? d + " gün önce" : Math.floor(d / 7) + " hf önce";
}
function elapsed(ms) {
  var s = ms / 1000;
  if (s < 1) return Math.round(ms) + "ms";
  return s < 10 ? s.toFixed(1) + "s" : Math.round(s) + "s";
}
function bytes(n) {
  var u = ["B", "KB", "MB", "GB"], i = 0;
  while (n >= 1024 && i < 3) { n /= 1024; i++; }
  return (i ? n.toFixed(1) : n) + " " + u[i];
}
function debounce(fn, ms) {
  var t;
  return function () {
    var a = arguments, c = this;
    clearTimeout(t);
    t = setTimeout(function () { fn.apply(c, a); }, ms || 160);
  };
}

/* ============================================================
   TOAST
   ============================================================ */
function toast(msg, kind, opts) {
  opts = opts || {};
  var box = $("#toast");
  if (!box) return;
  var t = el("div", "tst " + (kind || "info"));
  var iconName = kind === "ok" ? "check" : kind === "err" ? "warn"
               : kind === "warn" ? "warn" : "info";
  t.innerHTML = '<span class="ti">' + ico(iconName) + '</span>' +
                '<span class="tx">' + esc(msg) + '</span>';
  if (opts.action) {
    var b = el("button", "", esc(opts.action));
    b.onclick = function () { try { opts.onAction && opts.onAction(); } catch (e) {} close(); };
    t.appendChild(b);
  }
  box.appendChild(t);
  var tm = setTimeout(close, opts.ms || (kind === "err" ? 5200 : 3000));
  function close() {
    clearTimeout(tm);
    t.classList.add("out");
    setTimeout(function () { t.remove(); }, 240);
  }
  t.addEventListener("click", function (e) { if (e.target.tagName !== "BUTTON") close(); });
  /* en fazla 4 toast */
  while (box.children.length > 4) box.firstChild.remove();
  return close;
}

/* ============================================================
   SÖZDİZİMİ VURGULAMA
   ============================================================ */
var KW = {
  py: "def class import from return if elif else for while in not and or is None True False try except finally with as lambda yield global nonlocal self async await pass break continue raise del assert print len range str int float dict list set tuple",
  js: "function const let var return if else for while class extends new this async await import export from default try catch finally throw typeof instanceof null undefined true false switch case break continue do delete in of yield static get set super",
  sh: "if then else fi for while do done case esac function return export local echo cd ls cat grep sed awk sudo apt pip npm git curl wget chmod mkdir rm cp mv source",
  go: "func package import return if else for range var const type struct interface map chan go defer select switch case break continue nil true false string int error",
  rs: "fn let mut pub use mod struct enum impl trait match if else for while loop return self Some None Ok Err true false const static ref move async await",
  sql:"SELECT FROM WHERE INSERT INTO VALUES UPDATE SET DELETE JOIN LEFT RIGHT INNER OUTER ON GROUP BY ORDER HAVING LIMIT OFFSET CREATE TABLE ALTER DROP INDEX AS AND OR NOT NULL DISTINCT COUNT SUM AVG MIN MAX"
};
var KWSET = {};
Object.keys(KW).forEach(function (k) {
  KWSET[k] = new Set(KW[k].split(" "));
  KWSET[k + "_lc"] = new Set(KW[k].toLowerCase().split(" "));
});

function langKey(lang) {
  lang = (lang || "").toLowerCase();
  if (/^(py|python|python3)$/.test(lang)) return "py";
  if (/^(js|javascript|jsx|ts|typescript|tsx|json|node)$/.test(lang)) return "js";
  if (/^(sh|bash|zsh|shell|console|terminal)$/.test(lang)) return "sh";
  if (/^(go|golang)$/.test(lang)) return "go";
  if (/^(rs|rust)$/.test(lang)) return "rs";
  if (/^(sql|postgres|mysql|sqlite)$/.test(lang)) return "sql";
  if (/^(c|cpp|c\+\+|java|cs|csharp|kt|kotlin|swift|php|rb|ruby)$/.test(lang)) return "js";
  return "";
}

function hl(line, key) {
  if (!key) return esc(line);
  var set = KWSET[key], setLc = KWSET[key + "_lc"];
  var out = "", last = 0, m;
  var re = /(\/\/[^\n]*|#[^\n]*|--[^\n]*|"""[\s\S]*?"""|'''[\s\S]*?'''|`(?:\\.|[^`\\])*`|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\b0[xX][0-9a-fA-F]+\b|\b\d+(?:\.\d+)?\b|\b[A-Za-z_$][\w$]*\b|[{}()\[\];,.:=+\-*\/<>!&|%^~?]+)/g;
  while ((m = re.exec(line))) {
    var tok = m[0];
    out += esc(line.slice(last, m.index));
    if (/^(\/\/|#|--)/.test(tok))                  out += '<span class="tok-c">' + esc(tok) + '</span>';
    else if (/^["'`]/.test(tok))                    out += '<span class="tok-s">' + esc(tok) + '</span>';
    else if (/^[\d]/.test(tok))                     out += '<span class="tok-n">' + esc(tok) + '</span>';
    else if (set.has(tok) || setLc.has(tok.toLowerCase()) && key === "sql")
                                                    out += '<span class="tok-k">' + esc(tok) + '</span>';
    else if (/^[{}()\[\];,.:=+\-*\/<>!&|%^~?]+$/.test(tok))
                                                    out += '<span class="tok-o">' + esc(tok) + '</span>';
    else if (/^[A-Z][\w$]*$/.test(tok))             out += '<span class="tok-b">' + esc(tok) + '</span>';
    else if (line[m.index + tok.length] === "(")    out += '<span class="tok-f">' + esc(tok) + '</span>';
    else                                            out += esc(tok);
    last = m.index + tok.length;
  }
  return out + esc(line.slice(last));
}

/* ============================================================
   MARKDOWN
   ============================================================ */
function mdInline(s) {
  s = esc(s);
  /* satır içi kod önce — içindeki markdown yorumlanmasın */
  var codes = [];
  s = s.replace(/`([^`]+)`/g, function (m, c) {
    codes.push(c); return "\u0000C" + (codes.length - 1) + "\u0000";
  });
  s = s.replace(/\*\*\*([^*]+)\*\*\*/g, "<strong><em>$1</em></strong>");
  s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/__([^_]+)__/g, "<strong>$1</strong>");
  s = s.replace(/(^|[\s(\[])\*([^*\n]+)\*(?=[\s).,!?:;\]]|$)/g, "$1<em>$2</em>");
  s = s.replace(/(^|[\s(\[])_([^_\n]+)_(?=[\s).,!?:;\]]|$)/g, "$1<em>$2</em>");
  s = s.replace(/~~([^~]+)~~/g, "<del>$1</del>");
  s = s.replace(/==([^=]+)==/g, "<mark>$1</mark>");
  /* bağlantı ve resim */
  s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g,
    '<img src="$2" alt="$1" loading="lazy">');
  s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g,
    '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  /* çıplak URL */
  s = s.replace(/(^|[\s])(https?:\/\/[^\s<]+[^\s<.,;:!?)])/g,
    '$1<a href="$2" target="_blank" rel="noopener noreferrer">$2</a>');
  s = s.replace(/\u0000C(\d+)\u0000/g, function (m, i) {
    return "<code>" + codes[+i] + "</code>";
  });
  return s;
}

var _cbSeq = 0;
function codeBlock(lang, code) {
  var key = langKey(lang);
  var lines = code.split("\n");
  var body = lines.map(function (l) {
    return '<span class="cl">' + (key ? hl(l, key) : esc(l)) + '</span>';
  }).join("\n");
  var id = "cb" + (++_cbSeq);
  var big = lines.length > 22;
  return '<div class="codeblock' + (big ? " folded" : "") + '" data-ln="' +
         (lines.length > 3 ? 1 : 0) + '" id="' + id + '">' +
    '<div class="cb-h">' +
      '<span class="lang">' + esc(lang || "kod") + '</span>' +
      '<span class="lines">' + lines.length + ' satır</span>' +
      '<span class="sp"></span>' +
      '<button class="cb-wrap" title="Satır kaydır">' + ico("quote") + '</button>' +
      '<button class="cb-dl" title="İndir">' + ico("download") + '</button>' +
      '<button class="cb-copy" title="Kopyala">' + ico("copy") + '<span>kopyala</span></button>' +
    '</div>' +
    '<pre>' + body + '</pre>' +
    (big ? '<button class="cb-more">tamamını göster (' + lines.length + ' satır)</button>' : '') +
  '</div>';
}

function mdRender(src) {
  /* Modeller bazen Markdown sınırlarını satır sonu olmadan üretir:
     "Kurulum```bash..." veya "metin## Başlık". Görsel katmanda
     güvenli bir normalizasyon yap; ham içeriği değiştirmeden render edilebilir
     bloklara ayır. */
  var normalized = String(src == null ? "" : src)
    /* Fence'i satır başına taşı. Dil adı ile ilk kod tokenı birleşmişse
       yaygın dilleri bilerek ayır: ```bashgit -> ```bash\ngit. */
    .replace(/([^\n])(```+|~~~+)/g, "$1\n$2")
    .replace(/(```+|~~~+)(python|py|javascript|js|typescript|ts|bash|sh|shell|json|html|css|java|kotlin|go|rust|c|cpp|csharp|cs|php|ruby|swift|sql|yaml|yml|toml|xml|text|txt)(?=\S)/gi, "$1$2\n")
    .replace(/([^\n])(```+|~~~+)(?=\s*$)/gm, "$1\n$2")
    .replace(/([^\n])(?=(#{1,6}\s+))/g, "$1\n")
    /* Yalnızca satır BAŞINDA madde/numara işareti varsa yeni satıra böl.
       "**text**" gibi bold içindeki tekil "*" ile karışmasın diye
       satır ortasındaki * / - karakterlerine dokunma. */
    .replace(/([^\n])(?=^[ \t]*(?:[-*+]\s+|\d+[.)]\s+|>\s?))/gm, "$1\n");
  var lines = normalized.split("\n");
  var html = "", i = 0;

  while (i < lines.length) {
    var l = lines[i];

    /* --- kod bloğu --- */
    var f = l.match(/^\s*(```+|~~~+)\s*([A-Za-z0-9_+#.-]*)\s*$/);
    if (f) {
      var fence = f[1][0], lang = f[2] || "", buf = [];
      i++;
      while (i < lines.length && !new RegExp("^\\s*" + fence + "{3,}\\s*$").test(lines[i])) {
        buf.push(lines[i]); i++;
      }
      i++;
      html += codeBlock(lang, buf.join("\n"));
      continue;
    }

    /* --- başlık --- */
    var h = l.match(/^\s{0,3}(#{1,6})\s+(.*)$/);
    if (h) {
      var lv = Math.min(h[1].length + 1, 6);
      html += "<h" + lv + ">" + mdInline(h[2].replace(/\s+#+\s*$/, "")) + "</h" + lv + ">";
      i++; continue;
    }

    /* --- yatay çizgi --- */
    if (/^\s*([-*_])\s*(\1\s*){2,}$/.test(l)) { html += "<hr>"; i++; continue; }

    /* --- tablo --- */
    if (/^\s*\|.*\|\s*$/.test(l) && i + 1 < lines.length &&
        /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
      var cells = function (row) {
        return row.trim().replace(/^\||\|$/g, "").split("|").map(function (c) { return c.trim(); });
      };
      var head = cells(l);
      var align = cells(lines[i + 1]).map(function (c) {
        if (/^:.*:$/.test(c)) return "center";
        if (/:$/.test(c)) return "right";
        return "left";
      });
      i += 2;
      var rows = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) { rows.push(cells(lines[i])); i++; }
      html += '<div class="tbl-wrap"><table><thead><tr>' +
        head.map(function (c, ci) {
          return '<th style="text-align:' + align[ci] + '">' + mdInline(c) + "</th>";
        }).join("") + "</tr></thead><tbody>" +
        rows.map(function (r) {
          return "<tr>" + head.map(function (_h, ci) {
            return '<td style="text-align:' + align[ci] + '">' + mdInline(r[ci] || "") + "</td>";
          }).join("") + "</tr>";
        }).join("") + "</tbody></table></div>";
      continue;
    }

    /* --- görev listesi --- */
    if (/^\s*[-*+]\s+\[[ xX]\]\s+/.test(l)) {
      html += '<ul class="task-list">';
      while (i < lines.length && /^\s*[-*+]\s+\[[ xX]\]\s+/.test(lines[i])) {
        var done = /\[[xX]\]/.test(lines[i]);
        var txt = lines[i].replace(/^\s*[-*+]\s+\[[ xX]\]\s+/, "");
        html += '<li><span class="tick' + (done ? " on" : "") + '">' +
                (done ? "✓" : "") + "</span><span>" + mdInline(txt) + "</span></li>";
        i++;
      }
      html += "</ul>"; continue;
    }

    /* --- madde listesi (iç içe destekli) --- */
    if (/^\s*[-*+]\s+/.test(l)) {
      html += renderList(lines, i, false);
      i = renderList.end;
      continue;
    }
    if (/^\s*\d+[.)]\s+/.test(l)) {
      html += renderList(lines, i, true);
      i = renderList.end;
      continue;
    }

    /* --- alıntı --- */
    if (/^\s*>\s?/.test(l)) {
      var q = [];
      while (i < lines.length && /^\s*>\s?/.test(lines[i])) {
        q.push(lines[i].replace(/^\s*>\s?/, "")); i++;
      }
      html += "<blockquote>" + mdRender(q.join("\n")) + "</blockquote>";
      continue;
    }

    /* --- paragraf --- */
    if (l.trim() === "") { i++; continue; }
    var para = [];
    while (i < lines.length && lines[i].trim() !== "" &&
           !/^\s*(```|~~~|#{1,6}\s|[-*+]\s|\d+[.)]\s|>\s?|\|)/.test(lines[i])) {
      para.push(lines[i]); i++;
    }
    if (para.length) html += "<p>" + mdInline(para.join("\n")).replace(/\n/g, "<br>") + "</p>";
    else i++;
  }
  return html;
}

/* iç içe liste oluşturucu */
function renderList(lines, start, ordered) {
  var tag = ordered ? "ol" : "ul";
  var re = ordered ? /^(\s*)\d+[.)]\s+(.*)$/ : /^(\s*)[-*+]\s+(.*)$/;
  var baseIndent = (lines[start].match(/^\s*/) || [""])[0].length;
  var out = "<" + tag + ">", i = start;
  while (i < lines.length) {
    var m = lines[i].match(re);
    if (!m) {
      /* devam satırı (girintili düz metin) */
      if (lines[i].trim() !== "" && (lines[i].match(/^\s*/)[0].length > baseIndent)) {
        out = out.replace(/<\/li>$/, "<br>" + mdInline(lines[i].trim()) + "</li>");
        i++; continue;
      }
      break;
    }
    var ind = m[1].length;
    if (ind < baseIndent) break;
    if (ind > baseIndent) {
      var sub = renderList(lines, i, /^\s*\d+[.)]/.test(lines[i]));
      out = out.replace(/<\/li>$/, sub + "</li>");
      i = renderList.end;
      continue;
    }
    out += "<li>" + mdInline(m[2]) + "</li>";
    i++;
  }
  renderList.end = i;
  return out + "</" + tag + ">";
}

/* ---- dışa aktar ---- */
W.UI = {
  $: $, $$: $$, el: el, esc: esc, ico: ico, I: I,
  toast: toast, ts: ts, agoTxt: agoTxt, elapsed: elapsed,
  bytes: bytes, debounce: debounce,
  mdRender: mdRender, mdInline: mdInline, codeBlock: codeBlock, hl: hl
};

})(window);

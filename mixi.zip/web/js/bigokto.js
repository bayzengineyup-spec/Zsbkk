/* ============================================================
   BigOkto — Büyük yüzen ahtapot maskotu
   - Her zaman en son mesajın üstünde durur
   - Duruma göre animasyon: think, write, tool, error, idle, done
   - Mesajlar arası atlama animasyonu
   ============================================================ */
(function (global) {
  "use strict";

  var el = null;          // büyük maskot DOM elemanı
  var notebookEl = null;  // defter+kalem SVG katmanı
  var toolArmsEl = null;  // araç kolları katmanı
  var currentMsg = null;  // şu an üstünde durduğu mesaj
  var jumpRaf = null;
  var initDone = false;
  var currentState = "idle";

  /* ─── SVG: defter + kalem ─────────────────────────────── */
  var NOTEBOOK_SVG = '<svg class="bk-notebook" viewBox="0 0 60 50" xmlns="http://www.w3.org/2000/svg">' +
    /* defter gövdesi */
    '<rect class="bk-cover" x="4" y="6" width="38" height="42" rx="3" fill="var(--bg-3)" stroke="var(--ember)" stroke-width="1.4"/>' +
    /* spiral */
    '<circle cx="4" cy="12" r="2.2" fill="none" stroke="var(--ember)" stroke-width="1.2"/>' +
    '<circle cx="4" cy="20" r="2.2" fill="none" stroke="var(--ember)" stroke-width="1.2"/>' +
    '<circle cx="4" cy="28" r="2.2" fill="none" stroke="var(--ember)" stroke-width="1.2"/>' +
    '<circle cx="4" cy="36" r="2.2" fill="none" stroke="var(--ember)" stroke-width="1.2"/>' +
    /* satırlar */
    '<line class="bk-line bk-l1" x1="10" y1="16" x2="36" y2="16" stroke="var(--line)" stroke-width=".9"/>' +
    '<line class="bk-line bk-l2" x1="10" y1="22" x2="36" y2="22" stroke="var(--line)" stroke-width=".9"/>' +
    '<line class="bk-line bk-l3" x1="10" y1="28" x2="36" y2="28" stroke="var(--line)" stroke-width=".9"/>' +
    '<line class="bk-line bk-l4" x1="10" y1="34" x2="30" y2="34" stroke="var(--line)" stroke-width=".9"/>' +
    /* kalem */
    '<g class="bk-pen">' +
      '<rect x="42" y="2" width="5" height="30" rx="2" fill="var(--ember)" transform="rotate(18 44 17)"/>' +
      '<polygon points="42,30 47,30 44.5,36" fill="var(--ink-3)" transform="rotate(18 44 33)"/>' +
      '<rect x="42" y="2" width="5" height="5" rx="1" fill="var(--acc-hi)" transform="rotate(18 44 4)"/>' +
    '</g>' +
    /* yazı efekti — ince kıvrık çizgiler */
    '<g class="bk-writing">' +
      '<path class="bk-w1" d="M10 16 Q18 14 26 16 Q30 17 36 15" fill="none" stroke="var(--ink-4)" stroke-width=".7" opacity="0"/>' +
      '<path class="bk-w2" d="M10 22 Q20 20 30 22 Q33 23 36 21" fill="none" stroke="var(--ink-4)" stroke-width=".7" opacity="0"/>' +
      '<path class="bk-w3" d="M10 28 Q16 26 24 28 Q28 29 36 27" fill="none" stroke="var(--ink-4)" stroke-width=".7" opacity="0"/>' +
    '</g>' +
  '</svg>';

  /* ─── Araç baloncukları SVG ───────────────────────────── */
  var TOOL_ICONS = {
    bash:   "⚙",
    shell:  "⚙",
    read:   "📄",
    write:  "✏️",
    search: "🔍",
    think:  "💭",
    web:    "🌐",
    default:"🔧"
  };

  function toolIcon(name) {
    if (!name) return TOOL_ICONS["default"];
    var k = String(name).toLowerCase();
    for (var key in TOOL_ICONS) {
      if (k.indexOf(key) >= 0) return TOOL_ICONS[key];
    }
    return TOOL_ICONS["default"];
  }

  /* ─── BigOkto DOM oluştur ─────────────────────────────── */
  function build() {
    if (el) return;

    el = document.createElement("div");
    el.id = "bigokto";
    el.className = "bigokto";
    el.dataset.state = "idle";
    el.setAttribute("aria-hidden", "true");

    /* Büyük okto SVG */
    var oktoDiv = global.Okto ? global.Okto.make({ size: 96, state: "idle" }) : document.createElement("div");
    oktoDiv.classList.add("bk-okto");
    el.appendChild(oktoDiv);

    /* Defter+kalem katmanı */
    notebookEl = document.createElement("div");
    notebookEl.className = "bk-book-wrap";
    notebookEl.innerHTML = NOTEBOOK_SVG;
    el.appendChild(notebookEl);

    /* Araç kolları katmanı */
    toolArmsEl = document.createElement("div");
    toolArmsEl.className = "bk-tools-wrap";
    el.appendChild(toolArmsEl);

    /* Konuşma balonu (durum metni) */
    var bubble = document.createElement("div");
    bubble.className = "bk-bubble";
    el.appendChild(bubble);

    document.body.appendChild(el);

    /* Mascot durum dinle */
    if (global.Mascot) {
      global.Mascot.on(function (s, meta) {
        setState(s, meta);
      });
    }

    initDone = true;
  }

  /* ─── Duruma göre animasyon ───────────────────────────── */
  function setState(s, meta) {
    if (!el) return;
    currentState = s;
    el.dataset.state = s;

    /* Büyük okto durumunu senkronla */
    var oktoInner = el.querySelector(".bk-okto");
    if (oktoInner && global.Okto) global.Okto.set(oktoInner, s);

    /* Durum baloncuğu metni */
    var bubble = el.querySelector(".bk-bubble");
    if (bubble && global.Okto) {
      var hint = global.Okto.hint(s);
      if (hint) {
        bubble.textContent = hint;
        bubble.classList.add("bk-bubble-show");
        clearTimeout(bubble._hideTimer);
        bubble._hideTimer = setTimeout(function () {
          bubble.classList.remove("bk-bubble-show");
        }, 2200);
      }
    }

    /* Araç kolları */
    if (s === "work" || s === "search" || s === "read") {
      showToolArms(meta && meta.tool ? meta.tool : "default");
    } else {
      hideToolArms();
    }
  }

  /* ─── Araç kolları görüntüle ──────────────────────────── */
  function showToolArms(toolName) {
    if (!toolArmsEl) return;
    var icon = toolIcon(toolName);
    toolArmsEl.innerHTML =
      '<div class="bk-tool-badge">' +
        '<span class="bk-tool-icon">' + icon + '</span>' +
        '<span class="bk-tool-name">' + (toolName || "araç") + '</span>' +
      '</div>';
    toolArmsEl.classList.add("bk-tools-show");
  }

  function hideToolArms() {
    if (!toolArmsEl) return;
    toolArmsEl.classList.remove("bk-tools-show");
  }

  /* ─── En son mesajı bul & konumlandır ────────────────── */
  function getTargetMsg() {
    var inner = document.getElementById("chatInner");
    if (!inner) return null;
    /* En son AI veya user mesajı */
    var msgs = inner.querySelectorAll(".msg.ai, .msg.user");
    if (!msgs.length) return null;
    return msgs[msgs.length - 1];
  }

  /* ─── Konumlandırma (scroll, resize sonrası) ─────────── */
  function reposition() {
    if (!el || !initDone) return;
    var target = getTargetMsg();
    if (!target) {
      el.style.opacity = "0";
      el.style.pointerEvents = "none";
      return;
    }
    var chat = document.getElementById("chat");
    if (!chat) return;

    var chatRect = chat.getBoundingClientRect();
    var msgRect  = target.getBoundingClientRect();

    /* ahtapot mesajın sağ üstüne konumlanır */
    var x = msgRect.right - chatRect.left - 56;
    var y = msgRect.top  - chatRect.top  - 72 + chat.scrollTop;

    /* sınır: chat alanı içinde kal */
    x = Math.max(8, Math.min(x, chatRect.width - 120));
    y = Math.max(8, y);

    el.style.transform = "translate(" + x + "px," + y + "px)";
    el.style.opacity = "1";
    el.style.pointerEvents = "auto";
  }

  /* ─── Yeni mesaj gelince zıpla ────────────────────────── */
  function jumpTo(msgEl) {
    if (!el || !initDone) return;
    if (currentMsg === msgEl) return;
    currentMsg = msgEl;

    /* Zıplama efekti */
    el.classList.remove("bk-jump");
    void el.offsetWidth;
    el.classList.add("bk-jump");

    setTimeout(function () {
      reposition();
      el.classList.remove("bk-jump");
    }, 480);
  }

  /* ─── Scroll ve resize dinle ──────────────────────────── */
  function bindListeners() {
    var chat = document.getElementById("chat");
    if (chat) {
      chat.addEventListener("scroll", function () {
        if (jumpRaf) return;
        jumpRaf = requestAnimationFrame(function () {
          jumpRaf = null;
          reposition();
        });
      }, { passive: true });
    }
    window.addEventListener("resize", reposition, { passive: true });
  }

  /* ─── Dışa aç ─────────────────────────────────────────── */
  global.BigOkto = {
    init: function () {
      build();
      bindListeners();
      /* ilk konumlandırma */
      setTimeout(reposition, 300);
    },
    jumpTo: jumpTo,
    reposition: reposition,
    setState: setState
  };

})(window);

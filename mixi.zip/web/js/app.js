/* ============================================================
   app.js — Mixium uygulama mantığı
   durum · websocket · mesaj oluşturma · araç kartları
   ============================================================ */
(function (W) {
"use strict";

var U = W.UI;
var $ = U.$, $$ = U.$$, el = U.el, esc = U.esc, ico = U.ico, toast = U.toast;

/* ============================================================
   AYARLAR — kalıcı
   ============================================================ */
var DEFAULTS = {
  theme: "dark", accent: "teal", density: "cozy", textsize: "md",
  motion: "on", grain: "on", wide: "0", sound: "off",
  autoscroll: "1", showThinking: "1", sideCollapsed: "0",
  enterSends: "1", codeWrap: "0", timestamps: "1"
};
var S = {};
try { S = Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem("mx.settings") || "{}")); }
catch (e) { S = Object.assign({}, DEFAULTS); }

function saveSettings() {
  try { localStorage.setItem("mx.settings", JSON.stringify(S)); } catch (e) {}
}
function applySettings() {
  var r = document.documentElement;
  r.dataset.theme = S.theme;
  r.dataset.accent = S.accent;
  r.dataset.density = S.density;
  r.dataset.textsize = S.textsize;
  r.dataset.motion = S.motion === "off" ? "off" : "on";
  r.dataset.grain = S.grain;
  r.dataset.wide = S.wide;
  var app = $("#app");
  if (app) app.dataset.side = S.sideCollapsed === "1" ? "collapsed" : "open";
  saveSettings();
}
function setSetting(k, v) { S[k] = v; applySettings(); }

/* ============================================================
   DURUM
   ============================================================ */
var state = {
  ws: null, busy: false, session: null, model: null, ai: null,
  models: [], sessions: [], mode: "auto",
  ready: false,         // hello alındı mı
  cur: null,            // akan asistan mesajı
  curPresence: null,
  toolOpen: null, toolBuf: "", toolT0: 0,
  runT0: 0, toolCount: 0, editCount: 0,
  pinned: true, tick: null,
  attachments: [], drafts: {},
  reconnectTries: 0,
  reconnectTimer: null,
  helloTimer: null,
  connectSeq: 0,
  submitInFlight: false,
  responseWatchdog: null,
  effort: "normal",    // efor seviyesi
  thinking: false,       // gerçek düşünme açık/kapalı
};

/* ============================================================
   WEBSOCKET
   ============================================================ */
function send(o) {
  if (state.ws && state.ws.readyState === 1) {
    state.ws.send(JSON.stringify(o));
    return true;
  }
  toast("Bağlantı yok — yeniden bağlanılıyor", "warn");
  return false;
}

function setConn(s) {
  var d = $("#connDot"), t = $("#connTxt");
  if (!d) return;
  d.className = "dot " + s;
  t.textContent = s === "on" ? "bağlı" : s === "off" ? "bağlantı kesildi" : "bağlanıyor…";
}

function connect() {
  /* Eski socket açık/yarı-açık kaldıysa yeni bağlantıyla yarışmasın. */
  var seq = ++state.connectSeq;
  if (state.reconnectTimer) {
    clearTimeout(state.reconnectTimer);
    state.reconnectTimer = null;
  }
  if (state.helloTimer) {
    clearTimeout(state.helloTimer);
    state.helloTimer = null;
  }

  setConn("connecting");
  state.ready = false;

  var proto = location.protocol === "https:" ? "wss" : "ws";
  var url = proto + "://" + location.host + "/ws";
  var ws;
  try {
    ws = new WebSocket(url);
    state.ws = ws;
  } catch (e) {
    scheduleReconnect(seq);
    return;
  }

  /* Sunucu bağlantıyı kabul edip hello göndermiyorsa sonsuza kadar
     "bağlanıyor" durumunda kalma. */
  state.helloTimer = setTimeout(function () {
    if (seq !== state.connectSeq || state.ws !== ws || state.ready) return;
    try { ws.close(); } catch (_) {}
  }, 8000);

  ws.onopen = function () {
    if (seq !== state.connectSeq || state.ws !== ws) {
      try { ws.close(); } catch (_) {}
      return;
    }
    setConn("on");
    state.reconnectTries = 0;
  };

  ws.onmessage = function (e) {
    if (seq !== state.connectSeq || state.ws !== ws) return;
    var m;
    try { m = JSON.parse(e.data); } catch (_) { return; }

    if (m && m.type === "hello") {
      state.ready = true;
      if (state.helloTimer) {
        clearTimeout(state.helloTimer);
        state.helloTimer = null;
      }
    }

    try { handle(m); } catch (err) { console.error("handle:", err, m); }
  };

  ws.onclose = function () {
    if (seq !== state.connectSeq || state.ws !== ws) return;
    if (state.helloTimer) {
      clearTimeout(state.helloTimer);
      state.helloTimer = null;
    }
    state.submitInFlight = false;
    state.ready = false;
    if (state.busy) setBusy(false);
    setBusy(false);
    setConn("off");
    scheduleReconnect(seq);
  };

  ws.onerror = function () {
    /* onclose normalde hemen arkasından gelir. */
    try { ws.close(); } catch (_) {}
  };
}

function scheduleReconnect(seq) {
  if (seq !== state.connectSeq) return;
  if (state.reconnectTimer) return;

  state.reconnectTries++;
  var wait = Math.min(8000, Math.max(500, 800 * state.reconnectTries));
  state.reconnectTimer = setTimeout(function () {
    state.reconnectTimer = null;
    connect();
  }, wait);
}

/* ============================================================
   MESAJ OLUŞTURMA
   ============================================================ */
function chatInner() { return $("#chatInner"); }

function clearEmpty() {
  var e = $("#empty");
  if (e) e.remove();
}

/**
 * Mesaj kartı üretir.
 * KRİTİK: her asistan mesajı KENDİ maskotunu alır ve varsayılan
 * olarak DONDURULMUŞ gelir. Yalnızca aktif koşunun maskotu canlanır.
 */
function addMsg(role, content, opts) {
  opts = opts || {};
  clearEmpty();
  var m = el("div", "msg " + role);
  m.dataset.mid = "m" + Date.now() + Math.random().toString(36).slice(2, 6);

  /* --- avatar --- */
  var mascot = null;
  if (role === "ai") {
    var av = el("div", "ok-avatar");
    mascot = W.Mascot.make({ size: 30, state: "idle" });
    mascot.classList.add("mx-frozen");
    av.appendChild(mascot);
    m.appendChild(av);
  } else if (role === "user") {
    var uav = el("div", "user-avatar", "Sen");
    uav.textContent = (S.userInitials || "S");
    m.appendChild(uav);
  } else if (role === "err") {
    var eav = el("div", "user-avatar");
    eav.style.background = "linear-gradient(140deg,var(--err),#8b2b2b)";
    eav.innerHTML = ico("warn");
    m.appendChild(eav);
  }

  /* --- gövde --- */
  var bub = el("div", "bubble");
  if (role !== "sys") {
    var who = el("div", "who");
    var nm = role === "user" ? "Sen" : role === "err" ? "Hata" : "Mixium";
    who.innerHTML = '<span class="nm">' + nm + "</span>" +
      (role === "ai" && state.model
        ? '<span class="tag model">' + esc(shortModel(state.model)) + "</span>" : "");
    /* Hem kullanıcı hem AI mesajında kopyalama üst satırın en sağında. */
    if (role === "ai" || role === "user") {
      var topCopy = el("button", "msg-top-copy", "Kopyala");
      topCopy.innerHTML = ico("copy");
      topCopy.onclick = function (e) {
        e.stopPropagation();
        copyText(m._raw || content || "").then(function () {
          topCopy.innerHTML = ico("check");
          topCopy.classList.add("done");
          setTimeout(function () {
            topCopy.innerHTML = ico("copy");
            topCopy.classList.remove("done");
          }, 1400);
        });
      };
      who.appendChild(topCopy);
    }
    bub.appendChild(who);
  }

  /* Ekler mesaj gövdesine düz metin olarak yazılmaz.
     Gerçek bir dosya kartı olarak gösterilir. */
  if (opts.attachments && opts.attachments.length) {
    var attBox = el("div", "msg-attachments");
    opts.attachments.forEach(function (a) {
      var card = el("div", "msg-attachment");
      var kind = a.kind === "zip" ? "ZIP" : (String(a.name || "").split(".").pop() || "FILE").toUpperCase();
      card.innerHTML = '<span class="ma-icon">' + ico("file") + '</span>' +
        '<span class="ma-main"><b>' + esc(a.name || "dosya") + '</b>' +
        '<small>' + esc(kind) + ' · ' + U.bytes(a.size || 0) + '</small></span>';
      attBox.appendChild(card);
    });
    bub.appendChild(attBox);
  }

  var body = el("div", "body");
  if (role === "ai") body.innerHTML = content ? U.mdRender(content) : "";
  else body.textContent = content || "";
  bub.appendChild(body);

  /* Kullanıcı mesajının altında hiçbir eylem butonu gösterilmez.
     Kopyalama yalnızca üst başlıktaki düğmeden yapılır. */
  if (role === "ai") {
    bub.appendChild(buildActs(role, m, body));
  }

  m.appendChild(bub);
  chatInner().appendChild(m);

  m._body = body;
  m._raw = content || "";
  m._presence = mascot;
  wireCode(body);
  if (state.pinned) scrollBottom();
  return m;
}

function shortModel(id) {
  var NT = { "A": "Minimax 3.0", "B": "ChatGPT 5.5", "C": "NoTrack v1" };
  if (NT[id]) return NT[id];
  return String(id).replace(/^.*\//, "").slice(0, 22);
}

function buildActs(role, msgEl, body) {
  var acts = el("div", "msg-acts");

  function mk(name, iconName, title, fn) {
    var b = el("button", "act");
    b.title = title;
    b.innerHTML = ico(iconName) + '<span class="lbl-txt">' + esc(name) + "</span>";
    b.onclick = function (e) { e.stopPropagation(); fn(b); };
    acts.appendChild(b);
    return b;
  }

  if (role === "ai") {
    mk("Yeniden", "refresh", "Bu yanıtı yeniden üret", function () {
      var prev = findPrevUser(msgEl);
      if (!prev) { toast("Önceki istem bulunamadı", "warn"); return; }
      if (state.busy) { toast("Önce mevcut işlem bitsin", "warn"); return; }
      submitText(prev, { regen: true });
    });
  }

  mk("Alıntı", "quote", "Yanıtta alıntıla", function () {
    var ta = $("#input");
    var t = (msgEl._raw || body.innerText).split("\n")
      .slice(0, 12).map(function (l) { return "> " + l; }).join("\n");
    ta.value = t + "\n\n" + ta.value;
    ta.focus(); autoGrow();
  });

  /* Kullanıcının kendi mesajında silme eylemi gösterme.
     Asistan mesajlarında mevcut yerel gizleme davranışı korunur. */
  if (role === "ai") {
    mk("Sil", "trash", "Bu mesajı gizle", function () {
      msgEl.style.transition = "opacity .2s, transform .2s";
      msgEl.style.opacity = "0";
      msgEl.style.transform = "translateX(-12px)";
      setTimeout(function () { msgEl.remove(); }, 210);
    });
  }

  /* Saat artık üst başlıkta değil, alt eylem satırında. */
  if (S.timestamps === "1") {
    var stamp = el("span", "msg-time-bottom");
    stamp.textContent = U.ts();
    acts.appendChild(stamp);
  }

  return acts;
}

function findPrevUser(node) {
  var p = node.previousElementSibling;
  while (p) {
    if (p.classList.contains("user")) return p._raw || p.querySelector(".body").textContent;
    p = p.previousElementSibling;
  }
  return null;
}

function copyText(t) {
  if (navigator.clipboard && W.isSecureContext) return navigator.clipboard.writeText(t);
  return new Promise(function (res) {
    var ta = document.createElement("textarea");
    ta.value = t; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); } catch (e) {}
    ta.remove(); res();
  });
}

/* ---- kod bloğu düğmeleri ---- */
function wireCode(root) {
  $$(".codeblock", root).forEach(function (cb) {
    if (cb.dataset.wired) return;
    cb.dataset.wired = "1";
    var pre = cb.querySelector("pre");
    var cp = cb.querySelector(".cb-copy");
    if (cp) cp.onclick = function () {
      copyText(pre.innerText).then(function () {
        cp.classList.add("ok");
        cp.innerHTML = ico("check") + "<span>kopyalandı</span>";
        setTimeout(function () {
          cp.classList.remove("ok");
          cp.innerHTML = ico("copy") + "<span>kopyala</span>";
        }, 1500);
      });
    };
    var wr = cb.querySelector(".cb-wrap");
    if (wr) wr.onclick = function () { cb.classList.toggle("wrap"); };
    var dl = cb.querySelector(".cb-dl");
    if (dl) dl.onclick = function () {
      var lang = (cb.querySelector(".lang") || {}).textContent || "txt";
      var extMap = { python: "py", javascript: "js", typescript: "ts", bash: "sh", shell: "sh" };
      var ext = extMap[lang] || (lang.length <= 5 ? lang : "txt");
      var blob = new Blob([pre.innerText], { type: "text/plain;charset=utf-8" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "mixium-" + Date.now() + "." + ext;
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
      toast("Kod indirildi", "ok");
    };
    var more = cb.querySelector(".cb-more");
    if (more) more.onclick = function () {
      cb.classList.remove("folded");
      more.remove();
    };
  });
}

/* ============================================================
   AKIŞ — asistan metni
   ============================================================ */
function ensureStream() {
  if (!state.cur) {
    state.cur = addMsg("ai", "");
    state.cur.classList.add("streaming");
    state.cur._raw = "";
    /* SADECE bu mesajın maskotu canlanır */
    if (state.cur._presence && W.Mascot) {
      W.Mascot.claim(state.cur._presence);
      state.curPresence = state.cur._presence;
      W.Mascot.state("talk");
    }
  }
  return state.cur;
}

var _renderPending = false;
var _renderTimer = null;
function _doRender() {
  _renderPending = false;
  if (_renderTimer) { clearTimeout(_renderTimer); _renderTimer = null; }
  if (!state.cur) return;
  state.cur._body.innerHTML = U.mdRender(state.cur._raw);
  wireCode(state.cur._body);
  if (state.pinned) scrollBottom();
}
function appendText(t) {
  if (!t) return;
  var m = ensureStream();

  // Upstream/provider bazen delta yerine birikmiş cevabı tekrar yollar.
  // Frontend tarafında da ikinci bir güvenlik katmanı: mevcut metinle
  // örtüşen (cumulative) chunk'ı yalnızca yeni kısmına indir.
  var raw = m._raw || "";
  if (raw && t === raw) return;
  if (raw && t.indexOf(raw) === 0) {
    t = t.slice(raw.length);
    if (!t) return;
  }

  // Bazı modeller cevabın başına son kullanıcı mesajını yankılıyor
  // ("Selam" -> "Selam! 😊"). İlk AI parçasında bu yankıyı temizle.
  if (!raw) {
    var prevUser = findPrevUser(m);
    if (prevUser) {
      var u = String(prevUser).trim();
      var x = String(t);
      if (u && x.slice(0, u.length).toLowerCase() === u.toLowerCase()) {
        t = x.slice(u.length).replace(/^[\\s:：,，.!！?？~～-]+/, "");
        if (!t) return;
      }
    }
  }

  m._raw += t;
  // Anlık karakter render: chunk gelince ya rAF ile hemen ya da max 16ms sonra zorla.
  if (_renderPending) {
    // Zaten bir rAF bekliyor — timer ile en fazla 16ms'de zorla render et
    if (!_renderTimer) {
      _renderTimer = setTimeout(_doRender, 16);
    }
    return;
  }
  _renderPending = true;
  requestAnimationFrame(_doRender);
}

/* scroll ziplamasini onler: yeniden render sonrasi layout oturunca tekrar en alta */
function scrollBottom(force) {
  var c = $("#chat");
  if (!c) return;
  if (force) state.pinned = true;
  requestAnimationFrame(function () {
    if (!c) return;
    c.scrollTop = c.scrollHeight;
  });
}

/* ============================================================
   ARAÇ KARTLARI
   ============================================================ */
var TOOL_ICON = {
  bash: "terminal", shell: "terminal", run: "play",
  read: "file", write: "edit", edit: "edit", multi_edit: "edit",
  patch: "layers", glob: "folder", grep: "search", tree: "folder",
  todo: "check", fetch: "globe", web_search: "globe", browser: "globe",
  download: "download", calc: "cpu", git: "branch", memory: "brain",
  jobs: "clock", subagent: "sparkle", whois: "shield",
  json_query: "code", csv_stat: "grid", text_stat: "book",
  diff_files: "layers", replace_glob: "edit", file_info: "info",
  hash_tool: "key", encode: "code", uuid_tool: "key", time_tool: "clock",
  regex_test: "filter", env_info: "cpu", pkg_info: "layers",
  port_check: "globe", archive: "folder", pretty: "sparkle",
  sandbox_py: "play", count_tokens: "cpu", project_map: "grid",
  lint_py: "check"
};

function toolCard(name, arg) {
  var host = state.cur ? state.cur._body : ensureStream()._body;
  var c = el("div", "tool running open");
  c.innerHTML =
    '<div class="tool-h">' +
      '<span class="tool-ico">' + ico(TOOL_ICON[name] || "wrench") + "</span>" +
      '<span class="tool-nm">' + esc(name) + "</span>" +
      '<span class="tool-arg">' + esc(arg || "") + "</span>" +
      '<span class="tool-ms"></span>' +
      '<span class="tool-st"><span class="tool-spinner"></span></span>' +
      '<span class="tool-chev">' + ico("chevD") + "</span>" +
    "</div>" +
    '<div class="tool-body"><div class="inner"></div></div>';

  var head = c.querySelector(".tool-h");
  head.onclick = function () { c.classList.toggle("open"); };

  host.appendChild(c);
  c._inner = c.querySelector(".inner");
  c._t0 = Date.now();
  state.toolCount++;
  updateStatusMeta();

  /* maskot: aracın türüne göre — SADECE aktif maskot */
  W.Mascot.tool(name);
  setStatus(W.Mascot.label(W.Mascot.currentState()), name);

  if (state.pinned) scrollBottom();
  return c;
}

function toolOut(card, text) {
  if (!card) return;
  var sec = card._outSec;
  if (!sec) {
    sec = el("div", "tool-sec");
    sec.innerHTML = '<div class="lbl">çıktı</div><pre></pre>';
    card._inner.appendChild(sec);
    card._outSec = sec;
    card._pre = sec.querySelector("pre");
  }
  card._pre.textContent += (card._pre.textContent ? "\n" : "") + text;
  /* diff renklendirme */
  if (/^[+-]/m.test(text)) colorDiff(card._pre);
  card._pre.scrollTop = card._pre.scrollHeight;
  if (state.pinned) scrollBottom();
}

function colorDiff(pre) {
  var txt = pre.textContent;
  if (!/^[-+@]/m.test(txt)) return;
  pre.innerHTML = txt.split("\n").map(function (l) {
    if (/^\+\+\+|^---|^@@/.test(l)) return '<span class="d-hdr">' + esc(l) + "</span>";
    if (l[0] === "+") return '<span class="d-add">' + esc(l) + "</span>";
    if (l[0] === "-") return '<span class="d-del">' + esc(l) + "</span>";
    return esc(l);
  }).join("\n");
}

function toolDone(card, meta, failed) {
  if (!card) return;
  card.classList.remove("running");
  card.classList.add(failed ? "failed" : "ok-done");
  var st = card.querySelector(".tool-st");
  st.innerHTML = ico(failed ? "warn" : "check");
  st.style.color = failed ? "var(--err)" : "var(--ok)";
  var ms = card.querySelector(".tool-ms");
  ms.textContent = U.elapsed(Date.now() - card._t0);
  if (meta) {
    var arg = card.querySelector(".tool-arg");
    if (!arg.textContent.trim()) arg.textContent = meta;
  }
  /* uzun çıktıyı kapat, kısa olanı açık bırak */
  var len = card._pre ? card._pre.textContent.length : 0;
  if (len > 700 || failed === false && len === 0) card.classList.remove("open");
  if (failed) {
    card.classList.add("open");
    if (state.curPresence) W.Mascot.state("error");
  }
}

/* ============================================================
   PLAN ONAYI KARTLARI
   —————————————————————————————————————————————————————————————
   Kaynak: Claude Code ExitPlanModeV2Tool.checkPermissions() +
           PlanApprovalMessage.tsx → davranış Mixium'a adapte edildi.
   UI: toolCard() bileşeni reuse edildi. Yeni CSS sınıfı yok.
   Claude Code'un React/TUI UI'ı ALINMADI — sadece approve/reject
   lifecycle mantığı alındı.
   ============================================================ */

/* Aktif plan kartlarını plan_id ile izle */
var _planCards = {};  /* plan_id -> card DOM element */

function planApprovalCard(plan, brief) {
  if (!plan || !plan.id) return;

  /* Mevcut akış balonuna ya da yeni bir balona ekle */
  var host = state.cur ? state.cur._body : ensureStream()._body;

  /* toolCard() kalıbıyla uyumlu — aynı .tool sınıflarını kullan */
  var c = el("div", "tool running open plan-approval-card");
  c.dataset.planId = plan.id;

  var toolLabel = plan.tool ? esc(plan.tool) : "işlem";
  var argsLabel = brief ? esc(brief) : (plan.summary ? esc(plan.summary) : "");

  c.innerHTML =
    '<div class="tool-h">' +
      '<span class="tool-ico">' + ico("layers") + "</span>" +
      '<span class="tool-nm">Plan Onayı</span>' +
      '<span class="tool-arg">' + toolLabel + (argsLabel ? " · " + argsLabel : "") + "</span>" +
      '<span class="tool-ms"></span>' +
      '<span class="tool-st"><span class="tool-spinner"></span></span>' +
      '<span class="tool-chev">' + ico("chevD") + "</span>" +
    "</div>" +
    '<div class="tool-body"><div class="inner">' +
      /* Plan özeti */
      '<div class="plan-info">' +
        '<p class="plan-what">' + ico("shield") + " <strong>" + toolLabel + "</strong>" +
          (argsLabel ? " — " + argsLabel : "") +
        "</p>" +
        '<p class="plan-hint">Bu işlemi onaylamak istiyor musunuz?</p>' +
      "</div>" +
      /* Geri bildirim alanı (red için) */
      '<div class="plan-fb-wrap" style="display:none">' +
        '<textarea class="plan-fb" rows="2" placeholder="Neden reddediyorsunuz? (opsiyonel)"></textarea>' +
      "</div>" +
      /* Butonlar — mevcut .btn-ghost sınıfı */
      '<div class="plan-actions">' +
        '<button class="btn-ghost plan-btn-approve" title="Onayla ve çalıştır">' +
          ico("check") + " Onayla" +
        "</button>" +
        '<button class="btn-ghost plan-btn-reject" title="Reddet">' +
          ico("warn") + " Reddet" +
        "</button>" +
      "</div>" +
    "</div></div>";

  var head = c.querySelector(".tool-h");
  head.onclick = function () { c.classList.toggle("open"); };

  /* Onayla butonu */
  var btnApprove = c.querySelector(".plan-btn-approve");
  btnApprove.onclick = function (e) {
    e.stopPropagation();
    _sendPlanResponse(plan.id, "approve", "");
    _lockPlanCard(c, "Onaylandı…");
  };

  /* Reddet butonu — önce geri bildirim alanını göster */
  var btnReject = c.querySelector(".plan-btn-reject");
  var fbWrap = c.querySelector(".plan-fb-wrap");
  var fbEl   = c.querySelector(".plan-fb");
  var _rejectReady = false;

  btnReject.onclick = function (e) {
    e.stopPropagation();
    if (!_rejectReady) {
      /* İlk tık: geri bildirim alanını aç, butonu "Gönder"e çevir */
      fbWrap.style.display = "";
      fbEl.focus();
      btnReject.textContent = "Reddet — Gönder";
      _rejectReady = true;
      return;
    }
    /* İkinci tık: gerçekten reddet */
    var feedback = fbEl.value.trim();
    _sendPlanResponse(plan.id, "reject", feedback);
    _lockPlanCard(c, "Reddedildi" + (feedback ? ": " + feedback.slice(0, 60) : ""));
  };

  host.appendChild(c);
  c._t0 = Date.now();
  _planCards[plan.id] = c;

  /* Maskot: onay bekleniyor */
  if (state.curPresence) W.Mascot.state("think");
  setStatus("Plan onayı bekleniyor", plan.tool);

  if (state.pinned) scrollBottom();
  return c;
}

function _sendPlanResponse(planId, action, feedback) {
  send({ type: "plan_respond", plan_id: planId, action: action, feedback: feedback || "" });
}

function _lockPlanCard(card, statusText) {
  /* Butonları kaldır, kartı kilitli göster */
  var actions = card.querySelector(".plan-actions");
  if (actions) actions.remove();
  var fbWrap = card.querySelector(".plan-fb-wrap");
  if (fbWrap) fbWrap.remove();
  var hintEl = card.querySelector(".plan-hint");
  if (hintEl) hintEl.textContent = statusText || "İşleniyor…";
}

function planApprovalDone(planId, approved, feedback) {
  var card = _planCards[planId];
  if (!card) return;
  delete _planCards[planId];

  /* toolDone() kalıbıyla aynı state geçişi */
  card.classList.remove("running");
  card.classList.add(approved ? "ok-done" : "failed");

  var st = card.querySelector(".tool-st");
  if (st) {
    st.innerHTML = ico(approved ? "check" : "warn");
    st.style.color = approved ? "var(--ok)" : "var(--err)";
  }
  var ms = card.querySelector(".tool-ms");
  if (ms) ms.textContent = U.elapsed(Date.now() - (card._t0 || Date.now()));

  /* Geri bildirim alanı ve butonları temizle */
  var actions = card.querySelector(".plan-actions");
  if (actions) actions.remove();
  var fbWrap = card.querySelector(".plan-fb-wrap");
  if (fbWrap) fbWrap.remove();

  /* Bilgi metni güncelle */
  var hintEl = card.querySelector(".plan-hint");
  if (hintEl) {
    if (approved) {
      hintEl.textContent = "Onaylandı — işlem çalışıyor.";
    } else {
      hintEl.textContent = "Reddedildi" + (feedback ? ": " + feedback.slice(0, 120) : "") + ". Plan modunda kalındı.";
    }
  }

  /* Mascot */
  if (approved) {
    if (state.curPresence) W.Mascot.state("work");
    clearStatus();
  } else {
    if (state.curPresence) W.Mascot.state("idle");
    clearStatus();
    toast(feedback ? "Plan reddedildi: " + feedback.slice(0, 80) : "Plan reddedildi", "warn");
  }

  card.classList.add("open");
  if (state.pinned) scrollBottom();
}

/* ============================================================
   TODO / TASK SİSTEMİ
   Claude Code TodoWriteTool + TaskCreate/Update/Stop lifecycle'ından adapte.
   UI: mevcut .tool / .tool-body / .tool-h CSS sınıfları — yeni class yok.
   ============================================================ */
var _todoPanelEl = null;  /* aktif todo panel DOM elementi */
var _taskCards   = {};    /* task_id -> card DOM element */

/* Status → CSS sınıfı + sembol eşlemesi */
var TODO_STATUS_MAP = {
  "pending":   { cls: "",         sym: "○", label: "bekliyor" },
  "active":    { cls: "running",  sym: "◉", label: "çalışıyor" },
  "in_progress":{ cls: "running", sym: "◉", label: "çalışıyor" },
  "done":      { cls: "ok-done",  sym: "✓", label: "tamamlandı" },
  "completed": { cls: "ok-done",  sym: "✓", label: "tamamlandı" }
};
var TASK_STATUS_MAP = {
  "pending":   { cls: "",         sym: "○", label: "bekliyor" },
  "running":   { cls: "running",  sym: "◉", label: "çalışıyor" },
  "completed": { cls: "ok-done",  sym: "✓", label: "tamamlandı" },
  "failed":    { cls: "failed",   sym: "✗", label: "hata" },
  "cancelled": { cls: "failed",   sym: "⊘", label: "durduruldu" }
};

/**
 * Todo listesini mevcut akış mesajının içine render et.
 * Zaten bir todo paneli varsa güncelle, yoksa yenisini oluştur.
 * Plan sistemindeki planApprovalCard() kalıbı kullanıldı.
 */
function renderTodoPanel(items) {
  if (!items || items.length === 0) {
    if (_todoPanelEl && _todoPanelEl.parentNode) {
      _todoPanelEl.parentNode.removeChild(_todoPanelEl);
    }
    _todoPanelEl = null;
    return;
  }

  /* Tüm item'lar tamamlandıysa paneli kaldır */
  var allDone = items.every(function(it) {
    return it.status === "done" || it.status === "completed";
  });
  if (allDone && _todoPanelEl && _todoPanelEl.parentNode) {
    _todoPanelEl.parentNode.removeChild(_todoPanelEl);
    _todoPanelEl = null;
    return;
  }

  var doneCount    = items.filter(function(it) {
    return it.status === "done" || it.status === "completed";
  }).length;
  var activeCount  = items.filter(function(it) {
    return it.status === "active" || it.status === "in_progress";
  }).length;

  /* Panel yok mu? Oluştur */
  if (!_todoPanelEl) {
    var host = state.cur ? state.cur._body : ensureStream()._body;
    var c = el("div", "tool open todo-panel");
    c.innerHTML =
      '<div class="tool-h">' +
        '<span class="tool-ico">' + ico("check") + "</span>" +
        '<span class="tool-nm">Görevler</span>' +
        '<span class="tool-arg todo-progress"></span>' +
        '<span class="tool-chev">' + ico("chevron-down") + "</span>" +
      "</div>" +
      '<div class="tool-body"><div class="inner todo-list"></div></div>';

    /* Chevron toggle */
    c.querySelector(".tool-h").addEventListener("click", function() {
      c.classList.toggle("open");
    });
    host.appendChild(c);
    _todoPanelEl = c;
  }

  /* Progress güncelle */
  var progEl = _todoPanelEl.querySelector(".todo-progress");
  if (progEl) {
    progEl.textContent = doneCount + "/" + items.length + " tamamlandı";
    if (activeCount > 0) {
      progEl.textContent += " · " + activeCount + " aktif";
    }
  }

  /* Status gösterge rengi */
  _todoPanelEl.classList.remove("running", "ok-done");
  if (activeCount > 0)       _todoPanelEl.classList.add("running");
  else if (doneCount === items.length) _todoPanelEl.classList.add("ok-done");

  /* Liste render */
  var listEl = _todoPanelEl.querySelector(".todo-list");
  if (!listEl) return;
  listEl.innerHTML = "";
  items.forEach(function(it, idx) {
    var sm = TODO_STATUS_MAP[it.status] || TODO_STATUS_MAP["pending"];
    var row = document.createElement("div");
    row.className = "todo-row " + sm.cls;
    var label = it.activeForm && (it.status === "active" || it.status === "in_progress")
                ? esc(it.activeForm) : esc(it.content || "");
    row.innerHTML =
      '<span class="todo-sym">' + esc(sm.sym) + "</span>" +
      '<span class="todo-label">' + label + "</span>";
    listEl.appendChild(row);
  });

  if (state.pinned) scrollBottom();
}

/**
 * Tek bir task'ı toolCard kalıbıyla göster/güncelle.
 * Her task_id için bir kart tutulur; durum değişince güncellenir.
 */
function updateTaskCard(task) {
  if (!task || !task.id) return;
  var tid = String(task.id);
  var sm  = TASK_STATUS_MAP[task.status] || TASK_STATUS_MAP["pending"];
  var activeLabel = task.activeForm && task.status === "running"
                    ? esc(task.activeForm) : esc(task.title || "");

  /* Kart var mı? */
  if (_taskCards[tid]) {
    var c = _taskCards[tid];
    /* Sınıf güncelle */
    c.classList.remove("running", "ok-done", "failed");
    if (sm.cls) c.classList.add(sm.cls);

    /* Başlık güncelle */
    var argEl = c.querySelector(".tool-arg");
    if (argEl) argEl.textContent = activeLabel;

    /* Meta güncelle */
    var msEl = c.querySelector(".tool-ms");
    if (msEl) msEl.textContent = sm.label;

    /* Sonuç/hata */
    var inner = c.querySelector(".tool-body .inner");
    if (inner && (task.result || task.error)) {
      inner.textContent = task.result || task.error || "";
    }
    return;
  }

  /* Yeni kart oluştur — toolCard() kalıbıyla uyumlu */
  var host = state.cur ? state.cur._body : ensureStream()._body;
  var card = el("div", "tool open task-card " + sm.cls);
  card.dataset.taskId = tid;
  card.innerHTML =
    '<div class="tool-h">' +
      '<span class="tool-ico">' + ico("sparkle") + "</span>" +
      '<span class="tool-nm">#' + esc(tid) + "</span>" +
      '<span class="tool-arg">' + activeLabel + "</span>" +
      '<span class="tool-ms">' + esc(sm.label) + "</span>" +
      (task.status === "running"
        ? '<span class="tool-spinner"></span>'
        : "") +
      '<span class="tool-chev">' + ico("chevron-down") + "</span>" +
    "</div>" +
    '<div class="tool-body"><div class="inner">' +
      (task.result || task.error ? esc(task.result || task.error) : "") +
    "</div></div>";

  /* Chevron toggle */
  card.querySelector(".tool-h").addEventListener("click", function() {
    card.classList.toggle("open");
  });

  host.appendChild(card);
  _taskCards[tid] = card;
  if (state.pinned) scrollBottom();
}

/* run_start'ta todo panel ve task kartlarını temizle */
var _origRunStart_todo = null;  // hook: run_start'a eklemek için aşağıda patch

/* ============================================================
   DURUM ÇUBUĞU
   ============================================================ */
function setStatus(txt, sub) {
  var t = $("#statusTxt");
  if (!t) return;
  t.textContent = txt || "";
  t.className = "txt shimmer";
  var s = $("#statusSub");
  if (s) s.textContent = sub ? "· " + sub : "";
}
function updateStatusMeta() {
  var e = $("#statusEl");
  if (!e) return;
  var parts = [];
  if (state.toolCount) parts.push(state.toolCount + " araç");
  if (state.runT0) parts.push(U.elapsed(Date.now() - state.runT0));
  e.textContent = parts.join(" · ");
}
function clearStatus() {
  var t = $("#statusTxt");
  if (t) { t.textContent = ""; t.className = "txt"; }
  var s = $("#statusSub"); if (s) s.textContent = "";
  var e = $("#statusEl"); if (e) e.textContent = "";
}

function setBusy(b) {
  state.busy = b;
  $("#sendBtn").disabled = b;
  $("#bottom").classList.toggle("busy", b);
  $("#composer").classList.toggle("busy", b);
  if (b) {
    state.runT0 = Date.now();
    state.toolCount = 0;
    clearInterval(state.tick);
    state.tick = setInterval(updateStatusMeta, 250);
    clearTimeout(state.responseWatchdog);
    /* Sunucu/LLM tamamen asılırsa mobil UI sonsuza kadar Durdur'da kalmasın. */
    state.responseWatchdog = setTimeout(function () {
      if (!state.busy) return;
      state.submitInFlight = false;
      finishStream();
      setBusy(false);
      clearStatus();
      addMsg("err", "Model yanıtı zaman aşımına uğradı. Lütfen tekrar deneyin.");
      toast("Model yanıt vermedi — bağlantı yeniden denenebilir.", "err");
    }, 210000);
  } else {
    clearInterval(state.tick);
    state.tick = null;
    clearTimeout(state.responseWatchdog);
    state.responseWatchdog = null;
    state.runT0 = 0;
  }
}

/* ============================================================
   KAYDIRMA
   ============================================================ */
function initScroll() {
  var c = $("#chat");
  var btn = $("#scrollDown");
  c.addEventListener("scroll", function () {
    var gap = c.scrollHeight - c.scrollTop - c.clientHeight;
    state.pinned = gap < 90;
    if (btn) btn.classList.toggle("show", gap > 220);
  }, { passive: true });
  if (btn) btn.onclick = function () { scrollBottom(true); };
}

/* ============================================================
   SUNUCU MESAJ İŞLEYİCİ
   ============================================================ */
function handle(m) {
  switch (m.type) {
    case "hello":
      state.session = m.session;
      state.model = m.model;
      state.mode = m.mode || "auto";
      state.effort = m.effort || "normal";
      state.thinking = !!m.thinking;
      state.models = m.models || [];
      state.sessions = m.sessions || [];
      state.ready = true;
      // hello gelince eğer sahte busy varsa temizle
      if (state.busy && !state.submitInFlight) {
        setBusy(false);
      }
      setTitle(m.title, m.model);
      renderSessions(state.sessions);
      W.Pickers.fillModels(state.models, state.model);
      W.Pickers.setMode(state.mode);
      break;

    case "sessions":
      state.sessions = m.items || [];
      renderSessions(state.sessions);
      break;

    case "models":
      state.models = m.items || [];
      W.Pickers.fillModels(state.models, state.model);
      break;

    case "history":
      renderHistory(m);
      break;

    case "run_start":
      /* KRİTİK: submitInFlight burada SIFIRLANAMAZ.
         Sunucu run_start gönderene kadar ikinci dokunuş zaten engellenmeli;
         run_start geldikten sonra da işlem bitene kadar kilit aktif kalmalı. */
      state.submitInFlight = true;
      setBusy(true);
      finishStream();
      state.cur = null; state.toolOpen = null; state.toolBuf = "";
      /* Her yeni run'da todo panelini ve task kartlarını temizle */
      _todoPanelEl = null;
      _taskCards   = {};
      /* akış mesajını hemen oluştur ve maskotu ata */
      ensureStream();
      if (W.Mascot) W.Mascot.state("think");
      break;

    case "out":
      feedLine(m.text);
      break;

    case "final":
      break;

    case "done":
      state.submitInFlight = false;
      if (state.busy || state.cur) {
        finishStream();
        setBusy(false);
        clearStatus();
        if (state.curPresence) { W.Mascot.release("done"); state.curPresence = null; }
        if (S.sound === "on") beep();
      }
      break;

    case "error":
      state.submitInFlight = false;
      finishStream();
      addMsg("err", m.text);
      setBusy(false);
      clearStatus();
      W.Mascot.release("error");
      state.curPresence = null;
      toast("Bir hata oluştu: " + String(m.text || "sunucu hatası").slice(0, 180), "err");
      break;

    case "busy":
      state.submitInFlight = false;
      setBusy(false);
      toast("Bir işlem zaten sürüyor", "warn");
      break;

    case "session":
      state.session = m.id; state.model = m.model;
      setTitle(m.title === "yeni oturum" ? "Yeni oturum" : m.title, m.model);
      break;

    case "model_ok":
      state.model = m.model; state.ai = m.ai;
      W.Pickers.fillModels(state.models, state.model);
      toast("Model: " + shortModel(m.model), "ok");
      break;

    case "mode_ok":
      state.mode = m.mode;
      W.Pickers.setMode(m.mode);
      break;

    case "effort_ok":
      state.effort = m.effort;
      // Model picker menüsünü güncelle (checkmark)
      W.Pickers.fillModels(state.models, state.model);
      break;

    case "thinking_ok":
      state.thinking = !!m.on;
      break;

    case "tools_list":
      W.Panels.renderTools(m.items || []);
      break;

    /* ── Plan onay sistemi ────────────────────────────────────────────
       Backend: mixium_new.py PlanState + Permission.check() web adaptasyonu
       Claude Code ExitPlanModeV2Tool / checkPermissions mantığından alındı.
       UI: mevcut toolCard() bileşeni reuse edildi — yeni CSS yok.
    ─────────────────────────────────────────────────────────────────── */
    case "plan_approval_request":
      planApprovalCard(m.plan, m.brief || "");
      break;

    case "plan_approved":
      planApprovalDone(m.plan_id, true, "");
      break;

    case "plan_rejected":
      planApprovalDone(m.plan_id, false, m.feedback || "");
      break;

    /* ── Todo/Task sistemi ────────────────────────────────────────────
       Backend: mixium_new.py TodoWriteTool/TaskCreate/TaskUpdate adaptasyonu
       Claude Code'dan alınan lifecycle: pending→running→completed/failed/cancelled
       UI: mevcut toolCard CSS sınıfları kullanılır — yeni CSS yok.
    ─────────────────────────────────────────────────────────────────── */
    case "todo_update":
      renderTodoPanel(m.items || []);
      break;

    case "task_update":
      updateTaskCard(m.task);
      break;

    default:
      // Yönetim Paneli (DNA & Efor, Sistem, Modeller, Oturumlar) mesajları:
      // panel.js "Panel.on(m)" bekliyor; bu satır olmadan panel_* yanıtları
      // hiçbir yere ulaşmıyor ve sekmeler sonsuza dek "Yükleniyor…" kalıyor.
      if (typeof m.type === "string" && m.type.indexOf("panel_") === 0 &&
          W.Panel && W.Panel.on) {
        W.Panel.on(m);
      }
      if (W.Panels && W.Panels.handle) W.Panels.handle(m);
  }
}

function finishStream() {
  if (state.cur) {
    state.cur.classList.remove("streaming");
    if (state.cur._presence) {
      W.Mascot.freeze(state.cur._presence, "idle");
    }
  }
  if (state.toolOpen) {
    toolDone(state.toolOpen, "", false);
    state.toolOpen = null;
  }
}

/* ---- sunucudan gelen satırları ayrıştır ---- */
function feedLine(t) {
  if (t == null) return;

  /* Gerçek canlı streaming: \n ile biten = tam satır, bitmeden = chunk.
     Chunk gelince sadece append et, satır sonu ekleme.            */
  var isChunk = t.length > 0 && t[t.length - 1] !== "\n";

  /* satır sonu temizle (tam satırlarda) */
  var tLine = isChunk ? t : t.replace(/\r?\n$/, "");

  /* araç başlığı:  ● toolname arg  (sadece tam satırlarda) */
  if (!isChunk) {
    var tm = tLine.match(/^\s*[●•]\s+([A-Za-z_][\w]*)\s*(.*)$/);
    if (tm) {
      if (state.toolOpen) toolDone(state.toolOpen, "", false);
      state.toolOpen = toolCard(tm[1], tm[2]);
      state.toolBuf = "";
      return;
    }
    /* araç bitiş:  ⏿ meta */
    if (/^\s*[⏿⌐⏋⎿]/.test(tLine)) {
      if (state.toolOpen) {
        var meta = tLine.replace(/^\s*[⏿⌐⏋⎿]\s*/, "");
        toolDone(state.toolOpen, meta, /hata|error|başarısız/i.test(meta));
        state.toolOpen = null;
      }
      return;
    }
    /* araç çıktısı: girintili satırlar */
    if (state.toolOpen && /^\s{4,}/.test(tLine)) {
      var s = tLine.trim();
      if (s && s[0] !== "…") toolOut(state.toolOpen, s);
      return;
    }
    if (state.toolOpen && /^\s*…/.test(tLine)) return;
    /* gürültü filtreleri — sadece tam satırlarda */
    if (tLine.trim() === "") { appendText("\n"); return; }
    if (/^\s*[\d.]+s\s*(\d+ ara[cç]\s*)?(\d+ d[uü]zenleme\s*)?$/.test(tLine)) return;
    if (/^[▌|]\s/.test(tLine)) return;
  }

  /* metin akışı */
  var sniff = W.Mascot ? W.Mascot.sniff(tLine) : null;
  if (W.Mascot) {
    if (sniff && !state.toolOpen) W.Mascot.state(sniff);
    else if (!state.toolOpen) W.Mascot.state("talk");
  }

  /* chunk ise direkt append (satır sonu YOK), tam satırsa \n ekle */
  appendText(isChunk ? t : tLine + "\n");
}

/* ============================================================
   BAŞLIK / OTURUMLAR
   ============================================================ */
function setTitle(title, model) {
  var t = $("#topName");
  if (t) t.textContent = title && title !== "yeni oturum" ? title : "Yeni oturum";
  var b = $("#topBadge");
  if (b) {
    b.textContent = model ? shortModel(model) : "";
    b.style.display = model ? "" : "none";
  }
  document.title = (title && title !== "yeni oturum" ? title + " · " : "") + "Mixium";
}

function renderSessions(items) {
  var box = $("#sessList");
  if (!box) return;
  var q = ($("#sessSearch") || {}).value || "";
  var list = items;
  if (q.trim()) {
    var lq = q.toLowerCase();
    list = items.filter(function (s) {
      return (s.title || "").toLowerCase().indexOf(lq) >= 0 ||
             (s.model || "").toLowerCase().indexOf(lq) >= 0;
    });
  }
  var cnt = $("#sessCount");
  if (cnt) cnt.textContent = items.length;

  box.innerHTML = "";
  if (!list.length) {
    box.innerHTML = '<div class="sess-empty">' +
      (q.trim() ? "Eşleşen oturum yok." : "Henüz oturum yok.<br>Yeni oturum ile başla.") +
      "</div>";
    return;
  }
  list.forEach(function (s, i) {
    var d = el("div", "sess" + (state.session === s.id ? " active" : ""));
    d.style.animationDelay = Math.min(i * 18, 300) + "ms";
    var mins = Math.round(Date.now() / 1000 - s.mtime);
    d.innerHTML =
      '<div class="r1"><div class="t">' + esc(s.title || "yeni oturum") + "</div>" +
        '<div class="acts">' +
          '<button class="ren" title="Yeniden adlandır">' + ico("edit") + "</button>" +
          '<button class="del" title="Sil">' + ico("trash") + "</button>" +
        "</div></div>" +
      '<div class="r2"><span class="mdl">' + esc(shortModel(s.model || "?")) + "</span>" +
        "<span>" + (s.n ? s.n + " msj · " : "") + U.agoTxt(mins) + "</span></div>";

    d.querySelector(".del").onclick = function (e) {
      e.stopPropagation();
      W.Panels.confirm("Oturumu sil", "“" + (s.title || "bu oturum") +
        "” kalıcı olarak silinecek. Emin misin?", function () {
        send({ type: "del", id: s.id });
        toast("Oturum silindi", "ok");
      });
    };
    d.querySelector(".ren").onclick = function (e) {
      e.stopPropagation();
      toast("Başlığı üstteki alandan düzenleyebilirsin", "info");
    };
    d.onclick = function () {
      if (state.busy) { toast("Önce mevcut işlem bitsin", "warn"); return; }
      send({ type: "open", id: s.id });
      state.session = s.id;
      renderSessions(state.sessions);
      W.Shell.closeSidebar();
    };
    box.appendChild(d);
  });
}

function renderHistory(m) {
  var inner = chatInner();
  inner.innerHTML = "";
  state.cur = null; state.toolOpen = null; state.pinned = true;
  state.session = m.session;
  setTitle(m.title, m.model);
  if (m.model) state.model = m.model;

  var msgs = m.messages || [];
  if (!msgs.length) { showEmpty(); return; }
  msgs.forEach(function (x) {
    if (x.role === "system") return;
    var node = addMsg(x.role === "user" ? "user" : "ai", x.content || "", { attachments: x.attachments || [] });
    node.style.animation = "none";
    /* geçmiş maskotları KESİNLİKLE donmuş */
    if (node._presence) W.Mascot.freeze(node._presence, "idle");
  });
  renderSessions(state.sessions);
  requestAnimationFrame(function () { scrollBottom(true); });
}

/* ============================================================
   KARŞILAMA EKRANI
   ============================================================ */
var STARTERS = [
  ["folder",   "Bu projede ne var, mimarisini özetle"],
  ["search",   "Kodda TODO ve FIXME'leri bul, önceliklendir"],
  ["terminal", "Testleri çalıştır ve başarısız olanları düzelt"],
  ["bolt",     "Performans darboğazlarını tespit et"],
  ["shield",   "Güvenlik açıklarını tara ve raporla"],
  ["book",     "Bu koda README ve dokümantasyon yaz"]
];

function showEmpty() {
  var inner = chatInner();
  if ($("#empty")) return;
  var e = el("div", "");
  e.id = "empty";

  /* Mixium yerel durum çekirdeği */
  var hero = el("div", "hero-orb");
  hero.appendChild(W.Mascot.make({ size: 48, state: "idle" }));
  e.appendChild(hero);

  e.appendChild(el("h1", "hero-title", "Mixium"));
  e.appendChild(el("p", "hero-sub", "Ne yapalım?"));

  /* öneri chip'leri — sade, ikonsuz */
  var chips = el("div", "chips");
  STARTERS.forEach(function (s) {
    var c = el("button", "chip");
    c.innerHTML = '<span class="ct">' + esc(s[1]) + "</span>";
    c.onclick = function () { submitText(s[1]); };
    chips.appendChild(c);
  });
  e.appendChild(chips);

  inner.appendChild(e);
}

/* ============================================================
   GÖNDERİM
   ============================================================ */
function submitText(text, opts) {
  opts = opts || {};
  text = String(text || "").trim();
  if (!text && !state.attachments.length) return;
  if (!state.ready) { toast("Bağlanılıyor, lütfen bekle…", "warn"); return; }
  if (state.busy || state.submitInFlight) {
    // Eğer run_start hiç gelmemişse (sahte busy), temizle
    if (!state.submitInFlight) { setBusy(false); }
    else { toast("Bir işlem sürüyor", "warn"); return; }
  }
  // run_start sunucudan birkaç ms sonra gelebilir. O aralıkta ikinci
  // dokunmayı kabul etmek aynı kullanıcı mesajını iki kez kuyruğa sokuyordu.
  state.submitInFlight = true;
  setBusy(true);

  var outgoingAttachments = state.attachments.slice();
  /* ZIP'in binary icerigi asla textarea'ya / readAsText'e sokulmaz. */
  /* UI'da dosya kartı gösterilir; dosya adını mesaj metnine basmıyoruz.
     Böylece ZIP, kullanıcının mesajında düz metin gibi görünmez. */
  var displayText = text;
  var payload = [];
  var uploadFailed = false;
  outgoingAttachments.forEach(function (a, idx) {
    var uid = "u_" + Date.now().toString(36) + "_" + idx + "_" +
      Math.random().toString(36).slice(2, 8);
    var encoded = a.data || "";
    if (!send({ type: "upload_start", id: uid, name: a.name, kind: a.kind, size: a.size })) {
      uploadFailed = true;
      return;
    }
    for (var p = 0; p < encoded.length; p += 180000) {
      if (!send({ type: "upload_chunk", id: uid, data: encoded.slice(p, p + 180000) })) {
        uploadFailed = true;
        break;
      }
    }
    if (!uploadFailed && !send({ type: "upload_end", id: uid })) uploadFailed = true;
    payload.push({ upload_id: uid, name: a.name, kind: a.kind, size: a.size });
  });

  if (uploadFailed || !send({ type: "chat", text: text, attachments: payload })) {
    state.submitInFlight = false;
    setBusy(false);
    toast("Dosya gönderilemedi", "err");
    return;
  }
  if (!opts.regen) addMsg("user", displayText, { attachments: outgoingAttachments.map(function(a){ return {kind:a.kind,name:a.name,size:a.size}; }) });

  /* WebSocket mesaji basariyla kuyruğa girdikten sonra ekleri temizle. */
  state.attachments = [];
  renderAttachments();
  var ta = $("#input");
  ta.value = "";
  autoGrow();
  updateCount();
  scrollBottom(true);
}

function autoGrow() {
  var ta = $("#input");
  ta.style.height = "auto";
  ta.style.height = Math.min(ta.scrollHeight, 220) + "px";
}
function updateCount() {
  var ta = $("#input"), c = $("#charCount");
  if (!c) return;
  var n = ta.value.length;
  c.textContent = n ? (n > 2000 ? n.toLocaleString("tr-TR") : n) : "";
  c.className = "cinfo" + (n > 12000 ? " err" : n > 6000 ? " warn" : "");
}

/* ---- ekler ---- */
function renderAttachments() {
  var box = $("#attachRow");
  if (!box) return;
  box.innerHTML = "";
  state.attachments.forEach(function (a, i) {
    var n = el("div", "att");
    n.innerHTML = '<span class="ai">' + ico("file") + '</span>' +
      '<span class="an">' + esc(a.name) + "</span>" +
      '<span class="as">' + U.bytes(a.size) + "</span>" +
      '<button class="ax">' + ico("x") + "</button>";
    n.querySelector(".ax").onclick = function () {
      state.attachments.splice(i, 1);
      renderAttachments();
    };
    box.appendChild(n);
  });
}

function arrayBufferToBase64(buf) {
  var bytes = new Uint8Array(buf);
  var chunk = 0x8000;
  var out = "";
  for (var i = 0; i < bytes.length; i += chunk) {
    out += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunk, bytes.length)));
  }
  return btoa(out);
}

function addFiles(files) {
  Array.prototype.forEach.call(files, function (f) {
    var isZip = /\.zip$/i.test(f.name);
    var max = isZip ? 8 * 1024 * 1024 : 900000;

    if (f.size > max) {
      toast(f.name + " çok büyük (max " + (isZip ? "8 MB" : "900 KB") + ")", "warn");
      return;
    }

    /* Her eki byte olarak oku; sunucu parçaları aldıktan sonra ZIP'i açar,
       metin dosyasını UTF-8'e çevirir. */
    var br = new FileReader();
    br.onload = function () {
      try {
        state.attachments.push({
          kind: isZip ? "zip" : "text",
          name: f.name,
          size: f.size,
          data: arrayBufferToBase64(br.result)
        });
        renderAttachments();
        toast(f.name + (isZip ? " ZIP olarak eklendi" : " eklendi"), "ok");
      } catch (e) {
        toast(f.name + " okunamadı", "err");
      }
    };
    br.onerror = function () { toast(f.name + " okunamadı", "err"); };
    br.readAsArrayBuffer(f);
  });
}

function beep() {
  try {
    var ctx = new (W.AudioContext || W.webkitAudioContext)();
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.frequency.value = 660; o.type = "sine";
    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.06, ctx.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.28);
    o.start(); o.stop(ctx.currentTime + 0.3);
  } catch (e) {}
}

/* ---- dışa aktar ---- */
W.App = {
  state: state, S: S, setSetting: setSetting, applySettings: applySettings,
  send: send, connect: connect, handle: handle,
  addMsg: addMsg, showEmpty: showEmpty, submitText: submitText,
  scrollBottom: scrollBottom, initScroll: initScroll,
  autoGrow: autoGrow, updateCount: updateCount,
  addFiles: addFiles, renderAttachments: renderAttachments,
  renderSessions: renderSessions, setTitle: setTitle,
  setBusy: setBusy, finishStream: finishStream, clearStatus: clearStatus,
  toolCard: toolCard, copyText: copyText,
  shortModel: shortModel, DEFAULTS: DEFAULTS
};

})(window);

// İlk tarayıcı açılışında tek yeni sohbet oluşturulur.
// Yenileme ve arka plana gidip gelme yeni sohbet açmaz.
(function(){
  try {
    if (!localStorage.getItem('mx.browser_initialized')) {
      localStorage.setItem('mx.browser_initialized','1');
      window.addEventListener('load', function(){
        try { if (W.App && W.App.newChat) W.App.newChat(); } catch(e) {}
      }, {once:true});
    }
  } catch(e) {}
})();

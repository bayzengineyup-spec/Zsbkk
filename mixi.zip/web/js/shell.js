/* ============================================================
   shell.js — kabuk: kenar çubuğu, seçiciler, kısayollar,
   komut paleti, ayarlar, araç galerisi, onay diyaloğu,
   eğik çizgi komutları, sohbet içi arama, dışa aktarma
   ============================================================ */
(function (W) {
"use strict";

var U = W.UI, A = W.App;
var $ = U.$, $$ = U.$$, el = U.el, esc = U.esc, ico = U.ico, toast = U.toast;
var S = A.S;

/* ============================================================
   KENAR ÇUBUĞU
   ============================================================ */
function openSidebar()  { $("#side").classList.add("open"); }
function closeSidebar() { $("#side").classList.remove("open"); }
function toggleCollapse() {
  S.sideCollapsed = S.sideCollapsed === "1" ? "0" : "1";
  A.applySettings();
}

/* ============================================================
   AÇILIR MENÜ ALTYAPISI
   ============================================================ */
var _menu = null;
function closeMenu() {
  if (_menu) {
    _menu.el.remove();
    if (_menu.anchor) _menu.anchor.dataset.open = "0";
    _menu = null;
  }
}
function openMenu(anchor, items, opts) {
  closeMenu();
  opts = opts || {};
  var m = el("div", "menu");
  items.forEach(function (it) {
    if (it.sep)    { m.appendChild(el("div", "msep")); return; }
    if (it.header) { m.appendChild(el("div", "mh", esc(it.header))); return; }
    var b = el("button", "mi" + (it.danger ? " danger" : ""));
    b.setAttribute("aria-checked", it.checked ? "true" : "false");
    b.innerHTML =
      (it.icon ? '<span class="mic">' + ico(it.icon) + "</span>" : "") +
      '<span class="mi-t">' + esc(it.label) + "</span>" +
      (it.sub ? '<span class="mi-s">' + esc(it.sub) + "</span>" : "") +
      '<span class="ck">' + ico("check") + "</span>";
    b.onclick = function (e) {
      e.stopPropagation();
      closeMenu();
      try { it.onClick && it.onClick(); } catch (err) { console.error(err); }
    };
    m.appendChild(b);
  });
  document.body.appendChild(m);

  var r = anchor.getBoundingClientRect();
  var mw = m.offsetWidth, mh = m.offsetHeight;
  var left = opts.align === "right" ? r.right - mw : r.left;
  left = Math.max(8, Math.min(left, innerWidth - mw - 8));
  var top = r.bottom + 6;
  if (top + mh > innerHeight - 8) top = Math.max(8, r.top - mh - 6);
  m.style.left = left + "px";
  m.style.top = top + "px";
  anchor.dataset.open = "1";
  _menu = { el: m, anchor: anchor };

  setTimeout(function () {
    document.addEventListener("pointerdown", onDoc, { once: true });
  }, 0);
  function onDoc(e) {
    if (m.contains(e.target)) {
      document.addEventListener("pointerdown", onDoc, { once: true });
      return;
    }
    closeMenu();
  }
  return m;
}
addEventListener("resize", closeMenu);
addEventListener("keydown", function (e) { if (e.key === "Escape") closeMenu(); });

/* ============================================================
   MODEL & MOD SEÇİCİLERİ
   ============================================================ */
var MODES = [
  { id: "ask",  label: "Sor",   sub: "her adımda onay iste", icon: "shield" },
  { id: "plan", label: "Planla", sub: "önce plan çıkar",     icon: "layers" },
  { id: "auto", label: "Otomatik", sub: "dosyalar serbest, komutlar denetimli", icon: "bolt" },
  { id: "yolo", label: "Sınırsız", sub: "onay sorma (dikkat)", icon: "warn" }
];

var EFFORTS = [
  { id: "düşük",    label: "Düşük Efor",  sub: "hızlı, kısa cevaplar",     icon: "zap" },
  { id: "normal",   label: "Normal Efor", sub: "dengeli hız ve kalite",   icon: "target" },
  { id: "yüksek",   label: "Yüksek Efor", sub: "daha detaylı düşünür",     icon: "brain" },
  { id: "maksimum", label: "Maksimum Efor", sub: "en derin analiz, yavaş", icon: "flame" }
];

function fillModels(items, current) {
  var p = $("#modelPicker");
  if (!p) return;
  var cur = items.filter(function (x) { return x.id === current; })[0];
  p.querySelector(".pv").textContent = cur ? A.shortModel(cur.id) : (current ? A.shortModel(current) : "model");
  p.onclick = function () {
    if (!items.length) { toast("Model listesi boş", "warn"); return; }
    var menuItems = [{ header: "Model seç" }];
    menuItems = menuItems.concat(items.map(function (x) {
      return {
        label: A.shortModel(x.id),
        sub: x.ai || "",
        checked: x.id === A.state.model,
        onClick: function () { A.send({ type: "set_model", model: x.id, ai: x.ai || "" }); }
      };
    }));
    // Efor seçimi bölümü
    menuItems.push({ sep: true });
    menuItems.push({ header: "Efor seviyesi" });
    var curEffort = A.state.effort || "normal";
    EFFORTS.forEach(function (e) {
      menuItems.push({
        label: e.label, sub: e.sub, icon: e.icon,
        checked: e.id === curEffort,
        onClick: function () {
          A.send({ type: "set_effort", effort: e.id });
          A.state.effort = e.id;
          toast("Efor: " + e.label, "ok");
        }
      });
    });
    // Düşünme modu
    menuItems.push({ sep: true });
    menuItems.push({
      label: "Gerçek Düşünme",
      sub: A.state.thinking ? "açık" : "kapalı",
      icon: "brain",
      checked: !!A.state.thinking,
      onClick: function () {
        A.state.thinking = !A.state.thinking;
        A.send({ type: "set_thinking", on: A.state.thinking });
        toast("Düşünme: " + (A.state.thinking ? "Açık" : "Kapalı"), "ok");
      }
    });
    openMenu(p, menuItems);
  };
}

function setMode(mode) {
  var p = $("#modePicker");
  if (!p) return;
  var m = MODES.filter(function (x) { return x.id === mode; })[0] || MODES[2];
  p.dataset.mode = m.id;
  p.querySelector(".pv").textContent = m.label;
  p.onclick = function () {
    openMenu(p, [{ header: "İzin modu" }].concat(MODES.map(function (x) {
      return {
        label: x.label, sub: x.sub, icon: x.icon,
        checked: x.id === A.state.mode,
        onClick: function () { A.send({ type: "set_mode", mode: x.id }); }
      };
    })), { align: "right" });
  };
}

/* ============================================================
   ONAY DİYALOĞU
   ============================================================ */
function confirmDlg(title, text, onYes, opts) {
  opts = opts || {};
  var m = $("#confirm");
  m.hidden = false;
  $("#confirmTitle").textContent = title;
  $("#confirmText").innerHTML = text;
  $("#confirmYes").textContent = opts.yes || "Evet, devam et";
  $("#confirmYes").className = "btn " + (opts.danger === false ? "primary" : "danger");
  $("#backdrop").classList.add("show");
  function close() {
    m.hidden = true;
    if (!anyModalOpen()) $("#backdrop").classList.remove("show");
  }
  $("#confirmYes").onclick = function () { close(); try { onYes(); } catch (e) {} };
  $("#confirmNo").onclick = close;
  $("#confirmX").onclick = close;
}
function anyModalOpen() {
  return $$(".modal").some(function (m) { return !m.hidden; });
}

/* ============================================================
   MODAL YARDIMCISI
   ============================================================ */
function openModal(id) {
  var m = $(id);
  if (!m) return;
  m.hidden = false;
  $("#backdrop").classList.add("show");
  var f = m.querySelector("input,button,textarea");
  if (f) setTimeout(function () { f.focus(); }, 80);
}
function closeModal(id) {
  var m = $(id);
  if (m) m.hidden = true;
  if (!anyModalOpen()) $("#backdrop").classList.remove("show");
}
function closeAllModals() {
  $$(".modal").forEach(function (m) { m.hidden = true; });
  $("#backdrop").classList.remove("show");
  closeMenu();
}

/* ============================================================
   KOMUT PALETİ
   ============================================================ */
var COMMANDS = [];
function buildCommands() {
  COMMANDS = [
    { g: "Oturum", icon: "plus",    t: "Yeni oturum",         k: "Ctrl+N",  fn: newSession },
    { g: "Oturum", icon: "history", t: "Oturum ara",          k: "Ctrl+F",  fn: function () { openSidebar(); $("#sessSearch").focus(); } },
    { g: "Oturum", icon: "download",t: "Sohbeti Markdown indir", fn: exportMd },
    { g: "Oturum", icon: "code",    t: "Sohbeti JSON indir",  fn: exportJson },
    { g: "Oturum", icon: "share",   t: "Sohbeti panoya kopyala", fn: copyChat },
    { g: "Oturum", icon: "trash",   t: "Ekranı temizle",      fn: clearScreen },

    { g: "Görünüm", icon: S.theme === "dark" ? "sun" : "moon", t: "Tema değiştir", k: "Ctrl+J", fn: toggleTheme },
    { g: "Görünüm", icon: "expand", t: "Geniş/dar okuma alanı", fn: toggleWide },
    { g: "Görünüm", icon: "panel",  t: "Kenar çubuğunu daralt/aç", k: "Ctrl+B", fn: toggleCollapse },
    { g: "Görünüm", icon: "sparkle",t: "Vurgu rengini değiştir", fn: cycleAccent },
    { g: "Görünüm", icon: "book",   t: "Yazı boyutunu büyüt", fn: function () { cycleText(1); } },
    { g: "Görünüm", icon: "book",   t: "Yazı boyutunu küçült", fn: function () { cycleText(-1); } },

    { g: "Araçlar", icon: "wrench", t: "Araç galerisini aç",  k: "Ctrl+T", fn: function () { openModal("#tools"); requestTools(); } },
    { g: "Araçlar", icon: "settings", t: "Ayarlar",           k: "Ctrl+,", fn: function () { openModal("#settings"); } },
    { g: "Araçlar", icon: "grid",   t: "Yönetim paneli",      k: "Ctrl+Shift+P", fn: openPanel },
    { g: "Araçlar", icon: "key",    t: "Klavye kısayolları",  k: "?",      fn: function () { openModal("#keys"); } },
    { g: "Araçlar", icon: "search", t: "Sohbette ara",        k: "Ctrl+Shift+F", fn: openFind },

    { g: "Mod", icon: "shield", t: "Mod: Sor",     fn: function () { A.send({ type: "set_mode", mode: "ask" }); } },
    { g: "Mod", icon: "layers", t: "Mod: Planla",  fn: function () { A.send({ type: "set_mode", mode: "plan" }); } },
    { g: "Mod", icon: "bolt",   t: "Mod: Otomatik",fn: function () { A.send({ type: "set_mode", mode: "auto" }); } },
    { g: "Mod", icon: "warn",   t: "Mod: Sınırsız",fn: function () { A.send({ type: "set_mode", mode: "yolo" }); } },

    { g: "Çalıştırma", icon: "stop",    t: "Üretimi durdur", k: "Esc", fn: stopRun },
    { g: "Çalıştırma", icon: "refresh", t: "Son yanıtı yeniden üret", fn: regenLast }
  ];
}

var palSel = 0, palItems = [];
function openPalette() {
  buildCommands();
  openModal("#palette");
  var inp = $("#palInput");
  inp.value = "";
  renderPalette("");
  inp.oninput = function () { renderPalette(inp.value); };
  inp.onkeydown = function (e) {
    if (e.key === "ArrowDown") { e.preventDefault(); palSel = Math.min(palSel + 1, palItems.length - 1); paintSel(); }
    else if (e.key === "ArrowUp") { e.preventDefault(); palSel = Math.max(palSel - 1, 0); paintSel(); }
    else if (e.key === "Enter") {
      e.preventDefault();
      var it = palItems[palSel];
      if (it) { closeModal("#palette"); setTimeout(it.fn, 30); }
    }
  };
}
function renderPalette(q) {
  var list = $("#palList");
  var lq = q.trim().toLowerCase();
  palItems = COMMANDS.filter(function (c) {
    return !lq || (c.t + " " + c.g).toLowerCase().indexOf(lq) >= 0;
  });
  palSel = 0;
  if (!palItems.length) {
    list.innerHTML = '<div class="pal-empty">Sonuç yok</div>';
    return;
  }
  var html = "", g = null;
  palItems.forEach(function (c, i) {
    if (c.g !== g) { g = c.g; html += '<div class="pal-sec">' + esc(g) + "</div>"; }
    html += '<div class="pal-i" data-i="' + i + '">' +
      '<span class="pi">' + ico(c.icon) + "</span>" +
      '<span class="pt"><b>' + esc(c.t) + "</b></span>" +
      (c.k ? '<span class="kbd">' + esc(c.k) + "</span>" : "") + "</div>";
  });
  list.innerHTML = html;
  $$(".pal-i", list).forEach(function (n) {
    n.onclick = function () {
      var it = palItems[+n.dataset.i];
      closeModal("#palette");
      setTimeout(it.fn, 30);
    };
    n.onmouseenter = function () { palSel = +n.dataset.i; paintSel(); };
  });
  paintSel();
}
function paintSel() {
  $$(".pal-i").forEach(function (n) { n.classList.toggle("sel", +n.dataset.i === palSel); });
  var s = $(".pal-i.sel");
  if (s) s.scrollIntoView({ block: "nearest" });
}

/* ============================================================
   KOMUT EYLEMLERİ
   ============================================================ */
function newSession() {
  // Çalışan görev varsa önce durdur, sonra yeni oturum aç
  if (A.state.busy) {
    A.send({ type: "cancel" });
    A.setBusy(false);
  }
  A.send({ type: "new" });
  closeSidebar();
  // showEmpty çağırmıyoruz: sunucudan gelen boş history mesajı renderHistory'yi
  // tetikler, o da showEmpty'yi zaten çağırır. Böylece çakışma olmaz.
}
function toggleTheme() {
  S.theme = S.theme === "dark" ? "light" : "dark";
  A.applySettings();
  syncSettingsUI();
  toast(S.theme === "dark" ? "Karanlık tema" : "Aydınlık tema", "ok");
}
function toggleWide() {
  S.wide = S.wide === "1" ? "0" : "1";
  A.applySettings(); syncSettingsUI();
}
var ACCENTS = ["teal", "indigo", "violet", "amber", "rose", "emerald"];
function cycleAccent() {
  var i = ACCENTS.indexOf(S.accent);
  S.accent = ACCENTS[(i + 1) % ACCENTS.length];
  A.applySettings(); syncSettingsUI();
  toast("Vurgu: " + S.accent, "ok");
}
var TSIZES = ["sm", "md", "lg", "xl"];
function cycleText(dir) {
  var i = TSIZES.indexOf(S.textsize);
  i = Math.max(0, Math.min(TSIZES.length - 1, i + dir));
  S.textsize = TSIZES[i];
  A.applySettings(); syncSettingsUI();
}
function stopRun() {
  if (!A.state.busy) return;
  A.send({ type: "cancel" });
  /* İptal sonrası yeni mesaj gönderilebilmesi için gönderim kilidini de bırak. */
  A.state.submitInFlight = false;
  toast("Durduruldu", "warn");
  // UI'ı hemen temizle — sunucudan done bekleme
  A.finishStream();
  A.clearStatus();
  A.setBusy(false);
  W.Mascot && W.Mascot.release && W.Mascot.release("idle");
}
function regenLast() {
  var msgs = $$(".msg.user");
  if (!msgs.length) { toast("Yeniden üretilecek mesaj yok", "warn"); return; }
  var last = msgs[msgs.length - 1];
  A.submitText(last._raw || last.querySelector(".body").textContent, { regen: true });
}
function clearScreen() {
  confirmDlg("Ekranı temizle",
    "Görünen mesajlar ekrandan kaldırılacak. Sunucudaki oturum kaydı <b>silinmez</b>.",
    function () { $("#chatInner").innerHTML = ""; A.showEmpty(); }, { yes: "Temizle" });
}

function chatToMarkdown() {
  var out = ["# Mixium — " + ($("#topName").textContent || "Oturum"),
             "", "_" + new Date().toLocaleString("tr-TR") + " · model: " +
             (A.state.model || "?") + "_", ""];
  $$(".msg").forEach(function (m) {
    if (m.classList.contains("sys")) return;
    var who = m.classList.contains("user") ? "**Sen**"
            : m.classList.contains("err") ? "**Hata**" : "**Mixium**";
    var raw = m._raw || (m.querySelector(".body") || {}).innerText || "";
    out.push(who + "\n\n" + raw + "\n\n---\n");
  });
  return out.join("\n");
}
function dl(name, text, type) {
  var b = new Blob([text], { type: (type || "text/plain") + ";charset=utf-8" });
  var a = document.createElement("a");
  a.href = URL.createObjectURL(b);
  a.download = name;
  a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); }, 1200);
}
function exportMd() {
  dl("mixium-" + Date.now() + ".md", chatToMarkdown(), "text/markdown");
  toast("Markdown indirildi", "ok");
}
function exportJson() {
  var rows = $$(".msg").map(function (m) {
    return {
      role: m.classList.contains("user") ? "user"
          : m.classList.contains("err") ? "error" : "assistant",
      content: m._raw || (m.querySelector(".body") || {}).innerText || ""
    };
  });
  dl("mixium-" + Date.now() + ".json",
     JSON.stringify({ session: A.state.session, model: A.state.model,
                      exported: new Date().toISOString(), messages: rows }, null, 2),
     "application/json");
  toast("JSON indirildi", "ok");
}
function copyChat() {
  A.copyText(chatToMarkdown()).then(function () { toast("Sohbet kopyalandı", "ok"); });
}
function openPanel() {
  if (W.Panel && W.Panel.show) { W.Panel.show(); return; }
  toast("Yönetim paneli yüklenmedi", "warn");
}

/* ============================================================
   SOHBET İÇİ ARAMA
   ============================================================ */
var findState = { hits: [], idx: -1 };
function openFind() {
  var bar = $("#findBar");
  bar.hidden = false;
  var i = $("#findInput");
  i.focus(); i.select();
  i.oninput = U.debounce(function () { runFind(i.value); }, 130);
  i.onkeydown = function (e) {
    if (e.key === "Enter") { e.preventDefault(); stepFind(e.shiftKey ? -1 : 1); }
    if (e.key === "Escape") closeFind();
  };
  $("#findNext").onclick = function () { stepFind(1); };
  $("#findPrev").onclick = function () { stepFind(-1); };
  $("#findClose").onclick = closeFind;
}
function closeFind() {
  $("#findBar").hidden = true;
  clearFind();
}
function clearFind() {
  $$("mark.hit").forEach(function (m) {
    var p = m.parentNode;
    p.replaceChild(document.createTextNode(m.textContent), m);
    p.normalize();
  });
  findState = { hits: [], idx: -1 };
  $("#findCount").textContent = "";
}
function runFind(q) {
  clearFind();
  q = (q || "").trim();
  if (q.length < 2) return;
  var rx = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
  $$(".msg .body").forEach(function (body) {
    walk(body);
  });
  function walk(node) {
    for (var i = 0; i < node.childNodes.length; i++) {
      var c = node.childNodes[i];
      if (c.nodeType === 3) {
        var t = c.nodeValue;
        if (!rx.test(t)) { rx.lastIndex = 0; continue; }
        rx.lastIndex = 0;
        var frag = document.createDocumentFragment();
        var last = 0, m;
        while ((m = rx.exec(t))) {
          frag.appendChild(document.createTextNode(t.slice(last, m.index)));
          var mk = el("mark", "hit", esc(m[0]));
          frag.appendChild(mk);
          findState.hits.push(mk);
          last = m.index + m[0].length;
        }
        frag.appendChild(document.createTextNode(t.slice(last)));
        node.replaceChild(frag, c);
        i += frag.childNodes ? 0 : 0;
      } else if (c.nodeType === 1 && c.tagName !== "MARK") {
        walk(c);
      }
    }
  }
  $("#findCount").textContent = findState.hits.length ? "1/" + findState.hits.length : "yok";
  if (findState.hits.length) { findState.idx = 0; focusHit(); }
}
function stepFind(d) {
  if (!findState.hits.length) return;
  findState.idx = (findState.idx + d + findState.hits.length) % findState.hits.length;
  focusHit();
}
function focusHit() {
  findState.hits.forEach(function (h) { h.classList.remove("cur"); });
  var h = findState.hits[findState.idx];
  if (!h) return;
  h.classList.add("cur");
  h.scrollIntoView({ block: "center", behavior: "smooth" });
  $("#findCount").textContent = (findState.idx + 1) + "/" + findState.hits.length;
}

/* ============================================================
   EĞİK ÇİZGİ KOMUTLARI
   ============================================================ */
var SLASH = [
  ["/yeni",    "yeni oturum başlat"],
  ["/model",   "model değiştir — /model <ad>"],
  ["/mod",     "izin modu — /mod auto|ask|plan|yolo"],
  ["/dur",     "üretimi durdur"],
  ["/temizle", "ekranı temizle"],
  ["/tema",    "temayı değiştir"],
  ["/araclar", "araç galerisini aç"],
  ["/ayarlar", "ayarları aç"],
  ["/disaaktar","sohbeti markdown indir"],
  ["/ara",     "sohbette ara"],
  ["/yardim",  "komut listesi"]
];
var slashSel = 0;
function updateSlash() {
  var ta = $("#input"), box = $("#slashBox");
  var v = ta.value;
  if (!/^\/\w*$/.test(v)) { box.hidden = true; return; }
  var q = v.slice(1).toLowerCase();
  var hits = SLASH.filter(function (s) { return s[0].slice(1).indexOf(q) === 0; });
  if (!hits.length) { box.hidden = true; return; }
  slashSel = Math.min(slashSel, hits.length - 1);
  box.innerHTML = hits.map(function (s, i) {
    return '<div class="si' + (i === slashSel ? " sel" : "") + '" data-c="' + s[0] + '">' +
      '<span class="k">' + esc(s[0]) + '</span><span class="d">' + esc(s[1]) + "</span></div>";
  }).join("");
  box.hidden = false;
  box._hits = hits;
  $$(".si", box).forEach(function (n) {
    n.onclick = function () { applySlash(n.dataset.c); };
  });
}
function applySlash(cmd) {
  $("#slashBox").hidden = true;
  runSlash(cmd);
  $("#input").value = "";
  A.autoGrow(); A.updateCount();
}
function runSlash(line) {
  var parts = line.trim().split(/\s+/);
  var c = parts[0].toLowerCase(), rest = parts.slice(1).join(" ");
  switch (c) {
    case "/yeni": newSession(); break;
    case "/dur": stopRun(); break;
    case "/temizle": clearScreen(); break;
    case "/tema": toggleTheme(); break;
    case "/araclar": openModal("#tools"); requestTools(); break;
    case "/ayarlar": openModal("#settings"); break;
    case "/disaaktar": exportMd(); break;
    case "/ara": openFind(); break;
    case "/keys": case "/kisayol": openModal("#keys"); break;
    case "/mod":
      if (["ask", "plan", "auto", "yolo"].indexOf(rest) >= 0) A.send({ type: "set_mode", mode: rest });
      else toast("Mod: ask | plan | auto | yolo", "info");
      break;
    case "/model":
      if (rest) A.send({ type: "chat", text: "/model " + rest });
      else $("#modelPicker").click();
      break;
    case "/yardim":
      A.addMsg("sys", SLASH.map(function (s) { return s[0] + " — " + s[1]; }).join("\n"));
      break;
    default:
      A.send({ type: "chat", text: line });
  }
}

/* ============================================================
   ARAÇ GALERİSİ
   ============================================================ */
function requestTools() {
  var box = $("#toolGrid");
  if (box && !box.children.length) {
    box.innerHTML = '<div class="skel" style="height:88px"></div><div class="skel" style="height:88px"></div><div class="skel" style="height:88px"></div>';
  }
  var ok = A.send({ type: "tools_list" });
  /* Modal WS bağlanmadan açılırsa sonsuz shimmer bırakma. */
  if (!ok) {
    if (box) box.innerHTML = '<div class="pal-empty">Bağlantı kuruluyor…</div>';
    setTimeout(function () { if (document.querySelector('#tools:not([hidden])')) requestTools(); }, 500);
  } else {
    /* İlk hello ile araç isteği arasında yarış varsa ikinci kez iste. */
    setTimeout(function () { if (document.querySelector('#tools:not([hidden])')) A.send({ type: "tools_list" }); }, 350);
  }
}
function renderTools(items) {
  var box = $("#toolGrid");
  if (!box) return;
  if (!items.length) {
    box.innerHTML = '<div class="pal-empty">Araç listesi alınamadı</div>';
    return;
  }
  $("#toolCount").textContent = items.length;
  box.innerHTML = items.map(function (t) {
    return '<div class="tcard" data-n="' + esc(t.name) + '">' +
      '<div class="th"><span class="ti">' + ico(toolIcon(t.name)) + "</span>" +
      "<b>" + esc(t.name) + "</b></div>" +
      "<p>" + esc(t.desc || "") + "</p>" +
      '<div class="tf">' +
        (t["new"] ? '<span class="pill on">yeni</span>' : "") +
        (t.danger ? '<span class="pill">riskli</span>' : '<span class="pill">güvenli</span>') +
      "</div></div>";
  }).join("");
  $$(".tcard", box).forEach(function (c) {
    c.onclick = function () {
      var name = c.dataset.n;
      var t = items.filter(function (x) { return x.name === name; })[0];
      A.copyText(t.schema || "{}").then(function () {
        toast(name + " şeması kopyalandı", "ok");
      });
    };
  });
}
function toolIcon(n) {
  var M = { bash: "terminal", read: "file", write: "edit", edit: "edit",
    grep: "search", glob: "folder", tree: "folder", git: "branch",
    fetch: "globe", web_search: "globe", browser: "globe", memory: "brain",
    calc: "cpu", todo: "check", download: "download", subagent: "sparkle" };
  return M[n] || "wrench";
}

/* ============================================================
   AYARLAR ARAYÜZÜ
   ============================================================ */
function syncSettingsUI() {
  $$("[data-set]").forEach(function (n) {
    var k = n.dataset.set;
    if (n.classList.contains("sw")) {
      n.setAttribute("aria-checked", S[k] === "on" || S[k] === "1" ? "true" : "false");
    } else if (n.classList.contains("seg")) {
      $$("button", n).forEach(function (b) { b.classList.toggle("on", b.dataset.v === S[k]); });
    } else if (n.classList.contains("dots")) {
      $$("button", n).forEach(function (b) { b.classList.toggle("on", b.dataset.v === S[k]); });
    }
  });
}
function wireSettings() {
  $$("[data-set]").forEach(function (n) {
    var k = n.dataset.set;
    if (n.classList.contains("sw")) {
      n.onclick = function () {
        var on = n.getAttribute("aria-checked") === "true";
        var offV = (S[k] === "on" || S[k] === "off") ? (on ? "off" : "on") : (on ? "0" : "1");
        S[k] = offV;
        A.applySettings(); syncSettingsUI();
      };
    } else {
      $$("button", n).forEach(function (b) {
        b.onclick = function () { S[k] = b.dataset.v; A.applySettings(); syncSettingsUI(); };
      });
    }
  });
  var reset = $("#resetSettings");
  if (reset) reset.onclick = function () {
    confirmDlg("Ayarları sıfırla", "Tüm görünüm ve davranış ayarları varsayılana dönecek.",
      function () {
        Object.keys(A.DEFAULTS).forEach(function (k) { S[k] = A.DEFAULTS[k]; });
        A.applySettings(); syncSettingsUI();
        toast("Ayarlar sıfırlandı", "ok");
      });
  };
}

/* ============================================================
   KLAVYE KISAYOLLARI
   ============================================================ */
function initKeys() {
  addEventListener("keydown", function (e) {
    var mod = e.ctrlKey || e.metaKey;
    var inField = /INPUT|TEXTAREA/.test((e.target.tagName || ""));

    if (mod && e.key.toLowerCase() === "k") { e.preventDefault(); openPalette(); return; }
    if (mod && e.key.toLowerCase() === "n") { e.preventDefault(); newSession(); return; }
    if (mod && e.key.toLowerCase() === "j") { e.preventDefault(); toggleTheme(); return; }
    if (mod && e.key.toLowerCase() === "b") { e.preventDefault(); toggleCollapse(); return; }
    if (mod && e.key === ",")               { e.preventDefault(); openModal("#settings"); return; }
    if (mod && e.shiftKey && e.key.toLowerCase() === "f") { e.preventDefault(); openFind(); return; }
    if (mod && e.shiftKey && e.key.toLowerCase() === "p") { e.preventDefault(); openPanel(); return; }
    if (mod && e.key.toLowerCase() === "t" && !e.shiftKey) {
      e.preventDefault(); openModal("#tools"); requestTools(); return;
    }
    if (mod && e.key.toLowerCase() === "f" && !e.shiftKey) {
      e.preventDefault(); openSidebar(); $("#sessSearch").focus(); return;
    }
    if (e.key === "?" && !inField) { e.preventDefault(); openModal("#keys"); return; }
    if (e.key === "Escape") {
      if (!$("#findBar").hidden) { closeFind(); return; }
      if (anyModalOpen()) { closeAllModals(); return; }
      if (A.state.busy) { stopRun(); return; }
    }
    if (e.key === "/" && !inField) { e.preventDefault(); $("#input").focus(); }
  });
}

/* ============================================================
   COMPOSER OLAYLARI
   ============================================================ */
function initComposer() {
  var ta = $("#input"), comp = $("#composer");

  ta.addEventListener("focus", function () { comp.classList.add("focus"); });
  ta.addEventListener("blur",  function () {
    comp.classList.remove("focus");
    setTimeout(function () { $("#slashBox").hidden = true; }, 160);
  });
  ta.addEventListener("input", function () {
    A.autoGrow(); A.updateCount(); updateSlash();
  });
  ta.addEventListener("keydown", function (e) {
    var box = $("#slashBox");
    if (!box.hidden && box._hits) {
      if (e.key === "ArrowDown") { e.preventDefault(); slashSel = Math.min(slashSel + 1, box._hits.length - 1); updateSlash(); return; }
      if (e.key === "ArrowUp")   { e.preventDefault(); slashSel = Math.max(slashSel - 1, 0); updateSlash(); return; }
      if (e.key === "Tab" || e.key === "Enter") {
        e.preventDefault(); applySlash(box._hits[slashSel][0]); return;
      }
    }
    var sendKey = S.enterSends === "1"
      ? (e.key === "Enter" && !e.shiftKey)
      : (e.key === "Enter" && (e.ctrlKey || e.metaKey));
    if (sendKey) { e.preventDefault(); doSubmit(); }
    if (e.key === "ArrowUp" && !ta.value.trim()) {
      var last = $$(".msg.user").pop();
      if (last) { ta.value = last._raw || last.querySelector(".body").textContent; A.autoGrow(); }
    }
  });

  $("#sendBtn").onclick = doSubmit;
  $("#stopBtn").onclick = stopRun;

  /* dosya ekleme */
  var fi = $("#fileInput");
  $("#attachBtn").onclick = function () { fi.click(); };
  fi.onchange = function () { A.addFiles(fi.files); fi.value = ""; };

  /* sürükle-bırak */
  ["dragenter", "dragover"].forEach(function (ev) {
    comp.addEventListener(ev, function (e) { e.preventDefault(); comp.classList.add("drag"); });
  });
  ["dragleave", "drop"].forEach(function (ev) {
    comp.addEventListener(ev, function (e) { e.preventDefault(); comp.classList.remove("drag"); });
  });
  comp.addEventListener("drop", function (e) {
    if (e.dataTransfer && e.dataTransfer.files.length) A.addFiles(e.dataTransfer.files);
  });

  /* sesli giriş */
  var SR = W.SpeechRecognition || W.webkitSpeechRecognition;
  var micBtn = $("#micBtn");
  if (SR) {
    var rec = new SR();
    rec.lang = "tr-TR"; rec.continuous = false; rec.interimResults = true;
    var active = false;
    micBtn.onclick = function () {
      if (active) { rec.stop(); return; }
      try { rec.start(); active = true; micBtn.classList.add("rec"); toast("Dinliyorum…", "info"); }
      catch (e) { toast("Mikrofon başlatılamadı", "err"); }
    };
    rec.onresult = function (e) {
      var t = "";
      for (var i = e.resultIndex; i < e.results.length; i++) t += e.results[i][0].transcript;
      ta.value = t; A.autoGrow(); A.updateCount();
    };
    rec.onend = function () { active = false; micBtn.classList.remove("rec"); };
    rec.onerror = function () { active = false; micBtn.classList.remove("rec"); };
  } else {
    micBtn.style.display = "none";
  }

  function doSubmit() {
    var v = ta.value.trim();
    if (!v) return;
    if (v[0] === "/") { runSlash(v); ta.value = ""; A.autoGrow(); A.updateCount(); return; }
    A.submitText(v);
  }
}

/* ============================================================
   BAŞLATMA
   ============================================================ */
function boot() {
  A.applySettings();


  /* kenar çubuğu */
  $("#hamburger").onclick = openSidebar;
  $("#sideClose").onclick = closeSidebar;
  $("#sideCollapse").onclick = toggleCollapse;
  $("#backdrop").onclick = function () { closeSidebar(); closeAllModals(); };
  $("#newBtn").onclick = newSession;
  $("#sessSearch").oninput = U.debounce(function () { A.renderSessions(A.state.sessions); }, 120);

  /* üst çubuk */
  var _themeBtn = $("#themeBtn"); if (_themeBtn) _themeBtn.onclick = toggleTheme;
  var _brandThemeBtn = $("#brandThemeBtn"); if (_brandThemeBtn) _brandThemeBtn.onclick = toggleTheme;
  var _toolsBtn = $("#toolsBtn"); if (_toolsBtn) _toolsBtn.onclick = function () { openModal("#tools"); requestTools(); };
  var _settingsBtn = $("#settingsBtn"); if (_settingsBtn) _settingsBtn.onclick = function () { openModal("#settings"); };
  $("#moreBtn").onclick = function () {
    openMenu($("#moreBtn"), [
      { header: "Sohbet" },
      { label: "Sohbette ara", icon: "search", onClick: openFind },
      { label: "Markdown indir", icon: "download", onClick: exportMd },
      { label: "JSON indir", icon: "code", onClick: exportJson },
      { label: "Panoya kopyala", icon: "copy", onClick: copyChat },
      { label: "Yazdır", icon: "file", onClick: function () { print(); } },
      { sep: true },
      { header: "Görünüm" },
      { label: "Geniş okuma alanı", icon: "expand", checked: S.wide === "1", onClick: toggleWide },
      { label: "Vurgu rengi", icon: "sparkle", onClick: cycleAccent },
      { label: "Klavye kısayolları", icon: "key", onClick: function () { openModal("#keys"); } },
      { sep: true },
      { label: "Yönetim paneli", icon: "grid", onClick: openPanel },
      { label: "Ekranı temizle", icon: "trash", danger: true, onClick: clearScreen }
    ], { align: "right" });
  };
  $("#panelBtn").onclick = openPanel;

  /* başlık düzenleme */
  var tn = $("#topName");
  tn.onblur = function () {
    var v = tn.textContent.trim();
    if (v) A.send({ type: "rename", id: A.state.session, title: v });
  };
  tn.onkeydown = function (e) {
    if (e.key === "Enter") { e.preventDefault(); tn.blur(); }
  };

  /* modal kapatma düğmeleri */
  $$("[data-close]").forEach(function (b) {
    b.onclick = function () { closeModal(b.dataset.close); };
  });

  initComposer();
  initKeys();
  wireSettings();
  syncSettingsUI();
  A.initScroll();
  A.showEmpty();
  A.connect();

  /* Yönetim paneli — init edilmeden show() çağrılamaz */
  if (W.Panel && W.Panel.init) {
    W.Panel.init(function (obj) { A.send(obj); });
  }

  /* sekme başlığı: üretim tamamlandığında geri dön */
  var origTitle = document.title;
  document.addEventListener("mx:run-done", function () {
    if (!document.hidden) return;
    document.title = "✓ Hazır · Mixium";
    var once=function(){document.title=origTitle;removeEventListener("visibilitychange",once);};
    addEventListener("visibilitychange",once);
  });

  console.log("%cMixium", "font:700 20px sans-serif;color:#35d0bd",
              "arayüz hazır · Ctrl+K komut paleti");
}

/* ---- dışa aktar ---- */
W.Shell = {
  openSidebar: openSidebar, closeSidebar: closeSidebar,
  openModal: openModal, closeModal: closeModal, closeAllModals: closeAllModals,
  openMenu: openMenu, closeMenu: closeMenu, boot: boot,
  newSession: newSession, toggleTheme: toggleTheme, openPalette: openPalette,
  exportMd: exportMd, syncSettingsUI: syncSettingsUI
};
W.Pickers = { fillModels: fillModels, setMode: setMode };
W.Panels = { renderTools: renderTools, confirm: confirmDlg, requestTools: requestTools,
             handle: function () {} };

/* DOM hazır olunca başlat */
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", boot);
} else { boot(); }

})(window);

// Belirsiz görevlerde önce bilgi toplama davranışı.
(function(){
  W.MixiumIntent = {
    needsClarification: function(text){
      if(!text) return true;
      text = String(text).trim();
      return text.length < 8 || /^(yap|yap bunu|başla|oluştur)$/i.test(text);
    }
  };
})();

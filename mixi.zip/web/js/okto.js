/* ============================================================
   OKTO v2 — Mixium ahtapot maskotu
   ------------------------------------------------------------
   · Tamamen yeniden çizildi: 8 gerçek kol (4 arka + 4 ön)
   · Ağız YOK. Baş belirgin şekilde büyük ve yumuşak.
   · Kollar prosedürel üretilir: merkez eğri + kalınlık profili
     -> gerçek daralan silüet (çizgi değil, dolu gövde)
   · Her örnek KENDİ gradient id'sini alır -> aynı sayfada
     birden çok maskot birbirinin dokusunu bozmaz
   · Animasyon örnek bazlıdır: Okto.set(el,"think") sadece o
     elemanı etkiler. Global senkron YOKTUR.
   ============================================================ */
(function (global) {
  "use strict";

  var NS = "http://www.w3.org/2000/svg";
  var _uid = 0;

  var LABELS = {
    idle:   "hazır",
    think:  "düşünüyor",
    search: "araştırıyor",
    read:   "okuyor",
    write:  "yazıyor",
    work:   "çalışıyor",
    talk:   "anlatıyor",
    done:   "tamamlandı",
    error:  "takıldı",
    sleep:  "bekliyor"
  };

  var HINTS = {
    think:  ["bağlamı tartıyor", "planı kuruyor", "adımları sıralıyor", "seçenekleri eliyor"],
    search: ["kaynak tarıyor", "dosyalarda arıyor", "eşleşme kovalıyor", "dizini geziyor"],
    read:   ["dosyayı okuyor", "çıktıyı inceliyor", "satırları karşılaştırıyor"],
    write:  ["kod yazıyor", "dosyayı düzenliyor", "yamayı işliyor"],
    work:   ["komutu çalıştırıyor", "aracı sürüyor", "işlemi yürütüyor"],
    talk:   ["cevabı derliyor", "sonucu özetliyor"],
    idle:   ["komut bekliyor"],
    sleep:  ["dinleniyor"],
    done:   ["iş bitti"],
    error:  ["bir şeyler ters gitti"]
  };

  /* ==========================================================
     Geometri yardımcıları — prosedürel kol üretimi
     ========================================================== */

  /* Kübik bezier üzerinde nokta */
  function cubic(p0, p1, p2, p3, t) {
    var u = 1 - t, uu = u * u, uuu = uu * u;
    var tt = t * t, ttt = tt * t;
    return {
      x: uuu * p0.x + 3 * uu * t * p1.x + 3 * u * tt * p2.x + ttt * p3.x,
      y: uuu * p0.y + 3 * uu * t * p1.y + 3 * u * tt * p2.y + ttt * p3.y
    };
  }

  function pt(x, y) { return { x: x, y: y }; }

  function round2(n) { return Math.round(n * 100) / 100; }

  /**
   * Daralan kol silüeti üretir.
   * @param spec {p0,p1,p2,p3} kontrol noktaları
   * @param w0 taban genişliği (yarıçap)
   * @param w1 uç genişliği
   * @param seg örnek sayısı
   * @returns {d, points} — dolu path + merkez çizgi noktaları (vantuz için)
   */
  function tentaclePath(spec, w0, w1, seg) {
    seg = seg || 26;
    var left = [], right = [], mids = [];
    var i, t, p, prev, nx, ny, len, w, ease;

    for (i = 0; i <= seg; i++) {
      t = i / seg;
      p = cubic(spec.p0, spec.p1, spec.p2, spec.p3, t);
      mids.push(p);
      /* teğet */
      var t2 = Math.min(1, t + 0.012);
      var q = cubic(spec.p0, spec.p1, spec.p2, spec.p3, t2);
      var dx = q.x - p.x, dy = q.y - p.y;
      len = Math.hypot(dx, dy) || 1;
      nx = -dy / len; ny = dx / len;
      /* kalınlık profili: tabana yakın dolgun, uçta sivri
         ease = (1-t)^1.55 ile doğal daralma */
      ease = Math.pow(1 - t, 1.55);
      w = w1 + (w0 - w1) * ease;
      /* tabanda hafif şişkinlik (kas hissi) */
      w *= 1 + 0.16 * Math.sin(Math.PI * Math.min(1, t * 2.2));
      left.push(pt(p.x + nx * w, p.y + ny * w));
      right.push(pt(p.x - nx * w, p.y - ny * w));
    }

    var d = "M" + round2(left[0].x) + " " + round2(left[0].y);
    for (i = 1; i < left.length; i++) {
      d += "L" + round2(left[i].x) + " " + round2(left[i].y);
    }
    /* uçta yuvarlak kapak */
    var tip = mids[mids.length - 1];
    d += "Q" + round2(tip.x) + " " + round2(tip.y + w1 * 1.5) + " " +
         round2(right[right.length - 1].x) + " " + round2(right[right.length - 1].y);
    for (i = right.length - 2; i >= 0; i--) {
      d += "L" + round2(right[i].x) + " " + round2(right[i].y);
    }
    d += "Z";
    return { d: d, mids: mids };
  }

  /* Kol tanımları — viewBox 0 0 120 120
     Baş merkezi ~ (60,46), yarıçap ~ 33x29
     Arka kollar (behind) daha soluk, ön kollar (front) daha net. */
  var ARMS = [
    /* ---- arka sol dış ---- */
    { id: "b1", layer: "back", w0: 6.2, w1: 1.5,
      p0: pt(36, 62), p1: pt(20, 72), p2: pt(9, 88), p3: pt(14, 106) },
    /* ---- arka sol iç ---- */
    { id: "b2", layer: "back", w0: 6.6, w1: 1.6,
      p0: pt(46, 68), p1: pt(35, 82), p2: pt(28, 98), p3: pt(34, 112) },
    /* ---- arka sağ iç ---- */
    { id: "b3", layer: "back", w0: 6.6, w1: 1.6,
      p0: pt(74, 68), p1: pt(85, 82), p2: pt(92, 98), p3: pt(86, 112) },
    /* ---- arka sağ dış ---- */
    { id: "b4", layer: "back", w0: 6.2, w1: 1.5,
      p0: pt(84, 62), p1: pt(100, 72), p2: pt(111, 88), p3: pt(106, 106) },
    /* ---- ön sol dış (en hareketli — "el") ---- */
    { id: "f1", layer: "front", w0: 7.4, w1: 1.7,
      p0: pt(33, 66), p1: pt(17, 78), p2: pt(16, 96), p3: pt(28, 104) },
    /* ---- ön sol iç ---- */
    { id: "f2", layer: "front", w0: 8.0, w1: 1.8,
      p0: pt(48, 72), p1: pt(42, 88), p2: pt(44, 104), p3: pt(56, 110) },
    /* ---- ön sağ iç ---- */
    { id: "f3", layer: "front", w0: 8.0, w1: 1.8,
      p0: pt(72, 72), p1: pt(78, 88), p2: pt(76, 104), p3: pt(64, 110) },
    /* ---- ön sağ dış ---- */
    { id: "f4", layer: "front", w0: 7.4, w1: 1.7,
      p0: pt(87, 66), p1: pt(103, 78), p2: pt(104, 96), p3: pt(92, 104) }
  ];

  /* Kol üzerine vantuz dizisi (merkez çizgi noktalarından örnekle) */
  function suckers(mids, from, count, r0, r1) {
    var out = "", i, idx, p, r, t;
    for (i = 0; i < count; i++) {
      t = i / Math.max(1, count - 1);
      idx = Math.round((from + (mids.length - 1 - from) * t));
      p = mids[idx];
      r = r0 + (r1 - r0) * t;
      out += '<circle class="ok-suck" cx="' + round2(p.x) + '" cy="' +
             round2(p.y) + '" r="' + round2(r) + '"/>';
    }
    return out;
  }

  /* ==========================================================
     SVG üretimi
     ========================================================== */
  function buildSVG(uid) {
    var u = "o" + uid;
    var s = "";

    s += '<svg class="ok-svg" viewBox="0 0 120 124" xmlns="' + NS +
         '" role="img" aria-label="Mixium maskotu">';

    /* ---------- defs: doku, ışık, gölge ---------- */
    s += '<defs>';

    /* Ana gövde: üstten aydınlık, altta derin — subsurface hissi */
    s += '<radialGradient id="' + u + 'body" cx="42%" cy="28%" r="78%">' +
           '<stop offset="0%"   stop-color="var(--skin-hi)"/>' +
           '<stop offset="34%"  stop-color="var(--skin)"/>' +
           '<stop offset="70%"  stop-color="var(--skin-mid)"/>' +
           '<stop offset="100%" stop-color="var(--skin-lo)"/>' +
         '</radialGradient>';

    /* Kollar: baştan uca doğru koyulaşır */
    s += '<linearGradient id="' + u + 'arm" x1="0%" y1="0%" x2="0%" y2="100%">' +
           '<stop offset="0%"   stop-color="var(--skin)"/>' +
           '<stop offset="55%"  stop-color="var(--skin-mid)"/>' +
           '<stop offset="100%" stop-color="var(--skin-lo)"/>' +
         '</linearGradient>';
    s += '<linearGradient id="' + u + 'armb" x1="0%" y1="0%" x2="0%" y2="100%">' +
           '<stop offset="0%"   stop-color="var(--skin-mid)"/>' +
           '<stop offset="100%" stop-color="var(--skin-deep)"/>' +
         '</linearGradient>';

    /* Rim light — sağ alt kenardan gelen soğuk yansıma */
    s += '<linearGradient id="' + u + 'rim" x1="10%" y1="0%" x2="90%" y2="100%">' +
           '<stop offset="0%"  stop-color="var(--skin-hi)" stop-opacity="0"/>' +
           '<stop offset="72%" stop-color="var(--skin-hi)" stop-opacity="0"/>' +
           '<stop offset="100%" stop-color="var(--skin-hi)" stop-opacity=".72"/>' +
         '</linearGradient>';

    /* Üst parlaklık (specular) */
    s += '<radialGradient id="' + u + 'spec" cx="50%" cy="50%" r="50%">' +
           '<stop offset="0%"   stop-color="#ffffff" stop-opacity=".82"/>' +
           '<stop offset="55%"  stop-color="#ffffff" stop-opacity=".22"/>' +
           '<stop offset="100%" stop-color="#ffffff" stop-opacity="0"/>' +
         '</radialGradient>';

    /* Göz küresi */
    s += '<radialGradient id="' + u + 'eye" cx="38%" cy="32%" r="74%">' +
           '<stop offset="0%"   stop-color="#e8e0ff"/>' +
           '<stop offset="62%"  stop-color="#c0a8f0"/>' +
           '<stop offset="100%" stop-color="#8060c0"/>' +
         '</radialGradient>';

    /* İris */
    s += '<radialGradient id="' + u + 'iris" cx="42%" cy="34%" r="70%">' +
           '<stop offset="0%"   stop-color="var(--acc-hi)"/>' +
           '<stop offset="52%"  stop-color="var(--acc)"/>' +
           '<stop offset="100%" stop-color="var(--acc-deep)"/>' +
         '</radialGradient>';

    /* Zemin gölgesi */
    s += '<radialGradient id="' + u + 'gsh" cx="50%" cy="50%" r="50%">' +
           '<stop offset="0%"   stop-color="#000" stop-opacity=".42"/>' +
           '<stop offset="100%" stop-color="#000" stop-opacity="0"/>' +
         '</radialGradient>';

    /* Cilt beneği dokusu — mottling */
    s += '<filter id="' + u + 'skin" x="-15%" y="-15%" width="130%" height="130%">' +
           '<feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" seed="7" result="n"/>' +
           '<feColorMatrix in="n" type="saturate" values="0" result="ng"/>' +
           '<feComponentTransfer in="ng" result="nc">' +
             '<feFuncA type="table" tableValues="0 0.22"/>' +
           '</feComponentTransfer>' +
           '<feComposite in="nc" in2="SourceGraphic" operator="in"/>' +
         '</filter>';

    /* Gövde iç yumuşak gölge */
    s += '<filter id="' + u + 'soft" x="-30%" y="-30%" width="160%" height="160%">' +
           '<feGaussianBlur stdDeviation="2.4"/>' +
         '</filter>';

    /* Aura parıltısı */
    s += '<filter id="' + u + 'glow" x="-45%" y="-45%" width="190%" height="190%">' +
           '<feGaussianBlur stdDeviation="3.2" result="b"/>' +
           '<feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>' +
         '</filter>';

    /* Baş maskesi (beneklerin taşmaması için) */
    s += '<clipPath id="' + u + 'head">' +
           '<path d="M60 13c19.4 0 33.4 13.6 33.4 32.8 0 12.6-4.6 22.4-11.6 28.6-6.2 5.4-13.8 8-21.8 8s-15.6-2.6-21.8-8c-7-6.2-11.6-16-11.6-28.6C26.6 26.6 40.6 13 60 13z"/>' +
         '</clipPath>';

    s += '</defs>';

    /* ---------- zemin gölgesi ---------- */
    s += '<ellipse class="ok-ground" cx="60" cy="114" rx="30" ry="6.4" fill="url(#' + u + 'gsh)"/>';

    /* ---------- aura (durum halkası) ---------- */
    s += '<circle class="ok-aura" cx="60" cy="47" r="40" fill="none" ' +
         'stroke="var(--acc)" stroke-width="1.4" opacity="0"/>';

    /* ---------- arka kollar ---------- */
    s += '<g class="ok-back">';
    ARMS.filter(function (a) { return a.layer === "back"; }).forEach(function (a) {
      var r = tentaclePath(a, a.w0, a.w1, 24);
      s += '<g class="ok-arm ok-' + a.id + '">' +
             '<path class="ok-arm-fill" d="' + r.d + '" fill="url(#' + u + 'armb)"/>' +
             '<g class="ok-sucks">' + suckers(r.mids, 8, 5, 1.15, 0.45) + '</g>' +
           '</g>';
    });
    s += '</g>';

    /* ---------- gövde grubu (nefes alır) ---------- */
    s += '<g class="ok-body">';

    /* mantle / baş — büyük, yumuşak, damla biçimli */
    var HEAD = 'M60 13c19.4 0 33.4 13.6 33.4 32.8 0 12.6-4.6 22.4-11.6 28.6' +
               '-6.2 5.4-13.8 8-21.8 8s-15.6-2.6-21.8-8' +
               'c-7-6.2-11.6-16-11.6-28.6C26.6 26.6 40.6 13 60 13z';
    s += '<path class="ok-head" d="' + HEAD + '" fill="url(#' + u + 'body)"/>';

    /* cilt beneği dokusu */
    s += '<g clip-path="url(#' + u + 'head)">' +
           '<path d="' + HEAD + '" fill="var(--skin-deep)" filter="url(#' + u + 'skin)" opacity=".55"/>' +
           /* mantle üstündeki hafif sırt çizgisi */
           '<path d="M60 15c-9 6-13 16-13 27" stroke="var(--skin-hi)" stroke-width="1.1" ' +
             'fill="none" opacity=".2" stroke-linecap="round"/>' +
           '<path d="M60 15c9 6 13 16 13 27" stroke="var(--skin-hi)" stroke-width="1.1" ' +
             'fill="none" opacity=".14" stroke-linecap="round"/>' +
           /* alt iç gölge */
           '<ellipse cx="60" cy="86" rx="30" ry="14" fill="var(--skin-deep)" ' +
             'opacity=".42" filter="url(#' + u + 'soft)"/>' +
         '</g>';

    /* rim light */
    s += '<path class="ok-rim" d="' + HEAD + '" fill="url(#' + u + 'rim)" opacity=".8"/>';

    /* üst specular — büyük yumuşak ışık */
    s += '<ellipse class="ok-spec" cx="47" cy="27" rx="15" ry="10" ' +
         'fill="url(#' + u + 'spec)" transform="rotate(-22 47 27)"/>';
    s += '<ellipse class="ok-spec2" cx="76" cy="31" rx="5.2" ry="3.4" ' +
         'fill="url(#' + u + 'spec)" opacity=".5" transform="rotate(-18 76 31)"/>';

    /* ---------- gözler (ağız YOK) ---------- */
    s += '<g class="ok-eyes">';

    /* sol göz */
    s += '<g class="ok-eye ok-eye-l">' +
           '<ellipse class="ok-eye-shadow" cx="47.5" cy="49.5" rx="11.4" ry="10.6" ' +
             'fill="var(--skin-deep)" opacity=".38" filter="url(#' + u + 'soft)"/>' +
           '<ellipse class="ok-sclera" cx="47" cy="48.6" rx="10.6" ry="9.9" fill="url(#' + u + 'eye)"/>' +
           '<g class="ok-pupil-g">' +
             '<circle class="ok-iris" cx="47" cy="49" r="6.1" fill="url(#' + u + 'iris)"/>' +
             '<ellipse class="ok-pupil" cx="47" cy="49" rx="3.05" ry="4.5" fill="var(--skin-eye)"/>' +
             '<circle class="ok-gleam" cx="44.6" cy="46.1" r="2.1" fill="#fff" opacity=".95"/>' +
             '<circle class="ok-gleam2" cx="49.8" cy="52.1" r="1.05" fill="#fff" opacity=".42"/>' +
           '</g>' +
           '<path class="ok-lid ok-lid-t" d="M36.4 48.6a10.6 9.9 0 0 1 21.2 0z" fill="var(--skin-mid)"/>' +
           '<path class="ok-lid ok-lid-b" d="M36.4 48.6a10.6 9.9 0 0 0 21.2 0z" fill="var(--skin-mid)"/>' +
         '</g>';

    /* sağ göz */
    s += '<g class="ok-eye ok-eye-r">' +
           '<ellipse class="ok-eye-shadow" cx="73.5" cy="49.5" rx="11.4" ry="10.6" ' +
             'fill="var(--skin-deep)" opacity=".38" filter="url(#' + u + 'soft)"/>' +
           '<ellipse class="ok-sclera" cx="73" cy="48.6" rx="10.6" ry="9.9" fill="url(#' + u + 'eye)"/>' +
           '<g class="ok-pupil-g">' +
             '<circle class="ok-iris" cx="73" cy="49" r="6.1" fill="url(#' + u + 'iris)"/>' +
             '<ellipse class="ok-pupil" cx="73" cy="49" rx="3.05" ry="4.5" fill="var(--skin-eye)"/>' +
             '<circle class="ok-gleam" cx="70.6" cy="46.1" r="2.1" fill="#fff" opacity=".95"/>' +
             '<circle class="ok-gleam2" cx="75.8" cy="52.1" r="1.05" fill="#fff" opacity=".42"/>' +
           '</g>' +
           '<path class="ok-lid ok-lid-t" d="M62.4 48.6a10.6 9.9 0 0 1 21.2 0z" fill="var(--skin-mid)"/>' +
           '<path class="ok-lid ok-lid-b" d="M62.4 48.6a10.6 9.9 0 0 0 21.2 0z" fill="var(--skin-mid)"/>' +
         '</g>';

    s += '</g>';  /* /eyes */

    /* yanak/alın vurgusu — ağız yerine yumuşak hacim */
    s += '<ellipse class="ok-blush ok-blush-l" cx="38" cy="61" rx="6.4" ry="3.4" ' +
         'fill="var(--acc-hi)" opacity=".1"/>';
    s += '<ellipse class="ok-blush ok-blush-r" cx="82" cy="61" rx="6.4" ry="3.4" ' +
         'fill="var(--acc-hi)" opacity=".1"/>';

    s += '</g>';  /* /body */

    /* ---------- ön kollar ---------- */
    s += '<g class="ok-front">';
    ARMS.filter(function (a) { return a.layer === "front"; }).forEach(function (a) {
      var r = tentaclePath(a, a.w0, a.w1, 28);
      s += '<g class="ok-arm ok-' + a.id + '">' +
             '<path class="ok-arm-fill" d="' + r.d + '" fill="url(#' + u + 'arm)"/>' +
             '<path class="ok-arm-hi" d="' + r.d + '" fill="url(#' + u + 'rim)" opacity=".55"/>' +
             '<g class="ok-sucks">' + suckers(r.mids, 6, 7, 1.5, 0.5) + '</g>' +
           '</g>';
    });
    s += '</g>';

    /* ---------- durum parçacıkları ---------- */
    s += '<g class="ok-fx">' +
           '<circle class="ok-bub ok-bub1" cx="30" cy="34" r="2.2"/>' +
           '<circle class="ok-bub ok-bub2" cx="92" cy="26" r="1.6"/>' +
           '<circle class="ok-bub ok-bub3" cx="24" cy="60" r="1.25"/>' +
           '<circle class="ok-bub ok-bub4" cx="98" cy="56" r="1.9"/>' +
         '</g>';

    /* ---------- düşünme baloncukları ---------- */
    s += '<g class="ok-think">' +
           '<circle class="ok-td ok-td1" cx="88" cy="20" r="2.6"/>' +
           '<circle class="ok-td ok-td2" cx="97" cy="12" r="3.6"/>' +
           '<circle class="ok-td ok-td3" cx="108" cy="5" r="4.6"/>' +
         '</g>';

    s += '</svg>';
    return s;
  }

  /* ==========================================================
     Genel API
     ========================================================== */

  /**
   * Yeni maskot elemanı üretir.
   * @param opts {size:number, state:string, tone:'default'|'flat'}
   */
  function make(opts) {
    opts = opts || {};
    if (typeof opts === "number") opts = { size: opts };
    var size = opts.size || 40;
    var el = document.createElement("div");
    el.className = "okto";
    el.style.setProperty("--ok-size", size + "px");
    el.dataset.state = opts.state || "idle";
    el.dataset.oid = String(++_uid);
    el.innerHTML = buildSVG(_uid);
    if (opts.tone) el.dataset.tone = opts.tone;
    /* göz takibi sadece büyük maskotlarda */
    if (size >= 56) enableGaze(el);
    return el;
  }

  /** Durum değiştir — SADECE bu eleman etkilenir. */
  function set(el, state) {
    if (!el) return;
    if (!LABELS[state]) state = "idle";
    if (el.dataset.state === state) return;
    el.dataset.state = state;
    /* kısa "geçiş" darbesi */
    el.classList.remove("ok-pulse");
    void el.offsetWidth;
    el.classList.add("ok-pulse");
  }

  function get(el) { return el ? (el.dataset.state || "idle") : "idle"; }

  function label(state) { return LABELS[state] || state || ""; }

  function hint(state) {
    var arr = HINTS[state] || HINTS.idle;
    return arr[Math.floor(Math.random() * arr.length)];
  }

  /** Tek seferlik tepki: zıpla / şaşır / onayla */
  function react(el, kind) {
    if (!el) return;
    var cls = "ok-react-" + (kind || "bounce");
    el.classList.remove("ok-react-bounce", "ok-react-nod", "ok-react-shake", "ok-react-wave");
    void el.offsetWidth;
    el.classList.add(cls);
    setTimeout(function () { el.classList.remove(cls); }, 1100);
  }

  /* ---- göz takibi: imleci izler (yalnız büyük maskot) ---- */
  var _gazeEls = [];
  var _gazeBound = false;

  function enableGaze(el) {
    _gazeEls.push(el);
    if (_gazeBound) return;
    _gazeBound = true;
    var raf = null, mx = 0, my = 0;
    window.addEventListener("pointermove", function (e) {
      mx = e.clientX; my = e.clientY;
      if (raf) return;
      raf = requestAnimationFrame(function () {
        raf = null;
        for (var i = _gazeEls.length - 1; i >= 0; i--) {
          var n = _gazeEls[i];
          if (!n.isConnected) { _gazeEls.splice(i, 1); continue; }
          var r = n.getBoundingClientRect();
          if (!r.width) continue;
          var cx = r.left + r.width / 2, cy = r.top + r.height * 0.42;
          var dx = (mx - cx) / Math.max(180, r.width * 4);
          var dy = (my - cy) / Math.max(180, r.height * 4);
          dx = Math.max(-1, Math.min(1, dx)) * 2.3;
          dy = Math.max(-1, Math.min(1, dy)) * 1.7;
          n.style.setProperty("--gx", dx.toFixed(2) + "px");
          n.style.setProperty("--gy", dy.toFixed(2) + "px");
        }
      });
    }, { passive: true });
  }

  /* ---- rastgele göz kırpma: her örnek kendi ritminde ---- */
  function autoBlink(el) {
    if (!el) return;
    function loop() {
      if (!el.isConnected) return;
      var wait = 2600 + Math.random() * 4200;
      setTimeout(function () {
        if (!el.isConnected) return;
        el.classList.add("ok-blink");
        setTimeout(function () { el.classList.remove("ok-blink"); }, 170);
        /* bazen çift kırpma */
        if (Math.random() < 0.22) {
          setTimeout(function () {
            el.classList.add("ok-blink");
            setTimeout(function () { el.classList.remove("ok-blink"); }, 150);
          }, 300);
        }
        loop();
      }, wait);
    }
    loop();
  }

  global.Okto = {
    make: make,
    set: set,
    get: get,
    label: label,
    hint: hint,
    react: react,
    autoBlink: autoBlink,
    states: Object.keys(LABELS)
  };

})(window);

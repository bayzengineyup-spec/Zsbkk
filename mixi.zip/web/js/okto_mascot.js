/* ============================================================
   OKTO PIXEL MASCOT
   Uses the user's supplied Pixel Ahtapot artwork as the live
   in-app mascot while preserving the existing OktoPus API.
   ============================================================ */
(function(global){
  "use strict";
  var uid=0;
  var LABEL={idle:"hazır",think:"düşünüyor",write:"yazıyor",tool:"araç kullanıyor",error:"takıldı",done:"tamamlandı",sleep:"bekliyor"};
  var SVG="<svg class=\"po-svg\" viewBox=\"0 0 700 600\" class=\"pixel\" aria-label=\"Minecraft tarz\u0131 detayl\u0131 piksel ahtapot\">\n      <!-- 8 kol -->\n      <g class=\"tentacle t1\">\n        <path class=\"body\" d=\"M310 360 C250 400 195 420 125 402 C70 388 54 343 83 319 C104 302 125 316 112 337 C101 354 123 363 147 359 C206 349 247 320 286 296Z\"/>\n        <path class=\"body2\" d=\"M112 337 C98 350 106 367 132 367 C105 378 79 357 82 332 C84 315 101 305 114 314Z\"/>\n      </g>\n      <g class=\"tentacle t2\">\n        <path class=\"body\" d=\"M285 384 C235 440 180 478 123 468 C75 460 58 425 79 402 C95 384 119 394 111 414 C104 431 124 437 143 427 C190 402 218 365 247 329Z\"/>\n      </g>\n      <g class=\"tentacle t3\">\n        <path class=\"body\" d=\"M335 390 C315 457 282 520 229 531 C184 540 163 511 180 488 C193 471 215 479 207 498 C204 508 218 509 230 500 C264 474 278 424 278 364Z\"/>\n      </g>\n      <g class=\"tentacle t4\">\n        <path class=\"body\" d=\"M372 390 C383 456 407 514 455 529 C496 542 524 520 514 496 C507 477 484 481 490 499 C494 511 480 510 468 501 C437 476 422 425 420 365Z\"/>\n      </g>\n      <g class=\"tentacle t5\">\n        <path class=\"body\" d=\"M416 369 C468 426 520 462 574 448 C622 436 639 398 616 377 C598 360 579 374 589 394 C597 410 576 419 556 408 C512 385 482 348 454 315Z\"/>\n      </g>\n\n      <!-- Selam veren kol -->\n      <g id=\"waveArm\">\n        <path class=\"body\" d=\"M430 320 C477 278 511 226 502 176 C495 135 516 108 543 117 C566 125 563 150 548 159 C536 166 540 184 549 195 C566 216 580 237 569 269 C557 304 521 337 469 369Z\"/>\n        <path class=\"body2\" d=\"M514 173 C504 139 520 112 543 117 C562 122 564 142 550 156 C536 170 543 184 551 196 C530 184 519 181 514 173Z\"/>\n      </g>\n\n      <!-- Arka kol -->\n      <g class=\"tentacle t6\">\n        <path class=\"body\" d=\"M273 320 C220 286 178 241 183 195 C188 154 217 141 236 159 C251 173 241 191 225 188 C211 185 207 202 218 217 C235 239 263 253 299 268Z\"/>\n      </g>\n      <g class=\"tentacle t7\">\n        <path class=\"body\" d=\"M390 310 C435 270 474 228 472 190 C470 153 445 140 428 158 C414 173 424 190 439 188 C452 187 456 201 445 215 C430 235 408 249 374 263Z\"/>\n      </g>\n\n      <!-- Yeni gövde/kafa: tek parça, daha dolgun ve yuvarlak -->\n      <path class=\"body\" d=\"M238 214 C235 178 239 143 258 116 C279 84 311 66 350 66 C389 66 421 84 442 116 C461 143 465 178 462 214 L455 286 C451 322 433 350 406 367 C390 377 371 383 350 384 C329 383 310 377 294 367 C267 350 249 322 245 286Z\"/>\n      <path class=\"body2\" d=\"M257 174 C262 127 298 88 350 84 C402 88 438 127 443 174 C420 157 389 149 350 149 C311 149 280 157 257 174Z\"/>\n      <path class=\"shadow\" d=\"M255 286 C274 310 300 324 350 326 C400 324 426 310 445 286 L455 286 C451 322 433 350 406 367 C390 377 371 383 350 384 C329 383 310 377 294 367 C267 350 249 322 245 286Z\" opacity=\".28\"/>\n\n      <!-- Büyük, sade gözler -->\n      <rect class=\"eye\" x=\"286\" y=\"188\" width=\"24\" height=\"24\"/>\n      <rect class=\"eye\" x=\"390\" y=\"188\" width=\"24\" height=\"24\"/>\n      <rect class=\"shine\" x=\"291\" y=\"193\" width=\"6\" height=\"6\"/>\n      <rect class=\"shine\" x=\"395\" y=\"193\" width=\"6\" height=\"6\"/>\n\n      <!-- Gövdeye hafif piksel doku -->\n      <g class=\"pixelShade\">\n        <rect x=\"278\" y=\"117\" width=\"11\" height=\"11\" fill=\"#873820\"/><rect x=\"309\" y=\"96\" width=\"9\" height=\"9\" fill=\"#d27537\"/>\n        <rect x=\"340\" y=\"88\" width=\"10\" height=\"10\" fill=\"#873820\"/><rect x=\"378\" y=\"99\" width=\"10\" height=\"10\" fill=\"#d27537\"/>\n        <rect x=\"407\" y=\"122\" width=\"9\" height=\"9\" fill=\"#873820\"/><rect x=\"268\" y=\"153\" width=\"10\" height=\"10\" fill=\"#d27537\"/>\n        <rect x=\"421\" y=\"157\" width=\"10\" height=\"10\" fill=\"#7d321e\"/><rect x=\"282\" y=\"240\" width=\"9\" height=\"9\" fill=\"#d27537\"/>\n        <rect x=\"317\" y=\"256\" width=\"10\" height=\"10\" fill=\"#7d321e\"/><rect x=\"371\" y=\"246\" width=\"9\" height=\"9\" fill=\"#d27537\"/>\n        <rect x=\"407\" y=\"271\" width=\"9\" height=\"9\" fill=\"#7d321e\"/><rect x=\"302\" y=\"306\" width=\"10\" height=\"10\" fill=\"#d27537\"/>\n        <rect x=\"348\" y=\"319\" width=\"9\" height=\"9\" fill=\"#7d321e\"/><rect x=\"387\" y=\"305\" width=\"10\" height=\"10\" fill=\"#d27537\"/>\n      </g>\n\n      <!-- vantuzlar -->\n      <g class=\"suckers\">\n        <circle class=\"sucker\" cx=\"118\" cy=\"359\" r=\"6\"/><circle class=\"sucker\" cx=\"143\" cy=\"353\" r=\"6\"/>\n        <circle class=\"sucker\" cx=\"181\" cy=\"339\" r=\"6\"/><circle class=\"sucker\" cx=\"207\" cy=\"323\" r=\"6\"/>\n        <circle class=\"sucker\" cx=\"111\" cy=\"425\" r=\"6\"/><circle class=\"sucker\" cx=\"145\" cy=\"423\" r=\"6\"/>\n        <circle class=\"sucker\" cx=\"193\" cy=\"389\" r=\"6\"/><circle class=\"sucker\" cx=\"220\" cy=\"361\" r=\"6\"/>\n        <circle class=\"sucker\" cx=\"238\" cy=\"493\" r=\"6\"/><circle class=\"sucker\" cx=\"258\" cy=\"465\" r=\"6\"/>\n        <circle class=\"sucker\" cx=\"286\" cy=\"419\" r=\"6\"/><circle class=\"sucker\" cx=\"468\" cy=\"500\" r=\"6\"/>\n        <circle class=\"sucker\" cx=\"446\" cy=\"469\" r=\"6\"/><circle class=\"sucker\" cx=\"420\" cy=\"421\" r=\"6\"/>\n        <circle class=\"sucker\" cx=\"563\" cy=\"415\" r=\"6\"/><circle class=\"sucker\" cx=\"535\" cy=\"400\" r=\"6\"/>\n        <circle class=\"sucker\" cx=\"511\" cy=\"375\" r=\"6\"/><circle class=\"sucker\" cx=\"545\" cy=\"215\" r=\"6\"/>\n        <circle class=\"sucker\" cx=\"529\" cy=\"247\" r=\"6\"/><circle class=\"sucker\" cx=\"503\" cy=\"280\" r=\"6\"/>\n      </g>\n\n      <!-- su i\u00e7inde par\u0131lt\u0131lar -->\n      <rect class=\"spark\" x=\"570\" y=\"150\" width=\"5\" height=\"5\"/>\n      <rect class=\"spark\" x=\"150\" y=\"220\" width=\"4\" height=\"4\" style=\"animation-delay:-.8s\"/>\n      <rect class=\"spark\" x=\"610\" y=\"290\" width=\"5\" height=\"5\" style=\"animation-delay:-1.2s\"/>\n    </svg>";

  function make(size){
    var el=document.createElement("div");
    el.className="oktopus pixel-octo";
    el.style.setProperty("--op-size",(size||64)+"px");
    el.dataset.state="idle";
    el.dataset.oid=String(++uid);
    el.innerHTML=SVG;
    var cap=document.createElement("span");
    cap.className="op-cap"; cap.textContent=LABEL.idle; el.appendChild(cap);
    return el;
  }
  function set(el,st){
    if(!el) return;
    if(!LABEL[st]) st="idle";
    el.dataset.state=st;
    var cap=el.querySelector(".op-cap"); if(cap) cap.textContent=LABEL[st];
  }
  function get(el){return el?el.dataset.state||"idle":"idle";}
  function tools(el,names){return;}
  function react(el,kind){
    if(!el)return;
    var c="po-react-"+(kind||"bounce");
    el.classList.remove("po-react-bounce","po-react-nod","po-react-shake","po-react-wave","po-react-hop");
    void el.offsetWidth; el.classList.add(c);
    setTimeout(function(){el.classList.remove(c);},1000);
  }
  global.OktoPus={make:make,set:set,get:get,tools:tools,react:react,label:function(s){return LABEL[s]||s;},states:Object.keys(LABEL)};
  if(!global.Okto){
    global.Okto={
      make:function(opts){opts=opts||{};var size=typeof opts==="number"?opts:(opts.size||64);var e=make(size);if(opts.state&&opts.state!=="idle")set(e,opts.state);return e;},
      set:set,get:get,react:react,label:function(s){return LABEL[s]||s;},tools:tools,autoBlink:function(){},states:Object.keys(LABEL)
    };
  }
})(window);

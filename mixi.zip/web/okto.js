/* ============================================================
   OKTO — ahtapot maskotu: SVG üretici + durum motoru
   Okto.make(size)        -> DOM elemanı döner
   Okto.set(el, "think")  -> durum değiştirir
   Okto.bus.state("work") -> global maskotları senkronlar
   ============================================================ */
(function (global) {
  "use strict";

  var NS = "http://www.w3.org/2000/svg";

  /* durum -> insan okunur etiket (durum çubuğunda kullanılır) */
  var LABELS = {
    idle:   "hazır",
    think:  "düşünüyor",
    search: "araştırıyor",
    read:   "okuyor",
    write:  "yazıyor",
    work:   "çalışıyor",
    talk:   "anlatıyor",
    done:   "tamamlandı",
    error:  "hata"
  };

  /* durum -> durum çubuğu için dönen ipucu cümleleri */
  var HINTS = {
    think:  ["bağlamı tartıyor", "planı kuruyor", "adımları sıralıyor"],
    search: ["kaynak tarıyor", "dosyalarda arıyor", "eşleşme kovalıyor"],
    read:   ["dosyayı okuyor", "çıktıyı inceliyor", "notları karşılaştırıyor"],
    write:  ["kod yazıyor", "dosyayı düzenliyor", "satırları işliyor"],
    work:   ["komutu çalıştırıyor", "aracı sürüyor", "işlemi yürütüyor"],
    talk:   ["cevabı derliyor", "sonucu özetliyor"],
    idle:   ["komut bekliyor"],
    done:   ["iş bitti"],
    error:  ["bir şeyler ters gitti"]
  };

  /* ---- SVG gövde şablonu ----------------------------------- */
  function svgMarkup() {
    return '' +
'<svg viewBox="0 0 64 64" xmlns="' + NS + '" aria-hidden="true">' +
  '<defs>' +
    '<linearGradient id="oktoBody" x1="20%" y1="0%" x2="80%" y2="100%">' +
      '<stop offset="0%" stop-color="var(--skin-2)"/>' +
      '<stop offset="60%" stop-color="var(--skin)"/>' +
      '<stop offset="100%" stop-color="var(--skin-3)"/>' +
    '</linearGradient>' +
    '<linearGradient id="oktoArm" x1="0%" y1="0%" x2="0%" y2="100%">' +
      '<stop offset="0%" stop-color="var(--skin)"/>' +
      '<stop offset="100%" stop-color="var(--skin-3)"/>' +
    '</linearGradient>' +
  '</defs>' +

  /* ---- arka kollar (her zaman dalgalanır) ---- */
  '<g class="o-arms-back">' +
    '<path class="o-arm o-arm-thin o-arm-b1" d="M20 34c-4.6 3.4-8.4 4.2-9.6 9.4-.7 3 .8 5.6 3 5.9"/>' +
    '<path class="o-arm o-arm-thin o-arm-b2" d="M25 37c-3 4.6-6.2 6-6.2 11.4 0 3.2 1.7 5 3.6 4.8"/>' +
    '<path class="o-arm o-arm-thin o-arm-b3" d="M39 37c3 4.6 6.2 6 6.2 11.4 0 3.2-1.7 5-3.6 4.8"/>' +
    '<path class="o-arm o-arm-thin o-arm-b4" d="M44 34c4.6 3.4 8.4 4.2 9.6 9.4.7 3-.8 5.6-3 5.9"/>' +
    '<circle class="o-suck" cx="13.6" cy="46.5" r="1.5"/>' +
    '<circle class="o-suck" cx="21.4" cy="50.6" r="1.5"/>' +
    '<circle class="o-suck" cx="42.6" cy="50.6" r="1.5"/>' +
    '<circle class="o-suck" cx="50.4" cy="46.5" r="1.5"/>' +
  '</g>' +

  /* ---- gövde / baş ---- */
  '<path class="o-body" d="M32 6c11 0 18.4 8 18.4 18.2 0 7.4-3.2 12-6.6 14.4-2.6 1.9-5 2.6-11.8 2.6s-9.2-.7-11.8-2.6c-3.4-2.4-6.6-7-6.6-14.4C13.6 14 21 6 32 6z"/>' +
  '<ellipse class="o-gloss" cx="25.5" cy="15.5" rx="5.4" ry="3.4" transform="rotate(-24 25.5 15.5)"/>' +

  /* ---- kaşlar ---- */
  '<path class="o-brow o-brow-l" d="M20.6 20.4c1.9-1.5 4.6-1.6 6.4-.5"/>' +
  '<path class="o-brow o-brow-r" d="M37 19.9c1.8-1.1 4.5-1 6.4.5"/>' +

  /* ---- gözler ---- */
  '<g class="o-eyes">' +
    '<ellipse class="o-eye" cx="24.4" cy="26.6" rx="5.1" ry="5.5"/>' +
    '<ellipse class="o-eye" cx="39.6" cy="26.6" rx="5.1" ry="5.5"/>' +
    '<circle class="o-pupil" cx="24.4" cy="26.8" r="2.5"/>' +
    '<circle class="o-pupil" cx="39.6" cy="26.8" r="2.5"/>' +
    '<circle class="o-eye-shine" cx="22.9" cy="24.8" r=".95" fill="rgba(255,255,255,.92)"/>' +
    '<circle class="o-eye-shine" cx="38.1" cy="24.8" r=".95" fill="rgba(255,255,255,.92)"/>' +
    '<rect class="o-lid" x="19.3" y="21.1" width="10.2" height="11" rx="5.1"/>' +
    '<rect class="o-lid" x="34.5" y="21.1" width="10.2" height="11" rx="5.1"/>' +
  '</g>' +

  /* ---- ağız + dil ---- */
  '<path class="o-mouth" d="M28.6 35c1.9 1.8 4.9 1.8 6.8 0"/>' +
  '<ellipse class="o-tongue" cx="32" cy="36.6" rx="2" ry="1.3"/>' +

  /* ---- düşünce baloncukları ---- */
  '<g class="o-bubbles">' +
    '<circle class="o-bub o-bub1" cx="50" cy="16" r="1.7"/>' +
    '<circle class="o-bub o-bub2" cx="54" cy="13" r="2.3"/>' +
    '<circle class="o-bub o-bub3" cx="58.4" cy="9.6" r="3"/>' +
  '</g>' +

  /* ---- çene tutan kol (think) ---- */
  '<g class="o-tool o-arm-chin">' +
    '<path class="o-arm o-arm-thin" d="M40 38c3.4.6 5.2-1 5.4-3.6"/>' +
    '<circle class="o-suck" cx="45.2" cy="33.6" r="1.4"/>' +
  '</g>' +

  /* ---- büyüteç + tutan kol (search) ---- */
  '<g class="o-tool o-arm-loupe">' +
    '<path class="o-arm o-arm-thin" d="M41 38c4 1.8 7 1.4 9.6-1"/>' +
  '</g>' +
  '<g class="o-tool o-loupe">' +
    '<line class="o-loupe-handle" x1="52" y1="35.4" x2="57.4" y2="41"/>' +
    '<circle class="o-loupe-glass" cx="49.4" cy="32.6" r="6.4"/>' +
    '<circle class="o-loupe-rim" cx="49.4" cy="32.6" r="6.4"/>' +
    '<ellipse class="o-loupe-shine" cx="47.2" cy="30.2" rx="2.1" ry="1.3" transform="rotate(-32 47.2 30.2)"/>' +
  '</g>' +

  /* ---- kitap + iki kol (read) ---- */
  '<g class="o-tool o-arm-book-l">' +
    '<path class="o-arm o-arm-thin" d="M23 38c-3 2.6-4.6 4.6-4.6 7.4"/>' +
  '</g>' +
  '<g class="o-tool o-arm-book-r">' +
    '<path class="o-arm o-arm-thin" d="M41 38c3 2.6 4.6 4.6 4.6 7.4"/>' +
  '</g>' +
  '<g class="o-tool o-book">' +
    '<path class="o-book-cover" d="M17.4 44.6h29.2v12H17.4z" rx="1"/>' +
    '<path class="o-book-page" d="M19 45.8h12.2v9.6H19zM32.8 45.8H45v9.6H32.8z"/>' +
    '<line class="o-book-line" x1="20.8" y1="48.4" x2="29.4" y2="48.4"/>' +
    '<line class="o-book-line" x1="20.8" y1="50.6" x2="29.4" y2="50.6"/>' +
    '<line class="o-book-line" x1="20.8" y1="52.8" x2="27.2" y2="52.8"/>' +
    '<line class="o-book-line" x1="34.6" y1="48.4" x2="43.2" y2="48.4"/>' +
    '<line class="o-book-line" x1="34.6" y1="50.6" x2="43.2" y2="50.6"/>' +
    '<line class="o-book-line" x1="34.6" y1="52.8" x2="41" y2="52.8"/>' +
    '<path class="o-page-flip" d="M32.8 45.8H45v9.6H32.8z"/>' +
    '<line x1="32" y1="44.8" x2="32" y2="56.2" stroke="var(--brass-dim)" stroke-width="1.1"/>' +
  '</g>' +

  /* ---- kağıt + tüy kalem (write) ---- */
  '<g class="o-tool o-paper">' +
    '<rect class="o-paper-sheet" x="14.6" y="44" width="21" height="14" rx="1.2"/>' +
    '<line class="o-ink-line o-ink-line1" x1="17.6" y1="48" x2="31.6" y2="48"/>' +
    '<line class="o-ink-line o-ink-line2" x1="17.6" y1="51.2" x2="31.6" y2="51.2"/>' +
    '<line class="o-ink-line o-ink-line3" x1="17.6" y1="54.4" x2="27.4" y2="54.4"/>' +
  '</g>' +
  '<g class="o-tool o-arm-quill">' +
    '<path class="o-arm o-arm-thin" d="M40 38c2.6 3 3.4 5.4 2.4 8.4"/>' +
    '<circle class="o-suck" cx="42.2" cy="46.8" r="1.4"/>' +
  '</g>' +
  '<g class="o-tool o-quill">' +
    '<line class="o-quill-shaft" x1="36.4" y1="54.6" x2="45.6" y2="43.4"/>' +
    '<path class="o-quill-feather" d="M45.6 43.4c2.6-3.4 5.4-5.6 8-6.2-1 3-2.6 6.4-5.2 8.6-1.2 1-2.4.6-2.8-2.4z"/>' +
  '</g>' +

  /* ---- dişliler + uzanan kollar + kıvılcım (work) ---- */
  '<g class="o-tool o-arm-reach-l">' +
    '<path class="o-arm" d="M21 37c-5 2.4-8.6 3.6-10.6 8"/>' +
    '<circle class="o-suck" cx="10.6" cy="45.4" r="1.6"/>' +
  '</g>' +
  '<g class="o-tool o-arm-reach-r">' +
    '<path class="o-arm" d="M43 37c5 2.4 8.6 3.6 10.6 8"/>' +
    '<circle class="o-suck" cx="53.6" cy="45.4" r="1.6"/>' +
  '</g>' +
  '<g class="o-tool o-gear" style="transform-origin:52px 48px">' +
    '<circle class="o-gear-shape" cx="52" cy="48" r="4.4"/>' +
    '<path class="o-gear-shape" d="M52 41.6v-2M52 56.4v-2M45.6 48h-2M60.4 48h-2M47.4 43.4l-1.4-1.4M58 54l-1.4-1.4M56.6 43.4l1.4-1.4M46 54l1.4-1.4"/>' +
  '</g>' +
  '<g class="o-tool o-gear2" style="transform-origin:12px 50px">' +
    '<circle class="o-gear-shape" cx="12" cy="50" r="3.2"/>' +
    '<path class="o-gear-shape" d="M12 45.4v-1.6M12 56.2v-1.6M7.4 50H5.8M18.2 50h-1.6"/>' +
  '</g>' +
  '<circle class="o-spark" cx="52" cy="41" r="1.5"/>' +
  '<circle class="o-spark" cx="12" cy="44" r="1.2" style="animation-delay:.5s"/>' +

  /* ---- el hareketi kolu (talk) ---- */
  '<g class="o-tool o-arm-gesture" style="transform-origin:41px 38px">' +
    '<path class="o-arm o-arm-thin" d="M41 38c4.4 1.6 7.4 3.6 8.6 7.6"/>' +
    '<circle class="o-suck" cx="49.4" cy="45.4" r="1.5"/>' +
  '</g>' +
'</svg>';
  }

  /* ---- fabrika ---------------------------------------------- */
  var registry = [];

  function make(size, state) {
    var el = document.createElement("div");
    el.className = "okto " + (size ? "okto-" + size : "okto-md");
    el.setAttribute("data-state", state || "idle");
    el.innerHTML = svgMarkup();
    registry.push(el);
    return el;
  }

  function set(el, state) {
    if (!el) return;
    if (!LABELS[state]) state = "idle";
    // done/error kısa süreli: sonra idle'a döner
    el.setAttribute("data-state", state);
    if (state === "done" || state === "error") {
      clearTimeout(el._oktoT);
      el._oktoT = setTimeout(function () {
        if (el.getAttribute("data-state") === state) {
          el.setAttribute("data-state", "idle");
        }
      }, state === "done" ? 900 : 1400);
    }
  }

  /* çıktı satırından durumu tahmin et — araç adlarına bakar */
  function guess(line) {
    var s = (line || "").toLowerCase();
    if (/hata|error|traceback|başarısız|failed/.test(s))          return "error";
    if (/ara|search|grep|glob|bul|web|fetch|tavily/.test(s))      return "search";
    if (/oku|read|cat |görüntüle|view|list|ls /.test(s))          return "read";
    if (/yaz|write|edit|düzenle|patch|oluştur|create/.test(s))    return "write";
    if (/bash|shell|çalıştır|run|komut|exec|npm|pip|git/.test(s)) return "work";
    if (/düşün|think|plan|analiz/.test(s))                        return "think";
    return null;
  }

  function label(state) { return LABELS[state] || "hazır"; }

  function hint(state) {
    var arr = HINTS[state] || HINTS.idle;
    return arr[Math.floor(Math.random() * arr.length)];
  }

  global.Okto = {
    make: make,
    set: set,
    guess: guess,
    label: label,
    hint: hint,
    LABELS: LABELS,
    all: function () { return registry; }
  };
})(window);

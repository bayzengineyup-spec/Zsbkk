/* Mixium arayüz duman testi — jsdom
   Amaç: yeni tasarımdan sonra hiçbir JS yolunun kırılmadığını doğrulamak. */
const fs = require("fs");
const path = require("path");
const { JSDOM } = require("/tmp/node_modules/jsdom");

const WEB = "/home/user/build/web";
const html = fs.readFileSync(path.join(WEB, "index.html"), "utf8");

const dom = new JSDOM(html, { runScripts: "outside-only", pretendToBeVisual: true, url: "http://127.0.0.1:8420/" });
const { window } = dom;

window.matchMedia = window.matchMedia || (() => ({ matches: false, addListener(){}, removeListener(){}, addEventListener(){}, removeEventListener(){} }));
window.requestAnimationFrame = fn => setTimeout(() => fn(Date.now()), 0);
window.cancelAnimationFrame = clearTimeout;
window.WebSocket = class {
  constructor(u) { this.url = u; this.readyState = 0; this.sent = []; setTimeout(() => { this.readyState = 1; this.onopen && this.onopen(); }, 5); }
  send(d) { this.sent.push(d); }
  close() { this.readyState = 3; this.onclose && this.onclose(); }
};
window.scrollTo = () => {};
Object.defineProperty(window.HTMLElement.prototype, "scrollIntoView", { value(){}, writable: true });

const files = ["js/ui.js", "js/app.js", "js/shell.js", "panel.js"];
let fail = 0;
const ok  = m => console.log("  ok    " + m);
const bad = (m, e) => { fail++; console.log("  FAIL  " + m + (e ? "  → " + e : "")); };

for (const f of files) {
  try { window.eval(fs.readFileSync(path.join(WEB, f), "utf8")); ok("yüklendi: " + f); }
  catch (e) { bad("yüklenemedi: " + f, e.message); }
}

const A = window.App, U = window.UI, Sh = window.Shell;

console.log("\n— temel modüller —");
["UI", "App", "Shell", "Panel", "Pickers", "Panels"].forEach(k =>
  window[k] ? ok("window." + k) : bad("window." + k + " yok"));

console.log("\n— maskot kalıntısı olmamalı —");

console.log("\n— boot —");
try { Sh.boot(); ok("Shell.boot()"); } catch (e) { bad("Shell.boot()", e.message); }

console.log("\n— karşılama ekranı —");
const empty = window.document.querySelector("#empty");
empty ? ok("#empty basıldı") : bad("#empty yok");
if (empty) {
  empty.querySelector(".hero-title") ? ok("hero başlık") : bad("hero başlık yok");
  const chips = empty.querySelectorAll(".chip");
  chips.length ? ok("öneri satırı: " + chips.length) : bad("öneri yok");
  /^[\x00-\x7F\u0100-\u017F\s\wçğıöşüÇĞİÖŞÜ.,?!'"()·—–-]*$/.test(empty.textContent)
    ? ok("emoji içermiyor") : bad("emoji tespit edildi: " + empty.textContent);
}

console.log("\n— mesaj oluşturma —");
try {
  const um = A.addMsg("user", "merhaba");
  const am = A.addMsg("ai", "# Başlık\n\nBir **paragraf** ve `kod`.\n\n```py\nprint(1)\n```");
  um && am ? ok("kullanıcı + asistan mesajı") : bad("mesaj üretilemedi");
  am.querySelector(".ok-avatar") ? ok("asistan rol işareti") : bad("rol işareti yok");
  am.querySelector(".ok-avatar").children.length === 0 ? ok("rol işareti boş (CSS monogram)") : bad("rol işaretine düğüm enjekte edilmiş");
  am.querySelector(".codeblock") ? ok("kod bloğu render") : bad("kod bloğu yok");
  const aiActs = am.querySelectorAll(".msg-acts .act").length;
  const usActs = um.querySelectorAll(".msg-acts .act").length;
  aiActs === 2 ? ok("asistan eylem sayısı = 2") : bad("asistan eylem sayısı = " + aiActs + " (2 bekleniyordu)");
  usActs === 2 ? ok("kullanıcı eylem sayısı = 2") : bad("kullanıcı eylem sayısı = " + usActs);
} catch (e) { bad("addMsg", e.message); }

console.log("\n— araç kartı —");
try {
  A.state.cur = A.addMsg("ai", "");
  const card = A.toolCard("bash", "ls -la");
  card && card.querySelector(".tool-h") ? ok("araç kartı") : bad("araç kartı yok");
  const st = window.document.querySelector("#statusTxt").textContent;
  st === "Çalıştırıyor" ? ok('durum etiketi: "' + st + '"') : bad("durum etiketi: " + st);
} catch (e) { bad("toolCard", e.message); }

console.log("\n— sunucu mesajları —");
const msgs = [
  { type: "hello", session: "s1", model: "A", mode: "auto", models: [{ id: "A", ai: "x" }], sessions: [{ id: "s1", title: "Test", model: "A", n: 2, mtime: Date.now()/1000 }], title: "Test" },
  { type: "busy", on: true },
  { type: "out", text: "● bash ls\n" },
  { type: "out", text: "    dosya.txt\n" },
  { type: "out", text: "⏿ 12ms\n" },
  { type: "out", text: "Bitti.\n" },
  { type: "busy", on: false },
  { type: "sessions", items: [{ id: "s1", title: "Test", model: "A", n: 2, mtime: Date.now()/1000 }] },
  { type: "tools_list", items: [{ name: "bash", desc: "kabuk", schema: "{}" }] },
  { type: "mode_ok", mode: "plan" },
  { type: "model_ok", model: "A", ai: "x" }
];
msgs.forEach(m => { try { A.handle(m); ok("handle: " + m.type); } catch (e) { bad("handle: " + m.type, e.message); } });

console.log("\n— oturum listesi —");
const sess = window.document.querySelectorAll("#sessList .sess");
sess.length ? ok("oturum satırı: " + sess.length) : bad("oturum satırı yok");

console.log("\n— ayarlar & tema —");
try {
  Sh.syncSettingsUI(); ok("syncSettingsUI()");
  const before = window.document.documentElement.dataset.theme;
  Sh.toggleTheme();
  const after = window.document.documentElement.dataset.theme;
  before !== after ? ok("tema geçişi " + before + " → " + after) : bad("tema değişmedi");
  Sh.toggleTheme();
  window.document.documentElement.dataset.accent === undefined
    ? ok("accent özniteliği yok (tek aksan)") : bad("accent hâlâ yazılıyor");
} catch (e) { bad("ayarlar", e.message); }

console.log("\n— kaplamalar —");
try {
  Sh.openPalette(); window.document.querySelector("#palette").hidden === false ? ok("komut paleti") : bad("palet açılmadı");
  const items = window.document.querySelectorAll("#palList .pal-i").length;
  items ? ok("palet komutu: " + items) : bad("palet boş");
  Sh.closeAllModals(); ok("closeAllModals()");
  Sh.openModal("#settings"); Sh.closeModal("#settings"); ok("ayarlar aç/kapa");
  window.Panel.show(); window.document.querySelector("#panel").classList.contains("open") ? ok("yönetim paneli") : bad("panel açılmadı");
  window.Panel.close();
} catch (e) { bad("kaplamalar", e.message); }

console.log("\n— markdown —");
try {
  const h = U.mdRender("| a | b |\n|---|---|\n| 1 | 2 |\n\n- [x] iş\n- [ ] iş2\n\n> alıntı");
  /<table/.test(h) ? ok("tablo") : bad("tablo yok");
  /task-list/.test(h) ? ok("görev listesi") : bad("görev listesi yok");
  /blockquote/.test(h) ? ok("alıntı") : bad("alıntı yok");
} catch (e) { bad("mdRender", e.message); }

console.log("\n— CSS bütünlüğü —");
const cssFiles = ["typography", "tokens", "base", "layout", "chat", "overlays", "responsive"].map(n => "css/" + n + ".css").concat(["panel.css"]);
let allCss = "";
cssFiles.forEach(f => {
  const p = path.join(WEB, f);
  fs.existsSync(p) ? (allCss += fs.readFileSync(p, "utf8"), ok("var: " + f)) : bad("eksik: " + f);
});
// tanımsız değişken taraması
const defined = new Set([...allCss.matchAll(/--([a-z0-9-]+)\s*:/g)].map(m => m[1]));
const used = new Set([...allCss.matchAll(/var\(--([a-z0-9-]+)/g)].map(m => m[1]));
const missing = [...used].filter(v => !defined.has(v));
missing.length === 0 ? ok("tüm CSS değişkenleri tanımlı") : bad("tanımsız değişken: " + missing.join(", "));
// eski palet kalıntısı
/(--acc\b|--brass|--ink-dim|--bg-raise|35d0bd|7c83ff)/.test(allCss)
  ? bad("eski palet kalıntısı var") : ok("eski palet tamamen temizlenmiş");

// HTML'de kullanılan sınıflar CSS'te var mı (kritik olanlar)
const critical = ["brand-mark","btn-new","sess","picker","msg","bubble","body","codeblock","tool","composer","sendBtn","chip","hero-title","modal","sheet","sw","seg","tcard","kbd","tst"];
const missingCls = critical.filter(c => !allCss.includes("." + c) && !allCss.includes("#" + c));
missingCls.length === 0 ? ok("kritik sınıfların hepsi stillendirilmiş") : bad("stilsiz sınıf: " + missingCls.join(", "));

console.log("\n" + (fail ? "✗ " + fail + " hata" : "✓ tüm testler geçti"));
process.exit(fail ? 1 : 0);

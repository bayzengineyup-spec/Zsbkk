/* ============================================================
   ui-boot.js — güvenli entegrasyon katmanı
   Çekirdek WebSocket yaşam döngüsü app.js tarafından yönetilir.
   ============================================================ */
(function (W) {
  "use strict";

  function hookConnection() {
    var dot = document.querySelector("#connDot");
    if (!dot || !W.Panel || !W.Panel.setLive) return;

    function sync() {
      W.Panel.setLive(dot.classList.contains("on"));
    }

    new MutationObserver(sync).observe(dot, {
      attributes: true,
      attributeFilter: ["class"]
    });
    sync();
  }

  function hookPanel() {
    /* shell.js initializes Panel once. This layer only observes connection state. */
  }

  function start() {
    hookPanel();
    hookConnection();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})(window);

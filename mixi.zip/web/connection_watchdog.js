/* Connection watchdog — never leave the UI in "connecting" forever. */
(function (W) {
  "use strict";

  var timer = null;

  W.MixiumConnectionWatchdog = {
    start: function (timeout) {
      timeout = timeout || 10000;
      clearTimeout(timer);
      timer = setTimeout(function () {
        var dot = document.querySelector("#connDot");
        var state = W.App && W.App.state;

        if (state && !state.ready && dot &&
            dot.classList.contains("connecting")) {
          try {
            if (state.ws && state.ws.readyState !== 3) state.ws.close();
            else if (W.App.connect) W.App.connect();
          } catch (_) {
            try { if (W.App && W.App.connect) W.App.connect(); } catch (__) {}
          }
        }
      }, timeout);
    },
    done: function () {
      clearTimeout(timer);
      timer = null;
    }
  };

  function arm() {
    if (!W.App || !W.App.state) return;
    var state = W.App.state;
    var dot = document.querySelector("#connDot");
    if (!dot) return;

    if (state.ready) W.MixiumConnectionWatchdog.done();
    else W.MixiumConnectionWatchdog.start(10000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", arm, { once: true });
  } else {
    setTimeout(arm, 0);
  }
})(window);

# -*- coding: utf-8 -*-
"""
Mixium — B9 + B12: Real World Software Engineer + Full Autonomous Mode

`master_engineer_task(goal)` — kullanıcı isteğini uçtan uca yürütür:
Araştır → Planla → Mimari → Kodla → Test → Güvenlik → Performans → Review
→ Rapor.

`FullAutonomousMode` — arka planda görev kuyruğu; her değişiklik:
Permission → Checkpoint → Approval → Change → Test → Commit zincirinden
geçer. Zincirdeki herhangi bir halka reddederse değişiklik yapılmaz.

MIXIUM'a bağımlı değildir — tüm adımlar enjekte edilir (fail-closed).
"""

import time


class MasterEngineer:
    """Ana görev koşucusu: adım adım pipeline."""

    STEPS = ("research", "plan", "architecture", "code", "test",
             "security", "performance", "review", "report")

    def __init__(self, steps=None, on_step=None):
        """
        steps: {adım: callable(context) -> sonuç}
        on_step: (adım, sonuç) callback (opsiyonel)
        """
        self.steps = steps or {}
        self.on_step = on_step

    def run(self, goal):
        ctx = {"goal": goal, "started": time.time(), "results": {}}
        report = {"goal": goal, "steps": [], "status": "failed", "summary": ""}
        for s in self.STEPS:
            fn = self.steps.get(s)
            if fn is None:
                report["steps"].append({"step": s, "status": "skipped"})
                continue
            try:
                r = fn(ctx) or {}
                ctx["results"][s] = r
                status = "done" if r.get("ok", True) else "warn"
                report["steps"].append({"step": s, "status": status,
                                        "detail": r.get("detail", "")})
                if self.on_step:
                    try:
                        self.on_step(s, r)
                    except Exception:
                        pass
            except Exception as e:
                report["steps"].append({"step": s, "status": "error",
                                        "error": str(e)[:200]})
                report["status"] = "failed"
                report["summary"] = "%s adımında hata: %s" % (s, str(e)[:150])
                return report
        report["status"] = "done"
        report["summary"] = self._compose_summary(goal, ctx)
        report["elapsed"] = round(time.time() - ctx["started"], 2)
        return report

    @staticmethod
    def _compose_summary(goal, ctx):
        changes = ctx["results"].get("code", {}).get("changes", 0)
        tests = ctx["results"].get("test", {})
        t_ok = tests.get("passed", 0) if isinstance(tests, dict) else 0
        return ("Görev tamamlandı: %s — %d değişiklik, %d test geçti. "
                "Güvenlik+performans kontrolü yapıldı." % (goal[:80], changes, t_ok))


class FullAutonomousMode:
    """Tam otonom çalışma modu: Permission → Checkpoint → Approval →
    Change → Test → Commit zinciri."""

    def __init__(self, perm_fn=None, checkpoint_fn=None, approve_fn=None,
                 change_fn=None, test_fn=None, commit_fn=None, max_chain=50):
        self.perm_fn = perm_fn or (lambda op: (True, ""))
        self.checkpoint_fn = checkpoint_fn or (lambda: {})
        self.approve_fn = approve_fn or (lambda op: (True, ""))
        self.change_fn = change_fn or (lambda plan: False)
        self.test_fn = test_fn or (lambda: True)
        self.commit_fn = commit_fn or (lambda: None)
        self.max_chain = max_chain
        self.history = []

    def execute(self, plan):
        """Tek planı güvenlik zincirinden geçirerek uygula."""
        op = plan.get("op", "change")
        # 1. Permission
        ok, why = self.perm_fn(op)
        if not ok:
            return {"status": "blocked", "stage": "permission", "reason": why}
        # 2. Checkpoint
        state = self.checkpoint_fn()
        # 3. Approval
        ok, why = self.approve_fn(op)
        if not ok:
            return {"status": "blocked", "stage": "approval", "reason": why}
        # 4. Change
        try:
            changed = self.change_fn(plan)
        except Exception as e:
            return {"status": "failed", "stage": "change", "error": str(e)[:200]}
        if not changed:
            return {"status": "failed", "stage": "change", "error": "değişiklik uygulanamadı"}
        # 5. Test
        try:
            tested = self.test_fn()
        except Exception as e:
            tested = False
        if not tested:
            self._rollback(state)
            return {"status": "rollback", "stage": "test", "error": "test başarısız"}
        # 6. Commit
        try:
            self.commit_fn()
        except Exception as e:
            return {"status": "failed", "stage": "commit", "error": str(e)[:200]}
        rec = {"plan": plan.get("desc", op), "status": "committed",
               "ts": time.time()}
        self.history.append(rec)
        if len(self.history) > self.max_chain:
            del self.history[:len(self.history) - self.max_chain]
        return {"status": "committed", "chain": ["permission", "checkpoint",
                                                 "approval", "change", "test",
                                                 "commit"]}

    def _rollback(self, state):
        try:
            self.change_fn({"op": "rollback", "state": state})
        except Exception:
            pass

    def run_queue(self, plans):
        out = []
        for p in plans:
            out.append(self.execute(p))
        return out

    def status(self):
        return {"executed": len(self.history),
                "recent": self.history[-5:]}

# -*- coding: utf-8 -*-
"""
Mixium — Task Planner Engine (Aşama 9, 9A/9B/9C/9F)

- 9A TaskPlanner  : Goal -> Analysis -> Plan Steps -> Execution -> Verification
- 9B PlanStateMachine : CREATED/ANALYZING/PLANNING/EXECUTING/VERIFYING/DONE/FAILED
                        (her geçiş kayıt altında) + workspace içi cache
                        (.mixium/plans/active_plan.json -> crash sonrası resume)
- 9C ReflectionLoop : execute->observe->evaluate->repair, max 3 repair cycle
- 9F ToolPlanner    : plan adımına göre tool sırası ÖNERİR (çağırmaz)

Bu modül MIXIUM'A BAĞIMLI DEĞİLDİR (mixium_new import etmez).
"""

import json
import threading
import time
import uuid
from pathlib import Path

PLAN_STATES = ("CREATED", "ANALYZING", "PLANNING", "EXECUTING",
               "VERIFYING", "DONE", "FAILED")
STEP_TYPES = ("inspect", "search", "edit", "create", "test", "verify")
STEP_STATUS = ("pending", "running", "completed", "failed", "skipped")


class Plan:
    """9A plan modeli: {id, goal, steps[], current_step, completed, state, log}."""

    def __init__(self, goal="", steps=None, pid=None):
        self.id = pid or uuid.uuid4().hex[:10]
        self.goal = goal
        self.steps = steps or []
        self.current_step = 0
        self.completed = False
        self.state = "CREATED"
        self.log = []
        self.repair_count = 0
        self.created_at = time.time()

    def to_dict(self):
        return {
            "id": self.id, "goal": self.goal, "steps": self.steps,
            "current_step": self.current_step, "completed": self.completed,
            "state": self.state, "log": self.log,
            "repair_count": self.repair_count, "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, d):
        p = cls(goal=d.get("goal", ""), steps=d.get("steps", []),
                pid=d.get("id"))
        p.current_step = d.get("current_step", 0)
        p.completed = bool(d.get("completed", False))
        p.state = d.get("state", "CREATED")
        p.log = d.get("log", [])
        p.repair_count = d.get("repair_count", 0)
        p.created_at = d.get("created_at", time.time())
        return p


class PlanStateMachine:
    """9B: durum geçişleri + kayıt (crash sonrası incelenebilir)."""

    def __init__(self):
        self.transitions = []   # [(from, to, ts)]

    def transition(self, plan, new_state):
        if new_state not in PLAN_STATES:
            return False
        old = plan.state
        if old == new_state:
            return False
        plan.state = new_state
        plan.log.append({"from": old, "to": new_state, "ts": time.time()})
        self.transitions.append((old, new_state, time.time()))
        return True

    def history(self):
        return [{"from": f, "to": t, "ts": ts} for f, t, ts in self.transitions]


class TaskPlanner:
    """9A/9B: plan oluştur, kaydet, resume, adım yönetimi."""

    def __init__(self, root="."):
        self.root = Path(root).expanduser().resolve()
        self.plans_dir = self.root / ".mixium" / "plans"
        self.active_path = self.plans_dir / "active_plan.json"
        self.sm = PlanStateMachine()
        self._lock = threading.Lock()

    def _allowed(self):
        """plans_dir workspace (root) içinde mi? (fail-closed)."""
        try:
            d = self.plans_dir.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def create_plan(self, goal, steps):
        """steps: [str] veya [{'description','type','dependencies'}]."""
        with self._lock:
            plan = Plan(goal=goal)
            for i, s in enumerate(steps or []):
                if isinstance(s, str):
                    s = {"description": s, "type": "inspect"}
                typ = s.get("type", "inspect")
                if typ not in STEP_TYPES:
                    typ = "inspect"
                plan.steps.append({
                    "id": i + 1,
                    "description": str(s.get("description", "")).strip(),
                    "type": typ,
                    "status": "pending",
                    "dependencies": list(s.get("dependencies") or []),
                })
            self.sm.transition(plan, "PLANNING")
            self.save_plan(plan)
            return plan

    def save_plan(self, plan):
        if not self._allowed():
            return False
        try:
            self.plans_dir.mkdir(parents=True, exist_ok=True)
            self.active_path.write_text(
                json.dumps(plan.to_dict(), ensure_ascii=False, indent=2),
                "utf-8")
            return True
        except Exception:
            return False

    def load_active(self):
        try:
            if self.active_path.exists():
                return Plan.from_dict(json.loads(
                    self.active_path.read_text("utf-8")))
        except Exception:
            return None
        return None

    def resume(self):
        """Crash sonrası devam: aktif planı yükle."""
        return self.load_active()

    def current(self, plan):
        if plan.completed:
            return None
        for st in plan.steps:
            if st["status"] in ("pending", "running", "failed"):
                return st
        return None

    def advance(self, plan, status="completed", step_id=None):
        """Mevcut adımı işaretle ve current_step'i ilerlet."""
        cur = self.current(plan)
        if cur is None:
            return None
        if step_id is not None:
            cur = next((s for s in plan.steps if s["id"] == step_id), cur)
        cur["status"] = status
        plan.current_step = cur["id"]
        plan.completed = all(s["status"] in ("completed", "skipped")
                             for s in plan.steps)
        if plan.completed:
            self.sm.transition(plan, "DONE")
        self.save_plan(plan)
        return cur

    def status_text(self, plan):
        if plan is None:
            return "aktif plan yok (plan_create ile oluştur)"
        lines = [
            "PLAN #%s  [%s]" % (plan.id, plan.state),
            "hedef: %s" % plan.goal,
            "repair: %d/3" % plan.repair_count,
        ]
        for st in plan.steps:
            mark = {"pending": " ", "running": ">", "completed": "✓",
                    "failed": "✗", "skipped": "-"}.get(st["status"], " ")
            lines.append("  %s [%s] %s (%s)" % (
                mark, st["status"], st["description"], st["type"]))
        return "\n".join(lines)


class ReflectionLoop:
    """9C: execute->observe->evaluate->repair. Maksimum 3 repair cycle."""

    def __init__(self, max_cycles=3):
        self.max_cycles = max_cycles
        self.cycles = 0
        self.history = []

    def register_repair(self):
        """Bir repair döngüsü kaydet; limit aşıldıysa False (sonsuz loop yasak)."""
        if self.cycles >= self.max_cycles:
            return False
        self.cycles += 1
        self.history.append("repair")
        return True

    def reset(self):
        self.cycles = 0
        self.history = []

    def exhausted(self):
        return self.cycles >= self.max_cycles


class ToolPlanner:
    """9F: plan adımı tipine göre tool sırası önerir (araç ÇAĞIRMAZ)."""

    SUGGEST = {
        "inspect": ["read", "glob", "tree"],
        "search": ["grep", "code_search", "tool_search"],
        "edit": ["read", "edit"],
        "create": ["write"],
        "test": ["test_status", "bash"],
        "verify": ["test_status", "lsp_diagnostics"],
    }

    def suggest(self, steps):
        """steps: [{'type':...}] veya ['inspect', ...] -> [tool_adı...] (sıralı, tekrarsız)."""
        order, seen = [], set()
        for s in steps or []:
            t = s.get("type") if isinstance(s, dict) else s
            for tool in self.SUGGEST.get(t, []):
                if tool not in seen:
                    seen.add(tool)
                    order.append(tool)
        return order

    def suggest_text(self, goal, steps):
        tools = self.suggest(steps)
        if not tools:
            return "'%s' için tool önerisi yok" % goal
        return "\n".join("%d %s" % (i + 1, t) for i, t in enumerate(tools))

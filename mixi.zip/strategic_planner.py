# -*- coding: utf-8 -*-
"""Mixium A20 — strategic planner; suggestions only."""
import time
import uuid

class StrategicPlanner:
    def __init__(self, goals=None, chief=None, experiences=None):
        self.goals, self.chief, self.experiences = goals, chief, experiences
        self.history = []
    def plan(self, goal_id=None, horizon=4):
        goals = self.goals.list_goals() if self.goals else []
        goal = next((g for g in goals if not goal_id or g['id'] == goal_id), None)
        if not goal:
            return {"id": "strategy_" + uuid.uuid4().hex[:8], "status": "no_goal", "steps": [], "risks": ["aktif hedef yok"]}
        milestones = goal.get('milestones', [])
        steps = []
        for i, m in enumerate(milestones[:max(1, int(horizon))], 1):
            steps.append({"period": i, "title": m.get('title', 'Milestone'), "action": "Milestone'u çalış ve ilerlemeyi güncelle.", "status": m.get('status', 'pending')})
        if not steps:
            steps = [{"period": i, "title": x, "action": "Küçük, ölçülebilir bir adım tanımla.", "status": "pending"} for i, x in enumerate(("Analiz", "Uygulama", "Test", "Review")[:max(1, int(horizon))], 1)]
        result = {"id": "strategy_" + uuid.uuid4().hex[:8], "goal": goal, "steps": steps, "progress": goal.get('progress', 0), "risks": [] if goal.get('progress', 0) >= 0 else ["ilerleme verisi eksik"], "created": time.time()}
        self.history.append(result); self.history = self.history[-50:]
        return result
    def status(self): return {"plans": self.history[-20:], "count": len(self.history)}

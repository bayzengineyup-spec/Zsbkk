# -*- coding: utf-8 -*-
"""
Mixium — AI Research Brain (Aşama 14C)

DNA modeli arka planda sürekli araştırma yapabilir; ama "her şeyi indirmek"
DEĞİL. Kaliteli bilgi filtreleme: Source Quality + Relevance + Freshness.
Eşik üstü kaynaklar DNAStore'a yazılır (research kategorisi).

MIXIUM'a bağımlı değildir; research_fn (ResearchAgent.research) enjekte edilir.
"""

import time

QUALITY_DOMAINS = ("docs.", "github.com", "wikipedia.org", "stackoverflow.com",
                   ".edu", ".gov", "official", "readthedocs")


class ResearchBrain:
    def __init__(self, root=".", store=None, research_fn=None):
        self.root = root
        self.store = store
        self.research_fn = research_fn
        self._last = None

    def score_source(self, source, topic):
        """{quality, relevance, freshness, total} — deterministik skorlama."""
        source = source or {}
        url = str(source.get("url", "")).lower()
        title = str(source.get("title", "")).lower()
        snippet = str(source.get("snippet", "")).lower()
        topic_l = (topic or "").lower()

        quality = 50
        for dom in QUALITY_DOMAINS:
            if dom in url:
                quality = 90
                break

        relevance = 50
        for kw in topic_l.split():
            if kw and (kw in title or kw in snippet):
                relevance = min(100, relevance + 25)

        freshness = 50
        ts = source.get("ts")
        if ts:
            try:
                age_days = (time.time() - float(ts)) / 86400.0
                freshness = max(0, 100 - int(age_days * 5))
            except Exception:
                freshness = 50

        total = int(0.5 * quality + 0.3 * relevance + 0.2 * freshness)
        return {"quality": quality, "relevance": relevance,
                "freshness": freshness, "total": total}

    def research_once(self, topic, min_score=60):
        """Bir araştırma turu; eşik üstü kaynaklar store'a yazılır."""
        if self.research_fn is None:
            return {"ok": False, "error": "research_fn bağlı değil"}
        r = self.research_fn(topic) or {}
        stored = []
        for s in (r.get("sources") or []):
            if not isinstance(s, dict):
                continue
            sc = self.score_source(s, topic)
            if sc["total"] >= min_score and self.store is not None:
                self.store.add(
                    "research",
                    "Kaynak: %s — %s" % (s.get("url", ""),
                                         str(s.get("snippet", ""))[:500]),
                    source=s.get("url", ""), confidence=sc["total"])
                stored.append({"url": s.get("url"), "score": sc["total"]})
        self._last = {"topic": topic, "ts": time.time(), "stored": stored,
                      "summary": r.get("summary", "")}
        return {"ok": True, "stored": len(stored), "sources": stored,
                "summary": r.get("summary", ""),
                "confidence": r.get("confidence", 0)}

    def last_research(self):
        return self._last

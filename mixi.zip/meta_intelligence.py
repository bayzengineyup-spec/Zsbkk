# -*- coding: utf-8 -*-
"""Mixium A22 — Meta Intelligence Layer.

Coordinates existing intelligence layers (Master Core, DNA, Expert Knowledge,
Memory, Agent Society, Model Governance, Self Management) through injected
providers. Produces a strategy only; never mutates permissions or sandbox.
"""
import json
import threading
import time
import uuid
from pathlib import Path


class MetaIntelligence:
    def __init__(self, root=".", providers=None):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "meta_intelligence.json"
        self.providers = dict(providers or {})
        self._lock = threading.RLock()
        self.log = []
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                data = json.loads(self.path.read_text(encoding="utf-8"))
                self.log = data.get("log", []) if isinstance(data, dict) else []
        except Exception:
            self.log = []

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps({"log": self.log[-200:]}, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            value = fn()
            return default if value is None else value
        except Exception:
            return default

    def strategy(self, task, intent=None):
        """Analyze a request and pick model/agent/knowledge/tool/experience."""
        task = str(task or "")
        intent = intent or "analyze"
        # model + agent from Master Core / Model Governance
        routing = self._get("routing", {}) or {}
        model_route = routing.get("model", {}) or {}
        agent_route = routing.get("agent", {}) or {}
        # knowledge sources
        sources = []
        for name in ("dna", "expert", "pattern", "research", "personal"):
            content = self._get(name)
            if content:
                sources.append(name)
        # past experience
        experience = self._get("experience", {}) or {}
        similar = []
        for rec in experience.get("recent", []) or []:
            if isinstance(rec, dict):
                similar.append(rec.get("pattern") or rec.get("action") or "")
        similar = [s for s in similar if s][:5]
        # tools (read-only suggestions)
        tools = self._get("tools", []) or []
        tools = tools[:12]
        # risk
        health = self._get("health", {}) or {}
        risk = 0
        if isinstance(health, dict):
            risk = max(0, min(100, 100 - int(health.get("system_health", 50))))
        confidence = max(0, min(100, 100 - risk))
        result = {
            "id": "meta_" + uuid.uuid4().hex[:10],
            "task": task[:500],
            "intent": intent,
            "strategy": "Önce read-only keşif; yazma/destructif adımlar onay zincirinden geçer.",
            "models": model_route,
            "agents": agent_route,
            "knowledge": sources,
            "tools": tools,
            "experience": similar,
            "risk": risk,
            "confidence": confidence,
            "time": time.time(),
        }
        with self._lock:
            self.log.append({k: v for k, v in result.items() if k != "task"})
            self._save()
        return result

    def status(self):
        with self._lock:
            return {"log": self.log[-20:], "count": len(self.log), "path": str(self.path)}

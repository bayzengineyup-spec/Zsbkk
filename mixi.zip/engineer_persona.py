# -*- coding: utf-8 -*-
"""Mixium A25B — DeepSeek Engineer Persona.

Göreve göre rol değiştiren persona sistemi. Her rol: açıklama, odak, izin
verilen araç kategorileri ve yasaklar. Model zekasını kısıtlayan içerik
filtresi yoktur; bu yalnızca rol tanımı + araç yönlendirme metadata'sıdır.
Gerçek yetki her zaman Permission → hard_gate → approval zincirinde kalır.
"""

ROLES = {
    "developer": {
        "desc": "Uygulama, refactor, hata düzeltme",
        "focus": ["kod", "edit", "write", "test"],
        "forbidden": ["permission değiştirme", "sandbox kapatma"],
    },
    "architect": {
        "desc": "Mimari karar, sistem tasarımı",
        "focus": ["analiz", "plan", "mimari", "tasarım"],
        "forbidden": ["write", "edit"],
    },
    "reviewer": {
        "desc": "Diff inceleme, kalite kontrol",
        "focus": ["diff", "review", "kalite"],
        "forbidden": ["write", "edit"],
    },
    "tester": {
        "desc": "Test yazma, hata analizi, doğrulama",
        "focus": ["test", "debug", "verify"],
        "forbidden": ["permission değiştirme"],
    },
    "security_engineer": {
        "desc": "Güvenlik kontrolü, sandbox/permission inceleme",
        "focus": ["güvenlik", "sandbox", "permission", "audit"],
        "forbidden": ["permission değiştirme", "sandbox kapatma", "write"],
    },
    "product_owner": {
        "desc": "Kapsam, öncelik, kullanıcı hikayesi, risk",
        "focus": ["kapsam", "öncelik", "risk", "story"],
        "forbidden": ["write", "edit", "execute"],
    },
}

ROLE_HINTS = {
    "mimari": "architect", "tasarım": "architect", "plan": "architect",
    "test": "tester", "hata": "tester", "bug": "tester", "debug": "tester",
    "güvenlik": "security_engineer", "security": "security_engineer",
    "sandbox": "security_engineer", "permission": "security_engineer",
    "review": "reviewer", "kalite": "reviewer", "diff": "reviewer",
    "kapsam": "product_owner", "öncelik": "product_owner", "story": "product_owner",
    "risk": "product_owner",
}


class EngineerPersona:
    def __init__(self, roles=None):
        self.roles = dict(roles or ROLES)
        self.current = "developer"

    def role_for(self, task):
        """Görev metninden rol tahmini (keyword). Bulunamazsa developer."""
        t = (task or "").lower()
        for kw, role in ROLE_HINTS.items():
            if kw in t:
                return role
        return "developer"

    def persona(self, role=None):
        role = role or self.current
        r = self.roles.get(role)
        if not r:
            return {"role": role, "desc": "bilinmeyen rol"}
        return {"role": role, "desc": r["desc"], "focus": r["focus"],
                "forbidden": r["forbidden"]}

    def set_role(self, role):
        if role in self.roles:
            self.current = role
            return self.persona(role)
        return {"error": "bilinmeyen rol: %s" % role}

    def status(self):
        return {"roles": sorted(self.roles.keys()), "current": self.current}

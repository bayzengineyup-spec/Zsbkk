# -*- coding: utf-8 -*-
"""
Mixium — B6: Autonomous Test Lab (Universal Test Engineer)

Bütün sistemi test eder: Kod (compile/unit/integration), AI (memory/DNA/
agents/orchestration), Güvenlik (sandbox/permissions/approval), Gerçek
kullanım senaryoları.

Her kontrol izole edilir: bir test başarısız olursa diğerleri çalışmaya
devam eder. MIXIUM'a bağımlı değildir — kontroller enjekte edilir.
"""

import time


class TestLab:
    """Test grupları çalıştırıcı — hepsini dener, toplu rapor verir."""

    DEFAULT_GROUPS = ("code", "ai", "security", "scenario")

    def __init__(self, root=".", checks=None):
        """
        checks: {group: [ (name, callable->bool, description) ]}
        """
        self.root = root
        self.checks = checks or {}

    def register(self, group, name, fn, desc=""):
        self.checks.setdefault(group, []).append((name, fn, desc))

    def run_group(self, group):
        results = []
        for name, fn, desc in self.checks.get(group, []):
            t0 = time.time()
            try:
                ok = bool(fn())
                results.append({"name": name, "status": "PASS" if ok else "FAIL",
                                "time": round(time.time() - t0, 2), "desc": desc})
            except Exception as e:
                results.append({"name": name, "status": "ERROR",
                                "error": str(e)[:200], "time": round(time.time() - t0, 2),
                                "desc": desc})
        return results

    def run(self, groups=None):
        groups = groups or self.DEFAULT_GROUPS
        out = {"groups": {}, "passed": 0, "failed": 0, "errors": 0, "total": 0}
        for g in groups:
            res = self.run_group(g)
            out["groups"][g] = res
            for r in res:
                out["total"] += 1
                if r["status"] == "PASS":
                    out["passed"] += 1
                elif r["status"] == "FAIL":
                    out["failed"] += 1
                else:
                    out["errors"] += 1
        out["summary"] = "%d/%d PASS" % (out["passed"], out["total"])
        return out

    # ── hazır yardımcı kontroller ─────────────────────────────────
    @staticmethod
    def check_py_compile(files):
        import py_compile
        def _fn():
            for f in files:
                try:
                    py_compile.compile(str(f), doraise=True)
                except Exception:
                    return False
            return True
        return ("py_compile", _fn, "tüm dosyalar derleniyor")

    @staticmethod
    def check_import(module_name):
        import importlib
        def _fn():
            try:
                importlib.import_module(module_name)
                return True
            except Exception:
                return False
        return ("import_%s" % module_name, _fn, "modül import edilebiliyor")

    @staticmethod
    def check_call(fn, desc=""):
        return ("call_%s" % (desc or fn.__name__), fn, desc)

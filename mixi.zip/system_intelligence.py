# -*- coding: utf-8 -*-
"""Mixium A28 — System Intelligence Core.

Takip: bütün agent durumları, worker durumları, memory kalitesi, knowledge
kalitesi, hata geçmişi, performans. Tek read-only snapshot üretir. Provider
enjeksiyonlu; hiçbir sistem değiştirilmez.
"""


class SystemIntelligenceCore:
    def __init__(self, providers=None):
        self.providers = dict(providers or {})

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn() if callable(fn) else fn
            return default if v is None else v
        except Exception:
            return default

    def snapshot(self):
        agents = self._get("agents", [])
        workers = self._get("workers", [])
        memory = self._get("memory", {})
        knowledge = self._get("knowledge", {})
        errors = self._get("errors", [])
        perf = self._get("performance", {})
        health = self._get("health", {})

        # basit zeka seviyesi hesaplama (uydurma değil, sinyallerden)
        score = 50
        signals = 0
        total = 0
        if isinstance(memory, dict) and memory.get("records") is not None:
            total += min(100, memory.get("records", 0)); signals += 1
        if isinstance(knowledge, dict) and knowledge.get("records") is not None:
            total += min(100, knowledge.get("records", 0)); signals += 1
        if isinstance(health, dict) and health.get("system_health") is not None:
            total += health.get("system_health", 50); signals += 1
        if signals:
            score = round(total / signals, 1)

        return {
            "intelligence_score": score,
            "agents": agents,
            "workers": workers,
            "memory_quality": memory,
            "knowledge_quality": knowledge,
            "error_history": errors,
            "performance": perf,
            "health": health,
        }

    def status(self):
        return self.snapshot()

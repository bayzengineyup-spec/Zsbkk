# -*- coding: utf-8 -*-
"""Mixium A22 — Advanced Reasoning Engine.

Generates alternatives, pros/cons, risk and long-term outcome estimation.
Produces an execution plan; it does not execute anything itself.
"""
import threading
import time
import uuid

DEFAULT_ALTERNATIVES = (
    "Read-only keşifle başla ve mevcut durumu doğrula",
    "Küçük, geri alınabilir (checkpoint'li) adımlarla ilerle",
    "Önce test/doğrulama çalıştır, sonra değişiklik yap",
)


class ReasoningEngine:
    def __init__(self, providers=None):
        self.providers = dict(providers or {})
        self._lock = threading.RLock()
        self.log = []

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn()
            return default if v is None else v
        except Exception:
            return default

    def reason(self, problem, alternatives=None, intent="read"):
        problem = str(problem or "").strip()
        if not problem:
            return None
        alts = list(alternatives or DEFAULT_ALTERNATIVES)
        evaluated = []
        for alt in alts:
            pros, cons = self._pros_cons(alt, problem)
            risk = self._risk(alt, intent)
            evaluated.append({"alternative": alt, "pros": pros, "cons": cons, "risk": risk})
        evaluated.sort(key=lambda x: x["risk"])
        best = evaluated[0]
        outcome = "Uzun vadede: %s" % self._long_term(best["alternative"], intent)
        plan = {"id": "reason_" + uuid.uuid4().hex[:8], "problem": problem[:800],
                "alternatives": evaluated, "best": best["alternative"], "outcome": outcome,
                "intent": intent, "created": time.time()}
        with self._lock:
            self.log.append(plan)
            self.log = self.log[-100:]
        return plan

    @staticmethod
    def _pros_cons(alt, problem):
        alt_l = alt.lower()
        if "read-only" in alt_l or "keşif" in alt_l:
            return ["Güvenli, yan etkisiz", "Mevcut durumu doğrular"], ["Doğrudan çözüm üretmez"]
        if "küçük" in alt_l or "geri alınabilir" in alt_l:
            return ["Checkpoint ile geri alınabilir", "Kademeli ilerleme"], ["Daha fazla adım gerektirir"]
        if "test" in alt_l or "doğrulama" in alt_l:
            return ["Hataları erken yakalar", "Doğrulama sağlar"], ["Önce test yazılmalı"]
        return ["Alternatif değerlendirildi"], ["Ek doğrulama gerekebilir"]

    @staticmethod
    def _risk(alt, intent):
        base = 20
        alt_l = alt.lower()
        if "read-only" in alt_l or "keşif" in alt_l:
            base = 5
        elif "küçük" in alt_l or "geri alınabilir" in alt_l:
            base = 25
        elif "test" in alt_l:
            base = 15
        if intent == "destructive":
            base = min(95, base + 55)
        elif intent == "write":
            base = min(90, base + 25)
        return base

    @staticmethod
    def _long_term(alt, intent):
        alt_l = alt.lower()
        if "read-only" in alt_l or "keşif" in alt_l:
            return "güvenilir temel kurulur; yazma adımları onay zincirinde kalır."
        if "geri alınabilir" in alt_l:
            return "kademeli ilerleme ile risk düşük tutulur; her adım doğrulanır."
        return "mevcut doğrulama akışıyla ilerlenir; sonucu ölçülür."

    def status(self):
        with self._lock:
            return {"plans": self.log[-20:], "count": len(self.log)}

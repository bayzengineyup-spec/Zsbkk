# -*- coding: utf-8 -*-
"""
Mixium — Learning Scheduler (Aşama 16A)

Arka plan öğrenme görevlerini yönetir:
    expert research / knowledge update / pattern discovery /
    user preference update / intelligence evaluation

Özellikler:
- interval (saniye) + priority (düşük sayı = yüksek öncelik)
- task queue (idempotent kayıt)
- pause/resume
- crash recovery (her görev exception → failed olarak kaydedilir, scheduler düşmez)
- AgentDaemon (Aşama 12E) ile uyumlu: run_cycle() tek tur çalıştırır,
  daemon'ın job_fn'i olarak kullanılabilir.

MIXIUM'a bağımlı değildir. Fail-closed: görev çalışırken hata olursa
state bozulmaz, failed listesine eklenir.
"""

import json
import threading
import time
import uuid
from pathlib import Path

LEARNING_TASKS = (
    "expert_research",
    "knowledge_update",
    "pattern_discovery",
    "user_preference_update",
    "intelligence_evaluation",
)


class LearningScheduler:
    def __init__(self, root=".", interval=1800, max_tasks=100):
        self.root = Path(root)
        self.dir = self.root / ".mixium" / "learning"
        self.interval = interval
        self.max_tasks = max_tasks
        self._lock = threading.RLock()
        self._paused = False
        self._state = {
            "tasks": {},      # id -> {name, priority, interval, last_run, status, error}
            "history": [],    # son çalıştırma kayıtları (max 200)
            "stats": {"runs": 0, "ok": 0, "failed": 0},
        }
        self._load()

    # ── dosya / izin ────────────────────────────────────────────────
    def _allowed(self, p):
        try:
            p = Path(p).resolve()
            root = self.root.resolve()
            return root in p.parents or p == root
        except Exception:
            return False

    def _load(self):
        try:
            if self._allowed(self.dir / "scheduler.json"):
                with open(self.dir / "scheduler.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    self._state = data
                    self._state.setdefault("tasks", {})
                    self._state.setdefault("history", [])
                    self._state.setdefault("stats", {"runs": 0, "ok": 0, "failed": 0})
        except Exception:
            pass

    def _save(self):
        try:
            if not self._allowed(self.dir):
                return False
            self.dir.mkdir(parents=True, exist_ok=True)
            tmp = self.dir / "scheduler.json.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._state, f, ensure_ascii=False, indent=1)
            tmp.replace(self.dir / "scheduler.json")
            return True
        except Exception:
            return False

    # ── görev yönetimi ──────────────────────────────────────────────
    def add_task(self, name, priority=50, interval=None):
        """Görev ekle (idempotent: aynı isim varsa günceller)."""
        if name not in LEARNING_TASKS:
            return False, "bilinmeyen görev tipi"
        with self._lock:
            tasks = self._state["tasks"]
            if len(tasks) >= self.max_tasks:
                return False, "görev limiti aşıldı"
            t = tasks.get(name)
            now = time.time()
            if t is None:
                t = {"name": name, "priority": int(priority),
                     "interval": int(interval or self.interval),
                     "last_run": 0, "status": "pending", "error": ""}
                tasks[name] = t
            else:
                t["priority"] = int(priority)
                t["interval"] = int(interval or t.get("interval") or self.interval)
            self._save()
            return True, "ok"

    def remove_task(self, name):
        with self._lock:
            if name in self._state["tasks"]:
                del self._state["tasks"][name]
                self._save()
                return True
            return False

    def pause(self):
        with self._lock:
            self._paused = True
        return True

    def resume(self):
        with self._lock:
            self._paused = False
        return True

    def is_paused(self):
        return self._paused

    # ── çalıştırma ──────────────────────────────────────────────────
    def due_tasks(self):
        """interval'i dolmuş görevleri öncelik sırasına göre döndürür."""
        now = time.time()
        out = []
        with self._lock:
            for t in self._state["tasks"].values():
                if now - t.get("last_run", 0) >= t.get("interval", self.interval):
                    out.append(t)
        out.sort(key=lambda t: t.get("priority", 50))
        return out

    def run_cycle(self, job_fn):
        """Tek tur: due görevleri çalıştır. job_fn(name) -> ok/err.

        AgentDaemon uyumlu — daemon'ın job_fn'i olarak verilebilir.
        Hata olursa görev failed işaretlenir, scheduler çökmez.
        """
        if self._paused:
            return 0
        due = self.due_tasks()
        ran = 0
        for t in due:
            name = t["name"]
            try:
                ok = job_fn(name)
                status = "ok" if ok else "failed"
                err = "" if ok else "görev False döndü"
            except Exception as e:
                status = "failed"
                err = f"{type(e).__name__}: {e}"
            with self._lock:
                t["last_run"] = time.time()
                t["status"] = status
                t["error"] = err[:200]
                self._state["stats"]["runs"] += 1
                if status == "ok":
                    self._state["stats"]["ok"] += 1
                else:
                    self._state["stats"]["failed"] += 1
                self._state["history"].append({
                    "time": time.time(), "task": name, "status": status,
                    "error": err[:200]})
                self._state["history"] = self._state["history"][-200:]
                self._state["tasks"] = {
                    k: v for k, v in self._state["tasks"].items()
                    if k in LEARNING_TASKS}
            self._save()
            ran += 1
        return ran

    def status(self):
        with self._lock:
            tasks = []
            for t in sorted(self._state["tasks"].values(),
                            key=lambda x: x.get("priority", 50)):
                tasks.append({
                    "name": t["name"], "priority": t.get("priority", 50),
                    "interval": t.get("interval", self.interval),
                    "last_run": t.get("last_run", 0),
                    "status": t.get("status", "pending"),
                    "error": t.get("error", "")[:120]})
            return {
                "paused": self._paused,
                "interval": self.interval,
                "tasks": tasks,
                "stats": dict(self._state["stats"]),
                "history": list(self._state["history"][-20:]),
            }

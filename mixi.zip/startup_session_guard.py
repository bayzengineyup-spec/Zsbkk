"""Keeps one browser session through reloads and resume."""

KEY = "mixium_active_session"

def should_create_session(storage):
    return KEY not in storage

# -*- coding: utf-8 -*-
"""Mixium A30 — Human Browser Agent (İnsan tarayıcı simülasyonu).

Browser MCP / browser_agent üzerine kurulur. Sadece sayfa açmak değil; insan
davranışı: sayfa açma, menü gezme, buton kullanma, form doldurma, yanlış
kullanım deneme, bekleme, geri dönme, tekrar deneme. Browser sağlanmazsa
fail-closed (aksiyon alınmaz, hata döner).
"""

import time


class HumanBrowserAgent:
    def __init__(self, browser=None, wait_range=(0.3, 1.2)):
        self.browser = browser  # browser_agent.BrowserAgent | mcp_browser.MCPBrowser | None
        self.wait_range = tuple(wait_range)
        self.actions = []

    def _has(self):
        return self.browser is not None

    def _call(self, method, *args, **kw):
        if not self._has():
            return {"ok": False, "error": "browser yok (fail-closed)"}
        fn = getattr(self.browser, method, None)
        if not callable(fn):
            return {"ok": False, "error": "browser %s desteklemiyor" % method}
        try:
            r = fn(*args, **kw)
            return r if isinstance(r, dict) else {"ok": True, "result": r}
        except Exception as e:
            return {"ok": False, "error": str(e)[:200]}

    def _human_wait(self):
        try:
            lo, hi = self.wait_range
            time.sleep(lo + (hi - lo) * 0.5)
        except Exception:
            time.sleep(0.5)

    def _log(self, action, result):
        self.actions.append({"action": action, "result": result, "t": time.time()})
        self.actions = self.actions[-200:]

    def open(self, url):
        self._human_wait()
        r = self._call("open", url)
        self._log("open", r)
        return r

    def navigate(self, url):
        self._human_wait()
        r = self._call("navigate", url)
        self._log("navigate", r)
        return r

    def menu(self, label):
        self._human_wait()
        r = self._call("click", label) if hasattr(self.browser, "click") else \
            {"ok": False, "error": "click desteklenmiyor"}
        self._log("menu", r)
        return r

    def click(self, selector):
        self._human_wait()
        r = self._call("click", selector)
        self._log("click", r)
        return r

    def fill(self, selector, value):
        self._human_wait()
        r = self._call("type", selector, value) if hasattr(self.browser, "type") else \
            self._call("fill", selector, value)
        self._log("fill", r)
        return r

    def wait(self, seconds=1.0):
        try:
            time.sleep(max(0.0, float(seconds)))
        except Exception:
            pass
        self._log("wait", {"ok": True})
        return {"ok": True, "waited": seconds}

    def back(self):
        self._human_wait()
        r = self._call("back")
        self._log("back", r)
        return r

    def wrong_use(self, selector="__invalid__"):
        """Yanlış kullanım denemesi: olmayan seçici / bozuk giriş."""
        self._human_wait()
        r = self._call("click", selector)
        self._log("wrong_use", r)
        return r

    def retry(self, action, *args):
        """Başarısız bir aksiyonu yeniden dene (en fazla 2 deneme)."""
        for i in range(2):
            r = getattr(self, action)(*args)
            if r and r.get("ok"):
                self._log("retry:%s" % action, r)
                return r
        self._log("retry_failed:%s" % action, {"ok": False})
        return {"ok": False, "error": "retry başarısız"}

    def session(self, script):
        """script: [ {action, arg} ] — insan davranış dizisi."""
        out = []
        for step in (script or []):
            act = str(step.get("action", "")).lower()
            fn = getattr(self, act, None)
            if callable(fn):
                r = fn(step.get("arg"))
            else:
                r = {"ok": False, "error": "bilinmeyen action: %s" % act}
            out.append({"action": act, "result": r})
        return {"steps": out, "count": len(out)}

    def status(self):
        return {"browser": bool(self._has()), "actions": len(self.actions),
                "last": self.actions[-1] if self.actions else None}

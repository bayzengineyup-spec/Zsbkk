# -*- coding: utf-8 -*-
"""
MIXIUM WEB · Yonetim Paneli arka ucu
====================================
mixiweb.py bunu import eder. WS uzerinden gelen panel mesajlarini
karsilar; sistem loglari, model dogrulama, oturum/istatistik verir.

Tasarim notu: mixium_new.py'ye HIC dokunmaz. Sadece okur.
"""

import os
import sys
import time
import json
import platform
import threading
import collections

# ── halka tampon: tum sistem loglari ────────────────────────────
_LOG_MAX = 800
_LOGS = collections.deque(maxlen=_LOG_MAX)
_LOG_LOCK = threading.Lock()
_LOG_SEQ = [0]

# panel'e canli log itmek icin kayitli WS gonderici fonksiyonlari
_SUBS = []
_SUB_LOCK = threading.Lock()

BOOT_TS = time.time()

# olay sayaclari — panel istatistikleri
STATS = {
    "runs": 0,          # baslatilan agent kosusu
    "runs_ok": 0,
    "runs_err": 0,
    "tool_calls": 0,
    "tokens_out": 0,    # tahmini (karakter/4)
    "ws_connects": 0,
    "model_switches": 0,
    "bytes_out": 0,
}


def log(level, source, msg, extra=None):
    """Sistem logu kaydeder ve abonelere canli iter.

    level : debug | info | ok | warn | error
    source: ws | agent | api | model | session | tool | http | panel
    """
    _LOG_SEQ[0] += 1
    rec = {
        "id": _LOG_SEQ[0],
        "ts": time.time(),
        "level": str(level),
        "src": str(source),
        "msg": str(msg)[:2000],
    }
    if extra:
        try:
            rec["extra"] = json.loads(json.dumps(extra, default=str))[:1] \
                if isinstance(extra, list) else json.loads(json.dumps(extra, default=str))
        except Exception:
            rec["extra"] = {"raw": str(extra)[:400]}
    with _LOG_LOCK:
        _LOGS.append(rec)
    _push(rec)
    return rec


def _push(rec):
    with _SUB_LOCK:
        subs = list(_SUBS)
    for fn in subs:
        try:
            fn({"type": "panel_log", "rec": rec})
        except Exception:
            try:
                _SUBS.remove(fn)
            except Exception:
                pass


def subscribe(fn):
    with _SUB_LOCK:
        if fn not in _SUBS:
            _SUBS.append(fn)


def unsubscribe(fn):
    with _SUB_LOCK:
        if fn in _SUBS:
            _SUBS.remove(fn)


def logs(limit=300, level=None, src=None, q=None):
    """Filtreli log listesi dondurur (en yeni sonda)."""
    with _LOG_LOCK:
        rows = list(_LOGS)
    if level and level != "all":
        order = ["debug", "info", "ok", "warn", "error"]
        if level in order:
            mn = order.index(level)
            rows = [r for r in rows
                    if r["level"] in order and order.index(r["level"]) >= mn]
    if src and src != "all":
        rows = [r for r in rows if r["src"] == src]
    if q:
        ql = q.lower()
        rows = [r for r in rows if ql in r["msg"].lower() or ql in r["src"].lower()]
    return rows[-int(limit or 300):]


def clear_logs():
    with _LOG_LOCK:
        _LOGS.clear()
    log("info", "panel", "log tamponu temizlendi")


# ── sistem bilgisi ──────────────────────────────────────────────
def _mem():
    """psutil olmadan RSS ve sistem bellegi (Linux /proc)."""
    out = {"rss_mb": None, "total_mb": None, "avail_mb": None, "pct": None}
    try:
        with open("/proc/self/statm") as f:
            pages = int(f.read().split()[1])
        out["rss_mb"] = round(pages * os.sysconf("SC_PAGE_SIZE") / 1048576, 1)
    except Exception:
        pass
    try:
        info = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, _, v = line.partition(":")
                info[k] = int(v.strip().split()[0])
        out["total_mb"] = round(info.get("MemTotal", 0) / 1024, 1)
        out["avail_mb"] = round(info.get("MemAvailable", 0) / 1024, 1)
        if out["total_mb"]:
            out["pct"] = round(100.0 * (1 - out["avail_mb"] / out["total_mb"]), 1)
    except Exception:
        pass
    return out


def _load():
    try:
        a, b, c = os.getloadavg()
        return {"1": round(a, 2), "5": round(b, 2), "15": round(c, 2),
                "cpus": os.cpu_count()}
    except Exception:
        return {"1": None, "5": None, "15": None, "cpus": os.cpu_count()}


def _disk(path="."):
    try:
        st = os.statvfs(path)
        total = st.f_blocks * st.f_frsize / 1073741824.0
        free = st.f_bavail * st.f_frsize / 1073741824.0
        return {"total_gb": round(total, 1), "free_gb": round(free, 1),
                "pct": round(100.0 * (1 - free / total), 1) if total else None}
    except Exception:
        return {}


def sysinfo(M=None, extra=None):
    """Panel 'Sistem' sekmesi verisi."""
    up = time.time() - BOOT_TS
    d = {
        "uptime_s": int(up),
        "uptime_h": "%dsa %02ddk %02dsn" % (up // 3600, (up % 3600) // 60, up % 60),
        "pid": os.getpid(),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cwd": os.getcwd(),
        "threads": threading.active_count(),
        "mem": _mem(),
        "load": _load(),
        "disk": _disk(os.getcwd()),
        "stats": dict(STATS),
        "log_count": len(_LOGS),
        "boot_ts": BOOT_TS,
    }
    if M is not None:
        d["mixium"] = _mixium_info(M)
    if extra:
        d.update(extra)
    return d


def _mixium_info(M):
    """mixium_new modulunden guvenli sekilde durum okur."""
    info = {}
    def g(name, fn, default=None):
        try:
            info[name] = fn()
        except Exception as e:
            info[name] = default
            info.setdefault("_errors", []).append("%s: %s" % (name, e))

    g("base_api",   lambda: getattr(M, "BASE_API", "?"))
    g("main_model", lambda: getattr(M, "MAIN_MODEL", "?"))
    g("fast_model", lambda: getattr(M, "FAST_MODEL", "?"))
    g("main_ai",    lambda: getattr(M, "MAIN_AI", "?"))
    g("model_count", lambda: len(getattr(M.API, "models", []) or []))
    g("perm_mode",  lambda: getattr(M.PERM, "mode", "?"))
    g("tools",      lambda: sorted(list(getattr(M, "TOOLS", {}).keys()))
                    if isinstance(getattr(M, "TOOLS", None), dict) else [])
    g("tool_count", lambda: len(getattr(M, "TOOLS", {}) or {}))
    g("conf",       lambda: {k: v for k, v in dict(getattr(M, "CONF", {})).items()
                             if "key" not in str(k).lower()
                             and "token" not in str(k).lower()
                             and "secret" not in str(k).lower()})
    g("has_token",  lambda: bool(getattr(getattr(M, "API", None), "token", None)))
    g("polling",    lambda: bool(getattr(M, "USE_POLLING", False)))
    return info


# ── model dogrulama: secilen model GERCEKTEN geliyor mu? ────────
def verify_model(M, model_id, ai_name=None, prompt=None):
    """Modele minik bir istek atar, donen cevabi ve gecen sureyi olcer.

    Panel'deki 'Modeli sina' butonu bunu cagirir. Boylece
    'model degistirdim ama gercekten degisti mi?' sorusu kanitlanir.
    """
    t0 = time.time()
    res = {"model": model_id, "ai": ai_name, "ok": False,
           "ms": 0, "reply": "", "error": None}
    try:
        if not ai_name:
            for m in (getattr(M.API, "models", []) or []):
                if isinstance(m, dict) and m.get("id") == model_id:
                    ai_name = m.get("ai_name") or getattr(M, "MAIN_AI", "claude")
                    break
        res["ai"] = ai_name
        p = prompt or ("Sadece su formatta tek satir don: MODEL=<kendi model kimligin>. "
                       "Baska hicbir sey yazma.")
        log("info", "model", "sinama basladi: %s (%s)" % (model_id, ai_name))
        out = M.API.generate(p, model_id, ai_name)
        res["reply"] = (out or "").strip()[:400]
        res["ok"] = bool(res["reply"])
    except Exception as e:
        res["error"] = str(e)[:400]
        log("error", "model", "sinama hatasi %s: %s" % (model_id, e))
    res["ms"] = int((time.time() - t0) * 1000)
    if res["ok"]:
        log("ok", "model", "sinama tamam: %s · %dms" % (model_id, res["ms"]))
    return res


def models_health(M):
    """Tum model listesini, hangisinin aktif oldugunu ozetler."""
    rows = []
    try:
        for m in (getattr(M.API, "models", []) or []):
            if not isinstance(m, dict):
                continue
            rows.append({
                "id": m.get("id", "?"),
                "ai": m.get("ai_name", ""),
                "tags": [k for k in ("vision", "tools", "fast", "reasoning")
                         if m.get(k)],
                "raw_keys": sorted([k for k in m.keys()])[:12],
            })
    except Exception as e:
        log("error", "model", "liste okunamadi: %s" % e)
    return rows


# ── oturum istatistikleri ───────────────────────────────────────
def session_stats(chat_dir):
    """Disktеki oturum dosyalarindan ozet cikarir."""
    import pathlib
    out = {"count": 0, "messages": 0, "bytes": 0, "by_model": {}, "recent": []}
    try:
        p = pathlib.Path(chat_dir)
        files = sorted(p.glob("*.json"), key=lambda f: f.stat().st_mtime,
                       reverse=True)
        out["count"] = len(files)
        for f in files:
            try:
                out["bytes"] += f.stat().st_size
                d = json.loads(f.read_text())
                msgs = d.get("messages", [])
                out["messages"] += len(msgs)
                mdl = d.get("model", "?")
                out["by_model"][mdl] = out["by_model"].get(mdl, 0) + 1
                if len(out["recent"]) < 12:
                    out["recent"].append({
                        "id": d.get("id", f.stem),
                        "title": (d.get("title") or "yeni oturum")[:44],
                        "model": mdl,
                        "n": len(msgs),
                        "mtime": f.stat().st_mtime,
                    })
            except Exception:
                continue
    except Exception as e:
        log("error", "panel", "oturum istatistigi: %s" % e)
    out["kb"] = round(out["bytes"] / 1024.0, 1)
    return out


def bump(key, n=1):
    try:
        STATS[key] = STATS.get(key, 0) + n
    except Exception:
        pass

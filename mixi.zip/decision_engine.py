# -*- coding: utf-8 -*-
"""
Mixium — Decision Intelligence Engine (Aşama 16E)

Ana modele bilgi değil KARAR DESTEĞİ verir.

Girdi:
    User DNA      (preferences / tercih listesi)
    Expert Knowledge (eşleşen uzman kayıtlar)
    Project State (health / test sonuçları)
    Task          (mevcut görev metni)

Çıktı:
    {
      recommendation: str,
      reasoning: [str],
      confidence: 0-100,
      alternatives: [str],
    }

MIXIUM'a bağımlı değildir; her kaynak fonksiyon enjekte edilir.
Fail-closed: kaynak yoksa güvenli varsayılan öneri (yazma öncesi onay).
"""

import json
import threading
import time
from pathlib import Path

# Güvenli varsayılan: yazma/destructif işlemler her zaman onay ister
SAFE_DEFAULTS = {
    "recommendation": "Önce read-only keşif yap; yazma/destructif işlemler için onay iste.",
    "reasoning": ["Permission zinciri korunur", "Yazma işlemleri approval_gate'ten geçer"],
    "confidence": 70,
    "alternatives": ["Keşif araçlarıyla başla", "Plan oluştur, sonra uygula"],
}


class DecisionEngine:
    def __init__(self, root=".", user_dna_fn=None, expert_fn=None,
                 project_fn=None):
        """user_dna_fn() -> {'preferences': [...], 'avoid': [...]} veya None
        expert_fn(task)  -> uzman kayıt listesi (expert_store.query sonucu)
        project_fn()     -> {'health_score': int, 'test_failed': int} veya None"""
        self.root = Path(root)
        self.dir = self.root / ".mixium" / "learning"
        self.user_dna_fn = user_dna_fn
        self.expert_fn = expert_fn
        self.project_fn = project_fn
        self._lock = threading.RLock()
        self._log = []

    def _allowed(self, p):
        try:
            p = Path(p).resolve()
            root = self.root.resolve()
            return root in p.parents or p == root
        except Exception:
            return False

    def _save_log(self):
        try:
            if not self._allowed(self.dir):
                return
            self.dir.mkdir(parents=True, exist_ok=True)
            with open(self.dir / "decisions.json", "w", encoding="utf-8") as f:
                json.dump(self._log[-100:], f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    # ── karar ───────────────────────────────────────────────────────
    def decide(self, task, intent="read"):
        """intent: read | write | destructive | research | test.

        Güvenli politika (fail-closed):
        - read/research/test  -> onay gerektirmez (keşif)
        - write               -> öneri + onay vurgusu
        - destructive         -> reddet (öneri: onaysız yapma)
        """
        reasoning = []
        alt = []
        conf = 50

        # 1) Kullanıcı tercihleri
        prefs = []
        avoid = []
        if self.user_dna_fn:
            try:
                ud = self.user_dna_fn() or {}
                prefs = ud.get("preferences") or []
                avoid = ud.get("avoid") or []
                if prefs:
                    reasoning.append("Kullanıcı tercihi: " + "; ".join(prefs[:3]))
            except Exception:
                pass

        # 2) Uzman bilgi
        expert_hits = []
        if self.expert_fn:
            try:
                expert_hits = self.expert_fn(task) or []
                if expert_hits:
                    top = expert_hits[0]
                    t = top.get("knowledge") or top.get("content") or ""
                    reasoning.append("Uzman kayıt: " + str(t)[:160])
            except Exception:
                pass

        # 3) Proje durumu
        health = None
        if self.project_fn:
            try:
                health = self.project_fn() or {}
                hs = health.get("health_score")
                if hs is not None:
                    reasoning.append(f"Proje sağlık skoru: {hs}/100")
            except Exception:
                pass

        # 4) intent bazlı politika
        if intent in ("write", "destructive"):
            if intent == "destructive":
                recommendation = ("Destructif işlem önerilmez: "
                                  "önce read-only analiz + onay şartı.")
                conf = 85
                alt.append("Değişikliği geri alınabilir (checkpoint) yap")
            else:
                recommendation = ("Yazma işlemi yapılabilir ancak "
                                  "approval_gate + permission zincirinden geçmeli.")
                conf = 75
                alt.append("Önce diff üret, sonra uygula")
                alt.append("Değişikliği change_tracker'a kaydet")
        elif intent in ("research", "test"):
            recommendation = "Keşif/test işlemi güvenli: read-only araçlarla ilerle."
            conf = 60
            alt.append("Sonuçları expert store'a kaydet (doğrulayıcıdan geçerek)")
        else:  # read
            recommendation = "Read-only keşif ile başla; yazma gerekiyorsa onay al."
            conf = 55
            alt.append("Uzman bilgiyi önce sorgula")

        # avoid tercihlerine uy
        for a in avoid:
            if a and a.lower() in task.lower():
                recommendation += " (kullanıcının kaçındığı: " + str(a) + ")"
                break

        # health düşükse test öner
        if health and (health.get("test_failed") or 0) > 0:
            alt.append("Önce test_status ile mevcut hataları özetle")
            conf = min(conf, 40)

        result = {
            "task": str(task)[:300],
            "intent": intent,
            "recommendation": recommendation,
            "reasoning": reasoning[:6],
            "confidence": int(conf),
            "alternatives": alt[:4],
        }
        with self._lock:
            self._log.append({"time": time.time(), **result})
            self._log = self._log[-100:]
            self._save_log()
        return result

    def recent(self, limit=20):
        with self._lock:
            return list(self._log[-limit:])

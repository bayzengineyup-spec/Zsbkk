# -*- coding: utf-8 -*-
"""
Mixium — Agent Runtime (Aşama 10, 10A/10D/10E/10F)

- 10A Agent yaşam döngüsü: CREATED/RUNNING/WAITING/COMPLETED/FAILED/CANCELLED
- 10D Mesaj sistemi: {from, to, type, payload}; tipler REQUEST/RESULT/ERROR/STATUS
- 10E Paralel çalıştırma: ThreadPoolExecutor (max 4 worker) + crash izolasyonu
- 10F Memory isolation: her agent kendi context + task_history tutar

Bu modül MIXIUM'A BAĞIMLI DEĞİLDİR (mixium_new import etmez).
"""

import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

AGENT_STATES = ("CREATED", "RUNNING", "WAITING", "COMPLETED", "FAILED", "CANCELLED")
MSG_TYPES = ("REQUEST", "RESULT", "ERROR", "STATUS")

DEFAULT_MAX_WORKERS = 4
DEFAULT_MAX_AGENTS = 8


class Agent:
    """10A: tek bir ajanın state modeli."""

    def __init__(self, role, goal, agent_id=None, context=None, tools=None):
        self.id = agent_id or uuid.uuid4().hex[:10]
        self.role = role
        self.goal = goal
        self.status = "CREATED"
        self.context = dict(context or {})     # 10F: kısa süreli context
        self.tools = list(tools or [])         # role allowlist
        self.result = None
        self.errors = []
        self.task_history = []                 # 10F: kendi task geçmişi
        self.created_at = time.time()
        self.started_at = None
        self.finished_at = None

    def to_dict(self):
        return {
            "id": self.id, "role": self.role, "goal": self.goal,
            "status": self.status, "context": self.context,
            "tools": self.tools, "result": self.result,
            "errors": self.errors, "task_history": self.task_history,
            "created_at": self.created_at,
        }


class Message:
    """10D: ajanlar arası mesaj."""

    def __init__(self, sender, receiver, mtype, payload):
        self.sender = sender
        self.receiver = receiver
        self.type = mtype if mtype in MSG_TYPES else "STATUS"
        self.payload = payload
        self.ts = time.time()

    def to_dict(self):
        return {"from": self.sender, "to": self.receiver,
                "type": self.type, "payload": self.payload, "ts": self.ts}


class AgentRuntime:
    """Ajanları yönetir: spawn, thread pool, mesaj kuyruğu, crash izolasyonu."""

    def __init__(self, max_workers=DEFAULT_MAX_WORKERS, max_agents=DEFAULT_MAX_AGENTS):
        self.agents = {}          # id -> Agent
        self.messages = []        # Message log (10D)
        self.max_workers = max_workers
        self.max_agents = max_agents
        self._lock = threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=max_workers)

    # ---- mesaj sistemi (10D) ----
    def send_message(self, sender, receiver, mtype, payload):
        msg = Message(sender, receiver, mtype, payload)
        with self._lock:
            self.messages.append(msg)
        return msg

    def messages_for(self, agent_id):
        with self._lock:
            return [m.to_dict() for m in self.messages
                    if m.receiver == agent_id or m.sender == agent_id]

    # ---- spawn (10A + 10E) ----
    def spawn(self, role, goal, runner, context=None, tools=None):
        """Yeni ajan oluştur ve thread pool'da çalıştır.

        runner(agent) -> result  (exception fırlatırsa FAILED + crash izolasyonu)
        Sonsuz spawn yasak: max_agents aşılınca None döner.
        """
        with self._lock:
            if len(self.agents) >= self.max_agents:
                return None
            agent = Agent(role, goal, context=context, tools=tools)
            self.agents[agent.id] = agent
        self.send_message("orchestrator", agent.id, "REQUEST",
                          {"goal": goal, "role": role})
        self._pool.submit(self._run, agent, runner)
        return agent

    def _run(self, agent, runner):
        """Crash izolasyonu: runner exception'ı runtime'ı düşürmez."""
        agent.status = "RUNNING"
        agent.started_at = time.time()
        self.send_message(agent.id, "orchestrator", "STATUS",
                          {"status": "RUNNING"})
        try:
            result = runner(agent)
            agent.result = result
            agent.status = "COMPLETED"
            self.send_message(agent.id, "orchestrator", "RESULT",
                              {"result": result})
        except Exception as e:  # noqa: BLE001 — crash izolasyonu
            agent.errors.append("%s: %s" % (type(e).__name__, e))
            agent.status = "FAILED"
            self.send_message(agent.id, "orchestrator", "ERROR",
                              {"error": str(e)})
        finally:
            agent.finished_at = time.time()

    def get(self, agent_id):
        return self.agents.get(agent_id)

    def list_agents(self):
        with self._lock:
            return [a.to_dict() for a in self.agents.values()]

    def wait_all(self, timeout=None):
        """Tüm ajanların bitmesini bekle (thread pool'u kapatır)."""
        self._pool.shutdown(wait=True)
        return self.list_agents()

    def summary(self):
        rows = []
        for a in self.agents.values():
            rows.append("%s [%s] %s: %s" % (
                a.role, a.status, a.id[:8], (a.goal or "")[:40]))
        return "\n".join(rows) if rows else "ajan yok"

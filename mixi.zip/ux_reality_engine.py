# -*- coding: utf-8 -*-
"""Mixium A27 — Human Experience Tester (UX Reality Engine).

İnsan gibi değerlendirir: yeni kullanıcı anlayabilir mi, buton isimleri
mantıklı mı, akış karışıyor mu, hata mesajları anlaşılır mı, kullanıcı nerede
takılır. UI metadata'sı enjekte edilir (panel/buton/akış); yoksa boş audit.
"""


class UXRealityEngine:
    def __init__(self, ui_meta=None):
        self.ui_meta = ui_meta or {}
        self.audits = []

    def audit(self, ui_meta=None):
        meta = ui_meta or self.ui_meta
        findings = []
        buttons = meta.get("buttons", [])
        pages = meta.get("pages", [])
        flows = meta.get("flows", [])
        errors = meta.get("error_messages", [])

        # buton isimleri
        for b in buttons:
            name = str(b)
            if len(name) < 2:
                findings.append({"type": "button_label", "severity": "medium",
                                 "message": "buton adı çok kısa: %r" % name})
            if any(w in name.lower() for w in ("ok", "click", "button", "submit")):
                findings.append({"type": "button_label", "severity": "low",
                                 "message": "belirsiz buton adı: %s" % name})

        # akış
        if len(flows) == 0 and buttons:
            findings.append({"type": "flow", "severity": "medium",
                             "message": "akış tanımı eksik; kullanıcı yönlendirmesi net değil"})

        # hata mesajları
        for e in errors:
            if "hata" not in str(e).lower() and "error" not in str(e).lower():
                findings.append({"type": "error_message", "severity": "low",
                                 "message": "hata mesajı aksiyon önerisi içermiyor: %s" % e})

        # yeni kullanıcı
        if not meta.get("onboarding"):
            findings.append({"type": "onboarding", "severity": "info",
                             "message": "yeni kullanıcı için yönlendirme/yardım yok"})

        score = max(0, 100 - sum(3 if f["severity"] == "medium" else 1 for f in findings))
        rec = {"findings": findings, "ux_score": score,
               "summary": "%d bulgu" % len(findings)}
        self.audits.append(rec)
        return rec

    def status(self):
        return {"audits": len(self.audits), "last": self.audits[-1] if self.audits else None}

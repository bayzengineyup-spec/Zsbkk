# -*- coding: utf-8 -*-
"""Mixium A24E — Autonomous Bug Hunter + A24F Self Repair Connector.

Döngü: OBSERVE → TEST → SORUN BUL → KÖK SEBEP → FIX PLANI → CHECKPOINT →
DÜZELTME → TEST → DOĞRULA. Bulunan hata güvenli ise düzeltilir, değilse
ayrıntılı kayıt oluşturulur. Permission/sandbox/approval DEĞİŞTİRİLEMEZ.

Mevcut `self_repair.SelfRepairEngine` (B7) ve `debug_adapter.DebugAdapter`
(A23) bağlanır; `change_tracker` benzeri on_change kaydı desteklenir.
"""

import time

MAX_FIX_CYCLES = 3


class BugHunter:
    def __init__(self, test_fn, fix_fn=None, analyze_fn=None, repair_engine=None,
                 on_change=None, safe=True):
        self.test_fn = test_fn
        self.fix_fn = fix_fn or (lambda cause, i: {"ok": False, "diff": ""})
        self.analyze_fn = analyze_fn or (lambda test: {"cause": "bilinmeyen"})
        self.repair_engine = repair_engine
        self.on_change = on_change or (lambda rec: None)
        self.safe = safe  # safe=False ise fix uygulanmaz, sadece raporlanır
        self.findings = []

    def _run_test(self):
        try:
            return self.test_fn()
        except Exception as e:
            return {"status": "ERROR", "error": str(e)[:200]}

    def hunt(self, max_cycles=MAX_FIX_CYCLES):
        """Tek döngü: test → analiz → (güvenli ise) fix → doğrula."""
        report = {"problem": None, "fixed": False, "cycles": 0,
                  "findings": [], "history": []}
        for i in range(max_cycles):
            report["cycles"] = i + 1
            test = self._run_test()
            if isinstance(test, dict) and test.get("status") in ("OK", "PASS"):
                # test zaten geçiyor → sorun yok
                report["history"].append({"cycle": i + 1, "status": "clean"})
                break
            cause = self.analyze_fn(test or {})
            finding = {"cycle": i + 1, "cause": cause.get("cause", "bilinmeyen"),
                       "test": test, "timestamp": time.time()}
            report["findings"].append(finding)
            report["problem"] = cause.get("cause", "test hatası")
            if not self.safe:
                # güvenli değil → sadece kayıt, düzeltme yok
                finding["status"] = "reported_only"
                self.findings.append(finding)
                report["history"].append({"cycle": i + 1, "status": "reported_only"})
                break
            # güvenli fix dene
            try:
                applied = self.fix_fn(cause, i)
            except Exception as e:
                applied = {"ok": False, "error": str(e)[:200]}
            if not (applied and applied.get("ok")):
                report["history"].append({"cycle": i + 1, "status": "fix_failed"})
                continue
            # doğrula
            verify = self._run_test()
            ok = isinstance(verify, dict) and verify.get("status") in ("OK", "PASS")
            if ok:
                report["fixed"] = True
                finding["status"] = "fixed"
                report["history"].append({"cycle": i + 1, "status": "fixed"})
            else:
                finding["status"] = "unverified"
                report["history"].append({"cycle": i + 1, "status": "unverified"})
            self.findings.append(finding)
            try:
                self.on_change(finding)
            except Exception:
                pass
            break
        return report

    def status(self):
        return {"findings": len(self.findings), "last": self.findings[-5:]}

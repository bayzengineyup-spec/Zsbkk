"""Keeps browser session stable across reload/background resume."""

def needs_first_session(storage):
    return not storage.get('mixium_initialized')

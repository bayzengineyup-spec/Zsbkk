# -*- coding: utf-8 -*-
"""Mixium A26 — Senior Engineer Brain.

Kod yazmadan önce mimari düşünme, mevcut kodu anlama, risk/performans/güvenlik/
uzun vadeli bakım analizi ve alternatif çözüm üretme. Döngü:
ANALYZE → UNDERSTAND → DESIGN → IMPLEMENT → TEST → REVIEW → IMPROVE.

Model zekasını kısıtlamaz; yalnızca yapılandırılmış karar/analiz çıktısı üretir.
Güvenlik zinciri (Permission/hard_gate/approval) gerçek aksiyonda kalır.
"""


class SeniorEngineer:
    def __init__(self, reviewer=None, code_quality_fn=None):
        self.reviewer = reviewer          # advanced_code_review.AdvancedCodeReview
        self.code_quality_fn = code_quality_fn  # () -> {overall, scores}

    def _phase(self, name, ok=True, **kw):
        rec = {"phase": name, "ok": bool(ok)}
        rec.update(kw)
        return rec

    def analyze(self, task, code=None):
        """Görev + opsiyonel kod için senior karar/analiz paketi üretir."""
        out = {"task": str(task)[:500], "phases": []}
        # ANALYZE — risk/güvenlik/performans anahtar kelimeleri
        t = (task or "").lower()
        risks = []
        if any(k in t for k in ("sil", "delete", "reset", "drop", "rm ")):
            risks.append("destructive işlem içeriyor")
        if any(k in t for k in ("auth", "token", "password", "secret", "şifre")):
            risks.append("güvenlik/hassas veri kapsamı")
        if any(k in t for k in ("performans", "yavaş", "optimize", "büyük")):
            risks.append("performans hassasiyeti")
        out["phases"].append(self._phase("analyze", ok=True,
            risks=risks or ["belirgin risk yok"]))

        # UNDERSTAND
        lines = (code or "").splitlines()
        classes = sum(1 for l in lines if l.strip().startswith("class "))
        funcs = sum(1 for l in lines if l.strip().startswith(("def ", "async def ")))
        out["phases"].append(self._phase("understand", ok=True,
            code_lines=len(lines), classes=classes, functions=funcs))

        # DESIGN
        alt = []
        if classes and funcs:
            alt.append("modüler yapı korunabilir; etki alanını sınırla")
        if funcs > 10:
            alt.append("büyük modül — sorumluluk ayrımı düşün")
        out["phases"].append(self._phase("design", ok=True,
            alternatives=alt or ["mevcut yapı korunarak minimal değişiklik"]))

        # IMPLEMENT — öneri (gerçek değişiklik burada yapılmaz)
        out["phases"].append(self._phase("implement", ok=True,
            note="gerçek edit CodeEditor + Permission zincirinden geçer"))

        # TEST
        out["phases"].append(self._phase("test", ok=True,
            note="test_status / test_lab ile doğrula"))

        # REVIEW — code review (varsa)
        review = None
        if self.reviewer is not None and code:
            try:
                review = self.reviewer.review(code)
            except Exception:
                review = None
        out["phases"].append(self._phase("review", ok=bool(review), review=review))

        # IMPROVE
        cq = None
        if self.code_quality_fn is not None:
            try:
                cq = self.code_quality_fn()
            except Exception:
                cq = None
        out["phases"].append(self._phase("improve", ok=True, code_quality=cq))
        out["risk_level"] = "high" if risks else "low"
        return out

    def status(self):
        return {"reviewer": self.reviewer is not None,
                "code_quality": self.code_quality_fn is not None}

# -*- coding: utf-8 -*-
"""
Mixium — Expert Knowledge Engine (Aşama 15A)

Uzman seviyesinde bilgileri kategorize eder:
    software_architecture / advanced_coding / security / ai_research /
    system_design / debugging / performance / open_source_patterns

Kayıt: {id, knowledge, source, domain, quality_score, confidence, created, version}.
Semantic retrieval: episodic_memory.embed + cosine. Kaynak güvenilirliği zorunlu
(knowledge_validator ile). MIXIUM'a bağımlı değildir.
"""

import json
import threading
import time
import uuid
from pathlib import Path

from episodic_memory import embed, cosine

CATEGORIES = ("software_architecture", "advanced_coding", "security",
              "ai_research", "system_design", "debugging", "performance",
              "open_source_patterns")


class ExpertKnowledgeStore:
    def __init__(self, root="."):
        self.root = Path(root).expanduser().resolve()
        self.expert_dir = self.root / ".dna" / "expert"
        self.records = {c: [] for c in CATEGORIES}
        self._lock = threading.Lock()
        self._load()

    def _allowed(self, p):
        try:
            d = p.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def _cat_path(self, category):
        return self.expert_dir / (category + ".json")

    def _load(self):
        self.records = {c: [] for c in CATEGORIES}
        if not self.expert_dir.exists():
            return
        for c in CATEGORIES:
            p = self._cat_path(c)
            try:
                if p.exists():
                    data = json.loads(p.read_text("utf-8"))
                    self.records[c] = data if isinstance(data, list) else []
            except Exception:
                self.records[c] = []

    def _save_cat(self, category):
        if not self._allowed(self._cat_path(category)):
            return
        try:
            self.expert_dir.mkdir(parents=True, exist_ok=True)
            self._cat_path(category).write_text(
                json.dumps(self.records.get(category, []), ensure_ascii=False),
                "utf-8")
        except Exception:
            pass

    def add(self, knowledge, domain, source="", quality_score=50, confidence=50):
        domain = domain if domain in CATEGORIES else "advanced_coding"
        knowledge = str(knowledge)[:8000]
        with self._lock:
            rec = {"id": uuid.uuid4().hex[:8], "knowledge": knowledge,
                   "source": str(source)[:300], "domain": domain,
                   "quality_score": max(0, min(100, int(quality_score))),
                   "confidence": max(0, min(100, int(confidence))),
                   "created": time.time(), "version": 1,
                   "embedding": [[int(i), float(x)]
                                 for i, x in embed(knowledge).items()]}
            self.records[domain].append(rec)
            self._save_cat(domain)
            return rec

    def similarity(self, text, top_k=5):
        """(score, record) çiftleri — validator için."""
        qv = embed(text)
        scored = []
        with self._lock:
            for c in CATEGORIES:
                for r in self.records.get(c, []):
                    e = {int(i): float(x) for i, x in (r.get("embedding") or [])}
                    scored.append((cosine(qv, e), r))
        scored.sort(key=lambda x: x[0], reverse=True)
        return scored[:max(1, min(50, top_k))]

    def query(self, text, top_k=5, domains=None, min_confidence=0):
        qv = embed(text)
        cats = [d for d in (domains or []) if d in CATEGORIES] or list(CATEGORIES)
        scored = []
        with self._lock:
            for c in cats:
                for r in self.records.get(c, []):
                    if r.get("confidence", 0) < min_confidence:
                        continue
                    e = {int(i): float(x) for i, x in (r.get("embedding") or [])}
                    scored.append((cosine(qv, e), r))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [r for s, r in scored[:max(1, min(50, top_k))] if s > 0]

    def rollback(self, record_id):
        with self._lock:
            for c in list(self.records):
                before = len(self.records[c])
                self.records[c] = [r for r in self.records[c]
                                   if r.get("id") != record_id]
                if len(self.records[c]) != before:
                    self._save_cat(c)
                    return True
        return False

    def count(self):
        return sum(len(v) for v in self.records.values())

    def categories(self):
        return {c: len(self.records.get(c, [])) for c in CATEGORIES}

    def recent(self, limit=20):
        allr = [r for v in self.records.values() for r in v]
        allr.sort(key=lambda r: r.get("created", 0), reverse=True)
        return allr[:limit]

    def context_block(self, text, top_k=5, min_confidence=40):
        hits = self.query(text, top_k=top_k, min_confidence=min_confidence)
        if not hits:
            return ""
        lines = ["[EXPERT BAĞLAM]"]
        for r in hits:
            lines.append("- [%s] %s" % (r["domain"], r["knowledge"][:200]))
        return "\n".join(lines)

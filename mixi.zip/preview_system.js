// Mixium Live Preview + File Actions
window.MixiumPreview = {
  supported(name='') { return /\.(html?|htm|svg|md|css|js)$/i.test(name); },
  open(file, content) {
    const panel=document.createElement('iframe');
    panel.className='mixium-preview-frame';
    panel.srcdoc = content;
    document.body.appendChild(panel);
    return panel;
  }
};

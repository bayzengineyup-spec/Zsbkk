# -*- coding: utf-8 -*-
"""Mixium A23 — Knowledge Consolidator.

Merges DNA, Memory, Expert Knowledge, World Model and Failure Intelligence.
Reduces duplicates, finds contradictions and surfaces high-quality knowledge.
"""
import threading
import time
import uuid


class KnowledgeConsolidator:
    def __init__(self, providers=None, max_entries=500):
        self.providers = dict(providers or {})
        self.max_entries = max(1, int(max_entries))
        self._lock = threading.RLock()
        self.entries = []
        self.contradictions = []

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn()
            return default if v is None else v
        except Exception:
            return default

    def _collect(self):
        entries = []
        for source in ("dna", "memory", "expert", "world", "failure"):
            data = self._get(source)
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        entries.append({"source": source, "text": str(item.get("content") or item.get("knowledge") or item.get("text") or item.get("prevention") or "")[:400], "quality": float(item.get("confidence", item.get("count", 50)) or 50)})
                    elif isinstance(item, str):
                        entries.append({"source": source, "text": item[:400], "quality": 50.0})
        return [e for e in entries if e["text"].strip()]

    def consolidate(self):
        """Merge, dedupe and detect contradictions."""
        raw = self._collect()
        with self._lock:
            # dedupe by normalized text
            seen, merged = set(), []
            for e in raw:
                norm = e["text"].lower().strip()
                if norm in seen:
                    continue
                seen.add(norm)
                merged.append(e)
            self.entries = merged[-self.max_entries:]
            # contradiction detection: conflicting keywords in same topic
            contradictions = []
            for i in range(len(self.entries)):
                for j in range(i + 1, len(self.entries)):
                    a, b = self.entries[i], self.entries[j]
                    if self._conflict(a["text"], b["text"]):
                        contradictions.append({"a": a, "b": b, "topic": self._topic(a["text"])})
            self.contradictions = contradictions[-50:]
        return {"entries": len(self.entries), "deduped": len(raw) - len(self.entries),
                "contradictions": len(self.contradictions)}

    @staticmethod
    def _conflict(a, b):
        a_l, b_l = a.lower(), b.lower()
        # simple negation-based conflict heuristic
        pairs = (("kullan", "kullanma"), ("öner", "önerme"), ("yap", "yapma"),
                 ("destekle", "destekleme"), ("enable", "disable"), ("use", "avoid"))
        for pos, neg in pairs:
            if pos in a_l and neg in b_l:
                return True
            if neg in a_l and pos in b_l:
                return True
        return False

    @staticmethod
    def _topic(text):
        words = [w for w in text.lower().split() if len(w) > 4]
        return " ".join(words[:4]) if words else "bilinmeyen"

    def status(self):
        with self._lock:
            return {"entries": len(self.entries), "contradictions": self.contradictions,
                    "path": "in-memory"}

# -*- coding: utf-8 -*-
"""Mixium A23 — Real World Autonomous Mode.

Human-like working mode: research (web research, collect sources, analyze,
report, self-check) and coding project (plan, code, test, review, fix).
Planning/reporting only; execution stays in the existing permission chain.
"""
import threading
import time
import uuid


class RealAutonomousMode:
    def __init__(self, providers=None):
        self.providers = dict(providers or {})
        self._lock = threading.RLock()
        self.sessions = []

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn()
            return default if v is None else v
        except Exception:
            return default

    def run(self, goal, mode=None):
        goal = str(goal or "").strip()
        if not goal:
            return None
        mode = mode or ("research" if any(k in goal.lower() for k in ("araştır", "research", "incele", "kaynak", "web")) else "coding")
        if mode == "research":
            steps = ["Web araştırması başlat", "Kaynakları topla", "Bilgiyi analiz et", "Rapor üret", "Kendi kontrolünü yap"]
        else:
            steps = ["Plan oluştur", "Kod geliştir", "Test et", "Review yap", "Düzeltmeleri uygula", "Rapor üret"]
        session = {"id": "real_" + uuid.uuid4().hex[:10], "goal": goal[:1000], "mode": mode,
                   "steps": steps, "status": "planned", "sources": [], "report": None,
                   "self_check": {"ok": True, "notes": []}, "created": time.time()}
        with self._lock:
            self.sessions.append(session)
            self.sessions = self.sessions[-50:]
        return session

    def status(self):
        with self._lock:
            return {"sessions": self.sessions[-20:], "count": len(self.sessions)}

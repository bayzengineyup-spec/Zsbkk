# -*- coding: utf-8 -*-
"""Mixium A26 — Real Engineer Simulation.

Sistemin kendisine şu rollerle baktırır: Senior Developer, Architect,
Security Engineer, QA Engineer, Performance Engineer. Her rol ayrı
değerlendirme yapar (enjekte edilen reviewer/değerlendirici fn üzerinden,
yoksa deterministik heuristik). Model zekasını kısıtlamaz.
"""

ROLES = {
    "senior_developer": {"focus": "kod kalitesi, okunabilirlik, SOLID"},
    "architect": {"focus": "mimari, bağımlılıklar, ölçeklenebilirlik"},
    "security_engineer": {"focus": "güvenlik, sızıntı, unsafe ops"},
    "qa_engineer": {"focus": "test, edge case, hata ihtimali"},
    "performance_engineer": {"focus": "performans, karmaşıklık, darboğaz"},
}


class EngineerSimulation:
    def __init__(self, reviewer=None):
        self.reviewer = reviewer  # advanced_code_review.AdvancedCodeReview
        self.runs = []

    def evaluate(self, code):
        """Her rol için ayrı değerlendirme üretir."""
        base = None
        if self.reviewer is not None:
            try:
                base = self.reviewer.review(code)
            except Exception:
                base = None
        findings = base.get("findings", []) if base else []
        text = code or ""

        def _cat(*cats):
            return [f for f in findings if f.get("category") in cats]

        roles = {
            "senior_developer": {
                "focus": ROLES["senior_developer"]["focus"],
                "score": max(0, 100 - sum(f["severity"] * 6 for f in _cat("readability", "maintainability", "complexity"))),
                "notes": [f["suggestion"] for f in _cat("readability", "maintainability", "complexity")][:3],
            },
            "architect": {
                "focus": ROLES["architect"]["focus"],
                "score": max(0, 100 - sum(f["severity"] * 6 for f in _cat("maintainability", "complexity"))),
                "notes": [f["suggestion"] for f in _cat("maintainability", "complexity")][:3],
            },
            "security_engineer": {
                "focus": ROLES["security_engineer"]["focus"],
                "score": max(0, 100 - sum(f["severity"] * 10 for f in _cat("security", "error_risk"))),
                "notes": [f["suggestion"] for f in _cat("security", "error_risk")][:3],
            },
            "qa_engineer": {
                "focus": ROLES["qa_engineer"]["focus"],
                "score": max(0, 100 - sum(f["severity"] * 6 for f in _cat("error_risk", "complexity"))),
                "notes": [f["suggestion"] for f in _cat("error_risk", "complexity")][:3],
            },
            "performance_engineer": {
                "focus": ROLES["performance_engineer"]["focus"],
                "score": max(0, 100 - sum(f["severity"] * 6 for f in _cat("complexity"))),
                "notes": [f["suggestion"] for f in _cat("complexity")][:3],
            },
        }
        if not findings:
            for r in roles.values():
                r["notes"] = ["belirgin sorun tespit edilmedi"]
        rec = {"roles": roles, "overall": base}
        self.runs.append(rec)
        return rec

    def status(self):
        return {"runs": len(self.runs), "roles": sorted(ROLES.keys())}

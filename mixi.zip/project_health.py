# -*- coding: utf-8 -*-
"""
Mixium — Project Health System (Aşama 12D)

Toplar: test sonucu + lint (compile) + LSP diagnostics + dependency sorunları +
git dirty state. Çıktı: {health_score: 0-100, errors, warnings, recommendations}.

MIXIUM'a bağımlı değildir; veriler enjekte edilir (mixium_new gerçek test_status/
lsp/code_intel/git_manager ile bağlar).
"""


class ProjectHealth:
    def __init__(self):
        pass

    def evaluate(self, test=None, lint_errors=0, lsp_errors=0,
                 dependency_issues=None, git_dirty=None):
        """Tüm girdileri toplayıp health score üretir."""
        score = 100
        errors = []
        warnings = []
        recommendations = []

        # test
        if test is not None:
            failed = test.get("failed", 0)
            terr = test.get("errors", 0)
            if failed or terr:
                errors.append("test: %d başarısız, %d hata" % (failed, terr))
                score -= min(30, (failed + terr) * 10)
            else:
                recommendations.append("testler temiz")

        # lint
        if lint_errors:
            errors.append("lint: %d sözdizimi hatası" % lint_errors)
            score -= min(20, lint_errors * 5)

        # LSP
        if lsp_errors:
            warnings.append("LSP: %d tanı" % lsp_errors)
            score -= min(15, lsp_errors * 2)

        # dependency
        for d in (dependency_issues or []):
            warnings.append("dependency: %s" % d)
            score -= 5

        # git dirty
        if git_dirty is not None:
            n = len(git_dirty) if isinstance(git_dirty, list) else int(git_dirty)
            if n:
                warnings.append("git: %d değişiklik (commit edilmemiş)" % n)
                score -= min(10, n * 2)
            else:
                recommendations.append("git temiz")

        score = max(0, min(100, score))
        if score >= 80:
            recommendations.append("proje sağlıklı")
        elif score >= 50:
            recommendations.append("proje orta sağlıkta — sorunları ele al")
        else:
            recommendations.append("proje kritik — acil müdahale")
        return {
            "health_score": score,
            "errors": errors,
            "warnings": warnings,
            "recommendations": recommendations,
        }

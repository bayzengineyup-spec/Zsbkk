# -*- coding: utf-8 -*-
"""
Mixium — Autonomous Research Loop (Aşama 16C)

Arka planda araştırma döngüsü:
    Research Goal
        ↓
    Knowledge Acquisition
        ↓
    Validation
        ↓
    Expert Store
        ↓
    Pattern Extraction

Kurallar:
- sonsuz loop yok (max_iterations)
- timeout (saniye)
- kaynak kalite kontrolü (knowledge_validator / acquisition filtresi)

MIXIUM'a bağımlı değildir; acquire_fn ve pattern_fn enjekte edilir.
Fail-closed: her adım exception izolasyonludur, loop sonucu raporlanır.
"""

import json
import threading
import time
import uuid
from pathlib import Path


class AutonomousResearch:
    def __init__(self, root=".", acquire_fn=None, pattern_fn=None,
                 validator=None, max_iterations=5, timeout=120):
        """acquire_fn(topic) -> kayıt dict veya None (knowledge_acquisition).
        pattern_fn(text) -> kalıp önerileri listesi (code_learning).
        validator  -> knowledge_validator (varsa acquire öncesi kontrol)."""
        self.root = Path(root)
        self.dir = self.root / ".mixium" / "learning"
        self.acquire_fn = acquire_fn
        self.pattern_fn = pattern_fn
        self.validator = validator
        self.max_iterations = max_iterations
        self.timeout = timeout
        self._lock = threading.RLock()
        self._jobs = {}      # job_id -> {goal, status, iteration, result, error, created}
        self._load()

    def _allowed(self, p):
        try:
            p = Path(p).resolve()
            root = self.root.resolve()
            return root in p.parents or p == root
        except Exception:
            return False

    def _load(self):
        try:
            if self._allowed(self.dir / "research_jobs.json"):
                with open(self.dir / "research_jobs.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    self._jobs = data
        except Exception:
            pass

    def _save(self):
        try:
            if not self._allowed(self.dir):
                return False
            self.dir.mkdir(parents=True, exist_ok=True)
            tmp = self.dir / "research_jobs.json.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._jobs, f, ensure_ascii=False, indent=1)
            tmp.replace(self.dir / "research_jobs.json")
            return True
        except Exception:
            return False

    # ── iş yönetimi ─────────────────────────────────────────────────
    def start(self, goal, max_iterations=None):
        job_id = uuid.uuid4().hex[:12]
        with self._lock:
            self._jobs[job_id] = {
                "goal": goal[:500], "status": "running", "iteration": 0,
                "max_iterations": int(max_iterations or self.max_iterations),
                "result": [], "error": "", "created": time.time(),
            }
            self._save()
        return job_id

    def run_once(self, goal, max_iterations=None):
        """Senkron tam loop: start + loop'u sonuna kadar ilerlet + rapor."""
        job_id = self.start(goal, max_iterations)
        return self.run_loop(job_id)

    def step(self, job_id):
        """Bir iteration adımı. Döngü bitince completed/failed."""
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.get("status") != "running":
                return False
            job["iteration"] += 1
            it = job["iteration"]
            goal = job["goal"]
        deadline = time.time() + self.timeout
        try:
            # 1) bilgi edin (doğrulayıcıdan geç)
            acquired = None
            if self.acquire_fn:
                acquired = self.acquire_fn(goal)
            accepted = True
            if acquired and self.validator is not None:
                try:
                    v = self.validator.validate(acquired)
                    accepted = bool(v.get("accepted", True))
                except Exception:
                    accepted = True
            if acquired and accepted:
                with self._lock:
                    job["result"].append({
                        "iteration": it, "kind": "knowledge",
                        "content": str(acquired)[:1500]})
            # 2) kalıp çıkarımı
            if self.pattern_fn and acquired:
                try:
                    patterns = self.pattern_fn(str(acquired))
                    if patterns:
                        with self._lock:
                            job["result"].append({
                                "iteration": it, "kind": "pattern",
                                "content": str(patterns)[:1500]})
                except Exception:
                    pass
            done = it >= job["max_iterations"] or time.time() > deadline
            with self._lock:
                if done:
                    job["status"] = "completed"
                    job["error"] = ""
                    self._save()
                else:
                    job["status"] = "running"
            return done
        except Exception as e:
            with self._lock:
                job["status"] = "failed"
                job["error"] = f"{type(e).__name__}: {e}"[:300]
                self._save()
            return True

    def run_loop(self, job_id):
        """job_id için loop'u max_iterations'a kadar ilerlet."""
        guard = 0
        while guard < self.max_iterations + 2:
            with self._lock:
                job = self._jobs.get(job_id)
                if job is None or job.get("status") != "running":
                    return self.status(job_id)
            done = self.step(job_id)
            guard += 1
            if done:
                return self.status(job_id)
        with self._lock:
            job = self._jobs.get(job_id)
            if job and job.get("status") == "running":
                job["status"] = "failed"
                job["error"] = "max iteration aşıldı"
                self._save()
        return self.status(job_id)

    def status(self, job_id=None):
        with self._lock:
            if job_id:
                return dict(self._jobs.get(job_id, {}))
            return {k: {kk: vv for kk, vv in v.items() if kk != "result"}
                    for k, v in self._jobs.items()}

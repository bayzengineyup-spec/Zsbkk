# -*- coding: utf-8 -*-
"""
Mixium — Knowledge Acquisition Agent (Aşama 15B)

Araştırma yapan ajan. Kaynaklar: GitHub kaliteli projeler, teknik bloglar,
makaleler, resmi dokümantasyon, açık kaynak kodlar. "Her şeyi toplama" YASAK.

Filtre: Source Quality + Technical Depth + Community Validation + Freshness.
Eşik üstü adaylar KnowledgeValidator'dan geçip store'a yazılır.

MIXIUM'a bağımlı değildir; research_fn + validator + store enjekte edilir.
"""

import time

QUALITY_DOMAINS = ("docs.", "github.com", "wikipedia.org", "stackoverflow.com",
                   ".edu", ".gov", "official", "readthedocs", "arxiv.org")


class KnowledgeAcquisition:
    def __init__(self, research_fn=None, validator=None, store=None):
        self.research_fn = research_fn
        self.validator = validator
        self.store = store
        self._last = None

    def score_source(self, source, topic):
        """{source_quality, technical_depth, community_validation, freshness, total}."""
        source = source or {}
        url = str(source.get("url", "")).lower()
        snippet = str(source.get("snippet", "")).lower()
        topic_l = (topic or "").lower()

        quality = 50
        for dom in QUALITY_DOMAINS:
            if dom in url:
                quality = 90
                break

        # technical depth: snippet uzunluğu + teknik anahtar kelimeler
        depth = 40
        for kw in ("pattern", "architecture", "design", "test", "security",
                   "performance", "module", "class", "function", "async"):
            if kw in snippet:
                depth = min(100, depth + 10)
        if len(snippet) > 200:
            depth = min(100, depth + 10)

        # community validation: github stars / upvotes gibi (ts/snippet proxy)
        community = 40
        for kw in topic_l.split():
            if kw and kw in snippet:
                community = min(100, community + 15)

        freshness = 50
        ts = source.get("ts")
        if ts:
            try:
                age_days = (time.time() - float(ts)) / 86400.0
                freshness = max(0, 100 - int(age_days * 5))
            except Exception:
                freshness = 50

        total = int(0.35 * quality + 0.25 * depth + 0.2 * community + 0.2 * freshness)
        return {"source_quality": quality, "technical_depth": depth,
                "community_validation": community, "freshness": freshness,
                "total": total}

    def acquire(self, topic, domain="advanced_coding", min_score=60):
        """Araştır -> skorla -> doğrula -> store (yalnızca kabul edilenler)."""
        if self.research_fn is None:
            return {"ok": False, "error": "research_fn bağlı değil"}
        r = self.research_fn(topic) or {}
        accepted, rejected = [], []
        for s in (r.get("sources") or []):
            if not isinstance(s, dict):
                continue
            sc = self.score_source(s, topic)
            if sc["total"] < min_score:
                rejected.append({"url": s.get("url"), "reason": "düşük skor %d" % sc["total"]})
                continue
            candidate = {"knowledge": "Kaynak: %s — %s" % (s.get("url", ""),
                                                           str(s.get("snippet", ""))[:500]),
                         "source": s.get("url", ""), "domain": domain,
                         "quality_score": sc["total"],
                         "confidence": sc["source_quality"]}
            verdict = self.validator.validate(candidate) if self.validator else \
                {"accepted": True, "confidence": sc["source_quality"],
                 "quality_score": sc["total"]}
            if verdict.get("accepted"):
                if self.store is not None:
                    self.store.add(candidate["knowledge"], domain,
                                   source=candidate["source"],
                                   quality_score=verdict.get("quality_score", sc["total"]),
                                   confidence=verdict.get("confidence", sc["source_quality"]))
                accepted.append({"url": s.get("url"), "score": sc["total"]})
            else:
                rejected.append({"url": s.get("url"), "reason": verdict.get("reason")})
        self._last = {"topic": topic, "ts": time.time(),
                      "accepted": accepted, "rejected": rejected}
        return {"ok": True, "accepted": len(accepted),
                "rejected": len(rejected), "sources": accepted,
                "summary": r.get("summary", ""), "confidence": r.get("confidence", 0)}

    def last_activity(self):
        return self._last

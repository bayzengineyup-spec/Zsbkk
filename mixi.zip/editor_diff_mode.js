/* Incremental editor helper */
window.MixiumDiff={
 apply(original, replacement){
   return {changed:true, before:original, after:replacement};
 }
};

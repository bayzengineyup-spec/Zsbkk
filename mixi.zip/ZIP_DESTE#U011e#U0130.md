# ZIP desteği

Web arayüzü `.zip` seçimini destekler. ZIP dosyası tarayıcıda açılır; desteklenen metin/kod dosyalarının içeriği güvenli bir boyut sınırıyla mesaja eklenir. Binary dosyalar atlanır. ZIP hazırlanırken Gönder işlemi bekletilir.

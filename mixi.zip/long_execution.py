# -*- coding: utf-8 -*-
"""Mixium A23 — Long Run Execution Engine.

Wraps AgentDaemon (A12) to manage multi-hour tasks with checkpoint, pause,
resume, cancel and crash recovery. The daemon file is not modified.
"""
import json
import threading
import time
import uuid
from pathlib import Path


class LongExecution:
    def __init__(self, root=".", daemon=None, max_runs=20):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "long_execution.json"
        self.daemon = daemon
        self.max_runs = max(1, int(max_runs))
        self._lock = threading.RLock()
        self.runs = {}
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.runs = d if isinstance(d, dict) else {}
        except Exception:
            self.runs = {}

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.runs, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def start(self, goal, job_fn):
        """Start a long run; job_fn(ctx) -> {"done": bool, ...} compatible with AgentDaemon."""
        if not str(goal or "").strip():
            return None
        with self._lock:
            if len(self.runs) >= self.max_runs:
                return None
            rid = "run_" + uuid.uuid4().hex[:10]
            self.runs[rid] = {"id": rid, "goal": str(goal)[:2000], "status": "CREATED",
                              "checkpoint": {}, "error": "", "created": time.time(), "updated": time.time()}
            self._save()
        # delegate to AgentDaemon when available
        if self.daemon is not None:
            try:
                self.daemon.start(goal, job_fn)
                self.runs[rid]["status"] = "RUNNING"
                self._save()
            except Exception as exc:
                self.runs[rid]["status"] = "FAILED"
                self.runs[rid]["error"] = str(exc)[:300]
                self._save()
        else:
            self.runs[rid]["status"] = "QUEUED"
            self._save()
        return dict(self.runs[rid])

    def checkpoint(self, rid, data=None):
        with self._lock:
            row = self.runs.get(str(rid))
            if not row:
                return None
            if data is not None:
                row["checkpoint"] = data
            row["updated"] = time.time()
            self._save()
            return dict(row)

    def pause(self, rid):
        if self.daemon is not None:
            try:
                self.daemon.pause()
            except Exception:
                pass
        with self._lock:
            row = self.runs.get(str(rid))
            if not row:
                return None
            row["status"] = "PAUSED"
            row["updated"] = time.time()
            self._save()
            return dict(row)

    def resume(self, rid):
        if self.daemon is not None:
            try:
                self.daemon.resume()
            except Exception:
                pass
        with self._lock:
            row = self.runs.get(str(rid))
            if not row:
                return None
            row["status"] = "RUNNING"
            row["updated"] = time.time()
            self._save()
            return dict(row)

    def cancel(self, rid):
        if self.daemon is not None:
            try:
                self.daemon.stop()
            except Exception:
                pass
        with self._lock:
            row = self.runs.get(str(rid))
            if not row:
                return None
            row["status"] = "CANCELLED"
            row["updated"] = time.time()
            self._save()
            return dict(row)

    def recover(self):
        """Crash recovery: mark any stale RUNNING runs as INTERRUPTED."""
        with self._lock:
            for row in self.runs.values():
                if row.get("status") in ("RUNNING", "QUEUED", "PAUSED"):
                    stale = time.time() - row.get("updated", 0) > 600
                    if stale:
                        row["status"] = "INTERRUPTED"
            self._save()
        return self.status()

    def status(self, rid=None):
        with self._lock:
            rows = [self.runs[str(rid)]] if rid and str(rid) in self.runs else list(self.runs.values()) if not rid else []
        return {"runs": rows, "count": len(rows), "path": str(self.path)}

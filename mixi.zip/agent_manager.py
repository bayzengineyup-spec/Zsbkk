# -*- coding: utf-8 -*-
"""Mixium A20 — Agent Manager facade.

Uses AgentSociety for metadata and optionally an injected AgentRuntime for
execution. It never changes permission or sandbox state.
"""
import threading
import time

class AgentManager:
    def __init__(self, society, runtime=None):
        self.society = society
        self.runtime = runtime
        self._lock = threading.RLock()
        self.tasks = {}

    def create_agent(self, role, goal=""):
        return self.society.create_agent(role, goal)

    def assign_task(self, agent_id, task, runner=None):
        agent = self.society.get(agent_id)
        if not agent:
            return {"ok": False, "error": "agent bulunamadı"}
        with self._lock:
            task_id = "soc_task_" + str(int(time.time() * 1000000))[-12:]
            self.tasks[task_id] = {"id": task_id, "agent_id": agent_id, "task": str(task)[:3000], "status": "ASSIGNED", "created": time.time()}
        self.society.update(agent_id, goal=str(task)[:2000], status="WAITING")
        # Execution remains delegated to the existing runtime; no local loop is forked.
        if runner is not None and self.runtime is not None:
            try:
                runtime_agent = self.runtime.spawn(agent["role"], str(task), runner, tools=agent.get("tools"))
                self.tasks[task_id]["runtime_agent_id"] = getattr(runtime_agent, "id", None)
                self.tasks[task_id]["status"] = "RUNNING" if runtime_agent else "REJECTED"
            except Exception as exc:
                self.tasks[task_id].update({"status": "FAILED", "error": str(exc)[:300]})
        return {"ok": True, "task": dict(self.tasks[task_id])}

    def pause_agent(self, agent_id):
        return bool(self.society.update(agent_id, status="PAUSED"))

    def resume_agent(self, agent_id):
        return bool(self.society.update(agent_id, status="RUNNING"))

    def evaluate_agent(self, agent_id, success, confidence=None, error="", feedback=None):
        return self.society.record_result(agent_id, success, confidence, error, feedback)

    def remove_agent(self, agent_id):
        return self.society.remove(agent_id)

    def status(self):
        with self._lock:
            tasks = list(self.tasks.values())[-50:]
        return {"society": self.society.status(), "tasks": tasks}

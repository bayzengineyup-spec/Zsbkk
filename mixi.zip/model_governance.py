# -*- coding: utf-8 -*-
"""Mixium — Model Governance (Aşama 18).

This is selection metadata, not a content or reasoning filter. It records
which trusted model may serve a role; execution still uses the existing API
and all tool actions remain subject to Permission/hard_gate/approval/sandbox.
"""
import json
import threading
import time
from pathlib import Path

ROLES = ("conversation", "coding", "research", "reasoning", "architecture",
         "review", "fast", "dna")
CAPABILITIES = ("reasoning", "coding", "analysis", "planning", "creativity", "research")


class ModelProfile:
    def __init__(self, model_id, name=None, provider="", capabilities=None,
                 roles=None, speed=None, quality=None, cost=None, limits=None,
                 enabled=True, ai_name=None):
        self.id = str(model_id)
        self.name = str(name or self.id)
        self.provider = str(provider or "unknown")
        self.capabilities = sorted({str(x) for x in (capabilities or []) if str(x) in CAPABILITIES})
        self.roles = sorted({str(x) for x in (roles or []) if str(x) in ROLES})
        self.speed = speed
        self.quality = quality
        self.cost = cost
        self.limits = dict(limits or {}) if isinstance(limits or {}, dict) else {}
        self.enabled = bool(enabled)
        self.ai_name = ai_name or self.name

    def to_dict(self):
        return {"id": self.id, "name": self.name, "provider": self.provider,
                "capabilities": list(self.capabilities), "roles": list(self.roles),
                "speed": self.speed, "quality": self.quality, "cost": self.cost,
                "limits": dict(self.limits), "enabled": self.enabled,
                "ai_name": self.ai_name}


class ModelGovernance:
    def __init__(self, root=".", models=None, defaults=None):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "governance" / "models.json"
        self._lock = threading.RLock()
        self.models = {}
        self.assignments = {}
        self._load()
        # Catalog discovery is read-only; persistence occurs only for explicit
        # governance mutations (role assignment/register with persist=True).
        for model in models or []:
            self.register(model, persist=False)
        if defaults:
            for role, model_id in defaults.items():
                self.assign_role(role, model_id)

    def _allowed(self):
        try:
            p = self.path.resolve()
            root = self.root.resolve()
            return p == root or root in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                data = json.loads(self.path.read_text(encoding="utf-8"))
                for raw in data.get("models", []):
                    self.register(raw, persist=False)
                self.assignments = dict(data.get("assignments", {}))
        except Exception:
            self.models, self.assignments = {}, {}

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps({"models": [m.to_dict() for m in self.models.values()],
                                       "assignments": self.assignments,
                                       "updated_at": time.time()},
                                      ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    @staticmethod
    def _coerce(raw):
        if isinstance(raw, ModelProfile):
            return raw
        if not isinstance(raw, dict) or not raw.get("id"):
            return None
        return ModelProfile(raw["id"], name=raw.get("name") or raw.get("ai_name"),
                            provider=raw.get("provider", ""),
                            capabilities=raw.get("capabilities", []), roles=raw.get("roles", []),
                            speed=raw.get("speed"), quality=raw.get("quality"), cost=raw.get("cost"),
                            limits=raw.get("limits", {}), enabled=raw.get("enabled", True),
                            ai_name=raw.get("ai_name"))

    def register(self, profile, persist=True):
        p = self._coerce(profile)
        if p is None:
            return False
        with self._lock:
            self.models[p.id] = p
            if persist:
                self._save()
        return True

    def remove(self, model_id):
        with self._lock:
            if model_id not in self.models or model_id in self.assignments.values():
                return False
            del self.models[model_id]
            self._save()
            return True

    def get(self, model_id):
        with self._lock:
            p = self.models.get(str(model_id))
            return p.to_dict() if p else None

    def list_models(self, enabled_only=False):
        with self._lock:
            return [p.to_dict() for p in self.models.values() if not enabled_only or p.enabled]

    def assign_role(self, role, model_id):
        role = str(role)
        if role not in ROLES:
            return False, "bilinmeyen rol"
        with self._lock:
            p = self.models.get(str(model_id))
            if p is None or not p.enabled:
                return False, "model yok veya devre dışı"
            self.assignments[role] = p.id
            self._save()
        return True, "ok"

    def model_for_role(self, role):
        with self._lock:
            mid = self.assignments.get(role)
            p = self.models.get(mid) if mid else None
            return p.to_dict() if p and p.enabled else None

    def supports(self, model_id, capability):
        p = self.get(model_id)
        return bool(p and p.get("enabled") and capability in p.get("capabilities", []))

    def route(self, task_kind, fallback=None):
        role = str(task_kind or "conversation")
        if role not in ROLES:
            role = "conversation"
        profile = self.model_for_role(role)
        if profile:
            return {"role": role, "model": profile, "source": "governance"}
        if fallback:
            profile = self.get(fallback)
            if profile and profile.get("enabled"):
                return {"role": role, "model": profile, "source": "fallback"}
        return {"role": role, "model": None, "source": "unavailable"}

    def status(self):
        with self._lock:
            return {"models": self.list_models(), "assignments": dict(self.assignments),
                    "roles": list(ROLES), "capabilities": list(CAPABILITIES),
                    "config": str(self.path)}

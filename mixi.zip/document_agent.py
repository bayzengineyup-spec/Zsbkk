# -*- coding: utf-8 -*-
"""
Mixium — Document Intelligence (Aşama 13C)

Desteklenen formatlar: .md .html .docx .pdf
- Markdown/HTML : stdlib (read + regex).
- DOCX          : stdlib zipfile + xml.etree (word/document.xml).
- PDF           : pypdf varsa kullanılır; YOKSA fail-closed HATA (sahte metin yok).
- Binary dosya okunmaz (NUL bayt tespiti).

Fonksiyonlar: read_document / extract / summarize / compare.
MIXIUM'a bağımlı değildir; read_fn (dosya okuma) + summarize_fn enjekte edilir.
"""

import re
from pathlib import Path

_W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _is_binary(data):
    return b"\x00" in data[:8192]


def _docx_text(path):
    import zipfile
    import xml.etree.ElementTree as ET
    with zipfile.ZipFile(str(path)) as z:
        xml = z.read("word/document.xml")
    root = ET.fromstring(xml)
    paras = []
    for p in root.iter(_W_NS + "p"):
        parts = [t.text or "" for t in p.iter(_W_NS + "t")]
        paras.append("".join(parts))
    return "\n".join(paras)


def _pdf_text(path):
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError:
            return None   # fail-closed
    reader = PdfReader(str(path))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def _html_text(text):
    text = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", text)
    text = re.sub(r"(?s)<!--.*?-->", " ", text)
    text = re.sub(r"<br\s*/?>|</p>|</div>|</li>|</tr>", "\n", text)
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def _guess_lang(path):
    s = Path(path).suffix.lower().lstrip(".")
    return {"md": "markdown", "markdown": "markdown", "html": "html",
            "htm": "html", "docx": "docx", "pdf": "pdf"}.get(s)


class DocumentAgent:
    def __init__(self, read_fn=None, summarize_fn=None):
        self.read_fn = read_fn or (lambda p: Path(p).read_bytes())
        self.summarize_fn = summarize_fn

    def extract(self, path):
        """{path, lang, text} döndürür; desteklenmeyen/binary/fail-closed -> error."""
        p = Path(path)
        lang = _guess_lang(p.name)
        if lang is None:
            return {"path": str(p), "lang": None, "text": "",
                    "error": "desteklenmeyen format: %s" % p.suffix}
        try:
            data = self.read_fn(str(p))
        except Exception as e:
            return {"path": str(p), "lang": lang, "text": "",
                    "error": "okunamadı: %s" % e}
        if isinstance(data, str):
            data = data.encode("utf-8", "ignore")
        # docx/pdf = binary kapsayıcı; özel parser ile çözülür (NUL kontrolü yok)
        if lang == "docx":
            try:
                text = _docx_text(p)
            except Exception as e:
                return {"path": str(p), "lang": lang, "text": "",
                        "error": "docx okunamadı: %s" % e}
            return {"path": str(p), "lang": lang, "text": text, "error": ""}
        if lang == "pdf":
            text = _pdf_text(p)
            if text is None:
                return {"path": str(p), "lang": lang, "text": "",
                        "error": "PDF okuma için 'pypdf' gerekli (kurulu değil) — fail-closed"}
            return {"path": str(p), "lang": lang, "text": text, "error": ""}
        # metin formatları: binary kontrolü
        if _is_binary(data):
            return {"path": str(p), "lang": lang, "text": "",
                    "error": "binary dosya okunmaz"}
        if lang == "html":
            text = _html_text(data.decode("utf-8", "ignore"))
        else:  # markdown
            text = data.decode("utf-8", "ignore")
        return {"path": str(p), "lang": lang, "text": text, "error": ""}

    def read_document(self, path):
        """Metin döndürür; hata varsa 'HATA: ...'."""
        r = self.extract(path)
        if r.get("error"):
            return "HATA: %s" % r["error"]
        return r["text"]

    def summarize(self, path):
        r = self.extract(path)
        if r.get("error"):
            return "HATA: %s" % r["error"]
        text = r["text"]
        if self.summarize_fn is not None:
            try:
                return self.summarize_fn(text)
            except Exception as e:
                return "HATA: özetlenemedi: %s" % e
        return text[:2000] + ("\n… [kesildi]" if len(text) > 2000 else "")

    def compare(self, path1, path2):
        a = self.extract(path1)
        b = self.extract(path2)
        if a.get("error"):
            return "HATA: %s" % a["error"]
        if b.get("error"):
            return "HATA: %s" % b["error"]
        ta, tb = a["text"].splitlines(), b["text"].splitlines()
        import difflib
        diff = "\n".join(difflib.unified_diff(
            ta, tb, fromfile=a["path"], tofile=b["path"], lineterm=""))
        return diff if diff else "(içerik aynı)"

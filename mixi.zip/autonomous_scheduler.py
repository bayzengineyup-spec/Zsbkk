# -*- coding: utf-8 -*-
"""Mixium — Autonomous Scheduler (Aşama 19F).

Bounded worker: max cycles, timeout, pause/resume/stop, heartbeat and
exception isolation. It does not replace AgentDaemon; it is a small adapter
for periodic personal-system jobs.
"""
import threading
import time
import uuid


class AutonomousScheduler:
    def __init__(self, jobs=None, interval=1800, max_cycles=100, timeout=3600):
        self.jobs = dict(jobs or {})
        self.interval = max(0.1, float(interval)); self.max_cycles = max(1, int(max_cycles)); self.timeout = max(1, float(timeout))
        self._lock = threading.RLock(); self._stop = threading.Event(); self._pause = threading.Event(); self._thread = None
        self._state = {"id": "sched_" + uuid.uuid4().hex[:8], "status": "CREATED", "cycles": 0, "heartbeat": 0, "last_error": "", "last_results": {}}

    def add_job(self, name, fn):
        if not name or not callable(fn): return False
        with self._lock: self.jobs[str(name)] = fn
        return True

    def start(self):
        with self._lock:
            if self._thread and self._thread.is_alive(): return False
            self._stop.clear(); self._pause.clear(); self._state.update({"status":"RUNNING", "cycles":0, "last_error":""})
            self._thread = threading.Thread(target=self._run, name="mixium-autonomous-scheduler", daemon=True); self._thread.start()
        return True

    def _run(self):
        started = time.time()
        try:
            while not self._stop.is_set() and self._state["cycles"] < self.max_cycles and time.time() - started < self.timeout:
                while self._pause.is_set() and not self._stop.is_set(): time.sleep(0.1)
                if self._stop.is_set(): break
                results = {}
                for name, fn in list(self.jobs.items()):
                    try: results[name] = fn()
                    except Exception as exc: results[name] = {"ok":False, "error":str(exc)[:200]}
                with self._lock:
                    self._state["cycles"] += 1; self._state["heartbeat"] = time.time(); self._state["last_results"] = results
                if self._stop.wait(self.interval): break
            with self._lock:
                if self._state["status"] == "RUNNING": self._state["status"] = "COMPLETED"
        except Exception as exc:
            with self._lock: self._state.update({"status":"FAILED", "last_error":str(exc)[:300]})
        finally:
            with self._lock: self._state["heartbeat"] = time.time()

    def pause(self):
        self._pause.set(); self._state["status"] = "PAUSED"; return True
    def resume(self):
        if self._state.get("status") != "PAUSED": return False
        self._pause.clear(); self._state["status"] = "RUNNING"; return True
    def stop(self):
        self._stop.set(); self._state["status"] = "CANCELLED"
        if self._thread: self._thread.join(timeout=2)
        return True
    def heartbeat(self): return self._state.get("heartbeat", 0)
    def status(self):
        with self._lock:
            return dict(self._state) | {"jobs": sorted(self.jobs)}

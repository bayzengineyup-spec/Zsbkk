# -*- coding: utf-8 -*-
"""
Mixium — Web Research Agent (Aşama 13B)

Akış: query -> web_search -> fetch/browser -> extract -> summarize -> confidence.
Çıktı: {sources: [{url,title,snippet}], summary, confidence(0-100)}.

Confidence GERÇEK hesaplanır (uydurma değil): başarıyla çekilen kaynak oranı +
yeterli içeriğe sahip kaynak oranının ağırlıklı ortalaması. Formül:
    coverage = fetched / total
    content  = (len(text)>100 olanlar) / total
    confidence = round(100 * (0.5*coverage + 0.5*content))

MIXIUM'a bağımlı değildir; search_fn / fetch_fn / summarize_fn enjekte edilir.
"""


class ResearchAgent:
    def __init__(self, search_fn=None, fetch_fn=None, summarize_fn=None,
                 fetch_limit=3):
        self.search_fn = search_fn or (lambda q, n: [])
        self.fetch_fn = fetch_fn or (lambda u: "")
        self.summarize_fn = summarize_fn          # (query, texts) -> str (opsiyonel LLM)
        self.fetch_limit = fetch_limit

    def research(self, query, limit=None):
        """Web araştırması yapar; {sources, summary, confidence} döndürür."""
        limit = max(1, min(10, int(limit or self.fetch_limit)))
        results = self.search_fn(query, limit) or []
        sources = []
        fetched = 0
        rich = 0
        for r in results:
            if not isinstance(r, dict):
                continue
            url = str(r.get("url", "")).strip()
            text = ""
            ok = False
            if url:
                try:
                    text = str(self.fetch_fn(url) or "")
                    ok = bool(text) and not text.startswith("HATA")
                except Exception:
                    text, ok = "", False
            if ok:
                fetched += 1
            if ok and len(text) > 100:
                rich += 1
            sources.append({
                "url": url,
                "title": str(r.get("title", ""))[:200],
                "snippet": (str(r.get("snippet", "")) or text)[:300],
            })
        # özet
        texts = [str(r.get("snippet", "")) for r in sources if r.get("snippet")]
        if self.summarize_fn is not None and texts:
            try:
                summary = self.summarize_fn(query, texts)
            except Exception:
                summary = " ".join(texts)[:2000]
        else:
            summary = " ".join(texts)[:2000] or "kaynak bulunamadı"
        # confidence (deterministik)
        total = len(sources)
        if total == 0:
            confidence = 0
        else:
            coverage = fetched / total
            content = rich / total
            confidence = int(round(100 * (0.5 * coverage + 0.5 * content)))
        return {
            "sources": sources,
            "summary": summary,
            "confidence": confidence,
        }

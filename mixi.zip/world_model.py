# -*- coding: utf-8 -*-
"""Mixium A22 — Advanced World Model.

Organizes knowledge from existing stores and builds relationships between
concepts. Read-only aggregation; never runs tools.
"""
import json
import threading
import time
from pathlib import Path

CATEGORIES = ("technology", "industry", "architecture", "human_behavior", "problem_solving")


class WorldModel:
    def __init__(self, root=".", providers=None, max_nodes=800):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "world_model.json"
        self.providers = dict(providers or {})
        self.max_nodes = max(1, int(max_nodes))
        self._lock = threading.RLock()
        self.nodes = {}   # concept -> {"category", "related": [..], "count"}
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.nodes = d.get("nodes", {}) if isinstance(d, dict) else {}
        except Exception:
            self.nodes = {}

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps({"nodes": self.nodes}, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def _ingest(self, name, items):
        if not isinstance(items, list):
            return
        for item in items:
            if isinstance(item, dict):
                text = str(item.get("knowledge") or item.get("content") or item.get("pattern") or item.get("title") or "")[:400]
                category = str(item.get("domain") or item.get("category") or name)[:60]
            elif isinstance(item, str):
                text, category = str(item)[:400], name
            else:
                continue
            for word in self._keywords(text):
                row = self.nodes.setdefault(word, {"category": category, "related": [], "count": 0, "updated": time.time()})
                row["count"] += 1
        if len(self.nodes) > self.max_nodes:
            self.nodes = dict(sorted(self.nodes.items(), key=lambda kv: -kv[1].get("count", 0))[:self.max_nodes])

    @staticmethod
    def _keywords(text):
        import re
        stop = {"bir", "ve", "ile", "için", "bu", "şu", "the", "and", "for", "with", "that", "this", "from", "you", "your", "olmak", "gibi", "sonra", "önce", "ama", "veya", "değil", "yap", "et", "ol", "göre", "kadar", "daha", "en", "mi", "mu", "not"}
        words = re.findall(r"[a-zA-ZçğıöşüÇĞİÖŞÜ]{3,}", (text or "").lower())
        return [w for w in words if w not in stop][:6]

    def refresh(self):
        """Pull from existing stores and link co-occurring concepts."""
        data = self._get("knowledge", [])
        if isinstance(data, dict):
            data = data.get("records", []) if isinstance(data.get("records", []), list) else []
        with self._lock:
            self._ingest("knowledge", data)
            # link concepts that frequently co-occur in the same source batch
            keys = list(self.nodes.keys())
            for i in range(len(keys)):
                for j in range(i + 1, len(keys)):
                    a, b = keys[i], keys[j]
                    if a in self.nodes and b in self.nodes and b not in self.nodes[a]["related"]:
                        if len(self.nodes[a]["related"]) < 8:
                            self.nodes[a]["related"].append(b)
            self._save()
        return {"nodes": len(self.nodes)}

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn()
            return default if v is None else v
        except Exception:
            return default

    def query(self, concept, depth=1):
        concept = str(concept or "").lower()
        with self._lock:
            exact = self.nodes.get(concept)
            related = set()
            if exact:
                related.update(exact.get("related", []))
                if depth >= 1:
                    for r in list(related):
                        related.update(self.nodes.get(r, {}).get("related", []))
            else:
                for word, row in self.nodes.items():
                    if concept in word or word in concept:
                        related.add(word)
            return {"concept": concept, "related": sorted(related)[:20],
                    "direct": self.nodes.get(concept, {})}

    def status(self):
        with self._lock:
            by_cat = {}
            for row in self.nodes.values():
                by_cat[row.get("category", "other")] = by_cat.get(row.get("category", "other"), 0) + 1
            return {"nodes": len(self.nodes), "categories": by_cat, "path": str(self.path)}

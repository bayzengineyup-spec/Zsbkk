#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tools_extra.py — Mixium araç genişletme paketi
==============================================
mixium_new.py'nin TOOLS kaydına yeni araçlar ekler ve mevcut
araçları dayanıklı hale getirir. Motor dosyasına DOKUNMAZ.

Kullanım (mixiweb.py içinde):
    import mixium_new as M
    import tools_extra
    tools_extra.install(M)

Eklenenler
----------
  · Dayanıklılık sarmalayıcısı: her araç çağrısı try/except içinde,
    argüman tipleri otomatik düzeltilir, hata insanca raporlanır.
  · Yeni araçlar:
      json_query   — JSON/JSONL içinde yol sorgusu (jq benzeri)
      csv_stat     — CSV/TSV özet istatistiği
      text_stat    — metin/kod ölçümü (satır, kelime, karmaşıklık)
      diff_files   — iki dosya arası unified diff
      replace_glob — çoklu dosyada toplu regex değiştir
      file_info    — dosya meta verisi (boyut, tarih, tür, hash)
      hash_tool    — md5/sha1/sha256/sha512
      encode       — base64/hex/url/html encode-decode
      uuid_tool    — uuid4 / ulid benzeri kimlik üret
      time_tool    — zaman damgası, biçimlendirme, fark
      regex_test   — regex'i örnek metinde dene
      env_info     — çalışma ortamı raporu
      pkg_info     — python paket bilgisi
      port_check   — TCP port açık mı
      archive      — zip/tar oluştur veya listele
      pretty       — JSON/XML/SQL biçimlendir
      sandbox_py   — izole python parçacığı çalıştır
      count_tokens — kaba token tahmini
      project_map  — proje yapısı + dil dağılımı
      lint_py      — python sözdizimi denetimi (derleme)
"""

import os
import io
import re
import sys
import json
import time
import glob as _glob
import base64
import hashlib
import difflib
import platform
import subprocess

# ═════════════════════════════════════════════════════════════
#  Yardımcılar
# ═════════════════════════════════════════════════════════════

_MAXOUT = 24000


def _clip(s, n=_MAXOUT):
    s = str(s)
    if len(s) <= n:
        return s
    return s[:n] + "\n… (%d karakter kırpıldı)" % (len(s) - n)


def _arg(args, *names, default=None):
    """Birden çok olası anahtar adını dener — model yanlış ad
    kullanırsa araç patlamaz."""
    if not isinstance(args, dict):
        return default
    for n in names:
        if n in args and args[n] not in (None, ""):
            return args[n]
    return default


def _as_int(v, d=0):
    try:
        return int(float(v))
    except Exception:
        return d


def _as_bool(v, d=False):
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        return v.strip().lower() in ("1", "true", "evet", "yes", "on", "e")
    if v is None:
        return d
    try:
        return bool(v)
    except Exception:
        return d


def _read_text(path, limit=2_500_000):
    p = os.path.expanduser(str(path))
    if not os.path.exists(p):
        raise FileNotFoundError("dosya yok: %s" % p)
    if os.path.isdir(p):
        raise IsADirectoryError("bu bir klasör: %s" % p)
    if os.path.getsize(p) > limit:
        raise ValueError("dosya çok büyük (%d bayt)" % os.path.getsize(p))
    with open(p, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


# ═════════════════════════════════════════════════════════════
#  YENİ ARAÇLAR
# ═════════════════════════════════════════════════════════════

def t_json_query(args):
    """JSON içinde nokta yolu ile sorgula.
    {"path":"data.json","query":"users.0.name"}  veya
    {"data":"{...}","query":"a.b[2].c"}"""
    q = str(_arg(args, "query", "q", "path_expr", default="")).strip()
    raw = _arg(args, "data", "json", "text")
    src = _arg(args, "path", "file")
    if raw is None and src:
        raw = _read_text(src)
    if raw is None:
        return "HATA: 'path' veya 'data' gerekli"
    try:
        obj = json.loads(raw) if isinstance(raw, str) else raw
    except Exception as e:
        return "HATA: JSON çözülemedi — %s" % e
    if not q:
        return _clip(json.dumps(obj, ensure_ascii=False, indent=2))
    cur = obj
    for part in re.split(r"\.(?![^\[]*\])", q):
        if not part:
            continue
        m = re.match(r"^([^\[]*)((?:\[\d+\])*)$", part)
        key, idxs = (m.group(1), m.group(2)) if m else (part, "")
        if key:
            if isinstance(cur, dict):
                if key not in cur:
                    return "HATA: '%s' anahtarı yok. Mevcut: %s" % (
                        key, ", ".join(list(cur.keys())[:20]))
                cur = cur[key]
            else:
                return "HATA: '%s' için sözlük bekleniyordu, %s geldi" % (
                    key, type(cur).__name__)
        for i in re.findall(r"\[(\d+)\]", idxs or ""):
            i = int(i)
            if not isinstance(cur, list):
                return "HATA: dizin [%d] için liste bekleniyordu" % i
            if i >= len(cur):
                return "HATA: dizin [%d] sınır dışı (uzunluk %d)" % (i, len(cur))
            cur = cur[i]
    if isinstance(cur, (dict, list)):
        return _clip(json.dumps(cur, ensure_ascii=False, indent=2))
    return str(cur)


def t_csv_stat(args):
    """CSV/TSV dosyası özeti: sütunlar, satır sayısı, örnek, sayısal istatistik."""
    import csv as _csv
    p = _arg(args, "path", "file")
    if not p:
        return "HATA: 'path' gerekli"
    txt = _read_text(p)
    delim = _arg(args, "delimiter", "sep")
    if not delim:
        head = txt.split("\n", 1)[0]
        delim = "\t" if head.count("\t") > head.count(",") else ","
    rows = list(_csv.reader(io.StringIO(txt), delimiter=delim))
    if not rows:
        return "boş dosya"
    hdr = rows[0]
    body = rows[1:]
    out = ["dosya: %s" % p, "satır: %d (başlık hariç)" % len(body),
           "sütun: %d" % len(hdr), "ayraç: %r" % delim, "", "SÜTUNLAR"]
    for i, name in enumerate(hdr):
        vals = [r[i] for r in body if i < len(r) and r[i] != ""]
        nums = []
        for v in vals[:20000]:
            try:
                nums.append(float(v))
            except Exception:
                pass
        line = "  %-24s dolu=%d boş=%d" % (name[:24], len(vals), len(body) - len(vals))
        if nums and len(nums) > len(vals) * 0.7:
            nums.sort()
            line += "  min=%.4g max=%.4g ort=%.4g medyan=%.4g" % (
                nums[0], nums[-1], sum(nums) / len(nums), nums[len(nums) // 2])
        else:
            uniq = len(set(vals))
            line += "  benzersiz=%d" % uniq
            if uniq <= 8 and vals:
                line += "  {%s}" % ", ".join(sorted(set(vals))[:8])
        out.append(line)
    out.append("")
    out.append("İLK 5 SATIR")
    for r in body[:5]:
        out.append("  " + delim.join(str(x)[:24] for x in r))
    return _clip("\n".join(out))


def t_text_stat(args):
    """Metin/kod ölçümü: satır, kelime, karakter, en uzun satır, girinti tutarlılığı."""
    p = _arg(args, "path", "file")
    txt = _arg(args, "text", "content")
    if txt is None:
        if not p:
            return "HATA: 'path' veya 'text' gerekli"
        txt = _read_text(p)
    lines = txt.split("\n")
    words = len(re.findall(r"\S+", txt))
    blank = sum(1 for l in lines if not l.strip())
    comment = sum(1 for l in lines if l.strip().startswith(("#", "//", "--", "/*", "*")))
    longest = max(range(len(lines)), key=lambda i: len(lines[i])) if lines else 0
    tabs = sum(1 for l in lines if l.startswith("\t"))
    spaces = sum(1 for l in lines if l.startswith("  "))
    out = [
        "satır      : %d" % len(lines),
        "  boş      : %d" % blank,
        "  yorum    : %d" % comment,
        "  kod      : %d" % (len(lines) - blank - comment),
        "kelime     : %d" % words,
        "karakter   : %d" % len(txt),
        "en uzun    : satır %d (%d karakter)" % (longest + 1, len(lines[longest]) if lines else 0),
        "girinti    : %s" % ("sekme" if tabs > spaces else "boşluk" if spaces else "yok"),
    ]
    if tabs and spaces:
        out.append("UYARI      : karışık girinti (sekme=%d, boşluk=%d)" % (tabs, spaces))
    trail = sum(1 for l in lines if l != l.rstrip())
    if trail:
        out.append("UYARI      : %d satırda sondaki boşluk" % trail)
    return "\n".join(out)


def t_diff_files(args):
    """İki dosya arasında unified diff üretir."""
    a = _arg(args, "a", "left", "old", "file1")
    b = _arg(args, "b", "right", "new", "file2")
    if not a or not b:
        return "HATA: 'a' ve 'b' dosya yolları gerekli"
    ta = _read_text(a).split("\n")
    tb = _read_text(b).split("\n")
    ctx = _as_int(_arg(args, "context", default=3), 3)
    d = list(difflib.unified_diff(ta, tb, fromfile=str(a), tofile=str(b),
                                  lineterm="", n=ctx))
    if not d:
        return "fark yok — dosyalar aynı"
    sm = difflib.SequenceMatcher(None, "\n".join(ta), "\n".join(tb))
    return _clip("benzerlik: %.1f%%\n\n%s" % (sm.ratio() * 100, "\n".join(d)))


def t_replace_glob(args):
    """Birden çok dosyada regex ile toplu değiştirme.
    {"pattern":"**/*.py","find":"eski","replace":"yeni","regex":true,"dry":true}"""
    pat = str(_arg(args, "pattern", "glob", "files", default="**/*"))
    find = _arg(args, "find", "old", "search")
    repl = _arg(args, "replace", "new", default="")
    if find is None:
        return "HATA: 'find' gerekli"
    use_re = _as_bool(_arg(args, "regex", default=True), True)
    dry = _as_bool(_arg(args, "dry", "dry_run", "preview", default=False))
    root = str(_arg(args, "path", "cwd", default="."))
    files = [f for f in _glob.glob(os.path.join(root, pat), recursive=True)
             if os.path.isfile(f)]
    if not files:
        return "eşleşen dosya yok: %s" % pat
    try:
        rx = re.compile(find if use_re else re.escape(str(find)), re.M)
    except re.error as e:
        return "HATA: regex geçersiz — %s" % e
    changed, total = [], 0
    for f in files[:500]:
        try:
            src = _read_text(f)
        except Exception:
            continue
        new, n = rx.subn(str(repl), src)
        if n:
            total += n
            changed.append((f, n))
            if not dry:
                with open(f, "w", encoding="utf-8") as fh:
                    fh.write(new)
    if not changed:
        return "hiçbir dosyada eşleşme bulunamadı"
    head = "ÖNİZLEME (yazılmadı)" if dry else "UYGULANDI"
    body = "\n".join("  %-52s %d değişiklik" % (f, n) for f, n in changed[:120])
    return "%s — %d dosya, toplam %d değişiklik\n%s" % (head, len(changed), total, body)


def t_file_info(args):
    """Dosya meta verisi: boyut, tarih, tür, satır sayısı, sha256."""
    p = _arg(args, "path", "file")
    if not p:
        return "HATA: 'path' gerekli"
    p = os.path.expanduser(str(p))
    if not os.path.exists(p):
        return "HATA: yok — %s" % p
    st = os.stat(p)
    kind = "klasör" if os.path.isdir(p) else "dosya"
    out = [
        "yol      : %s" % os.path.abspath(p),
        "tür      : %s" % kind,
        "boyut    : %s" % _human(st.st_size),
        "değişim  : %s" % time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime)),
        "izin     : %s" % oct(st.st_mode & 0o777),
    ]
    if os.path.isdir(p):
        try:
            kids = os.listdir(p)
            out.append("içerik   : %d öğe" % len(kids))
        except Exception:
            pass
    else:
        try:
            with open(p, "rb") as f:
                data = f.read(8_000_000)
            out.append("sha256   : %s" % hashlib.sha256(data).hexdigest()[:32])
            if b"\0" not in data[:4096]:
                out.append("satır    : %d" % (data.count(b"\n") + 1))
                out.append("kodlama  : metin (utf-8 varsayıldı)")
            else:
                out.append("kodlama  : ikili")
        except Exception as e:
            out.append("okuma hatası: %s" % e)
    return "\n".join(out)


def _human(n):
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return "%.1f %s" % (n, u) if u != "B" else "%d B" % n
        n /= 1024.0
    return "%.1f PB" % n


def t_hash_tool(args):
    """md5/sha1/sha256/sha512 — metin veya dosya."""
    alg = str(_arg(args, "algo", "algorithm", "type", default="sha256")).lower()
    if alg not in ("md5", "sha1", "sha256", "sha512", "blake2b"):
        return "HATA: algo = md5|sha1|sha256|sha512|blake2b"
    txt = _arg(args, "text", "data", "content")
    p = _arg(args, "path", "file")
    h = hashlib.new(alg)
    if p:
        with open(os.path.expanduser(str(p)), "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        src = "dosya %s" % p
    elif txt is not None:
        h.update(str(txt).encode("utf-8"))
        src = "metin (%d karakter)" % len(str(txt))
    else:
        return "HATA: 'text' veya 'path' gerekli"
    return "%s(%s)\n%s" % (alg, src, h.hexdigest())


def t_encode(args):
    """base64 / hex / url / html — encode veya decode."""
    mode = str(_arg(args, "mode", "action", default="encode")).lower()
    fmt = str(_arg(args, "format", "type", "codec", default="base64")).lower()
    data = _arg(args, "text", "data", "content", default="")
    s = str(data)
    try:
        if fmt in ("base64", "b64"):
            return (base64.b64encode(s.encode()).decode() if mode.startswith("e")
                    else base64.b64decode(s + "=" * (-len(s) % 4)).decode("utf-8", "replace"))
        if fmt == "hex":
            return (s.encode().hex() if mode.startswith("e")
                    else bytes.fromhex(re.sub(r"\s", "", s)).decode("utf-8", "replace"))
        if fmt in ("url", "uri"):
            from urllib.parse import quote, unquote
            return quote(s, safe="") if mode.startswith("e") else unquote(s)
        if fmt == "html":
            import html as _h
            return _h.escape(s) if mode.startswith("e") else _h.unescape(s)
    except Exception as e:
        return "HATA: dönüştürülemedi — %s" % e
    return "HATA: format = base64|hex|url|html"


def t_uuid_tool(args):
    """Kimlik üret: uuid4, uuid1, kısa id, zaman sıralı id."""
    import uuid as _u
    kind = str(_arg(args, "kind", "type", default="uuid4")).lower()
    n = max(1, min(50, _as_int(_arg(args, "count", "n", default=1), 1)))
    out = []
    for _ in range(n):
        if kind == "uuid1":
            out.append(str(_u.uuid1()))
        elif kind in ("short", "kisa", "nano"):
            out.append(base64.urlsafe_b64encode(os.urandom(9)).decode().rstrip("="))
        elif kind in ("ulid", "sorted", "time"):
            out.append("%013X%s" % (int(time.time() * 1000),
                                    os.urandom(5).hex().upper()))
        else:
            out.append(str(_u.uuid4()))
    return "\n".join(out)


def t_time_tool(args):
    """Zaman: şimdi, dönüştür, fark, biçimlendir."""
    act = str(_arg(args, "action", "mode", default="now")).lower()
    if act in ("now", "simdi", "şimdi"):
        t = time.time()
        return ("yerel   : %s\nUTC     : %s\nunix    : %.3f\nISO     : %s" % (
            time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t)),
            time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(t)),
            t,
            time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t))))
    if act in ("parse", "from_unix", "convert"):
        v = _arg(args, "value", "timestamp", "unix")
        try:
            t = float(v)
        except Exception:
            return "HATA: sayısal zaman damgası gerekli"
        return time.strftime(str(_arg(args, "format", default="%Y-%m-%d %H:%M:%S")),
                             time.localtime(t))
    if act in ("diff", "fark"):
        a = float(_arg(args, "a", "start", default=0))
        b = float(_arg(args, "b", "end", default=time.time()))
        d = abs(b - a)
        return ("fark: %.2f saniye = %.2f dakika = %.2f saat = %.2f gün"
                % (d, d / 60, d / 3600, d / 86400))
    return "HATA: action = now|parse|diff"


def t_regex_test(args):
    """Regex'i örnek metinde dener, tüm eşleşmeleri ve grupları gösterir."""
    pat = _arg(args, "pattern", "regex", "re")
    txt = _arg(args, "text", "input", "sample", default="")
    if not pat:
        return "HATA: 'pattern' gerekli"
    flags = 0
    fs = str(_arg(args, "flags", default="")).lower()
    if "i" in fs: flags |= re.I
    if "m" in fs: flags |= re.M
    if "s" in fs: flags |= re.S
    try:
        rx = re.compile(str(pat), flags)
    except re.error as e:
        return "HATA: geçersiz regex — %s\n  konum: %s" % (e.msg, e.pos)
    ms = list(rx.finditer(str(txt)))
    if not ms:
        return "eşleşme yok\ndesen: %s\ngrup sayısı: %d" % (pat, rx.groups)
    out = ["%d eşleşme bulundu" % len(ms), ""]
    for i, m in enumerate(ms[:60], 1):
        out.append("%2d. [%d:%d] %r" % (i, m.start(), m.end(), m.group(0)[:120]))
        if m.groups():
            for gi, g in enumerate(m.groups(), 1):
                out.append("      grup %d: %r" % (gi, g))
        if m.groupdict():
            for k, v in m.groupdict().items():
                out.append("      <%s>: %r" % (k, v))
    return _clip("\n".join(out))


def t_env_info(args):
    """Çalışma ortamı raporu."""
    out = [
        "python   : %s" % sys.version.split()[0],
        "yürütücü : %s" % sys.executable,
        "platform : %s" % platform.platform(),
        "makine   : %s" % platform.machine(),
        "işlemci  : %s" % (platform.processor() or "?"),
        "cwd      : %s" % os.getcwd(),
        "kullanıcı: %s" % (os.environ.get("USER") or os.environ.get("USERNAME") or "?"),
        "ev       : %s" % os.path.expanduser("~"),
    ]
    try:
        out.append("çekirdek : %d" % (os.cpu_count() or 0))
    except Exception:
        pass
    try:
        import shutil as _sh
        u = _sh.disk_usage(".")
        out.append("disk     : %s boş / %s toplam" % (_human(u.free), _human(u.total)))
    except Exception:
        pass
    if _as_bool(_arg(args, "env", "vars", default=False)):
        out.append("")
        out.append("ORTAM DEĞİŞKENLERİ")
        for k in sorted(os.environ)[:80]:
            v = os.environ[k]
            if any(s in k.upper() for s in ("KEY", "TOKEN", "SECRET", "PASS")):
                v = "***gizli***"
            out.append("  %s=%s" % (k, v[:100]))
    return "\n".join(out)


def t_pkg_info(args):
    """Python paketi kurulu mu, sürümü ne?"""
    name = _arg(args, "name", "package", "pkg")
    if not name:
        try:
            import importlib.metadata as md
            names = sorted({d.metadata["Name"] for d in md.distributions()
                            if d.metadata.get("Name")})
            return "kurulu paket: %d\n%s" % (len(names), "\n".join("  " + n for n in names[:200]))
        except Exception as e:
            return "HATA: %s" % e
    try:
        import importlib.metadata as md
        v = md.version(str(name))
        try:
            mod = __import__(str(name).replace("-", "_"))
            loc = getattr(mod, "__file__", "?")
        except Exception:
            loc = "?"
        return "%s == %s\nkonum: %s" % (name, v, loc)
    except Exception:
        return "%s kurulu değil" % name


def t_port_check(args):
    """TCP port açık mı?"""
    import socket
    host = str(_arg(args, "host", default="127.0.0.1"))
    ports = _arg(args, "port", "ports", default=80)
    if isinstance(ports, (int, float, str)):
        ports = [ports]
    to = float(_arg(args, "timeout", default=1.5))
    out = []
    for p in list(ports)[:40]:
        p = _as_int(p, 0)
        s = socket.socket()
        s.settimeout(to)
        t0 = time.time()
        try:
            s.connect((host, p))
            out.append("  %s:%-6d AÇIK    (%.0f ms)" % (host, p, (time.time() - t0) * 1000))
        except Exception as e:
            out.append("  %s:%-6d kapalı  (%s)" % (host, p, type(e).__name__))
        finally:
            try:
                s.close()
            except Exception:
                pass
    return "\n".join(out) or "port belirtilmedi"


def t_archive(args):
    """Arşiv: oluştur / listele / çıkar (zip & tar)."""
    act = str(_arg(args, "action", "mode", default="list")).lower()
    p = _arg(args, "path", "file", "archive")
    if not p:
        return "HATA: 'path' gerekli"
    p = os.path.expanduser(str(p))
    if act in ("list", "ls", "listele"):
        if p.endswith(".zip"):
            import zipfile
            with zipfile.ZipFile(p) as z:
                items = z.infolist()
                return "zip: %s (%d öğe)\n%s" % (
                    p, len(items),
                    "\n".join("  %-56s %s" % (i.filename[:56], _human(i.file_size))
                              for i in items[:200]))
        import tarfile
        with tarfile.open(p) as t:
            names = t.getnames()
            return "tar: %s (%d öğe)\n%s" % (p, len(names),
                                             "\n".join("  " + n for n in names[:200]))
    if act in ("create", "make", "olustur", "oluştur"):
        src = _arg(args, "source", "src", "input", default=".")
        import zipfile
        base = os.path.expanduser(str(src))
        n = 0
        with zipfile.ZipFile(p, "w", zipfile.ZIP_DEFLATED) as z:
            if os.path.isfile(base):
                z.write(base, os.path.basename(base)); n = 1
            else:
                for root, _d, files in os.walk(base):
                    for f in files:
                        fp = os.path.join(root, f)
                        z.write(fp, os.path.relpath(fp, base))
                        n += 1
                        if n > 5000:
                            break
        return "oluşturuldu: %s (%d dosya, %s)" % (p, n, _human(os.path.getsize(p)))
    if act in ("extract", "unzip", "cikar", "çıkar"):
        dest = os.path.expanduser(str(_arg(args, "dest", "to", "output", default=".")))
        import zipfile
        if p.endswith(".zip"):
            with zipfile.ZipFile(p) as z:
                z.extractall(dest)
                return "çıkarıldı: %d öğe -> %s" % (len(z.infolist()), dest)
        import tarfile
        with tarfile.open(p) as t:
            t.extractall(dest)
            return "çıkarıldı -> %s" % dest
    return "HATA: action = list|create|extract"


def t_pretty(args):
    """JSON / XML / SQL biçimlendir."""
    fmt = str(_arg(args, "format", "type", "lang", default="json")).lower()
    txt = _arg(args, "text", "data", "content")
    p = _arg(args, "path", "file")
    if txt is None and p:
        txt = _read_text(p)
    if txt is None:
        return "HATA: 'text' veya 'path' gerekli"
    s = str(txt)
    try:
        if fmt == "json":
            return _clip(json.dumps(json.loads(s), ensure_ascii=False,
                                    indent=_as_int(_arg(args, "indent", default=2), 2),
                                    sort_keys=_as_bool(_arg(args, "sort", default=False))))
        if fmt in ("xml", "html"):
            import xml.dom.minidom as _md
            return _clip(_md.parseString(s).toprettyxml(indent="  "))
        if fmt == "sql":
            kw = ("SELECT", "FROM", "WHERE", "GROUP BY", "ORDER BY", "HAVING",
                  "LIMIT", "INSERT INTO", "VALUES", "UPDATE", "SET", "DELETE FROM",
                  "JOIN", "LEFT JOIN", "INNER JOIN", "ON", "AND", "OR")
            out = s
            for k in sorted(kw, key=len, reverse=True):
                out = re.sub(r"(?i)\b%s\b" % k.replace(" ", r"\s+"), "\n" + k, out)
            return _clip(re.sub(r"\n{2,}", "\n", out).strip())
    except Exception as e:
        return "HATA: biçimlendirilemedi — %s" % e
    return "HATA: format = json|xml|sql"


def t_sandbox_py(args):
    """Kısa Python parçacığını ayrı süreçte çalıştırır (zaman aşımlı)."""
    code = _arg(args, "code", "script", "source")
    if not code:
        return "HATA: 'code' gerekli"
    to = max(1, min(120, _as_int(_arg(args, "timeout", default=20), 20)))
    try:
        r = subprocess.run([sys.executable, "-c", str(code)],
                           capture_output=True, text=True, timeout=to)
        out = []
        if r.stdout:
            out.append("── çıktı ──\n" + r.stdout.rstrip())
        if r.stderr:
            out.append("── hata ──\n" + r.stderr.rstrip())
        out.append("çıkış kodu: %d" % r.returncode)
        return _clip("\n".join(out))
    except subprocess.TimeoutExpired:
        return "HATA: %d saniyede tamamlanmadı (zaman aşımı)" % to
    except Exception as e:
        return "HATA: %s" % e


def t_count_tokens(args):
    """Kaba token tahmini (dil duyarlı)."""
    txt = _arg(args, "text", "content", "data")
    p = _arg(args, "path", "file")
    if txt is None and p:
        txt = _read_text(p)
    if txt is None:
        return "HATA: 'text' veya 'path' gerekli"
    s = str(txt)
    words = len(re.findall(r"\w+", s))
    # latin ~ 1.3 token/kelime; kod ~ karakter/3.2
    code_like = len(re.findall(r"[{}();=<>\[\]]", s)) > len(s) * 0.02
    est = int(len(s) / 3.2) if code_like else int(words * 1.32 + len(s) * 0.05)
    return ("karakter : %d\nkelime   : %d\ntür      : %s\n"
            "tahmini token: ~%d\n(±%%15 yanılma payı)"
            % (len(s), words, "kod" if code_like else "düz metin", est))


_LANG = {
    ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript", ".jsx": "React",
    ".tsx": "React TS", ".html": "HTML", ".css": "CSS", ".scss": "SCSS",
    ".json": "JSON", ".md": "Markdown", ".sh": "Shell", ".go": "Go",
    ".rs": "Rust", ".java": "Java", ".c": "C", ".cpp": "C++", ".h": "C başlık",
    ".rb": "Ruby", ".php": "PHP", ".sql": "SQL", ".yml": "YAML", ".yaml": "YAML",
    ".toml": "TOML", ".xml": "XML", ".txt": "Metin", ".swift": "Swift",
    ".kt": "Kotlin", ".vue": "Vue", ".svelte": "Svelte",
}
_SKIP = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist",
         "build", ".next", ".cache", "target", ".idea", ".mypy_cache"}


def t_project_map(args):
    """Proje haritası: dil dağılımı, en büyük dosyalar, giriş noktaları."""
    root = os.path.expanduser(str(_arg(args, "path", "root", "dir", default=".")))
    if not os.path.isdir(root):
        return "HATA: klasör değil — %s" % root
    langs, files, total = {}, [], 0
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in _SKIP and not d.startswith(".")]
        for f in fns:
            fp = os.path.join(dp, f)
            ext = os.path.splitext(f)[1].lower()
            try:
                sz = os.path.getsize(fp)
            except Exception:
                continue
            total += 1
            files.append((sz, os.path.relpath(fp, root)))
            if ext in _LANG:
                d = langs.setdefault(_LANG[ext], {"n": 0, "b": 0, "l": 0})
                d["n"] += 1
                d["b"] += sz
                if sz < 900_000:
                    try:
                        with open(fp, "rb") as fh:
                            d["l"] += fh.read().count(b"\n")
                    except Exception:
                        pass
        if total > 24000:
            break
    files.sort(reverse=True)
    out = ["PROJE: %s" % os.path.abspath(root),
           "toplam dosya: %d" % total, ""]
    if langs:
        out.append("DİL DAĞILIMI")
        tl = sum(v["l"] for v in langs.values()) or 1
        for name, v in sorted(langs.items(), key=lambda x: -x[1]["l"]):
            pct = v["l"] * 100.0 / tl
            bar = "█" * int(pct / 4)
            out.append("  %-13s %5d dosya %7d satır %5.1f%% %s"
                       % (name, v["n"], v["l"], pct, bar))
    out.append("")
    out.append("EN BÜYÜK DOSYALAR")
    for sz, rel in files[:15]:
        out.append("  %10s  %s" % (_human(sz), rel))
    entries = [r for _s, r in files
               if os.path.basename(r) in ("main.py", "app.py", "index.js",
                                          "index.html", "package.json", "main.go",
                                          "Cargo.toml", "pyproject.toml", "setup.py",
                                          "Makefile", "docker-compose.yml", "Dockerfile")]
    if entries:
        out.append("")
        out.append("GİRİŞ NOKTALARI / YAPILANDIRMA")
        for e in entries[:20]:
            out.append("  " + e)
    return _clip("\n".join(out))


def t_lint_py(args):
    """Python sözdizimi denetimi — derlenebiliyor mu?"""
    p = _arg(args, "path", "file")
    code = _arg(args, "code", "text", "content")
    targets = []
    if code is not None:
        targets.append(("<girdi>", str(code)))
    elif p:
        pp = str(p)
        if any(c in pp for c in "*?["):
            for f in sorted(_glob.glob(os.path.expanduser(pp), recursive=True))[:200]:
                if f.endswith(".py"):
                    targets.append((f, _read_text(f)))
        else:
            targets.append((pp, _read_text(pp)))
    if not targets:
        return "HATA: 'path' veya 'code' gerekli"
    out, bad = [], 0
    for name, src in targets:
        try:
            compile(src, name, "exec")
            out.append("  ✓ %s" % name)
        except SyntaxError as e:
            bad += 1
            out.append("  ✗ %s\n      satır %s sütun %s: %s\n      %s"
                       % (name, e.lineno, e.offset, e.msg, (e.text or "").rstrip()))
        except Exception as e:
            bad += 1
            out.append("  ✗ %s — %s" % (name, e))
    head = "%d dosya denetlendi, %d hata" % (len(targets), bad)
    return _clip(head + "\n" + "\n".join(out))


# ═════════════════════════════════════════════════════════════
#  Dayanıklılık sarmalayıcısı
# ═════════════════════════════════════════════════════════════

def _harden(name, fn):
    """Aracı hataya dayanıklı hale getirir: argüman string gelirse
    JSON'a çevirir, istisnaları insanca rapora dönüştürür."""
    def wrapped(args, _n=name, _f=fn):
        # 1) argüman normalizasyonu
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except Exception:
                args = {"input": args}
        if args is None:
            args = {}
        if not isinstance(args, dict):
            args = {"input": args}
        # 2) çalıştır
        try:
            r = _f(args)
            return r if r is not None else "(boş sonuç)"
        except FileNotFoundError as e:
            return "HATA [%s]: dosya bulunamadı — %s" % (_n, e)
        except PermissionError as e:
            return "HATA [%s]: izin reddedildi — %s" % (_n, e)
        except IsADirectoryError as e:
            return "HATA [%s]: %s" % (_n, e)
        except TimeoutError as e:
            return "HATA [%s]: zaman aşımı — %s" % (_n, e)
        except KeyError as e:
            return "HATA [%s]: eksik argüman %s" % (_n, e)
        except (TypeError, ValueError) as e:
            return "HATA [%s]: geçersiz argüman — %s" % (_n, e)
        except Exception as e:
            import traceback
            tb = traceback.format_exc(limit=3)
            return "HATA [%s]: %s: %s\n%s" % (_n, type(e).__name__, e, tb[-600:])
    return wrapped


NEW_TOOLS = [
    ("json_query", t_json_query, "JSON içinde nokta yolu ile sorgula",
     '{"path":"data.json","query":"users.0.name"}', False),
    ("csv_stat", t_csv_stat, "CSV/TSV özeti: sütun, satır, istatistik",
     '{"path":"veri.csv"}', False),
    ("text_stat", t_text_stat, "Metin/kod ölçümü: satır, kelime, girinti",
     '{"path":"app.py"}', False),
    ("diff_files", t_diff_files, "İki dosya arası unified diff",
     '{"a":"eski.py","b":"yeni.py","context":3}', False),
    ("replace_glob", t_replace_glob, "Çoklu dosyada toplu regex değiştir",
     '{"pattern":"**/*.py","find":"eski","replace":"yeni","dry":true}', True),
    ("file_info", t_file_info, "Dosya meta verisi: boyut, tarih, hash",
     '{"path":"app.py"}', False),
    ("hash_tool", t_hash_tool, "md5/sha1/sha256/sha512 özeti",
     '{"algo":"sha256","path":"a.zip"}', False),
    ("encode", t_encode, "base64/hex/url/html encode-decode",
     '{"mode":"encode","format":"base64","text":"merhaba"}', False),
    ("uuid_tool", t_uuid_tool, "Kimlik üret: uuid4/uuid1/kısa/ulid",
     '{"kind":"uuid4","count":3}', False),
    ("time_tool", t_time_tool, "Zaman: şimdi/dönüştür/fark",
     '{"action":"now"}', False),
    ("regex_test", t_regex_test, "Regex'i örnek metinde dene",
     '{"pattern":"\\\\d+","text":"a1 b22","flags":"i"}', False),
    ("env_info", t_env_info, "Çalışma ortamı raporu",
     '{"env":false}', False),
    ("pkg_info", t_pkg_info, "Python paketi sürüm/konum bilgisi",
     '{"name":"requests"}', False),
    ("port_check", t_port_check, "TCP portu açık mı",
     '{"host":"127.0.0.1","ports":[80,443,8420]}', False),
    ("archive", t_archive, "Arşiv: listele/oluştur/çıkar (zip,tar)",
     '{"action":"list","path":"paket.zip"}', True),
    ("pretty", t_pretty, "JSON/XML/SQL biçimlendir",
     '{"format":"json","path":"veri.json"}', False),
    ("sandbox_py", t_sandbox_py, "İzole Python parçacığı çalıştır",
     '{"code":"print(2**10)","timeout":20}', True),
    ("count_tokens", t_count_tokens, "Kaba token tahmini",
     '{"path":"uzun.md"}', False),
    ("project_map", t_project_map, "Proje haritası: dil dağılımı, büyük dosyalar",
     '{"path":"."}', False),
    ("lint_py", t_lint_py, "Python sözdizimi denetimi",
     '{"path":"**/*.py"}', False),
]


def install(M, harden_existing=True, verbose=False):
    """Araçları M.TOOLS içine kaydeder ve mevcutları sağlamlaştırır."""
    added = []
    for name, fn, desc, schema, danger in NEW_TOOLS:
        if name in getattr(M, "TOOLS", {}):
            continue
        try:
            M.register(name, _harden(name, fn), desc, schema, danger)
            added.append(name)
        except Exception:
            # register imzası farklıysa doğrudan sözlüğe yaz
            try:
                M.TOOLS[name] = {"fn": _harden(name, fn), "desc": desc,
                                 "schema": schema, "danger": danger}
                added.append(name)
            except Exception:
                pass

    hardened = []
    if harden_existing:
        for name, spec in list(getattr(M, "TOOLS", {}).items()):
            if name in added:
                continue
            f = spec.get("fn")
            if f is None or getattr(f, "_mx_hardened", False):
                continue
            w = _harden(name, f)
            w._mx_hardened = True
            spec["fn"] = w
            hardened.append(name)

    if verbose:
        print("tools_extra: +%d yeni, %d sağlamlaştırıldı"
              % (len(added), len(hardened)))
    return {"added": added, "hardened": hardened,
            "total": len(getattr(M, "TOOLS", {}))}


def catalog(M=None):
    """Arayüzün araç galerisinde göstereceği liste."""
    rows = []
    src = getattr(M, "TOOLS", {}) if M else {}
    for name, spec in sorted(src.items()):
        rows.append({
            "name": name,
            "desc": spec.get("desc", ""),
            "schema": spec.get("schema", ""),
            "danger": bool(spec.get("danger")),
            "new": name in {t[0] for t in NEW_TOOLS},
        })
    return rows


if __name__ == "__main__":
    print("tools_extra — %d yeni araç tanımlı" % len(NEW_TOOLS))
    for n, _f, d, _s, dg in NEW_TOOLS:
        print("  %-14s %s%s" % (n, d, "  [riskli]" if dg else ""))

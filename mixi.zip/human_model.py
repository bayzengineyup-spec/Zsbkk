# -*- coding: utf-8 -*-
"""Mixium A22 — Advanced Human Adaptation.

Builds a user model (working style, preferred response format, decision
style, technical level, project habits) from injected Personal Graph, Memory
and DNA. Low-confidence inferences are kept below threshold; users can delete
entries.
"""
import json
import threading
import time
import uuid
from pathlib import Path

FIELDS = ("working_style", "response_format", "decision_style", "technical_level", "project_habits")


class HumanModel:
    def __init__(self, root=".", providers=None, max_entries=200):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "human_model.json"
        self.providers = dict(providers or {})
        self.max_entries = max(1, int(max_entries))
        self._lock = threading.RLock()
        self.entries = {}
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.entries = d if isinstance(d, dict) else {}
        except Exception:
            self.entries = {}

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.entries, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def learn(self, field, content, confidence=50.0, source="inference"):
        """Only store when confidence is high enough (poisoning guard)."""
        if field not in FIELDS or not str(content or "").strip():
            return None
        confidence = max(0.0, min(100.0, float(confidence)))
        if confidence < 55.0:
            return None
        eid = "user_" + uuid.uuid4().hex[:10]
        entry = {"id": eid, "field": field, "content": str(content)[:500], "confidence": confidence,
                 "source": str(source)[:60], "created": time.time(), "updated": time.time()}
        with self._lock:
            # replace a lower-confidence entry of same field+content
            for k, v in list(self.entries.items()):
                if v.get("field") == field and v.get("content") == entry["content"]:
                    if v.get("confidence", 0) < confidence:
                        v.update({"confidence": confidence, "source": source, "updated": time.time()})
                        self._save()
                        return dict(v)
                    return dict(v)
            if len(self.entries) >= self.max_entries:
                oldest = min(self.entries, key=lambda k: self.entries[k].get("updated", 0))
                self.entries.pop(oldest, None)
            self.entries[eid] = entry
            self._save()
            return dict(entry)

    def delete(self, entry_id):
        with self._lock:
            if self.entries.pop(str(entry_id), None) is not None:
                self._save()
                return True
        return False

    def profile(self):
        with self._lock:
            rows = [dict(v) for v in self.entries.values()]
        rows.sort(key=lambda x: -x.get("confidence", 0))
        return {"entries": rows, "fields": {f: [r for r in rows if r["field"] == f] for f in FIELDS}, "count": len(rows)}

    def refresh(self):
        """Pull high-confidence signals from injected sources."""
        graph = self._get("graph", {}) or {}
        nodes = graph.get("nodes", []) if isinstance(graph, dict) else graph if isinstance(graph, list) else []
        for node in nodes[:30]:
            if isinstance(node, dict):
                label = node.get("label")
                ntype = node.get("type")
                if label and ntype in ("preference", "decision", "learning"):
                    self.learn(ntype, label, confidence=75.0, source="personal_graph")
        return self.profile()

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn()
            return default if v is None else v
        except Exception:
            return default

    def status(self):
        return {"profile": self.profile(), "path": str(self.path)}

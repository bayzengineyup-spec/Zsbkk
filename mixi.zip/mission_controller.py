# -*- coding: utf-8 -*-
"""Mixium A28 — Autonomous Mission Controller.

Uzun görev yönetimi: hedef oluştur → plan oluştur → alt görev oluştur → ajan
ata → ilerleme takip et → sonuç değerlendir. Mevcut autonomous_core / project
execution desenleriyle uyumlu, bağımsız state yönetimi.
"""

import threading
import time
import uuid

STATES = ("created", "planning", "running", "paused", "done", "failed")


class MissionController:
    def __init__(self, assign_fn=None, progress_fn=None):
        self.assign_fn = assign_fn or (lambda subtask, agent: {"assigned": True})
        self.progress_fn = progress_fn or (lambda mid: {"progress": 0})
        self.missions = {}
        self._lock = threading.Lock()

    def create(self, goal):
        mid = "mis_%s" % uuid.uuid4().hex[:10]
        mission = {
            "id": mid, "goal": str(goal)[:500], "state": "created",
            "subtasks": [], "assigned": {}, "progress": 0,
            "created": time.time(), "history": [],
        }
        with self._lock:
            self.missions[mid] = mission
        self._log(mission, "created")
        return mission

    def plan(self, mid, subtasks):
        """subtasks: [ {id, description, type, dependencies} ]"""
        m = self.missions.get(mid)
        if not m:
            return {"error": "mission yok"}
        m["subtasks"] = list(subtasks)
        m["state"] = "planning"
        self._log(m, "planned")
        return m

    def assign(self, mid, subtask_id, agent):
        m = self.missions.get(mid)
        if not m:
            return {"error": "mission yok"}
        r = self.assign_fn({"id": subtask_id}, agent)
        m["assigned"][subtask_id] = agent
        self._log(m, "assigned:%s" % subtask_id)
        return r

    def tick(self, mid):
        m = self.missions.get(mid)
        if not m:
            return {"error": "mission yok"}
        if m["state"] == "paused":
            return m
        m["state"] = "running"
        prog = self.progress_fn(mid)
        if isinstance(prog, dict):
            m["progress"] = prog.get("progress", m.get("progress", 0))
        total = len(m["subtasks"]) or 1
        done = len(m["assigned"])
        m["progress"] = min(100, max(m.get("progress", 0), int(100 * done / total)))
        if m["progress"] >= 100:
            m["state"] = "done"
        self._log(m, "tick")
        return m

    def pause(self, mid):
        m = self.missions.get(mid)
        if m:
            m["state"] = "paused"
            self._log(m, "paused")
        return m

    def resume(self, mid):
        m = self.missions.get(mid)
        if m:
            m["state"] = "running"
            self._log(m, "resumed")
        return m

    def evaluate(self, mid):
        m = self.missions.get(mid)
        if not m:
            return {"error": "mission yok"}
        return {"id": mid, "state": m["state"], "progress": m["progress"],
                "subtasks": len(m["subtasks"]), "assigned": len(m["assigned"]),
                "done": m["state"] == "done"}

    def _log(self, m, event):
        m["history"].append({"event": event, "t": time.time()})
        m["history"] = m["history"][-50:]

    def status(self, mid=None):
        if mid:
            return self.missions.get(mid)
        return {"missions": len(self.missions),
                "active": [m["id"] for m in self.missions.values()
                           if m["state"] in ("running", "planning", "paused")]}

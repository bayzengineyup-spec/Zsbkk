# -*- coding: utf-8 -*-
"""Mixium A31 — Evolution Engine (Kendini geliştirme çekirdeği).

Sistemi analiz eder; eksik özellikler, mimari problemler, performans sorunları,
güvenlik riskleri ve UX sorunları bulur; geliştirme önerileri + öncelik sırası +
teknik plan üretir. Sadece öneri üretir; kritik sistem değişikliği YAPMAZ.
Provider-enjeksiyonlu.
"""

import time


class EvolutionEngine:
    def __init__(self, providers=None):
        self.providers = dict(providers or {})

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn() if callable(fn) else fn
            return default if v is None else v
        except Exception:
            return default

    def _issues(self):
        issues = []
        # mimari / performans / güvenlik / UX sinyalleri
        arch = self._get("architecture", {})
        perf = self._get("performance", {})
        security = self._get("security", {})
        ux = self._get("ux", {})
        health = self._get("health", {})
        for label, src in (("architecture", arch), ("performance", perf),
                           ("security", security), ("ux", ux)):
            if isinstance(src, dict):
                for k in ("issues", "warnings", "errors", "risks", "problems"):
                    vals = src.get(k) or []
                    for v in (vals if isinstance(vals, list) else [vals]):
                        issues.append({"area": label, "issue": v})
            elif isinstance(src, list):
                for v in src:
                    issues.append({"area": label, "issue": v})
        if isinstance(health, dict) and health.get("system_health", 100) < 60:
            issues.append({"area": "health", "issue": "düşük sistem sağlığı: %s" % health.get("system_health")})
        return issues

    def analyze(self):
        issues = self._issues()
        suggestions = []
        for i, it in enumerate(issues):
            suggestions.append({
                "priority": max(1, 5 - (i // 3)),  # basit öncelik (1 yüksek)
                "area": it.get("area"),
                "issue": str(it.get("issue"))[:200],
                "plan": "İncele → kök sebep → checkpoint → güvenli değişiklik → test → doğrula",
            })
        return {
            "issues": issues,
            "suggestions": suggestions,
            "t": time.time(),
        }

    def status(self):
        return {"suggestions": len(self.analyze()["suggestions"]),
                "areas": ["architecture", "performance", "security", "ux", "health"]}

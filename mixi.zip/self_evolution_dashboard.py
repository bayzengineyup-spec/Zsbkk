# -*- coding: utf-8 -*-
"""Mixium A31 — Self Evolution Dashboard (Kendini geliştirme paneli).

Sistem sağlık skoru, gelişim önerileri, bulunan sorunlar, tamamlanan
iyileştirmeler, gelecek planları, kalite değişimi. UI-independent, read-only.
Provider-enjeksiyonlu.
"""

import time


class SelfEvolutionDashboard:
    def __init__(self, providers=None):
        self.providers = dict(providers or {})

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn() if callable(fn) else fn
            return default if v is None else v
        except Exception:
            return default

    def status(self):
        health = self._get("health", {})
        evolution = self._get("evolution", {})
        issues = self._get("issues", [])
        improvements = self._get("improvements", [])
        future = self._get("future", {})
        quality = self._get("quality", {})
        # kalite değişimi (önceki/şimdiki skor)
        prev = quality.get("before") if isinstance(quality, dict) else None
        now = quality.get("after") if isinstance(quality, dict) else None
        growth = None
        if isinstance(prev, (int, float)) and isinstance(now, (int, float)):
            growth = round(float(now) - float(prev), 1)
        return {
            "system_health": health.get("system_health", 50) if isinstance(health, dict) else 50,
            "suggestions": (evolution or {}).get("suggestions", []),
            "found_issues": issues,
            "completed_improvements": improvements,
            "future_plans": future,
            "quality_change": {"before": prev, "after": now, "growth": growth},
            "generated_at": time.time(),
        }

# -*- coding: utf-8 -*-
"""
Mixium — MCP stdio client (pure-Python JSON-RPC)

Claude Code `@modelcontextprotocol/sdk` `client.ts` + `StdioClientTransport`
mantığının Mixium adaptasyonu. Sıfır harici bağımlılık (yalnızca stdlib).

Desteklenen lifecycle:
    connect() -> initialize() -> list_tools() -> call_tool() -> close()

JSON-RPC framing (LSP/MCP ortak kuralı):
    Content-Length: <n>\r\n\r\n<json-payload>
"""

import json
import os
import subprocess
import threading


class MCPError(Exception):
    """MCP bağlantı / protokol hatası."""


class MCPClient:
    """Tek bir stdio MCP sunucusuyla konuşan JSON-RPC istemcisi.

    Thread-safe: istek yazma+okuma döngüsü bir kilit altında çalışır, böylece
    aynı sunucuya farklı thread'lerden (ör. background agent) gelen istekler
    birbirine karışmaz.
    """

    def __init__(self, name, command, args=None, env=None, timeout=30):
        self.name = name
        self.command = command
        self.args = list(args or [])
        self.env = dict(os.environ)
        if env:
            self.env.update({str(k): str(v) for k, v in env.items()})
        self.timeout = timeout
        self.proc = None
        self.server_info = None
        self.tools = []
        self._lock = threading.Lock()
        self._next_id = 0

    # ---- JSON-RPC framing ----
    @staticmethod
    def _frame(msg):
        body = json.dumps(msg, ensure_ascii=False).encode("utf-8")
        return (b"Content-Length: " + str(len(body)).encode("utf-8") +
                b"\r\n\r\n" + body)

    @staticmethod
    def _read_frame(stream):
        headers = b""
        while b"\r\n\r\n" not in headers:
            chunk = stream.read(1)
            if not chunk:
                raise MCPError("baglanti kapandi (header okuma)")
            headers += chunk
        header_text = headers.decode("utf-8", "replace")
        length = None
        for line in header_text.split("\r\n"):
            if line.lower().startswith("content-length:"):
                try:
                    length = int(line.split(":", 1)[1].strip())
                except ValueError:
                    raise MCPError("gecersiz Content-Length")
        if length is None:
            raise MCPError("Content-Length header yok")
        body = b""
        while len(body) < length:
            chunk = stream.read(length - len(body))
            if not chunk:
                raise MCPError("baglanti kapandi (body okuma)")
            body += chunk
        try:
            return json.loads(body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as e:
            raise MCPError("bozuk JSON yanit: %s" % e)

    def _send(self, method, params=None):
        """İstek gönder, kendi id'li yanıtı döndür.

        Sunucudan gelen notification (id yok) yok sayılır; server->client
        isteği (method + id) desteklenmiyor diye hata ile yanıtlanır.
        """
        with self._lock:
            if self.proc is None or self.proc.poll() is not None:
                raise MCPError("sunucu sureci calismiyor")
            self._next_id += 1
            req_id = self._next_id
            self.proc.stdin.write(self._frame({
                "jsonrpc": "2.0", "id": req_id,
                "method": method, "params": params or {},
            }))
            self.proc.stdin.flush()
            while True:
                resp = self._read_frame(self.proc.stdout)
                rid = resp.get("id")
                if rid == req_id:
                    if "error" in resp:
                        err = resp["error"]
                        raise MCPError(str(err.get("message") or err))
                    return resp.get("result")
                if "method" in resp and rid is not None:
                    # server -> client isteği: desteklenmiyor (fail-closed)
                    self.proc.stdin.write(self._frame({
                        "jsonrpc": "2.0", "id": rid,
                        "error": {"code": -32601,
                                  "message": "Method not supported by Mixium"},
                    }))
                    self.proc.stdin.flush()
                # notification (id yok) -> yok say

    # ---- lifecycle ----
    def connect(self):
        self.proc = subprocess.Popen(
            [self.command] + self.args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=self.env,
        )
        return self

    def initialize(self):
        self.server_info = self._send("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "mixium", "version": "1.0"},
        })
        # initialized bildirimi (fire-and-forget)
        with self._lock:
            self.proc.stdin.write(self._frame({
                "jsonrpc": "2.0", "method": "notifications/initialized",
                "params": {},
            }))
            self.proc.stdin.flush()
        return self.server_info

    def list_tools(self):
        result = self._send("tools/list", {})
        if isinstance(result, dict):
            self.tools = result.get("tools", []) or []
        else:
            self.tools = []
        return self.tools

    def call_tool(self, tool_name, arguments=None):
        return self._send("tools/call", {
            "name": tool_name, "arguments": arguments or {},
        })

    def close(self):
        with self._lock:
            if self.proc is None:
                return
            p = self.proc
            self.proc = None
            try:
                p.stdin.close()
            except Exception:
                pass
            try:
                p.wait(timeout=2)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

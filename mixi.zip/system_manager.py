# -*- coding: utf-8 -*-
"""Mixium — Autonomous System Manager (Aşama 18).

The manager orchestrates existing components through injected callbacks. It
cannot alter the security core directly. Critical operations require the full
permission -> checkpoint -> approval -> action -> verify/rollback contract.
"""
import threading
import time

CRITICAL_OPERATIONS = frozenset({
    "permission_change", "sandbox_change", "security_change", "delete_main",
    "config_change", "model_role_assignment", "rollback", "restore", "commit", "reset",
})


class SystemManager:
    def __init__(self, operations=None, permission_fn=None, approval_fn=None,
                 checkpoint_fn=None, rollback_fn=None):
        self.operations = dict(operations or {})
        self.permission_fn = permission_fn or (lambda op, args=None: (False, "permission callback yok"))
        self.approval_fn = approval_fn or (lambda op, args=None: (False, "approval callback yok"))
        self.checkpoint_fn = checkpoint_fn or (lambda op, args=None: {})
        self.rollback_fn = rollback_fn or (lambda checkpoint, op, args=None: None)
        self._lock = threading.RLock()
        self._history = []

    def register(self, name, operation):
        if not name or not callable(operation):
            return False
        with self._lock:
            self.operations[str(name)] = operation
        return True

    def status(self):
        with self._lock:
            return {"operations": sorted(self.operations),
                    "critical_operations": sorted(CRITICAL_OPERATIONS),
                    "history": list(self._history[-20:])}

    def _gate(self, operation, args):
        try:
            result = self.permission_fn(operation, args)
            return result if isinstance(result, tuple) else (bool(result), "")
        except Exception as exc:
            return False, "permission hatası: %s" % exc

    def execute(self, operation, args=None, critical=None):
        """Execute an existing callback, fail-closed on unknown/gated actions."""
        args = dict(args or {})
        if operation not in self.operations:
            return {"status": "rejected", "stage": "operation", "error": "bilinmeyen işlem"}
        is_critical = operation in CRITICAL_OPERATIONS if critical is None else bool(critical)
        allowed, reason = self._gate(operation, args)
        if not allowed:
            return {"status": "rejected", "stage": "permission", "error": reason}
        checkpoint = None
        if is_critical:
            try:
                checkpoint = self.checkpoint_fn(operation, args)
            except Exception as exc:
                return {"status": "rejected", "stage": "checkpoint", "error": str(exc)[:300]}
            try:
                approved, reason = self.approval_fn(operation, args)
                if not approved:
                    return {"status": "rejected", "stage": "approval", "error": reason}
            except Exception as exc:
                return {"status": "rejected", "stage": "approval", "error": str(exc)[:300]}
        try:
            value = self.operations[operation](args)
            if isinstance(value, dict) and value.get("ok") is False:
                raise RuntimeError(value.get("error", "işlem başarısız"))
            result = {"status": "completed", "operation": operation, "result": value}
            self._record(operation, result)
            return result
        except Exception as exc:
            if is_critical and checkpoint is not None:
                try:
                    self.rollback_fn(checkpoint, operation, args)
                except Exception:
                    pass
            result = {"status": "rolled_back" if is_critical else "failed",
                      "operation": operation, "error": "%s: %s" % (type(exc).__name__, exc)}
            self._record(operation, result)
            return result

    def _record(self, operation, result):
        with self._lock:
            self._history.append({"operation": operation, "status": result.get("status"),
                                  "time": time.time(), "error": result.get("error", "")[:200]})
            self._history = self._history[-100:]

    def health(self):
        return self.execute("health_check", {}, critical=False)

    def pause(self, name):
        return self.execute("pause:" + name, {}, critical=False)

    def resume(self, name):
        return self.execute("resume:" + name, {}, critical=False)

    def run_tests(self):
        return self.execute("run_tests", {}, critical=False)

    def clear_cache(self):
        return self.execute("clear_cache", {}, critical=False)

    def archive(self):
        return self.execute("archive", {}, critical=False)

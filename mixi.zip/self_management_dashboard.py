# -*- coding: utf-8 -*-
"""Mixium — Self Management Dashboard API (Aşama 18).

UI-independent, read-only aggregation. Existing frontend/panel contracts are
not changed; this produces data that can be exposed by a future panel adapter.
"""
import time


class SelfManagementDashboard:
    def __init__(self, management=None, governance=None, providers=None):
        self.management = management
        self.governance = governance
        self.providers = dict(providers or {})

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            value = fn() if callable(fn) else fn
            return default if value is None else value
        except Exception:
            return default

    def status(self):
        health = {}
        if self.management is not None:
            try:
                health = self.management.snapshot()
            except Exception as exc:
                health = {"system_health": 0, "errors": [{"component": "dashboard", "message": str(exc)}]}
        return {
            "system_health": health.get("system_health", 50),
            "components": health.get("components", {}),
            "active_agents": health.get("active_agents", []),
            "memory_status": health.get("memory_status", {}),
            "learning_status": health.get("learning_status", {}),
            "errors": health.get("errors", []),
            "warnings": health.get("warnings", []),
            "recommendations": health.get("recommendations", []),
            "model_governance": self.governance.status() if self.governance else {},
            "dna": self._get("dna", {}),
            "knowledge": self._get("knowledge", {}),
            "research": self._get("research", {}),
            "performance": self._get("performance", {}),
            "improvements": self._get("improvements", []),
            # Aşama 19 executive layer: optional providers preserve the A18 API.
            "goals": self._get("goals", {}),
            "chief": self._get("chief", {}),
            "observer": self._get("observer", {}),
            "experiences": self._get("experiences", {}),
            "scheduler": self._get("scheduler", {}),
            # Aşama 20 society layer: optional providers preserve the A18 API.
            "society": self._get("society", {}),
            "reputation": self._get("reputation", {}),
            "strategic": self._get("strategic", {}),
            "project": self._get("project", {}),
            "decision": self._get("decision", {}),
            # Aşama 22 AGI layer: optional providers preserve the A18 API.
            "meta": self._get("meta", {}),
            "optimizer": self._get("optimizer", {}),
            "world_model": self._get("world_model", {}),
            "reasoning": self._get("reasoning", {}),
            "project_execution": self._get("project_execution", {}),
            "failure": self._get("failure", {}),
            "human_model": self._get("human_model", {}),
            # Aşama 23 OS core: optional providers preserve the A18 API.
            "autonomous_core": self._get("autonomous_core", {}),
            "task_autonomy": self._get("task_autonomy", {}),
            "supervisor": self._get("supervisor", {}),
            "long_execution": self._get("long_execution", {}),
            "debug": self._get("debug", {}),
            "consolidator": self._get("consolidator", {}),
            "real_mode": self._get("real_mode", {}),
            # Aşama 24 QA layer: optional providers preserve the A18 API.
            "human_sim": self._get("human_sim", {}),
            "product_test": self._get("product_test", {}),
            "web_reality": self._get("web_reality", {}),
            "logic_critic": self._get("logic_critic", {}),
            "bug_hunter": self._get("bug_hunter", {}),
            "test_campaign": self._get("test_campaign", {}),
            "quality": self._get("quality", {}),
            "internal_operator": self._get("internal_operator", {}),
            # Aşama 25 SWE loop: optional providers preserve the A18 API.
            "autonomous_fix": self._get("autonomous_fix", {}),
            "engineer": self._get("engineer", {}),
            "debug_cycle": self._get("debug_cycle", {}),
            "auto_test": self._get("auto_test", {}),
            "improvement_memory": self._get("improvement_memory", {}),
            "night_mode": self._get("night_mode", {}),
            # Aşama 26+27+28: optional providers preserve the A18 API.
            "senior_engineer": self._get("senior_engineer", {}),
            "code_review": self._get("code_review", {}),
            "engineering_memory": self._get("engineering_memory", {}),
            "engineer_sim": self._get("engineer_sim", {}),
            "product_owner": self._get("product_owner", {}),
            "ux_reality": self._get("ux_reality", {}),
            "full_product_test": self._get("full_product_test", {}),
            "deep_bug_hunter": self._get("deep_bug_hunter", {}),
            "mission_controller": self._get("mission_controller", {}),
            "continuous_improvement": self._get("continuous_improvement", {}),
            "system_intelligence": self._get("system_intelligence", {}),
            "deep_learning": self._get("deep_learning", {}),
            # Aşama 29+30+31: optional providers preserve the A18 API.
            "persistent_runtime": self._get("persistent_runtime", {}),
            "mission_queue": self._get("mission_queue", {}),
            "resource_manager": self._get("resource_manager", {}),
            "autonomous_recovery": self._get("autonomous_recovery", {}),
            "long_term_context": self._get("long_term_context", {}),
            "human_browser": self._get("human_browser", {}),
            "ux_stress": self._get("ux_stress", {}),
            "full_reality": self._get("full_reality", {}),
            "human_bug_report": self._get("human_bug_report", {}),
            "evolution_engine": self._get("evolution_engine", {}),
            "architecture_intelligence": self._get("architecture_intelligence", {}),
            "future_planner": self._get("future_planner", {}),
            "self_evolution": self._get("self_evolution", {}),
            "generated_at": time.time(),
        }

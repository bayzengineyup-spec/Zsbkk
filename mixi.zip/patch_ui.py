#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=========================================================
Calistir:  python3 patch_ui.py     (idempotent)
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
IDX = HERE / "web" / "index.html"
if not IDX.exists():
    print("index.html yok:", IDX); sys.exit(1)

s = IDX.read_text(encoding="utf-8")
orig = s
done = []

# ── 1) CSS dosyalarini <head>'e bagla ──────────────────────────
if 'href="theme.css"' not in s:
    s = s.replace("</head>",
        '<link rel="stylesheet" href="theme.css">\n'
        '<link rel="stylesheet" href="panel.css">\n'
        '</head>', 1)
    done.append("css link")

# ── 2) JS dosyalarini </body> oncesine bagla ───────────────────
    s = s.replace("</body>",
        '<script src="panel.js"></script>\n'
        '<script src="ui-boot.js"></script>\n'
        '</body>', 1)
    done.append("js link")

# ── 3) yan menuye Yonetim Paneli butonu ────────────────────────
if 'id="panelBtn"' not in s:
    btn = ('''  <button id="panelBtn" title="Yönetim paneli (Ctrl+Shift+P)">
    <svg width="15" height="15" viewBox="0 0 16 16" fill="none"
         stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
         stroke-linejoin="round">
      <rect x="1.8" y="2.4" width="12.4" height="11.2" rx="1.6"/>
      <path d="M1.8 6h12.4M5.4 6v7.6"/>
      <path d="M8 8.4h4M8 10.8h2.6"/>
    </svg>
    <span>Yönetim Paneli</span>
    <span class="kbd">⇧⌘P</span>
  </button>
''')
    s = s.replace('  <div id="sessTitle">Oturumlar</div>',
                  btn + '  <div id="sessTitle">Oturumlar</div>', 1)
    done.append("panel button")

    s = s.replace(
        '      <div id="status">\n        <span class="spin"></span>',
        '      <div id="status">\n'
        '        <span class="spin"></span>', 1)

if s != orig:
    IDX.write_text(s, encoding="utf-8")
    print("index.html yamalandi:", ", ".join(done))
else:
    print("index.html zaten yamali")

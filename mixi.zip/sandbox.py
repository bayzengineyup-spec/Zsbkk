#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mixium — Sandbox Adapter + Safe Execution Layer (Aşama 6B / E5)
=================================================================
Claude Code sandbox-adapter.ts + @anthropic-ai/sandbox-runtime mantığının
Mixium adaptasyonu. GERÇEK motor garanti DEĞİLDİR:

  · Linux'ta bubblewrap (bwrap), macOS'ta sandbox-exec tespit edilir.
  · Backend varsa gerçek OS sandbox kullanılır.
  · Backend yoksa (Termux/Android/PRoot) "soft sandbox" fallback'e düşülür:
      - mevcut workspace + sensitive kontrolleri (mixium_new.hard_gate) KORUNUR,
      - tehlikeli env değişkenleri (LD_PRELOAD, BASH_ENV, NODE_OPTIONS, ...)
        subprocess ortamından temizlenir (defense-in-depth),
      - fail_if_unavailable=True ise yazıcı bash reddedilir.
  · Sandbox, Permission engine'in ÜZERİNE eklenir; onun yerine geçmez.

Konfig modeli (Claude Code SandboxRuntimeConfig adaptasyonu):
  allow_read / deny_read / allow_write / deny_write / network_enabled /
  fail_if_unavailable
"""
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

# ══════════════════════════════════════════════════════════════════════
#  KONFIG MODELİ
# ══════════════════════════════════════════════════════════════════════
class SandboxConfig:
    """allow_read / deny_read / allow_write / deny_write / network_enabled /
    fail_if_unavailable (Claude Code SandboxRuntimeConfig adaptasyonu)."""

    def __init__(self, allow_read=None, deny_read=None, allow_write=None,
                 deny_write=None, network_enabled=True,
                 fail_if_unavailable=False):
        self.allow_read = list(allow_read or [])
        self.deny_read = list(deny_read or [])
        self.allow_write = list(allow_write or [])
        self.deny_write = list(deny_write or [])
        self.network_enabled = bool(network_enabled)
        self.fail_if_unavailable = bool(fail_if_unavailable)

    def to_dict(self):
        return {
            "allow_read": list(self.allow_read),
            "deny_read": list(self.deny_read),
            "allow_write": list(self.allow_write),
            "deny_write": list(self.deny_write),
            "network_enabled": bool(self.network_enabled),
            "fail_if_unavailable": bool(self.fail_if_unavailable),
        }

    @classmethod
    def from_dict(cls, d):
        d = d or {}
        return cls(
            allow_read=d.get("allow_read"),
            deny_read=d.get("deny_read"),
            allow_write=d.get("allow_write"),
            deny_write=d.get("deny_write"),
            network_enabled=d.get("network_enabled", True),
            fail_if_unavailable=d.get("fail_if_unavailable", False),
        )


# ══════════════════════════════════════════════════════════════════════
#  ORTAM TESPİTİ
# ══════════════════════════════════════════════════════════════════════
_BWRAP = shutil.which("bwrap") or shutil.which("bubblewrap")
_SEATBELT = shutil.which("sandbox-exec")

_bwrap_checked = {"done": False, "works": False}


def _bwrap_works():
    """bwrap binary'si varsa gerçekten çalışıyor mu? (lazy, tek seferlik)."""
    if _bwrap_checked["done"]:
        return _bwrap_checked["works"]
    _bwrap_checked["done"] = True
    if not _BWRAP:
        _bwrap_checked["works"] = False
        return False
    try:
        r = subprocess.run([_BWRAP, "--ro-bind", "/", "/", "--", "true"],
                           capture_output=True, timeout=10)
        _bwrap_checked["works"] = (r.returncode == 0)
    except Exception:
        _bwrap_checked["works"] = False
    return _bwrap_checked["works"]


def detect_backend():
    """'bwrap' | 'seatbelt' | None (unavailable)."""
    if _BWRAP and _bwrap_works():
        return "bwrap"
    if _SEATBELT:
        return "seatbelt"
    return None


def is_available():
    return detect_backend() is not None


# ══════════════════════════════════════════════════════════════════════
#  SOFT SANDBOX: tehlikeli env temizliği
# ══════════════════════════════════════════════════════════════════════
# Kod yükleme / başlatma dosyası değişkenleri (Claude Code SAFE_ENV_VARS
# yorumundaki "ASLA izin verilmemeli" listesi). LD_LIBRARY_PATH bilinçli
# olarak korunur (Android/Termux'ta meşru native kütüphane yolları).
DANGEROUS_ENV = {
    "LD_PRELOAD", "BASH_ENV", "ENV", "PYTHONPATH", "PYTHONSTARTUP",
    "NODE_OPTIONS", "RUBYOPT", "RUBYLIB", "PERL5LIB", "GIT_CONFIG_PARAMETERS",
    "DYLD_INSERT_LIBRARIES", "GOFLAGS", "RUSTFLAGS", "CLASSPATH", "PYTHONHOME",
}


def sanitized_env():
    """Tehlikeli env değişkenlerinden arındırılmış ortam sözlüğü."""
    env = os.environ.copy()
    for k in DANGEROUS_ENV:
        env.pop(k, None)
    return env


# ══════════════════════════════════════════════════════════════════════
#  YOL YARDIMCISI (file tool'ları için deny_write kararı)
# ══════════════════════════════════════════════════════════════════════
def path_denied_for_write(path, config):
    """Bir yol config.deny_write altındaysa eşleşen kalıbı döndürür."""
    if not config or not config.deny_write:
        return None
    try:
        rp = str(Path(str(path)).expanduser().resolve())
    except Exception:
        rp = str(path)
    rp_parents = [str(x) for x in Path(rp).parents]
    for d in config.deny_write:
        try:
            rd = str(Path(str(d)).expanduser().resolve()).rstrip("/")
        except Exception:
            rd = str(d).rstrip("/")
        if rp == rd or rp.startswith(rd + "/") or rd in rp_parents:
            return d
    return None


# ══════════════════════════════════════════════════════════════════════
#  SANDWBOX MOTORU
# ══════════════════════════════════════════════════════════════════════
class SandboxEngine:
    """Karar (decide) + sarmalama (wrap) motoru."""

    def __init__(self, config=None):
        self.config = config or SandboxConfig()

    @property
    def backend(self):
        return detect_backend()

    @property
    def available(self):
        return self.backend is not None

    def decide(self, command, is_read=False):
        """(use_sandbox, error) döndürür.
        use_sandbox=True → wrap() gerçek sarmalayıcı döndürür.
        error doluysa komut reddedilmelidir (fail-closed)."""
        b = self.backend
        if b:
            return True, None
        # Sandbox yok → soft fallback
        if self.config.fail_if_unavailable and not is_read:
            return False, ("sandbox kullanılamıyor (fail_if_unavailable=true) — "
                           "yazıcı komut reddedildi")
        return False, None

    def wrap(self, command, cwd=None):
        """Gerçek sandbox sarmalayıcısını argv listesi olarak döndürür;
        backend yoksa veya sarmalama başarısızsa None (soft fallback)."""
        b = self.backend
        if b == "bwrap":
            return self._wrap_bwrap(command, cwd)
        if b == "seatbelt":
            return self._wrap_seatbelt(command, cwd)
        return None

    # ── bwrap (Linux / WSL2) ───────────────────────────────────────────
    def _wrap_bwrap(self, command, cwd=None):
        cwd = cwd or "."
        args = [_BWRAP, "--die-with-parent",
                "--ro-bind", "/", "/",
                "--dev", "/dev",
                "--proc", "/proc",
                "--tmpfs", "/tmp"]
        writes = set(self.config.allow_write or [])
        writes.add(str(cwd))
        for w in sorted(writes):
            w = str(w)
            if w and Path(w).exists():
                args += ["--bind", w, w]
        for d in sorted(set(self.config.deny_write or [])):
            d = str(d)
            if d and Path(d).exists():
                args += ["--ro-bind", d, d]
        if not self.config.network_enabled:
            args += ["--unshare-net"]
        args += ["--chdir", str(cwd), "--", "/bin/sh", "-c", command]
        return args

    # ── seatbelt (macOS) — minimal profil, best-effort ─────────────────
    def _wrap_seatbelt(self, command, cwd=None):
        lines = ["(version 1)", "(allow default)"]
        if not self.config.network_enabled:
            lines.append("(deny network*)")
        for d in self.config.deny_write or []:
            lines.append('(deny file-write* (subpath "%s"))' % d)
        if cwd:
            lines.append('(allow file-write* (subpath "%s"))' % cwd)
        prof = "\n".join(lines) + "\n"
        try:
            fd, path = tempfile.mkstemp(suffix=".sb", prefix="mixium-sandbox-")
            with os.fdopen(fd, "w") as f:
                f.write(prof)
        except Exception:
            return None
        return [_SEATBELT, "-p", path, "/bin/sh", "-c", command]


# Modül seviyesinde kullanım kolaylığı
def status_string(config=None):
    """Kullanıcıya gösterilecek tek satırlık durum özeti."""
    b = detect_backend()
    if b:
        return f"sandbox: {b} (aktif)"
    if config and config.fail_if_unavailable:
        return "sandbox: kullanılamıyor (fail_if_unavailable — yazıcı komutlar engelli)"
    return "sandbox: yok — soft fallback (workspace + sensitive + env temizliği)"

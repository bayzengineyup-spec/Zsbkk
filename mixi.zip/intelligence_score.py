# -*- coding: utf-8 -*-
"""
Mixium — Intelligence Scoring System (Aşama 14D)

Sistem kendisini ölçer. Ölçümler (0-100, enjekte edilen metrikler):
    coding_quality / architecture_quality / bug_rate (düşük iyi) /
    test_success / decision_quality / research_accuracy

Çıktı: {intelligence_score:0-100, strengths[], weaknesses[], improvement_plan[]}.
Deterministik ağırlıklı skor (sayı uydurulmaz). MIXIUM'a bağımlı değildir.
"""


class IntelligenceScorer:
    WEIGHTS = (("coding_quality", "Kod kalitesi", 0.25),
               ("architecture_quality", "Mimari kalite", 0.20),
               ("bug_rate", "Hata oranı (düşük iyi)", 0.15),
               ("test_success", "Test başarısı", 0.15),
               ("decision_quality", "Karar kalitesi", 0.15),
               ("research_accuracy", "Araştırma doğruluğu", 0.10))

    @staticmethod
    def _val(metrics, key, default=50):
        try:
            return max(0, min(100, int(metrics.get(key, default))))
        except Exception:
            return default

    def evaluate(self, metrics):
        metrics = metrics or {}
        coding = self._val(metrics, "coding_quality")
        arch = self._val(metrics, "architecture_quality")
        bug = self._val(metrics, "bug_rate")            # düşük iyi
        test = self._val(metrics, "test_success")
        decision = self._val(metrics, "decision_quality")
        research = self._val(metrics, "research_accuracy")
        bug_score = max(0, 100 - bug)

        score = int(0.25 * coding + 0.20 * arch + 0.15 * bug_score +
                    0.15 * test + 0.15 * decision + 0.10 * research)

        strengths, weaknesses, plan = [], [], []
        for key, label, _w in self.WEIGHTS:
            v = {"coding_quality": coding, "architecture_quality": arch,
                 "bug_rate": bug_score, "test_success": test,
                 "decision_quality": decision, "research_accuracy": research}[key]
            (strengths if v >= 70 else weaknesses).append(label)
            if v < 70:
                plan.append("%s geliştir (skor %d)" % (label, v))

        return {"intelligence_score": score, "strengths": strengths,
                "weaknesses": weaknesses, "improvement_plan": plan}

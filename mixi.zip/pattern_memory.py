# -*- coding: utf-8 -*-
"""
Mixium — Expert Pattern Database (Aşama 15D)

Öğrenilen mühendislik kalıplarını saklar. Örnek:
    Pattern: "Large Python project architecture"
    Contains: [folder structure, module separation, testing strategy, ...]

Semantic retrieval destekler. MIXIUM'a bağımlı değildir.
"""

import json
import threading
import time
import uuid
from pathlib import Path

from episodic_memory import embed, cosine


class PatternMemory:
    def __init__(self, root="."):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".dna" / "patterns.json"
        self.patterns = []
        self._lock = threading.Lock()
        self._load()

    def _allowed(self):
        try:
            d = self.path.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def _load(self):
        try:
            if self.path.exists():
                self.patterns = json.loads(self.path.read_text("utf-8"))
        except Exception:
            self.patterns = []
        if not isinstance(self.patterns, list):
            self.patterns = []

    def _save(self):
        if not self._allowed():
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self.patterns, ensure_ascii=False),
                                 "utf-8")
        except Exception:
            pass

    def add_pattern(self, name, description, contains, source="", confidence=50):
        contains = [str(x)[:200] for x in (contains or [])]
        text = "%s: %s" % (name, "; ".join(contains))
        with self._lock:
            rec = {"id": uuid.uuid4().hex[:8], "name": str(name)[:200],
                   "description": str(description)[:1000],
                   "contains": contains,
                   "source": str(source)[:300],
                   "confidence": max(0, min(100, int(confidence))),
                   "ts": time.time(),
                   "embedding": [[int(i), float(x)]
                                 for i, x in embed(text).items()]}
            self.patterns.append(rec)
            if len(self.patterns) > 200:
                self.patterns = self.patterns[-200:]
            self._save()
            return rec

    def query(self, text, top_k=3):
        qv = embed(text)
        scored = []
        with self._lock:
            for r in self.patterns:
                e = {int(i): float(x) for i, x in (r.get("embedding") or [])}
                scored.append((cosine(qv, e), r))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [r for s, r in scored[:max(1, min(20, top_k))] if s > 0]

    def count(self):
        return len(self.patterns)

    def context_block(self, text, top_k=3):
        hits = self.query(text, top_k=top_k)
        if not hits:
            return ""
        lines = ["[PATTERN BAĞLAM]"]
        for r in hits:
            lines.append("- %s: %s" % (r["name"], ", ".join(r.get("contains", []))[:200]))
        return "\n".join(lines)

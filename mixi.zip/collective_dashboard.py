# -*- coding: utf-8 -*-
"""
Mixium — Collective Intelligence Dashboard (Aşama 15H)

Yönetim paneline READ-ONLY veri: knowledge count / sources / domains /
quality scores / learning activity / rejected knowledge / expert patterns.
UI/frontend DEĞİŞMEZ. MIXIUM'a bağımlı değildir.
"""

from pathlib import Path


class CollectiveDashboard:
    def __init__(self, root=".", expert_store=None, pattern_store=None,
                 validator=None, worker=None):
        self.root = Path(root).expanduser().resolve()
        self.expert_store = expert_store
        self.pattern_store = pattern_store
        self.validator = validator
        self.worker = worker

    def status(self):
        out = {
            "knowledge_count": 0,
            "sources": [],
            "domains": {},
            "quality_scores": [],
            "learning_activity": [],
            "rejected_knowledge": [],
            "expert_patterns": [],
        }
        if self.expert_store is not None:
            try:
                out["knowledge_count"] = self.expert_store.count()
                out["domains"] = self.expert_store.categories()
                recent = self.expert_store.recent(10)
                out["sources"] = list({r.get("source") for r in recent if r.get("source")})
                out["quality_scores"] = [{"domain": r["domain"],
                                          "score": r.get("quality_score", 0),
                                          "confidence": r.get("confidence", 0)}
                                         for r in recent]
            except Exception:
                pass
        if self.pattern_store is not None:
            try:
                out["expert_patterns"] = [
                    {"name": p["name"], "contains": p.get("contains", [])[:4]}
                    for p in self.pattern_store.patterns[-10:]]
            except Exception:
                pass
        if self.validator is not None:
            try:
                out["rejected_knowledge"] = [
                    {"knowledge": r.get("knowledge", "")[:80],
                     "reason": r.get("reason")}
                    for r in self.validator.rejected[-10:]]
            except Exception:
                pass
        if self.worker is not None:
            try:
                out["learning_activity"] = [
                    {"topic": h.get("topic"), "accepted": (h.get("result") or {}).get("accepted")}
                    for h in self.worker.recent(10)]
            except Exception:
                pass
        return out

# -*- coding: utf-8 -*-
"""
Mixium — Multi-Agent Orchestration (Aşama 10, 10B/10C/10G/10H)

- 10B Specialized agents: research / coding / testing / review (rol tanımları)
- 10C Orchestrator     : isteği analiz et -> rol seç -> dağıt -> topla -> birleştir
- 10G Rol bazlı limit  : read_only / allow_write / allow_execute (executor üzerinden)
- 10H ResultAggregator : {summary, changes, tests, warnings, next_steps};
                         çelişkide Review Agent öncelikli

Bu modül MIXIUM'A BAĞIMLI DEĞİLDİR. Araç çalıştırma `executor(tool, args)`
callable'ı üzerinden enjekte edilir -> mixium_new gerçek PERM+hard_gate+run_tool
ile bağlar. executor şu dict'i döndürür: {"ok": bool, "result": str, "error": str}.
"""

from agent_runtime import AgentRuntime

# 11E/12G — otonom LLM pipeline sırası (reviewer_plus son adım)
LLM_PIPELINE = ("architect", "research", "coding", "testing", "security",
                "review", "reviewer_plus")

# 13G — gerçek dünya pipeline'ı (Aşama 13); LLM_PIPELINE'dan AYRI.
REAL_WORLD_PIPELINE = ("planner", "research", "browser", "document",
                       "coding", "testing", "reviewer_plus", "report")


def _run_pipeline(goal, generate_fn, executor_factory, root, memory,
                  max_iterations, roles):
    """Ortak otonom zincir çalıştırıcı (LLM + real-world için)."""
    try:
        from agent_llm import AgentLLMRuntime
    except Exception:
        return {"ok": False, "error": "agent_llm.py bulunamadı"}
    runtime = AgentLLMRuntime(root=root, max_iterations=max_iterations)
    results = {}
    prev_summary = ""
    for role in roles:
        res = runtime.run_autonomous(
            goal, role, generate_fn, executor_factory(role),
            memory=memory, context={"previous": prev_summary})
        results[role] = res
        prev_summary = res.get("result", "")
    return results


def run_llm_pipeline(goal, generate_fn, executor_factory, root=".",
                     memory=None, max_iterations=10):
    """Aşama 11E: Architect -> ... -> Review otonom ajan zinciri.

    generate_fn(prompt, role, conversation) -> str
    executor_factory(role) -> executor(tool, args) -> {"ok","result","error"}
    Her ajan sonucu message payload olarak sıradakine aktarılır; ajanlar
    birbirinin memory'sine ERİŞEMEZ (yalnızca 'previous' özetini görür).
    """
    return _run_pipeline(goal, generate_fn, executor_factory, root, memory,
                         max_iterations, LLM_PIPELINE)


def run_real_world_pipeline(goal, generate_fn, executor_factory, root=".",
                            memory=None, max_iterations=10):
    """Aşama 13G: Planner -> Research -> Browser -> Document -> Coding ->
    Testing -> Reviewer++ -> Report gerçek dünya zinciri. LLM_PIPELINE'dan
    ayrıdır; aynı AgentLLMRuntime + persona/executor güvenlik zincirini
    kullanır (bypass yok).
    """
    return _run_pipeline(goal, generate_fn, executor_factory, root, memory,
                         max_iterations, REAL_WORLD_PIPELINE)


ROLES = {
    "research": {
        "description": "Kod keşfi: code_search, project_index, dependency_graph, LSP",
        "tools": ["project_index", "code_search", "dependency_graph",
                  "lsp_diagnostics", "grep", "glob", "read", "tree"],
        "read_only": True, "allow_write": False, "allow_execute": False,
    },
    "coding": {
        "description": "Uygulama: edit/write/multi_edit/patch + change tracker",
        "tools": ["write", "edit", "multi_edit", "patch"],
        "read_only": False, "allow_write": True, "allow_execute": False,
    },
    "testing": {
        "description": "Test: test_status + test çalıştırma + hata raporu",
        "tools": ["test_status", "bash"],
        "read_only": False, "allow_write": False, "allow_execute": True,
    },
    "review": {
        "description": "İnceleme: diff + güvenlik + kalite kontrolü",
        "tools": ["read", "git", "lsp_diagnostics", "code_search", "project_index"],
        "read_only": True, "allow_write": False, "allow_execute": False,
    },
}


def role_allowed(role, tool):
    info = ROLES.get(role)
    if not info:
        return False
    return tool in info.get("tools", [])


def role_info(role):
    return ROLES.get(role, {})


# ── specialized agent runners ──────────────────────────────────────────
def _research_runner(goal, ws, executor):
    out = {}
    for tool, args in (("project_index", {"path": ws}),
                       ("code_search", {"query": goal, "path": ws})):
        out[tool] = executor(tool, args)
    return out


def _coding_runner(goal, ws, executor, ops):
    changes = []
    for tool, args in (ops or []):
        r = executor(tool, args)
        changes.append({"tool": tool, "args": args, "result": r})
    return {"changes": changes}


def _testing_runner(goal, ws, executor):
    return {"tests": executor("test_status", {"path": ws})}


def _review_runner(goal, ws, executor, files):
    reads, warnings = [], []
    for f in (files or []):
        r = executor("read", {"path": f})
        reads.append({"file": f, "result": r})
        if not r.get("ok"):
            warnings.append("review: %s okunamadı: %s" % (f, r.get("error")))
    return {"reads": reads, "warnings": warnings}


class Orchestrator:
    """10C: analiz -> rol seç -> dağıt (paralel) -> topla -> merge."""

    def __init__(self, workspace=".", executor=None, runtime=None):
        self.workspace = workspace
        self.executor = executor or self._default_executor
        self.runtime = runtime or AgentRuntime()
        self.plan = []
        self.results = {}

    @staticmethod
    def _default_executor(tool, args):
        return {"ok": False, "result": "", "error": "executor bagli degil"}

    def analyze(self, request):
        """İsteğe göre gerekli rolleri seçer."""
        r = (request or "").lower()
        roles = []
        if any(k in r for k in ("ekle", "oluştur", "yaz", "implement", "düzelt",
                                "fix", "değiştir", "kod", "api", "bug")):
            roles += ["research", "coding"]
        else:
            roles.append("research")
        roles += ["testing", "review"]
        seen, out = set(), []
        for x in roles:
            if x not in seen:
                seen.add(x)
                out.append(x)
        self.plan = out
        return out

    def run(self, request, task=None):
        """Rolleri dispatch eder, tümünü bekler, sonuçları toplar."""
        roles = self.analyze(request)
        task = task or {}
        ws = self.workspace
        for role in roles:
            self.runtime.spawn(
                role, request, self.make_runner(role, task),
                context={"task": task}, tools=ROLES[role]["tools"])
        self.runtime.wait_all()
        for a in self.runtime.agents.values():
            self.results[a.role] = {
                "status": a.status, "result": a.result, "errors": a.errors}
        return self.results

    def run_single(self, role, goal, task=None):
        """Tek bir rolü çalıştır (agent_spawn aracı için)."""
        task = task or {}
        agent = self.runtime.spawn(
            role, goal, self.make_runner(role, task),
            context={"task": task}, tools=ROLES[role]["tools"])
        self.runtime.wait_all()
        return agent

    def make_runner(self, role, task):
        ws, ex = self.workspace, self.executor
        if role == "research":
            return lambda agent: _research_runner(agent.goal, ws, ex)
        if role == "coding":
            return lambda agent: _coding_runner(
                agent.goal, ws, ex, task.get("coding_ops", []))
        if role == "testing":
            return lambda agent: _testing_runner(agent.goal, ws, ex)
        if role == "review":
            return lambda agent: _review_runner(
                agent.goal, ws, ex, task.get("review_files", []))
        return lambda agent: {"ok": False, "error": "bilinmeyen rol: %s" % role}

    def merge(self):
        return ResultAggregator().merge(self.results)


class ResultAggregator:
    """10H: ajan sonuçlarını birleştirir. Çelişkide Review öncelikli."""

    def merge(self, results):
        results = results or {}
        changes, warnings, next_steps = [], [], []

        # coding -> changes
        coding = results.get("coding", {}).get("result") or {}
        for c in coding.get("changes", []) or []:
            r = c.get("result") or {}
            if r.get("ok"):
                changes.append({"tool": c.get("tool"),
                                "file": (c.get("args") or {}).get("path")})
            else:
                warnings.append("coding: %s -> %s" % (c.get("tool"),
                                                      r.get("error") or "hata"))

        # testing -> tests
        testing = results.get("testing", {}).get("result") or {}
        tests = testing.get("tests")
        if tests and not tests.get("ok"):
            warnings.append("testing: %s" % (tests.get("error") or "hata"))

        # review -> warnings (öncelikli)
        review = results.get("review", {}).get("result") or {}
        for w in review.get("warnings", []) or []:
            warnings.insert(0, w)

        # research -> next_steps
        research = results.get("research", {}).get("result") or {}
        cs = research.get("code_search") or {}
        if cs.get("ok"):
            next_steps.append("research: code_search tamam")

        n_ok = len(changes)
        summary = ("%d rol çalıştı, %d değişiklik, %d uyarı"
                   % (len(results), n_ok, len(warnings)))
        return {
            "summary": summary,
            "changes": changes,
            "tests": tests,
            "warnings": warnings,
            "next_steps": next_steps,
        }

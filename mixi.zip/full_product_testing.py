# -*- coding: utf-8 -*-
"""Mixium A27 — Full Application Test Campaign.

Frontend (buton/menü/sayfa/form/hata), Backend (API/tool/agent/memory/
streaming/session) ve uzun görevler (saatler süren işler, yarıda kesme,
devam, crash sonrası) için birleşik kampanya. Adapter'lar enjekte edilir.
"""

import time


class FullProductTesting:
    def __init__(self, adapters=None):
        self.adapters = dict(adapters or {})
        self.runs = []

    def _call(self, name, *args, **kw):
        fn = self.adapters.get(name)
        if fn is None:
            return None
        return fn(*args, **kw)

    def run(self, groups=None):
        groups = groups or ("frontend", "backend", "long_task")
        out = {"groups": {}, "passed": 0, "failed": 0, "skipped": 0, "total": 0}
        for g in groups:
            res = self._run_group(g)
            out["groups"][g] = res
            for r in res:
                out["total"] += 1
                st = r.get("status")
                if st == "PASS":
                    out["passed"] += 1
                elif st == "FAIL":
                    out["failed"] += 1
                else:
                    out["skipped"] += 1
        out["summary"] = "%d/%d PASS" % (out["passed"], out["total"])
        self.runs.append(out)
        return out

    def _run_group(self, group):
        def _chk(name, ok, desc=""):
            try:
                ok = bool(ok)
            except Exception as e:
                return {"name": name, "status": "FAIL", "desc": str(e)[:120]}
            return {"name": name, "status": "PASS" if ok else "FAIL", "desc": desc}

        if group == "frontend":
            btn = self.adapters.get("buttons")
            if btn is None:
                return [{"name": "buttons", "status": "SKIP", "desc": "frontend adapter yok"}]
            r = []
            for b in (btn() or []):
                r.append(_chk("button:%s" % b, self._call("click_button", b) is not None, b))
            return r or [_chk("frontend_empty", False, "buton listesi boş")]

        if group == "backend":
            api = self.adapters.get("api")
            tool = self.adapters.get("tool")
            mem = self.adapters.get("memory")
            stream = self.adapters.get("streaming")
            session = self.adapters.get("session")
            r = []
            if api is not None:
                r.append(_chk("api", self._call("api_call") is not None, "API yanıtı"))
            if tool is not None:
                r.append(_chk("tool", self._call("tool_call") is not None, "tool çağrısı"))
            if mem is not None:
                r.append(_chk("memory", self._call("memory_op") is not None, "memory"))
            if stream is not None:
                r.append(_chk("streaming", self._call("stream") is not None, "streaming"))
            if session is not None:
                r.append(_chk("session", self._call("session_op") is not None, "session"))
            return r or [{"name": "backend", "status": "SKIP", "desc": "backend adapter yok"}]

        # long_task
        long_fn = self.adapters.get("long_task")
        if long_fn is None:
            return [{"name": "long_task", "status": "SKIP", "desc": "long_task adapter yok"}]
        r = []
        r.append(_chk("long_start", long_fn("start") is not None, "başlat"))
        r.append(_chk("long_pause", long_fn("pause") is not None, "yarıda kesme"))
        r.append(_chk("long_resume", long_fn("resume") is not None, "devam"))
        r.append(_chk("long_recover", long_fn("recover") is not None, "crash sonrası"))
        return r

    def status(self):
        return {"runs": len(self.runs), "last": self.runs[-1] if self.runs else None}

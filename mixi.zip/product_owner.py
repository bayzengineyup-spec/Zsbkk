# -*- coding: utf-8 -*-
"""Mixium A27 — Product Owner Agent.

Bir özellik geldiğinde sorar: kullanıcı bunu neden ister, gerçek kullanım
senaryosu ne, eksik kalan yer var mı, daha basit çözüm mümkün mü. Deterministik
soru çerçevesi; model zekasını kısıtlamaz.
"""


class ProductOwnerAgent:
    def __init__(self, providers=None):
        self.providers = dict(providers or {})

    def analyze(self, feature):
        f = str(feature or "").strip()
        if not f:
            return {"error": "özellik açıklaması gerekli"}
        low = f.lower()
        # neden / değer
        value = []
        if "test" in low:
            value.append("kalite güvencesi / regresyon önleme")
        if "auth" in low or "giriş" in low or "login" in low:
            value.append("erişim kontrolü / güvenlik")
        if "performans" in low or "hız" in low:
            value.append("kullanıcı deneyimi / ölçeklenebilirlik")
        # basitlik
        simpler = []
        if len(f) > 200:
            simpler.append("kapsam daraltılabilir; MVP önceliklendir.")
        if " ve " in f or "," in f:
            simpler.append("çoklu istek içeriyor; tek tek ele al.")
        # eksik
        gaps = []
        if not any(k in low for k in ("test", "testi", "doğrula")):
            gaps.append("doğrulama/test kriteri belirtilmemiş")
        if not any(k in low for k in ("hata", "error", "rol", "izin")):
            gaps.append("hata/izin senaryosu belirtilmemiş")
        return {
            "feature": f,
            "why": value or ["genel kullanıcı değeri"],
            "use_cases": [{"scenario": s} for s in
                          ("birincil akış", "hata akışı", "uç durum")],
            "gaps": gaps or ["belirgin eksik yok"],
            "simpler_alternative": simpler or ["mevcut çözüm korunabilir"],
            "priority": "high" if gaps else "medium",
        }

    def status(self):
        return {"providers": list(self.providers.keys())}

# -*- coding: utf-8 -*-
"""
Mixium — Computer Use Layer (Aşama 13D)

GUI görevleri için ARAYÜZ + capability tespiti. Sahte mouse/keyboard ÜRETMEZ.

- available()      : DISPLAY / WAYLAND_DISPLAY / platform tespiti.
- screenshot/mouse/keyboard/window_state : her kritik işlem approve_fn
  (approval_gate) üzerinden geçer; gerçek motor yoksa fail-closed HATA.

Termux/Android headless ortamında `available() == False` -> "unavailable".
MIXIUM'a bağımlı değildir; gerçek motor exec_fn ile enjekte edilir (varsa).
"""

import os


class ComputerAgent:
    def __init__(self, approve_fn=None, exec_fn=None, display=None):
        self.approve_fn = approve_fn or (lambda action, args: (True, ""))
        self.exec_fn = exec_fn or (lambda action, args: "HATA: GUI motoru bağlı değil")
        self._display = display

    def available(self):
        if self._display is not None:
            return bool(self._display)
        return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))

    def _guard(self, action, args):
        if not self.available():
            return False, "HATA: computer use bu ortamda desteklenmiyor (DISPLAY yok)"
        ok, why = self.approve_fn(action, args)
        if not ok:
            return False, "onay gerekli — %s" % why
        return True, ""

    def _run(self, action, args):
        ok, why = self._guard(action, args)
        if not ok:
            return why
        try:
            return self.exec_fn(action, args)
        except Exception as e:
            return "HATA: %s: %s" % (type(e).__name__, e)

    def screenshot(self, path=None):
        return self._run("screenshot", {"path": path})

    def mouse(self, action, x=None, y=None):
        return self._run("mouse", {"action": action, "x": x, "y": y})

    def keyboard(self, keys):
        return self._run("keyboard", {"keys": keys})

    def window_state(self):
        return self._run("window_state", {})

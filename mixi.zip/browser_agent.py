# -*- coding: utf-8 -*-
"""
Mixium — Browser Agent (Aşama 13A)

Mevcut `t_browser` (Playwright) + `fetch` + (opsiyonel) MCP browser sunucusunun
üstüne İNCE bir yaşam döngüsü sarmalayıcısı. Yeni tarayıcı motoru GETİRMEZ.

Fonksiyonlar: open / navigate / click / type / wait / extract_text /
screenshot / close.

Motor sırası (fallback):
  1. Playwright (browser_fn)          — mevcut t_browser
  2. MCP browser (mcp_fn)             — mcp_add ile bağlanmışsa
  3. fetch (fetch_fn)                 — yalnızca metin (content/extract)

Riskli aksiyonlar (click / type / fill / submit) approve_fn üzerinden geçer
(approval_gate). MIXIUM'a bağımlı değildir; tüm fonksiyonlar enjekte edilir.
"""

RISKY_ACTIONS = ("click", "type", "fill", "submit", "press")


class BrowserAgent:
    def __init__(self, browser_fn=None, fetch_fn=None, mcp_fn=None,
                 approve_fn=None):
        self.browser_fn = browser_fn or (lambda action, args: "HATA: browser motoru yok")
        self.fetch_fn = fetch_fn or (lambda url: "HATA: fetch yok")
        self.mcp_fn = mcp_fn or (lambda action, args: "HATA: MCP browser yok")
        self.approve_fn = approve_fn or (lambda action, args: (True, ""))
        self._url = None

    def _exec(self, action, args):
        """Motor sırası: Playwright -> MCP -> fetch."""
        if self.browser_fn is not None:
            res = self.browser_fn(action, args)
            if not str(res).startswith("HATA"):
                return res
        if self.mcp_fn is not None:
            res = self.mcp_fn(action, args)
            if not str(res).startswith("HATA"):
                return res
        if action in ("content", "extract_text"):
            return self.fetch_fn(args.get("url") or self._url)
        return "HATA: tarayıcı motoru yok (Playwright/MCP/fetch)"

    def _risk(self, action, args):
        if action not in RISKY_ACTIONS:
            return ""
        ok, why = self.approve_fn(action, args)
        return "" if ok else why

    def open(self, url=None):
        self._url = url
        return ("browser açıldı" + (" → %s" % url if url else ""))

    def navigate(self, url):
        if not url:
            return "HATA: 'url' gerekli"
        self._url = url
        return self._exec("content", {"url": url})

    def click(self, selector):
        if not selector:
            return "HATA: 'selector' gerekli"
        why = self._risk("click", {"selector": selector, "url": self._url})
        if why:
            return "HATA: onay gerekli — %s" % why
        return self._exec("click", {"selector": selector, "url": self._url})

    def type(self, selector, value):
        if not selector:
            return "HATA: 'selector' gerekli"
        why = self._risk("type", {"selector": selector, "value": value, "url": self._url})
        if why:
            return "HATA: onay gerekli — %s" % why
        return self._exec("fill", {"selector": selector, "value": value,
                                   "url": self._url})

    def wait(self, seconds):
        s = max(0, min(30, int(seconds or 0)))
        return "beklendi: %ds" % s

    def extract_text(self):
        return self._exec("content", {"url": self._url})

    def screenshot(self, path=None):
        return self._exec("screenshot", {"path": path, "url": self._url})

    def close(self):
        self._url = None
        return "browser kapandı"

# -*- coding: utf-8 -*-
"""
Mixium — Expert Research Worker (Aşama 15G)

Arka planda çalışan ajan: yeni teknikleri araştırır, kaliteli projeleri
inceler, bilgi önerileri oluşturur. OTOMATİK sisteme ekleme YOK — önce
validation, sonra knowledge store.

run_once(topic) her istisnayı izole eder (crash recovery — worker düşmez).
MIXIUM'a bağımlı değildir; acquire_fn enjekte edilir.
"""

import time


class ExpertWorker:
    def __init__(self, acquire_fn=None, topics=()):
        self.acquire_fn = acquire_fn or (lambda t: {"ok": False, "error": "yok"})
        self.topics = list(topics)
        self.history = []

    def run_once(self, topic=None):
        topic = topic or (self.topics[0] if self.topics else "software design")
        try:
            r = self.acquire_fn(topic)
        except Exception as e:
            r = {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}
        rec = {"topic": topic, "ts": time.time(), "result": r}
        self.history.append(rec)
        if len(self.history) > 100:
            self.history = self.history[-100:]
        return rec

    def run_all(self):
        """Tüm konuları sırayla işler (her biri izole)."""
        out = []
        for t in self.topics:
            out.append(self.run_once(t))
        return out

    def recent(self, limit=20):
        return list(reversed(self.history[-limit:]))

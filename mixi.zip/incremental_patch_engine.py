"""Small-change patch helper. Prefer editing ranges over rewriting files."""

def apply_patch(text, old, new):
    if old not in text:
        return text, False
    return text.replace(old,new,1), True

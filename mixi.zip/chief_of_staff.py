# -*- coding: utf-8 -*-
"""Mixium — Personal AI Chief of Staff (Aşama 19B)."""


class ChiefOfStaff:
    def __init__(self, goals=None, tasks=None, experiences=None, observer=None):
        self.goals = goals
        self.tasks = tasks
        self.experiences = experiences
        self.observer = observer

    def status(self):
        goals = self.goals.list_goals() if self.goals else []
        tasks = self.tasks() if callable(self.tasks) else (self.tasks or [])
        unfinished = [t for t in tasks if isinstance(t, dict) and t.get("status") not in ("completed", "cancelled")]
        priorities = sorted([g for g in goals if g.get("status") == "active"], key=lambda g: -g.get("priority", 0))[:10]
        warnings = []
        if self.observer:
            try: warnings.extend(self.observer.status().get("warnings", [])[-5:])
            except Exception: pass
        recommendations = []
        for g in priorities[:3]:
            recommendations.append(g.get("title", "Hedef") + ": " + self.goals.suggest_next_action(g["id"]))
        if unfinished: recommendations.append("Yarım kalan görevleri önce tamamla veya yeniden planla.")
        return {"priorities": priorities, "unfinished_tasks": unfinished[:20],
                "recommendations": recommendations[:10], "warnings": warnings}

# -*- coding: utf-8 -*-
"""
Mixium — B3: Continuous Learning Brain

Arka planda çalışan öğrenme işçisi. Araştırma sonuçlarını analiz eder,
önemli bilgileri çıkarır ve DNA / Expert Knowledge depolarına aktarır.

Kaynak filtresi: Kaynak Kalitesi + Güvenilirlik + Teknik Derinlik + Tekrar Kontrolü.
Her şeyi kaydetmez. Hata → job FAILED (sistem düşmez).
"""

import json
import threading
import time
from pathlib import Path

MIN_SOURCE_SCORE = 0.55
MAX_JOBS = 50


class LearningWorker:
    """Basit background learning işçisi (daemon uyumlu run_cycle)."""

    def __init__(self, root=".", store=None, validator=None,
                 research_fn=None, on_extract=None):
        self.root = Path(root)
        self.dir = self.root / ".mixium" / "learning"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.store = store                # DNAStore / ExpertKnowledgeStore
        self.validator = validator or (lambda k, src, conf: conf >= MIN_SOURCE_SCORE)
        self.research_fn = research_fn    # (query) -> list[dict]
        self.on_extract = on_extract      # (knowledge, category, source, confidence)
        self._lock = threading.RLock()
        self._jobs = {}
        self._seen = set()
        self._load()

    def _load(self):
        p = self.dir / "jobs.json"
        if p.exists():
            try:
                self._jobs = json.loads(p.read_text(encoding="utf-8"))
                self._seen = set(self._jobs.keys())
            except Exception:
                pass

    def _save(self):
        tmp = self.dir / "jobs.json.tmp"
        tmp.write_text(json.dumps(self._jobs, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        import os
        os.replace(str(tmp), str(self.dir / "jobs.json"))

    def _score_source(self, source, depth_hint=0.5):
        """Kaynak kalite skoru: güvenilirlik + derinlik."""
        s = (source or "").lower()
        score = 0.35
        if any(d in s for d in ("docs.", ".org", "github.com", "arxiv.org",
                                "developer.", "learn.")):
            score += 0.25
        if any(d in s for d in (".com", ".io", ".dev")):
            score += 0.1
        score += 0.2 * max(0.0, min(1.0, float(depth_hint or 0)))
        return min(1.0, score)

    def schedule(self, topic, source, category="research", priority=5):
        with self._lock:
            jid = "lw_%d" % int(time.time() * 1000)
            job = {"id": jid, "topic": topic, "source": source,
                   "category": category, "priority": priority,
                   "status": "pending", "created": time.time()}
            self._jobs[jid] = job
            self._seen.add(jid)
            self._save()
            return jid

    def run_cycle(self, max_jobs=3):
        """Bir döngüde bekleyen işlerden bir kısmını işle (daemon uyumlu)."""
        with self._lock:
            pending = [j for j in self._jobs.values()
                       if j.get("status") == "pending"]
            pending.sort(key=lambda j: -j.get("priority", 5))
        results = []
        for job in pending[:max_jobs]:
            results.append(self._run_job(job["id"]))
        return results

    def _run_job(self, jid):
        with self._lock:
            job = self._jobs.get(jid)
            if not job:
                return None
            job["status"] = "running"
            job["started"] = time.time()
        try:
            items = []
            if self.research_fn:
                items = self.research_fn(job["topic"]) or []
            if not items and self.store is not None:
                # araştırma motoru yoksa depo üzerinden örnek analiz
                items = [{"text": r.get("content", ""),
                          "source": r.get("source", job.get("source", "")),
                          "depth": 0.5}
                         for r in self.store.query(category=job.get("category"), limit=3)]
            learned = 0
            for it in items:
                text = it.get("text") or ""
                if not text:
                    continue
                key = hash(text) % (2 ** 32)
                if key in self._seen and len(self._seen) > MAX_JOBS:
                    continue  # tekrar kontrolü
                self._seen.add(key)
                src_score = self._score_source(
                    it.get("source") or job.get("source", ""),
                    it.get("depth", 0.5))
                if src_score < MIN_SOURCE_SCORE:
                    continue
                if not self.validator(text, it.get("source", ""), src_score):
                    continue
                if self.on_extract:
                    try:
                        self.on_extract(text, job.get("category", "research"),
                                        it.get("source", ""), src_score)
                        learned += 1
                    except Exception:
                        pass
            with self._lock:
                job["status"] = "completed"
                job["learned"] = learned
                job["finished"] = time.time()
                self._save()
            return {"id": jid, "status": "completed", "learned": learned}
        except Exception as e:
            with self._lock:
                job["status"] = "failed"
                job["error"] = str(e)[:300]
                job["finished"] = time.time()
                self._save()
            return {"id": jid, "status": "failed", "error": str(e)[:200]}

    def pause(self):
        with self._lock:
            for j in self._jobs.values():
                if j.get("status") == "pending":
                    j["status"] = "paused"
            self._save()

    def resume(self):
        with self._lock:
            for j in self._jobs.values():
                if j.get("status") == "paused":
                    j["status"] = "pending"
            self._save()

    def status(self):
        with self._lock:
            by_status = {}
            for j in self._jobs.values():
                s = j.get("status", "?")
                by_status[s] = by_status.get(s, 0) + 1
            learned = sum(j.get("learned", 0) for j in self._jobs.values())
            return {"jobs": len(self._jobs), "by_status": by_status,
                    "learned_total": learned,
                    "dir": str(self.dir)}

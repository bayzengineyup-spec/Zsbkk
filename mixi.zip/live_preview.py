"""Live preview helpers for Mixium artifacts."""
from pathlib import Path

PREVIEWABLE = {'.html','.htm','.svg','.md'}

def can_preview(path):
    return Path(path).suffix.lower() in PREVIEWABLE

def preview_mode(path):
    return 'preview' if can_preview(path) else 'code'


def file_actions(path):
    return {
        'open': True,
        'download': True,
        'code': True,
        'preview': can_preview(path)
    }

"""Live preview and code artifact helpers."""
import mimetypes
from pathlib import Path

SUPPORTED_PREVIEW = {".html", ".htm", ".svg", ".md"}

def can_preview(path):
    return Path(path).suffix.lower() in SUPPORTED_PREVIEW

def artifact_actions(path):
    return {
        "open": True,
        "download": True,
        "code_view": True,
        "preview": can_preview(path)
    }

# -*- coding: utf-8 -*-
"""
Mixium — Master Intelligence Core (B1) + Model Router (B10)

Ana beyin katmanı. Görevleri:
- hangi agent çalışacak karar vermek
- hangi bilgilerin gerekli olduğunu seçmek
- gereksiz context yüklememek
- doğru modeli doğru görevde kullanmak (ModelRouter)

Bilgi seçimi (context azaltma): görev metninden intent + anahtar terimler
çıkarılır; yalnızca ilgili kaynaklar (DNA / Expert / Pattern / Graph)
seçilir. Boşsa hiçbir şey döndürülmez.

MIXIUM'a bağımlı değildir; tüm kaynaklar enjekte edilir. Fail-closed.
"""

import json
import re
import threading
import time
import uuid
from pathlib import Path

# ── intent analizi ───────────────────────────────────────────────────
INTENT_PATTERNS = {
    "research": ["araştır", "öğren", "incele", "kaynak", "web", "makale", "github",
                 "research", "investigate", "look up", "find", "search"],
    "coding": ["yaz", "kodla", "düzelt", "bug", "hata", "refactor", "ekle", "oluştur",
               "implement", "fix", "write", "code", "feature", "api"],
    "review": ["kontrol", "gözden geçir", "incele", "review", "audit", "güvenlik",
               "security", "quality", "kalite"],
    "test": ["test", "çalıştır", "doğrula", "verify", "check", "kontrol et"],
    "analyze": ["analiz", "mimari", "yapı", "architecture", "understand", "anla",
                "özetle", "summary", "explain", "açıkla"],
    "plan": ["plan", "tasarla", "adım", "strateji", "strategy", "design", "yaklaşım"],
}

# model tipleri (B10)
MODEL_TYPES = ("dna", "coding", "research", "reasoning", "fast")

ROUTE_BY_INTENT = {
    "research": "research",
    "coding": "coding",
    "test": "fast",
    "analyze": "reasoning",
    "plan": "reasoning",
    "review": "reasoning",
}


def detect_intent(task):
    """Görev metninden intent çıkar (boşsa 'analyze')."""
    task = (task or "").lower()
    scores = {}
    for intent, pats in INTENT_PATTERNS.items():
        s = sum(1 for p in pats if p in task)
        if s:
            scores[intent] = s
    if not scores:
        return "analyze"
    return max(scores, key=scores.get)


def extract_keywords(task, top=6):
    """Görevden önemli anahtar terimleri çıkar (basit, regex tabanlı)."""
    task = (task or "").lower()
    words = re.findall(r"[a-zçğıöşü]{3,}", task)
    stop = {"bir", "ve", "ile", "için", "bu", "şu", "the", "and", "for",
            "with", "that", "this", "from", "you", "your", "olmak", "gibi",
            "sonra", "önce", "ama", "veya", "değil", "yap", "et", "ol",
            "göre", "kadar", "daha", "en", "mi", "mu", "not"}
    words = [w for w in words if w not in stop]
    # sıklık
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    ranked = sorted(freq.items(), key=lambda x: (-x[1], x[0]))
    return [w for w, _ in ranked[:top]]


class ModelRouter:
    """B10: intent → model tipi. Panelden seçilen modeller kullanılır."""

    def __init__(self, models=None):
        """models: {model_type: model_id} dict. Eksikse varsayılan."""
        self.models = dict(models or {})
        self._lock = threading.RLock()

    def set_model(self, model_type, model_id):
        if model_type not in MODEL_TYPES:
            return False
        with self._lock:
            self.models[model_type] = str(model_id)
        return True

    def get_model(self, model_type):
        with self._lock:
            return self.models.get(model_type)

    def route(self, task):
        """Göreve uygun model tipini seç."""
        intent = detect_intent(task)
        mtype = ROUTE_BY_INTENT.get(intent, "fast")
        with self._lock:
            return {
                "intent": intent,
                "model_type": mtype,
                "model": self.models.get(mtype),
                "available": {k: v for k, v in self.models.items()},
            }

    def to_dict(self):
        with self._lock:
            return dict(self.models)


class MasterIntelligenceCore:
    """B1: ana beyin — agent/bilgi seçimi + context paketi."""

    def __init__(self, root=".", sources=None):
        """sources: {name: fn} — fn() ilgili bağlamı döndürür (string veya list).
        Örn. {'dna': lambda: ..., 'expert': ..., 'graph': ...}"""
        self.root = Path(root)
        self.dir = self.root / ".mixium" / "master"
        self.sources = dict(sources or {})
        self.router = ModelRouter()
        self._lock = threading.RLock()
        self._log = []
        self._load()

    def _allowed(self, p):
        try:
            p = Path(p).resolve()
            root = self.root.resolve()
            return root in p.parents or p == root
        except Exception:
            return False

    def _load(self):
        try:
            if self._allowed(self.dir / "master.json"):
                with open(self.dir / "master.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    self.router.models = data.get("models", {})
                    self._log = data.get("log", [])
        except Exception:
            pass

    def _save(self):
        try:
            if not self._allowed(self.dir):
                return
            self.dir.mkdir(parents=True, exist_ok=True)
            tmp = self.dir / "master.json.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"models": self.router.models, "log": self._log[-100:]},
                          f, ensure_ascii=False, indent=1)
            tmp.replace(self.dir / "master.json")
        except Exception:
            pass

    # ── bilgi seçimi ────────────────────────────────────────────────
    def plan(self, task, max_sources=3, max_chars=1800):
        """Görev için gerekli kaynakları seçer ve tek context paketi üretir.

        - intent + keyword çıkarır
        - yalnızca ilgili kaynakları çağırır (hepsi değil)
        - budget içinde paketler (gereksiz context yüklenmez)
        Dönüş: {intent, keywords, selected, package}
        """
        intent = detect_intent(task)
        kws = extract_keywords(task)
        # ilgili kaynak seçimi (intent bazlı öncelik)
        priority = self._source_priority(intent)
        ordered = sorted(priority, key=priority.get)
        selected = []
        used = 0
        package_parts = []
        for name in ordered:
            if len(selected) >= max_sources:
                break
            fn = self.sources.get(name)
            if fn is None:
                continue
            try:
                content = fn() or ""
                if isinstance(content, (list, tuple)):
                    content = "\n".join(str(x) for x in content)
                content = str(content).strip()
            except Exception:
                content = ""
            if not content:
                continue
            block = f"[{name.upper()}]\n{content[:max_chars // max(1, max_sources)]}"
            if used + len(block) > max_chars:
                block = block[: max(60, max_chars - used)]
            package_parts.append(block)
            used += len(block)
            selected.append(name)
            if used >= max_chars:
                break
        package = "\n\n".join(package_parts)
        result = {"intent": intent, "keywords": kws,
                  "selected": selected, "package": package,
                  "chars": used, "time": time.time()}
        with self._lock:
            self._log.append({k: v for k, v in result.items() if k != "package"})
            self._save()
        return result

    def _source_priority(self, intent):
        """intent'e göre kaynak önceliği (düşük sayı = önce)."""
        base = {name: 50 for name in self.sources}
        if intent in ("coding", "analyze"):
            base.update({"dna": 10, "expert": 20, "graph": 30, "project": 20})
        elif intent == "research":
            base.update({"expert": 10, "research": 20, "dna": 30})
        elif intent == "review":
            base.update({"project": 10, "expert": 20, "graph": 30})
        elif intent == "test":
            base.update({"project": 10, "expert": 30})
        return base

    def decide_agent(self, task):
        """Hangi specialized agent çalışmalı (A10 rolleri üzerinden)."""
        intent = detect_intent(task)
        route = {
            "research": "research",
            "coding": "coding",
            "test": "testing",
            "review": "review",
            "analyze": "research",
            "plan": "architect",
        }
        return {"intent": intent, "agent_role": route.get(intent, "research"),
                "reason": f"intent={intent}"}

    def status(self):
        with self._lock:
            return {
                "sources": sorted(self.sources.keys()),
                "models": self.router.to_dict(),
                "decisions": list(self._log[-20:]),
                "time": time.time(),
            }

# -*- coding: utf-8 -*-
"""Mixium — Autonomous Observer Agent (Aşama 19C)."""
import threading
import time


class ObserverAgent:
    def __init__(self, providers=None, window=20):
        self.providers = dict(providers or {})
        self.window = max(5, int(window))
        self._lock = threading.RLock()
        self.history = []

    def observe(self):
        snapshot = {"time": time.time(), "components": {}, "errors": [], "warnings": [], "recommendations": []}
        for name, fn in list(self.providers.items()):
            try:
                value = fn() if callable(fn) else fn
                snapshot["components"][name] = value
            except Exception as exc:
                snapshot["errors"].append({"component": name, "error": str(exc)[:300]})
        health = snapshot["components"].get("health", {})
        if isinstance(health, dict) and health.get("system_health", 100) < 70:
            snapshot["warnings"].append("Sistem sağlık skoru düşüyor.")
        test = snapshot["components"].get("tests", {})
        if isinstance(test, dict) and (test.get("failed", 0) or test.get("errors", 0)):
            snapshot["warnings"].append("Test başarısızlıkları gözlendi.")
            snapshot["recommendations"].append("Testing ve debug workflow gözden geçirilmeli.")
        with self._lock:
            self.history.append(snapshot); self.history = self.history[-self.window:]
        return snapshot

    def status(self):
        with self._lock:
            rows = list(self.history)
        warnings = []
        errors = []
        for row in rows:
            warnings.extend(row.get("warnings", [])); errors.extend(row.get("errors", []))
        return {"observations": len(rows), "warnings": warnings[-20:], "errors": errors[-20:],
                "last": rows[-1] if rows else None}

    def repeated_failures(self, key="tests"):
        count = 0
        for row in self.history[-self.window:]:
            value = row.get("components", {}).get(key, {})
            if isinstance(value, dict) and (value.get("failed", 0) or value.get("errors", 0)): count += 1
        return count

# -*- coding: utf-8 -*-
"""Mixium A25F — Improvement Memory.

Kaydeder: bulunan hata, çözüm, başarılı yöntem, başarısız yöntem, performans
sonucu. Sonraki problemlerde semantic recall (opsiyonel embed/cosine enjeksiyonu)
ile geri getirir. Max kayıt sınırı (LRU) korunur. Workspace içi .mixium/improvements.json.
"""

import json
import os
import threading
import time

MAX_RECORDS = 200


class ImprovementMemory:
    def __init__(self, root=".", max_records=MAX_RECORDS, embed_fn=None,
                 cosine_fn=None, persist_path=None):
        self.root = root
        self.max_records = max_records
        self.embed_fn = embed_fn
        self.cosine_fn = cosine_fn
        self.persist_path = persist_path or os.path.join(root, ".mixium", "improvements.json")
        self.records = []
        self._lock = threading.Lock()
        self._load()

    def _load(self):
        try:
            if os.path.exists(self.persist_path):
                with open(self.persist_path) as f:
                    self.records = json.load(f)[-self.max_records:]
        except Exception:
            self.records = []

    def _save(self):
        try:
            os.makedirs(os.path.dirname(self.persist_path), exist_ok=True)
            with open(self.persist_path, "w") as f:
                json.dump(self.records, f, ensure_ascii=False)
        except Exception:
            pass

    def record(self, kind, text, meta=None):
        """kind: bug|solution|success|failure|performance"""
        with self._lock:
            rec = {"id": "imp_%d" % int(time.time() * 1000),
                   "kind": kind, "text": str(text)[:2000],
                   "meta": dict(meta or {}), "timestamp": time.time(),
                   "embedding": None}
            if self.embed_fn is not None:
                try:
                    rec["embedding"] = list(self.embed_fn(rec["text"]))
                except Exception:
                    rec["embedding"] = None
            self.records.append(rec)
            if len(self.records) > self.max_records:
                self.records = self.records[-self.max_records:]
            self._save()
            return rec

    def recall(self, query, top_k=5, kind=None):
        """Semantic recall (embed/cosine varsa), yoksa keyword düşüşü."""
        with self._lock:
            pool = [r for r in self.records if kind is None or r.get("kind") == kind]
            if not pool:
                return []
            if self.embed_fn is not None and self.cosine_fn is not None:
                try:
                    qv = self.embed_fn(query)
                    scored = []
                    for r in pool:
                        if r.get("embedding"):
                            scored.append((self.cosine_fn(qv, r["embedding"]), r))
                        else:
                            scored.append((0.0, r))
                    scored.sort(key=lambda x: x[0], reverse=True)
                    return [r for _, r in scored[:top_k]]
                except Exception:
                    pass
            # keyword fallback
            q = (query or "").lower()
            scored = [(sum(1 for w in q.split() if w in r.get("text", "").lower()), r) for r in pool]
            scored.sort(key=lambda x: x[0], reverse=True)
            return [r for s, r in scored if s > 0][:top_k] or pool[-top_k:]

    def status(self):
        return {"records": len(self.records),
                "by_kind": {k: sum(1 for r in self.records if r.get("kind") == k)
                            for k in ("bug", "solution", "success", "failure", "performance")}}

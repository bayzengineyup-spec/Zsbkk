# -*- coding: utf-8 -*-
"""Mixium — Personal Knowledge Graph (Aşama 19E)."""
import json
import threading
import time
import uuid
from pathlib import Path

NODE_TYPES = ("user", "project", "skill", "preference", "decision", "goal", "learning", "experience")
EDGE_TYPES = ("related", "uses", "prefers", "decided", "pursues", "learned", "experienced", "depends")


class PersonalGraph:
    def __init__(self, root=".", max_nodes=1000, max_edges=3000):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "personal_graph.json"
        self.max_nodes, self.max_edges = max_nodes, max_edges
        self._lock = threading.RLock()
        self.nodes, self.edges = {}, []
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.nodes = d.get("nodes", {}) if isinstance(d, dict) else {}
                self.edges = d.get("edges", []) if isinstance(d, dict) else []
        except Exception:
            self.nodes, self.edges = {}, []

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps({"nodes": self.nodes, "edges": self.edges}, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def add_node(self, node_type, label, properties=None, node_id=None):
        node_type = str(node_type).lower()
        label = str(label or "").strip()
        if node_type not in NODE_TYPES or not label:
            return None
        with self._lock:
            nid = node_id or "node_" + uuid.uuid4().hex[:10]
            self.nodes[nid] = {"id": nid, "type": node_type, "label": label[:300],
                               "properties": dict(properties or {}), "created": time.time(), "updated": time.time()}
            if len(self.nodes) > self.max_nodes:
                oldest = min(self.nodes, key=lambda x: self.nodes[x].get("updated", 0))
                self.nodes.pop(oldest, None)
            self._save()
            return dict(self.nodes[nid])

    def connect(self, source, target, edge_type="related", properties=None):
        if edge_type not in EDGE_TYPES:
            return False
        with self._lock:
            if source not in self.nodes or target not in self.nodes:
                return False
            edge = {"source": source, "target": target, "type": edge_type,
                    "properties": dict(properties or {}), "created": time.time()}
            if not any(e["source"] == source and e["target"] == target and e["type"] == edge_type for e in self.edges):
                self.edges.append(edge)
                self.edges = self.edges[-self.max_edges:]
                self._save()
            return True

    def find(self, query="", node_type=None, limit=20):
        q = str(query or "").lower()
        with self._lock:
            rows = [dict(n) for n in self.nodes.values()
                    if (not q or q in n.get("label", "").lower() or q in json.dumps(n.get("properties", {}), ensure_ascii=False).lower())
                    and (node_type is None or n.get("type") == node_type)]
        return rows[:max(1, min(100, int(limit)))]

    def neighbors(self, node_id, depth=1):
        found = {node_id}; frontier = {node_id}
        for _ in range(max(1, min(3, int(depth)))):
            nxt = set()
            for e in self.edges:
                if e["source"] in frontier: nxt.add(e["target"])
                if e["target"] in frontier: nxt.add(e["source"])
            nxt -= found; found |= nxt; frontier = nxt
        return [dict(self.nodes[x]) for x in found if x in self.nodes]

    def query(self, query="", node_type=None, limit=20):
        return {"nodes": self.find(query, node_type, limit), "edges": [e for e in self.edges if e["source"] in self.nodes and e["target"] in self.nodes][:100]}

    def status(self):
        return {"nodes": len(self.nodes), "edges": len(self.edges), "types": sorted({n.get("type") for n in self.nodes.values()})}

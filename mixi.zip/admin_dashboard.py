# -*- coding: utf-8 -*-
"""
Mixium — B11: Admin Intelligence Dashboard

Panel verisi üretir: DNA öğrenilenler, model, güven skorları, bugün
öğrenilenler, araştırma kaynakları, çalışan işler, bulunan/düzeltilen
sorunlar, Intelligence Score (before/after/growth).

Salt-okunur. Kaynaklar enjekte edilir (yoksa 0/boş döner, çökmez).
"""

import time


class AdminDashboard:
    def __init__(self, sources=None):
        """
        sources: dict of callables, opsiyonel:
          dna_summary, dna_stats, learning_status, research_log,
          agents_status, improvements, intelligence_score
        """
        self.sources = sources or {}

    def _get(self, key, default=None):
        fn = self.sources.get(key)
        if fn is None:
            return default
        if not callable(fn):
            return fn if fn is not None else default
        try:
            return fn() or default
        except Exception:
            return default

    def status(self):
        score_now = self._get("intelligence_score", {})
        score_before = self._get("intelligence_score_before", 0)
        if isinstance(score_now, dict):
            now = score_now.get("score", 0)
        else:
            now = score_now or 0
        try:
            growth = round(float(now) - float(score_before or 0), 1)
        except Exception:
            growth = 0.0
        return {
            "dna": self._get("dna_summary", {}),
            "dna_model": self._get("dna_model", "deepseek"),
            "learning": self._get("learning_status", {}),
            "today_learned": self._get("today_learned", 0),
            "research": self._get("research_log", []),
            "agents": self._get("agents_status", {}),
            "improvements": self._get("improvements", []),
            "intelligence": {"score": now, "before": score_before,
                             "growth": growth},
            "generated": time.time(),
        }

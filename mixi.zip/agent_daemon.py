# -*- coding: utf-8 -*-
"""
Mixium — Agent Long Runner (Aşama 12E)

Uzun çalışan otonom agent: start/pause/resume/stop/heartbeat/checkpoint.
Persist: .mixium/agents/daemon.json (workspace içi, fail-closed).
Kurallar: max iteration + timeout + crash recovery; sonsuz loop YOK.

MIXIUM'a bağımlı değildir; çalışan iş `job_fn(ctx)` callable'ı olarak enjekte
edilir (mixium_new gerçek LLM pipeline'ı bağlar).
"""

import json
import threading
import time
import uuid
from pathlib import Path

STATES = ("CREATED", "RUNNING", "PAUSED", "COMPLETED", "FAILED", "CANCELLED")


class AgentDaemon:
    def __init__(self, root=".", max_iterations=100, timeout=3600):
        self.root = Path(root).expanduser().resolve()
        self.state_path = self.root / ".mixium" / "agents" / "daemon.json"
        self.max_iterations = max_iterations
        self.timeout = timeout
        self._lock = threading.Lock()
        self._state = {
            "id": None, "goal": "", "status": "CREATED", "iteration": 0,
            "checkpoint": {}, "heartbeat": 0, "error": None, "result": None,
        }
        self._stop = threading.Event()
        self._pause = threading.Event()
        self._thread = None
        self._load()

    # ---- persist ----
    def _allowed(self):
        try:
            d = self.state_path.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def _load(self):
        try:
            if self.state_path.exists():
                self._state = json.loads(self.state_path.read_text("utf-8"))
        except Exception:
            pass

    def _save(self):
        if not self._allowed():
            return
        try:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            self.state_path.write_text(json.dumps(self._state, ensure_ascii=False),
                                       "utf-8")
        except Exception:
            pass

    def _tick(self):
        self._state["heartbeat"] = time.time()
        self._save()

    # ---- lifecycle ----
    def start(self, goal, job_fn):
        """job_fn(ctx) -> result; ctx = {"iteration", "goal", "checkpoint"}."""
        with self._lock:
            if self._state["status"] == "RUNNING":
                return False
            self._state["id"] = self._state["id"] or uuid.uuid4().hex[:10]
            self._state["goal"] = goal
            self._state["status"] = "RUNNING"
            self._state["iteration"] = 0
            self._stop.clear()
            self._pause.clear()
            self._save()
        self._thread = threading.Thread(target=self._worker, args=(goal, job_fn),
                                        daemon=True)
        self._thread.start()
        return True

    def _worker(self, goal, job_fn):
        start = time.time()
        try:
            for i in range(1, self.max_iterations + 1):
                if self._stop.is_set():
                    self._state["status"] = "CANCELLED"
                    break
                if time.time() - start > self.timeout:
                    self._state["status"] = "FAILED"
                    self._state["error"] = "timeout"
                    break
                while self._pause.is_set() and not self._stop.is_set():
                    time.sleep(0.2)
                if self._stop.is_set():
                    self._state["status"] = "CANCELLED"
                    break
                self._state["iteration"] = i
                self._tick()
                result = job_fn({"iteration": i, "goal": goal,
                                 "checkpoint": self._state["checkpoint"]})
                self._state["checkpoint"] = {"iteration": i, "result": result}
                self._tick()
                if result is not None and isinstance(result, dict) and result.get("done"):
                    self._state["result"] = result
                    self._state["status"] = "COMPLETED"
                    break
            else:
                self._state["status"] = "COMPLETED"
        except Exception as e:
            self._state["status"] = "FAILED"
            self._state["error"] = "%s: %s" % (type(e).__name__, e)
        finally:
            self._tick()

    def pause(self):
        self._pause.set()
        self._state["status"] = "PAUSED"
        self._tick()
        return True

    def resume(self):
        if self._state["status"] != "PAUSED":
            return False
        self._pause.clear()
        self._state["status"] = "RUNNING"
        self._tick()
        return True

    def stop(self):
        self._stop.set()
        self._state["status"] = "CANCELLED"
        self._tick()
        if self._thread:
            self._thread.join(timeout=2)
        return True

    def heartbeat(self):
        self._tick()
        return self._state["heartbeat"]

    def checkpoint(self):
        self._tick()
        return dict(self._state["checkpoint"])

    def status(self):
        return dict(self._state)

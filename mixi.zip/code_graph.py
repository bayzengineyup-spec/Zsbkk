# -*- coding: utf-8 -*-
"""
Mixium — Knowledge Graph (Aşama 12F)

code_intel'in sembol index'i + dependency graph üzerine kurulur:
File -> Class -> Function -> Import -> Dependency düğümleri.

find_symbol(name)   -> sembolün tanımı + bulunduğu dosya/sınıf/fonksiyon ağacı
find_references(name) -> aynı ismi kullanan diğer semboller (basit substring)

800 dosya sınırını miras alır (code_intel indexer). MIXIUM'a bağımlı değildir.
"""


class CodeGraph:
    def __init__(self, indexer):
        """indexer: code_intel.ProjectIndexer (index() çağrılmış)."""
        self.indexer = indexer
        self.files = indexer.files
        self.symbols = indexer.symbols
        self.dependencies = indexer.dependencies

    def find_symbol(self, name):
        """Sembol tanımını bulur -> {"file","symbol","type","line"} veya None."""
        n = (name or "").lower()
        for s in self.symbols:
            if s["symbol"].lower() == n:
                return s
        return None

    def find_references(self, name):
        """Aynı ismi içeren sembolleri döndürür (dosya + satır)."""
        n = (name or "").lower()
        return [s for s in self.symbols if n in s["symbol"].lower()]

    def symbol_tree(self, name):
        """Sembol + bulunduğu dosyanın diğer sembolleri + dependency ağacı."""
        hit = self.find_symbol(name)
        if not hit:
            return None
        file = hit["file"]
        syms = [s for s in self.symbols if s["file"] == file]
        deps = self.dependencies.get(file, [])
        return {"symbol": hit, "same_file": syms, "dependencies": deps}

    def format_tree(self, name):
        """Okunur ağaç çıktısı (task örneğindeki format)."""
        tree = self.symbol_tree(name)
        if not tree:
            return "'%s' bulunamadı" % name
        hit = tree["symbol"]
        lines = [hit["file"]]
        for s in tree["same_file"]:
            if s["symbol"] == hit["symbol"]:
                lines.append(" ├ %s() [%s:%s]" % (s["symbol"], s["type"], s["line"]))
        for d in tree["dependencies"]:
            lines.append(" └ %s" % d)
        return "\n".join(lines)

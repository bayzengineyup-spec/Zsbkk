# Mixium — Sürüm 2.0 · Kapsamlı Arayüz Yenilemesi

Bu paket, arayüzün **tamamen sıfırdan** yeniden dokunmuş halidir.
Motor (`mixium_new.py`, `mixi_octo.py`) değişmedi — hız aynı.

---


| Eski | Yeni |
|---|---|
| 4 çizgi kol | **8 gerçek kol** (4 arka + 4 ön katman) |
| Ağız vardı | **Ağız yok** — jestle anlatır |
| Küçük baş | Baş belirgin şekilde **büyütüldü** |
| Düz renk | Prosedürel doku: `feTurbulence` cilt beneği, rim light, specular, altsatıh gölgesi |
| Sabit çizgi | Kollar **prosedürel üretilir**: bezier merkez eğrisi + daralan kalınlık profili → dolu, organik silüet |
| Vantuz yok | Her kolda kola göre küçülen **vantuz dizisi** (48 adet) |

**Animasyonlar gerçekçileştirildi:** her kolun kendi süresi ve negatif gecikmesi
var → senkronsuz, doğal dalgalanma. 10 ayrı durum: `idle · sleep · think ·
search · read · write · work · talk · done · error`. Her durumun kendine özgü
gövde eğimi, kol jesti, göz hareketi ve parçacık efekti var. Ayrıca rastgele
ritimli göz kırpma (bazen çift) ve imleci izleyen göz bebeği.

### ⚠ Ana hata çözüldü: animasyon sızıntısı

* Her maskot **kendi gradient ID'sini** alır → aynı sayfada çakışma yok.
  sınıfıyla **tamamen dondurur** (`animation:none`) → geçmiş mesajlar CPU/pil
  harcamaz.
* Yeni mesaj maskotu varsayılan olarak **donmuş** doğar.

---

## 2 · Tasarım sistemi

Yedi katmanlı CSS mimarisi (`web/css/`):

| Dosya | İçerik |
|---|---|
| `tokens.css` | Renk / tipografi / uzay / gölge / hareket token'ları |
| `base.css` | Reset, tipografi temeli, sahne ışığı, grain dokusu |
| `layout.css` | Kenar çubuğu, üst çubuk, seçiciler, menüler |
| `chat.css` | Mesajlar, kod blokları, araç kartları, composer |
| `overlays.css` | Modal, komut paleti, ayarlar, araç galerisi |
| `responsive.css` | Mobil / tablet / yazdırma / erişilebilirlik |

**Renk felsefesi:** aşırı renksiz değil, aşırı renkli değil. Nötr mürekkep zemin
(`#0b0f14`) üzerinde **tek bir aksan ailesi** (turkuaz + indigo destek).
6 aksan seçeneği, 2 tema, 4 yazı boyutu, 2 yoğunluk.

Gerçek **5 kademeli gölge merdiveni**, cam efektli yüzeyler, ince film greni ve
yavaşça sürüklenen arka plan auraları — "çizgi film" hissi tamamen gitti.

---

## 3 · Mobil uyum (baştan yazıldı)

* 5 kırılma noktası: 1500 / 1180 / 1024 / 720 / 380 px + kısa ekran + yatay mod
* `100dvh` / `100svh` — mobil tarayıcı çubuğu zıplaması yok
* `env(safe-area-inset-*)` — çentik ve alt çubuk saygısı
* Kod blokları, tablolar, araç çıktıları **artık taşmıyor** (kaydırmalı kap + gradyan ipucu)
* iOS zoom engeli (`font-size:16px` girişte)
* Dokunma hedefleri ≥ 38 px, `@media (hover:none)` için ayrı davranış
* Modal'lar mobilde **alt çekmece** olur (tutamaçlı)
* Yazdırma stili + yüksek kontrast + `prefers-reduced-motion`

---

## 4 · Yeni araçlar (`tools_extra.py`) — 20 adet

`json_query` · `csv_stat` · `text_stat` · `diff_files` · `replace_glob` ·
`file_info` · `hash_tool` · `encode` · `uuid_tool` · `time_tool` ·
`regex_test` · `env_info` · `pkg_info` · `port_check` · `archive` ·
`pretty` · `sandbox_py` · `count_tokens` · `project_map` · `lint_py`

**Toplam araç sayısı: 20 → 40**

### Araç hataları düzeltildi
Tüm araçlar (yeni + eski 20 tanesi) `_harden()` sarmalayıcısından geçer:

* Model argümanı string gönderirse **otomatik JSON'a çevrilir**
* Yanlış anahtar adı kullanılırsa `_arg()` alternatifleri dener
  (`path` / `file`, `find` / `old` / `search` …)
* Her istisna türü **insanca Türkçe mesaja** dönüşür — ham traceback yerine
  "HATA [read]: dosya bulunamadı — …"
* Araç asla `None` döndürmez, ajan akışı kırılmaz

---

## 5 · Yeni sistemler ve özellikler

**Komut paleti (Ctrl+K)** — 24 komut, gruplu, klavyeyle gezinilebilir, canlı filtre.

**Ayarlar paneli (Ctrl+,)** — 13 ayar: tema, 6 aksan rengi, yazı boyutu,
yoğunluk, geniş mod, doku efekti, animasyon, maskot, bitiş sesi, Enter davranışı,
otomatik kaydırma, zaman damgaları, düşünce kartları. Hepsi `localStorage`'da kalıcı.

**Araç galerisi (Ctrl+T)** — 40 aracın kartlı görünümü; tıklayınca JSON şeması kopyalanır.

**Sohbet içi arama (Ctrl+Shift+F)** — canlı vurgulama, ileri/geri gezinme, sayaç.

**Mesaj eylem çubuğu** — kopyala, yeniden üret, beğen/sorun bildir, alıntıla, düzenle, sil.

**Kod bloğu araç çubuğu** — dil etiketi, satır sayısı, satır numaraları, kopyala,
**indir** (doğru uzantıyla), satır kaydırma, uzun blokları katlama.

**Araç kartları** — canlı süre sayacı, açılır/kapanır çıktı, otomatik **diff
renklendirmesi** (+yeşil/−kırmızı), başarı/hata durumu, araca özel ikon.

**Eğik çizgi komutları** — `/` yazınca otomatik tamamlama menüsü, 11 komut.

**Diğer:** dosya ekleme + sürükle-bırak · sesli giriş (Web Speech) · Markdown/JSON
dışa aktarma · panoya kopyalama · yazdırma · oturum arama · başlık düzenleme
(inline) · "en alta in" düğmesi · üst ilerleme şeridi · yığılabilir toast'lar ·
oturum silme onayı · bağlantı durumu göstergesi · otomatik yeniden bağlanma
(kademeli bekleme) · sekme başlığı bildirimi · 14 klavye kısayolu

---

## 6 · Markdown motoru yenilendi

İç içe listeler · görev listeleri (`- [x]`) · hizalamalı tablolar · üstü çizili ·
`==vurgu==` · çıplak URL algılama · resimler · 6 dil için sözdizimi vurgulama
(Python, JS/TS, Shell, Go, Rust, SQL) · **XSS güvenliği doğrulandı**.

---

## 7 · Test

`node web/_smoketest.js` (jsdom) — **67 test, tamamı geçti**:
maskot yapısı (8 kol / ağız yok / benzersiz ID), durum izolasyonu,
araç→durum haritası, markdown, XSS, DOM bütünlüğü, mesaj oluşturma,
araç kartları, ayarlar, yardımcılar.

Python tarafı: `python3 tools_extra.py` ile 20 aracın hepsi canlı test edildi.

---

## Dosya yapısı

```
mixium-web/
├── mixiweb.py           # sunucu (tools_list + rename + ping eklendi)
├── tools_extra.py       # ★ YENİ — 20 araç + dayanıklılık katmanı
├── panel.py
└── web/
    ├── index.html       # ★ sıfırdan yazıldı
    ├── css/             # ★ 7 katmanlı yeni tasarım sistemi
    │   ├── tokens.css  base.css  layout.css  chat.css
    └── js/              # ★ modüler mimari
        ├── ui.js        # ikonlar, markdown, vurgulama, toast
        ├── app.js       # durum, websocket, mesajlar, araç kartları
        └── shell.js     # kısayollar, palet, ayarlar, menüler
```

## Çalıştırma

```bash
cd mixium-web
python3 mixiweb.py            # http://127.0.0.1:8420
```

Ek bağımlılık yok — saf Python stdlib, Termux'ta çalışır.


## V8 düzeltmesi
- Agent.run() artık workspace parametresini açıkça alıyor.
- mixiweb.py workspace bilgisini Agent.run()'a iletiyor.
- Ekli proje analizinde attachment_mode artık NameError üretmiyor.

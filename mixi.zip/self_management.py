# -*- coding: utf-8 -*-
"""Mixium — Self Management Core (Aşama 18).

This module only observes injected providers. It never mutates permission,
sandbox, agents, memory, or model state.
"""
import threading
import time


class SelfManagementCore:
    """Collect component status without allowing one broken provider to crash it."""

    def __init__(self, providers=None, thresholds=None):
        self.providers = dict(providers or {})
        self.thresholds = {"warning": 70, "critical": 40}
        if thresholds:
            self.thresholds.update(thresholds)
        self._lock = threading.RLock()
        self._last = None

    def register(self, name, provider):
        if not name or not callable(provider):
            return False
        with self._lock:
            self.providers[str(name)] = provider
        return True

    def unregister(self, name):
        with self._lock:
            return self.providers.pop(name, None) is not None

    @staticmethod
    def _call(provider):
        value = provider()
        if value is None:
            return {}
        if isinstance(value, dict):
            return value
        return {"value": value}

    @staticmethod
    def _component_health(name, value):
        """Return a bounded component score; missing data stays unknown."""
        if not isinstance(value, dict):
            return None
        for key in ("system_health", "health_score", "score", "overall"):
            if isinstance(value.get(key), (int, float)):
                return max(0, min(100, float(value[key])))
        status = str(value.get("status", "")).upper()
        if status in ("FAILED", "ERROR", "CRASHED"):
            return 0.0
        if status in ("RUNNING", "COMPLETED", "READY", "OK"):
            return 100.0
        return None

    def snapshot(self):
        with self._lock:
            providers = list(self.providers.items())
        components = {}
        errors = []
        warnings = []
        scores = []
        active_agents = []
        memory_status = {}
        learning_status = {}

        for name, provider in providers:
            started = time.time()
            try:
                value = self._call(provider)
                component = {"ok": True, "data": value,
                             "latency_ms": int((time.time() - started) * 1000)}
                score = self._component_health(name, value)
                if score is not None:
                    component["health"] = score
                    scores.append(score)
                status = str(value.get("status", "")).upper()
                if status in ("FAILED", "ERROR", "CRASHED"):
                    errors.append({"component": name, "message": value.get("error", status)})
                if name in ("agent_runtime", "agents", "background_agents"):
                    rows = value.get("active_agents", value.get("agents", []))
                    if isinstance(rows, list):
                        active_agents.extend(rows)
                if name in ("memory", "dna", "master_dna"):
                    memory_status[name] = value
                if name in ("learning", "learning_worker", "scheduler", "research"):
                    learning_status[name] = value
                for warning in value.get("warnings", []) if isinstance(value, dict) else []:
                    warnings.append({"component": name, "message": warning})
            except Exception as exc:
                component = {"ok": False, "data": {},
                             "error": "%s: %s" % (type(exc).__name__, exc),
                             "latency_ms": int((time.time() - started) * 1000)}
                errors.append({"component": name, "message": component["error"]})
            components[name] = component

        health = round(sum(scores) / len(scores)) if scores else 50
        if errors:
            health = max(0, health - min(30, len(errors) * 5))
        recommendations = []
        if not scores:
            recommendations.append("Bileşen sağlık verisi henüz mevcut değil; izleme sürüyor.")
        if errors:
            recommendations.append("Hatalı bileşenleri ve son hata kayıtlarını incele.")
        if health < self.thresholds["critical"]:
            recommendations.append("Sistem kritik sağlık seviyesinde; otomatik güvenlik değişikliği yapılmadı.")
        elif health < self.thresholds["warning"]:
            recommendations.append("Sistem sağlık seviyesi düşük; test ve worker durumlarını doğrula.")
        else:
            recommendations.append("Sistem gözlenen bileşenlerde sağlıklı görünüyor.")

        result = {
            "system_health": health,
            "active_agents": active_agents,
            "memory_status": memory_status,
            "learning_status": learning_status,
            "components": components,
            "errors": errors[:50],
            "warnings": warnings[:50],
            "recommendations": recommendations,
            "generated_at": time.time(),
        }
        with self._lock:
            self._last = result
        return result

    def status(self):
        return self.snapshot()

    def last_snapshot(self):
        with self._lock:
            return self._last.copy() if isinstance(self._last, dict) else None

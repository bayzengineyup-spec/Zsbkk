# -*- coding: utf-8 -*-
"""Mixium A22 — Autonomous Project Execution Engine.

Manages large projects through an explicit state machine. Delegation runs
through existing planner/orchestrator/delegation layers; this engine only
tracks state, requirements, tasks and reports.
"""
import json
import threading
import time
import uuid
from pathlib import Path

STATES = ("planning", "research", "development", "testing", "review", "deployment", "complete")


class ProjectExecutionEngine:
    def __init__(self, root=".", max_projects=30):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "project_execution.json"
        self.max_projects = max(1, int(max_projects))
        self._lock = threading.RLock()
        self.projects = {}
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.projects = d if isinstance(d, dict) else {}
        except Exception:
            self.projects = {}

    def _save(self):
        if not self._allowed():
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.projects, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
            return True
        except Exception:
            return False

    def create_project(self, title, goal=""):
        if not str(title or "").strip() or len(self.projects) >= self.max_projects:
            return None
        pid = "exec_" + uuid.uuid4().hex[:10]
        self.projects[pid] = {"id": pid, "title": str(title)[:300], "goal": str(goal)[:2000],
                              "state": "planning", "requirements": [], "tasks": [], "report": None,
                              "created": time.time(), "updated": time.time()}
        self._save()
        return self.get(pid)

    def get(self, pid):
        with self._lock:
            row = self.projects.get(str(pid))
            return json.loads(json.dumps(row)) if row else None

    def add_requirement(self, pid, requirement):
        p = self.projects.get(str(pid))
        if not p:
            return None
        p["requirements"].append({"id": "req_" + uuid.uuid4().hex[:8], "text": str(requirement)[:1000]})
        p["updated"] = time.time()
        self._save()
        return self.get(pid)

    def add_task(self, pid, role, title, dependencies=None):
        p = self.projects.get(str(pid))
        if not p:
            return None
        t = {"id": "etask_" + uuid.uuid4().hex[:8], "role": str(role), "title": str(title)[:500],
             "dependencies": list(dependencies or []), "status": "pending", "result": None}
        p["tasks"].append(t)
        p["updated"] = time.time()
        self._save()
        return dict(t)

    def update_task(self, pid, task_id, status=None, result=None):
        p = self.projects.get(str(pid))
        if not p:
            return None
        for t in p["tasks"]:
            if t["id"] == str(task_id):
                if status in ("pending", "running", "completed", "failed", "cancelled"):
                    t["status"] = status
                if result is not None:
                    t["result"] = str(result)[:2000]
                p["updated"] = time.time()
                self._save()
                return dict(t)
        return None

    def advance(self, pid, to_state=None):
        """Advance the state machine; only forward/valid transitions are allowed."""
        p = self.projects.get(str(pid))
        if not p:
            return None
        idx = STATES.index(p["state"])
        if to_state:
            if to_state not in STATES:
                return None
            target = STATES.index(to_state)
            if target <= idx:
                return None
            p["state"] = to_state
        else:
            if idx >= len(STATES) - 1:
                return None
            p["state"] = STATES[idx + 1]
        p["updated"] = time.time()
        if p["state"] == "complete":
            p["report"] = self._build_report(p)
        self._save()
        return self.get(pid)

    @staticmethod
    def _build_report(p):
        total = len(p["tasks"])
        done = sum(1 for t in p["tasks"] if t["status"] == "completed")
        failed = sum(1 for t in p["tasks"] if t["status"] == "failed")
        return {"progress": round(done * 100 / total, 1) if total else 0,
                "completed_tasks": done, "failed_tasks": failed, "warnings": ["%s görev hatalı" % t["role"] for t in p["tasks"] if t["status"] == "failed"][:10]}

    def status(self, pid=None):
        with self._lock:
            rows = [self.projects[str(pid)]] if pid and str(pid) in self.projects else list(self.projects.values()) if not pid else []
        out = []
        for p in rows:
            total = len(p["tasks"]); done = sum(1 for t in p["tasks"] if t["status"] == "completed")
            out.append({"id": p["id"], "title": p["title"], "state": p["state"], "requirements": p["requirements"],
                        "tasks": p["tasks"], "progress": round(done * 100 / total, 1) if total else 0, "report": p["report"]})
        return {"projects": out, "count": len(out), "path": str(self.path)}

# -*- coding: utf-8 -*-
"""Mixium A23 — Autonomous Debug & Repair adapter.

Wraps the A12 DebugLoop (unchanged) and adds: regression check after a fix,
failure learning callback, and rollback on persistent failure.
"""
import threading
import time

MAX_REPAIR = 3


class DebugAdapter:
    def __init__(self, test_fn, fix_fn, analyze_fn=None, regression_fn=None,
                 learn_fn=None, rollback_fn=None, max_repair=MAX_REPAIR):
        from debug_loop import DebugLoop
        self.loop = DebugLoop(test_fn, fix_fn, analyze_fn, max_repair)
        self.regression_fn = regression_fn
        self.learn_fn = learn_fn
        self.rollback_fn = rollback_fn
        self.history = []

    def run(self):
        result = self.loop.run()
        self.history.append(result)
        ok = result.get("status") == "OK"
        # regression check after a successful repair
        if ok and self.regression_fn is not None:
            try:
                reg = self.regression_fn()
                if reg and (reg.get("failed") or reg.get("errors")):
                    result["status"] = "REGRESSION"
                    result["regression"] = reg
                    ok = False
            except Exception as exc:
                result["status"] = "REGRESSION"
                result["regression"] = {"error": str(exc)}
                ok = False
        # learn from failure (isolated callback)
        if not ok and self.learn_fn is not None:
            try:
                self.learn_fn(result)
            except Exception:
                pass
        # rollback on persistent failure
        if not ok and self.rollback_fn is not None:
            try:
                result["rolled_back"] = bool(self.rollback_fn(result))
            except Exception:
                result["rolled_back"] = False
        return result

    def status(self):
        return {"history": self.history[-20:], "count": len(self.history)}

# -*- coding: utf-8 -*-
"""Mixium A30 — Human Bug Reporter (İnsan gibi hata raporu).

"Burada kullanıcı zorlanır", "bu akış mantıksız", "bu hata mesajı yetersiz"
gibi insan-dili raporlar üretir; sonra deep_bug_hunter + autonomous_fix ile
güvenli düzeltme zincirine bağlar (sağlanırsa). Fix engine yoksa yalnızca rapor.
"""

import time


class HumanBugReporter:
    def __init__(self, hunter=None, fix_engine=None):
        self.hunter = hunter      # deep_bug_hunter.DeepBugHunter | None
        self.fix_engine = fix_engine  # autonomous_fix.AutonomousFixEngine | None
        self.reports = []

    def _phrase(self, finding):
        src = (finding or {}).get("source", "unknown")
        result = (finding or {}).get("result", {})
        if result.get("error"):
            return "Hata mesajı yetersiz: %s" % str(result["error"])[:120]
        if result.get("plan"):
            return "Bu akış mantıksız/riskli: %s (%s)" % (
                str(result["plan"]).get("file", "?") if isinstance(result.get("plan"), dict) else result["plan"], src)
        return "Kullanıcı burada zorlanabilir: %s" % src

    def report(self, observations=None):
        findings = []
        if self.hunter is not None:
            try:
                findings = self.hunter.detect()
            except Exception as e:
                findings = [{"source": "hunter", "result": {"error": str(e)[:200]}}]
        if not findings and observations:
            findings = observations
        lines = [self._phrase(f) for f in findings]
        rec = {"reported": lines, "findings": findings, "t": time.time()}
        self.reports.append(rec)
        self.reports = self.reports[-50:]
        return rec

    def run(self, observations=None):
        rec = self.report(observations)
        rec["fix"] = None
        if self.fix_engine is not None:
            plans = [f.get("result", {}).get("plan") for f in rec["findings"]
                     if isinstance(f.get("result"), dict) and f.get("result", {}).get("plan")]
            plans = [p for p in plans if p][:3]
            if plans:
                try:
                    rec["fix"] = self.fix_engine.run(plans)
                except Exception as e:
                    rec["fix"] = {"error": str(e)[:200]}
        return rec

    def status(self):
        return {"reports": len(self.reports), "hunter": self.hunter is not None,
                "fix_engine": self.fix_engine is not None}

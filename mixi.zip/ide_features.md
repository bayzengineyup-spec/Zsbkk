# Mixium IDE Features
- Code / Preview tabs
- Preview button beside copy
- Download and open file actions
- Patch editing instead of full rewrite
- Connection watchdog
- Session persistence

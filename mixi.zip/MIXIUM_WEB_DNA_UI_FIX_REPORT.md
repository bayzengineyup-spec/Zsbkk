# MIXIUM Web + DNA + UI Düzeltme Raporu

## Düzeltilenler

1. Web üst çubuğundaki DNA model seçici kaldırıldı.
2. DNA model seçimi Yönetim Paneli içine taşındı.
3. Yönetim Paneli'ne DNA sekmesi eklendi; mevcut modeller listeleniyor ve aktif DNA modeli değiştirilebiliyor.
4. DNA paneli `panel_dna` WebSocket mesajıyla mevcut DNA yöneticisine bağlandı.
5. Web arayüzündeki eski görsel maskot/OKTO katmanı kaldırıldı; ilgili CSS/JS ve yardımcı dosyalar paket dışına çıkarıldı.
6. AI mesaj avatarı artık sade `M` işaretidir; görsel maskot runtime bağımlılığı yoktur.
7. Web Markdown renderer, modellerin satır sonlarını bozarak ürettiği fenced code block'ları normalize edecek şekilde güçlendirildi. Örneğin `Kurulum```bashgit ...` biçimi görsel olarak kod bloğuna ayrılabilir.
8. NoTrack kompakt prompt yolu selftest beklentisiyle uyumlu hale getirildi.
9. Mixium'un uygulama seviyesinde ayrıca içerik/moderasyon filtresi eklememesini ve doğrudan/samimi iletişimi hedefleyen ortak sistem davranış promptu eklendi.
10. Permission/Sandbox/Approval gibi gerçek sistem güvenlik kapıları korunmuştur.

## Doğrulama

- Python `py_compile`: PASS
- Web JS syntax (`node --check`): PASS
- `selftest.py`: 98 PASS / 0 FAIL / 4 uyarı
- `mixium_new` + `mixiweb` import smoke test: PASS
- Eski görsel kimlik dosyaları kaldırıldı.

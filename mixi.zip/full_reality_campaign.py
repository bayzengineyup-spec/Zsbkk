# -*- coding: utf-8 -*-
"""Mixium A30 — Full Reality Campaign (Gerçek kullanım kampanyası).

CHAT / MEMORY / TOOLS / STREAMING / FILE / AGENT senaryo grupları. Adapter
enjeksiyonlu; eksik adapter fail-closed (skipped). Sonuçlar `.mixium/`
altına yazılmaz (yalnızca bellek içi rapor), güvenlik zinciri değişmez.
"""

import time

GROUPS = ("chat", "memory", "tools", "streaming", "file", "agent")


class FullRealityCampaign:
    def __init__(self, adapters=None):
        self.adapters = dict(adapters or {})

    def _call(self, group):
        fn = self.adapters.get(group)
        if fn is None:
            return {"ok": False, "skipped": True, "reason": "adapter yok"}
        try:
            r = fn() if callable(fn) else fn
            return r if isinstance(r, dict) else {"ok": True, "result": r}
        except Exception as e:
            return {"ok": False, "error": str(e)[200]}

    def run(self, groups=None):
        groups = list(groups) if groups else list(GROUPS)
        out = {"groups": [], "passed": 0, "skipped": 0, "failed": 0}
        for g in groups:
            if g not in GROUPS:
                continue
            r = self._call(g)
            if r.get("skipped"):
                out["skipped"] += 1
            elif r.get("ok"):
                out["passed"] += 1
            else:
                out["failed"] += 1
            out["groups"].append({"group": g, "result": r})
        out["t"] = time.time()
        return out

    def status(self):
        return {"groups": list(GROUPS), "adapters": sorted(self.adapters.keys())}

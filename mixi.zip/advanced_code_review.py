# -*- coding: utf-8 -*-
"""Mixium A26 — Advanced Code Review Intelligence.

Kodu inceler: mimari kalite, okunabilirlik, sürdürülebilirlik, güvenlik,
performans, hata ihtimali, gereksiz karmaşıklık, büyüme problemi.
Çıktı: quality_score, risk_score, improvement_plan. Deterministik ve şeffaf.
"""


class AdvancedCodeReview:
    # (anahtar, kategori, önem, öneri) — deterministik kurallar
    RULES = [
        ("eval(", "security", 4, "eval kullanımı tehlikeli; safe parser kullan."),
        ("exec(", "security", 4, "exec kullanımından kaçın."),
        ("shell=True", "security", 4, "subprocess shell=True riskli."),
        ("except:", "error_risk", 3, "çıplak except hataları yutar; spesifik exception yakala."),
        ("TODO", "maintainability", 1, "TODO'ları tamamla veya izle."),
        ("global ", "maintainability", 2, "global state'i azalt; açık parametre geç."),
        ("while True", "complexity", 2, "sonsuz döngü çıkış koşulunu doğrula."),
        ("import *", "maintainability", 2, "yıldız import'tan kaçın."),
        ("print(", "readability", 1, "kalıcı print yerine logger kullan."),
    ]

    def __init__(self, rules=None):
        self.rules = list(rules or self.RULES)

    def review(self, code):
        lines = (code or "").splitlines()
        text = code or ""
        findings = []
        for kw, cat, sev, sug in self.rules:
            if kw in text:
                findings.append({"category": cat, "severity": sev,
                                 "pattern": kw, "suggestion": sug})
        # uzunluk / karmaşıklık
        if len(lines) > 400:
            findings.append({"category": "complexity", "severity": 2,
                             "pattern": "dosya>400 satır", "suggestion": "modülü böl."})
        if text.count("if ") + text.count("elif ") > 50:
            findings.append({"category": "complexity", "severity": 2,
                             "pattern": "çok sayıda dallanma", "suggestion": "erken return / polimorfizm."})
        # skorlar
        qual = max(0, 100 - sum(f["severity"] * 4 for f in findings))
        risk = min(100, sum(f["severity"] * 8 for f in findings))
        plan = []
        for f in sorted(findings, key=lambda x: -x["severity"])[:5]:
            plan.append("%s: %s" % (f["category"], f["suggestion"]))
        return {
            "quality_score": qual,
            "risk_score": risk,
            "findings": findings,
            "improvement_plan": plan,
            "summary": "%d bulgu" % len(findings),
        }

    def status(self):
        return {"rules": len(self.rules)}

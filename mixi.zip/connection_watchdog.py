"""Prevents infinite connecting states."""
import time

class ConnectionWatchdog:
    def __init__(self, timeout=15):
        self.timeout = timeout
        self.started = None

    def start(self):
        self.started = time.time()

    def timed_out(self):
        return self.started is not None and time.time() - self.started > self.timeout

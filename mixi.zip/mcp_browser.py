# -*- coding: utf-8 -*-
"""
Mixium — MCP Browser (Playwright MCP sunucusu entegrasyonu)

@playwright/mcp sunucusunu (mcp_browser/ altina kurulu) stdio yerine
**streamable HTTP** (SSE) modunda çalıştırır: stdio transport bu ortamda
yanıt vermiyor (Termux), SSE/HTTP modu doğrulandı ve çalışıyor.

Yaşam döngüsü (kendi kendini yönetir):
    ensure() -> start() -> initialize() -> tools/call -> stop()

Kullanım (browser_agent.py ile uyumlu):
    mb = MCPBrowser(root=".")
    mb.ensure()
    mb.call("navigate", {"url": "https://example.com"})
    mb.call("extract_text", {})
    mb.stop()

Fail-closed: sunucu yoksa / yanıt vermezse HATA döner, sistem çökmez.
MIXIUM'a bağımlı değildir. Yalnızca stdlib (urllib + subprocess).
"""

import json
import os
import random
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

# ── tool adı eşlemesi: semantik aksiyon -> @playwright/mcp tool ────────
ACTION_TO_TOOL = {
    "navigate": "browser_navigate",
    "click": "browser_click",
    "type": "browser_type",
    "fill": "browser_type",
    "press": "browser_press_key",
    "hover": "browser_hover",
    "select": "browser_select_option",
    "extract_text": "browser_snapshot",
    "snapshot": "browser_snapshot",
    "screenshot": "browser_screenshot",
    "close": "browser_close",
    "wait": "browser_wait",
    "new_tab": "browser_new_page",
    "tab_list": "browser_tab_list",
    "tab_close": "browser_tab_close",
}

RISKY = ("click", "type", "fill", "press", "select", "hover", "submit")


class MCPBrowser:
    """Playwright MCP sunucusu üzerinden tarayıcı otomasyonu.

    - sunucu sürecini yönetir (port çakışmasında yeni port dener)
    - streamable HTTP (POST /mcp) JSON-RPC ile konuşur
    - `call(action, args)` semantik aksiyonları tool adlarına eşler
    """

    def __init__(self, root=".", port=None, approve_fn=None, timeout=25):
        self.root = Path(root)
        self.port = port or self._free_port()
        self.timeout = timeout
        self.approve_fn = approve_fn or (lambda action, args: (True, ""))
        self.proc = None
        self.session_id = None
        self.tools = []
        self._ready = False
        self._lock = threading.RLock()
        self._candidates = self._server_candidates()

    # ── yardımcılar ────────────────────────────────────────────────
    def _free_port(self):
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        return port

    def _server_candidates(self):
        """Sunucu komut adayları (mcp_browser/node_modules + global npx)."""
        candidates = []
        base = self.root / "mcp_browser" / "node_modules" / "@playwright" / "mcp"
        if (base / "cli.js").exists():
            candidates.append(["node", str(base / "cli.js")])
        npx = os.environ.get("NPM_CONFIG_PREFIX") or os.environ.get("npm_config_prefix")
        if npx:
            candidates.append([str(Path(npx) / "bin" / "playwright-mcp")])
        candidates.append(["npx", "-y", "@playwright/mcp"])
        return candidates

    def _endpoint(self):
        return "http://127.0.0.1:%d/mcp" % self.port

    # ── yaşam döngüsü ──────────────────────────────────────────────
    def start(self, wait_s=45):
        """Sunucuyu başlat (headless + no-sandbox + isolated)."""
        with self._lock:
            if self.proc is not None and self.proc.poll() is None:
                return True
            # bilinen chromium yolu varsa deterministik olsun
            cr = self._chromium_path()
            args = ["--headless", "--no-sandbox", "--isolated",
                    "--host", "127.0.0.1", "--port", str(self.port),
                    "--allowed-hosts", "*"]
            if cr:
                args += ["--executable-path", cr, "--browser", "chromium"]
            for cmd in self._candidates:
                try:
                    self.proc = subprocess.Popen(
                        cmd + args,
                        stdin=subprocess.DEVNULL,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        env=dict(os.environ),
                    )
                except Exception:
                    self.proc = None
                    continue
                # sunucunun ayağa kalkmasını bekle (Chromium ilk açılış yavaş)
                deadline = time.time() + wait_s
                while time.time() < deadline:
                    if self.proc.poll() is not None:
                        break
                    if self._ping():
                        return True
                    time.sleep(0.5)
                # port dinlenmiyorsa sonraki aday
                try:
                    self.proc.kill()
                except Exception:
                    pass
                self.proc = None
            return False

    @staticmethod
    def _chromium_path():
        """Termux/ci ortamlarında indirilen chromium binary'sini bul."""
        cands = [
            "/root/.cache/ms-playwright/chromium-1181/chrome-linux/chrome",
            "/data/data/com.termux/files/usr/bin/chromium",
        ]
        for c in cands:
            if os.path.exists(c):
                return c
        return None

    def _ping(self):
        """Sunucu ayakta mı? POST /mcp 405 döner (GET desteklenmez) —
        HTTPError bile sunucunun dinledigini gosterir."""
        try:
            urllib.request.urlopen(self._endpoint(), timeout=2)
            return True
        except urllib.error.HTTPError as e:
            return e.code in (400, 401, 403, 404, 405, 500)
        except Exception:
            return False

    def stop(self):
        with self._lock:
            if self.proc is not None:
                try:
                    self.proc.kill()
                except Exception:
                    pass
                self.proc = None
            self.session_id = None
            self._ready = False

    def ensure(self):
        """Bağlantıyı garantile: start + initialize + tools/list."""
        if self._ready:
            return True
        if not self.start():
            return False
        try:
            self._post({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "mixium", "version": "1.0"},
            }})
            try:
                # notification: yanıt gövdesi beklenmez (id yok)
                self._post({"jsonrpc": "2.0", "method": "notifications/initialized",
                            "params": {}}, expect_body=False)
            except Exception:
                pass
            r = self._post({"jsonrpc": "2.0", "id": 2, "method": "tools/list",
                            "params": {}})
            self.tools = self._extract_result(r).get("tools", []) or []
            self._ready = True
            return True
        except Exception:
            self.stop()
            return False

    # ── JSON-RPC (streamable HTTP) ─────────────────────────────────
    def _post(self, payload, expect_body=True):
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(self._endpoint(), data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json, text/event-stream")
        if self.session_id:
            req.add_header("Mcp-Session-Id", self.session_id)
        resp = urllib.request.urlopen(req, timeout=self.timeout)
        sid = resp.headers.get("Mcp-Session-Id")
        if sid:
            self.session_id = sid
        body = resp.read().decode("utf-8", "replace")
        if not expect_body and not body.strip():
            return {}
        if "text/event-stream" in (resp.headers.get("Content-Type") or ""):
            out = None
            for line in body.splitlines():
                line = line.strip()
                if line.startswith("data:"):
                    try:
                        msg = json.loads(line[5:].strip())
                    except Exception:
                        continue
                    if msg.get("id") == payload.get("id"):
                        out = msg
            if out is None:
                raise RuntimeError("SSE yanitinda istek id bulunamadi")
            return out
        try:
            return json.loads(body)
        except Exception:
            raise RuntimeError("bozuk JSON yanit")

    @staticmethod
    def _extract_result(msg):
        if isinstance(msg, dict) and "result" in msg:
            return msg["result"]
        return {}

    # ── semantik aksiyon ───────────────────────────────────────────
    def call(self, action, args=None):
        """browser_agent.py uyumlu: (action, args) -> str sonuç."""
        args = dict(args or {})
        action = (action or "").lower()
        if action in RISKY:
            ok, why = self.approve_fn(action, args)
            if not ok:
                return "HATA: onay gerekli — %s" % why
        if not self._ready and not self.ensure():
            return "HATA: Playwright MCP sunucusu baslatilamadi"
        if action == "navigate":
            tool, params = "browser_navigate", {"url": args.get("url") or ""}
        elif action == "click":
            tool, params = self._locate("browser_click", args)
        elif action == "type" or action == "fill":
            tool, params = self._locate("browser_type", args)
            params["text"] = args.get("value") or args.get("text") or ""
        elif action == "extract_text" or action == "content":
            tool, params = "browser_snapshot", {}
        elif action == "screenshot":
            tool, params = "browser_screenshot", {"fullPage": bool(args.get("fullPage"))}
        elif action == "close":
            tool, params = "browser_close", {}
        elif action == "wait":
            tool, params = "browser_wait", {}
        elif action == "press":
            tool, params = self._locate("browser_press_key", args)
            params["key"] = args.get("key") or args.get("value") or ""
        elif action in ACTION_TO_TOOL:
            tool, params = ACTION_TO_TOOL[action], args
        else:
            return "HATA: bilinmeyen aksiyon: %s" % action
        # tool sunucuda yoksa fallback
        names = {t.get("name") for t in self.tools}
        if tool not in names:
            return "HATA: MCP tool yok: %s" % tool
        try:
            r = self._post({"jsonrpc": "2.0", "id": 3, "method": "tools/call",
                            "params": {"name": tool, "arguments": params or {}}})
        except Exception as e:
            return "HATA: MCP cagri basarisiz — %s" % e
        result = self._extract_result(r)
        if isinstance(result, dict):
            if result.get("isError"):
                content = result.get("content") or []
                txt = "; ".join(str(c.get("text", "")) for c in content if isinstance(c, dict))
                return "HATA: %s" % (txt or "MCP tool hatasi")
            content = result.get("content") or []
            txt = " ".join(str(c.get("text", "")) for c in content if isinstance(c, dict))
            return txt or json.dumps(result, ensure_ascii=False)[:800]
        return str(result)[:1200]

    def _locate(self, tool, args):
        """selector/element referansını tool'a uygun param olarak ilet."""
        params = {}
        if args.get("ref"):
            params["ref"] = args["ref"]
        elif args.get("selector"):
            params["selector"] = args["selector"]
        elif args.get("element"):
            params["element"] = args["element"]
        return tool, params

    def status(self):
        return {
            "engine": "mcp (@playwright/mcp, streamable HTTP)",
            "running": self.proc is not None and self.proc.poll() is None,
            "ready": self._ready,
            "port": self.port,
            "tools": sorted({t.get("name") for t in self.tools}),
            "session": bool(self.session_id),
        }

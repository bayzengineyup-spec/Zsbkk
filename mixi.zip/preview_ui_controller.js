/* Mixium Preview UI Controller */
window.MixiumPreview = {
  canPreview(name){
    return /\.(html?|svg|md)$/i.test(name || "");
  },
  open(file){
    window.dispatchEvent(new CustomEvent("mixium:preview",{detail:{file}}));
  }
};

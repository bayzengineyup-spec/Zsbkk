# -*- coding: utf-8 -*-
"""Mixium A22 — Self Optimization Engine.

Analyzes performance signals and produces proposals only. Applying a
proposal requires approval + checkpoint; it never self-modifies security.
"""
import threading
import time
import uuid


class SelfOptimizer:
    def __init__(self, providers=None, max_proposals=50):
        self.providers = dict(providers or {})
        self.max_proposals = max(1, int(max_proposals))
        self._lock = threading.RLock()
        self.proposals = []

    def _get(self, name, default=None):
        fn = self.providers.get(name)
        if fn is None:
            return default
        try:
            v = fn()
            return default if v is None else v
        except Exception:
            return default

    def analyze(self):
        """Collect performance signals and produce proposals."""
        proposals = []
        health = self._get("health", {}) or {}
        if isinstance(health, dict) and health.get("system_health", 100) < 70:
            proposals.append(("health", "Sistem health düşük; hatalı bileşenleri incele."))
        tests = self._get("tests", {}) or {}
        if isinstance(tests, dict) and (tests.get("failed", 0) or tests.get("errors", 0)):
            proposals.append(("testing", "Test başarısızlıkları var; debug loop ve test workflow'u gözden geçir."))
        reputation = self._get("reputation", {}) or {}
        leaderboard = reputation.get("leaderboard", []) if isinstance(reputation, dict) else []
        for row in leaderboard[:5]:
            if isinstance(row, dict) and row.get("success_rate", 100) < 60:
                proposals.append(("agent", "%s agent başarı oranı düşük (%s%%); görev dağıtımını gözden geçir." % (row.get("role"), row.get("success_rate"))))
        experiences = self._get("experience", {}) or {}
        if isinstance(experiences, dict) and experiences.get("failures", 0) > experiences.get("success", 0):
            proposals.append(("experience", "Başarısız deneyimler artıyor; çözüm pattern'lerini doğrula."))
        optimizer = self._get("optimizer", {}) or {}
        if isinstance(optimizer, dict) and optimizer.get("applied"):
            proposals.append(("optimization", "Önceki optimizasyonlar uygulanmış; sonuçlarını ölç."))
        if not proposals:
            proposals.append(("continuous", "Performans sinyalleri sağlıklı; izlemeye devam et."))
        result = []
        for area, text in proposals[:self.max_proposals]:
            result.append({"id": "opt_" + uuid.uuid4().hex[:8], "area": area, "proposal": text,
                           "status": "proposed", "created": time.time()})
        with self._lock:
            self.proposals.extend(result)
            self.proposals = self.proposals[-self.max_proposals:]
        return result

    def apply(self, proposal_id, approved=False):
        """Mark a proposal applied only when explicitly approved (permission chain)."""
        with self._lock:
            for p in self.proposals:
                if p["id"] == str(proposal_id):
                    p["status"] = "applied" if approved else "rejected"
                    p["updated"] = time.time()
                    return dict(p)
        return None

    def status(self):
        with self._lock:
            return {"proposals": list(self.proposals[-20:]), "count": len(self.proposals)}

# -*- coding: utf-8 -*-
"""Mixium A25E — Autonomous Test Engine.

Kendi test senaryolarını üretir, çalıştırır, sonucu analiz eder ve yeni test
ekler. Mevcut test_lab.TestLab (B6) yeniden yazılmaz; bu modül onu sararak
senaryo üretimi + sonuç analizi + genişletme ekler.
"""

import time


class AutonomousTestEngine:
    def __init__(self, lab=None, generators=None):
        """
        lab : test_lab.TestLab (register/run)
        generators: {name: callable -> bool} kullanıcı tanımlı senaryo üreticileri
        """
        self.lab = lab
        self.generators = dict(generators or {})
        self.generated = []   # üretilmiş senaryo kayıtları
        self.last_run = None

    def generate(self, specs):
        """specs: [ (name, bool_func, desc) ] — senaryoları lab'a kaydeder."""
        added = []
        for name, fn, desc in specs:
            if self.lab is not None:
                self.lab.register("autonomous", name, fn, desc)
            self.generated.append({"name": name, "desc": desc})
            added.append(name)
        return added

    def run(self, groups=None):
        if self.lab is None:
            return {"summary": "lab yok", "passed": 0, "failed": 0, "errors": 0, "total": 0}
        groups = groups or ["autonomous"]
        self.last_run = self.lab.run(groups)
        return self.last_run

    def analyze(self):
        """Son çalıştırma sonucunu analiz edip öneri üretir."""
        if not self.last_run:
            return {"analyzed": False, "message": "henüz çalıştırılmadı"}
        r = self.last_run
        total = r.get("total", 0)
        passed = r.get("passed", 0)
        rate = round(100.0 * passed / total, 1) if total else 0.0
        new_tests = []
        for g, res in (r.get("groups") or {}).items():
            for row in res:
                if row.get("status") in ("FAIL", "ERROR"):
                    new_tests.append({"name": "retry_" + row.get("name"),
                                      "desc": "yeniden dene: " + row.get("name")})
        return {"pass_rate": rate, "failed": r.get("failed", 0),
                "errors": r.get("errors", 0), "suggest_new_tests": new_tests[:10]}

    def status(self):
        return {"generated": len(self.generated), "last_run": self.last_run}

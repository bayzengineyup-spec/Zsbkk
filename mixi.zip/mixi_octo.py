#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mixium Maskot Motoru v2  —  Braille piksel sistemi
===================================================
Her Braille karakteri = 2 geniş × 4 yüksek piksel
Aynı terminal alanına 4× daha fazla dikey çözünürlük.

Mevcut _mixi_pixels() + _blit() sisteminin yerini alır.
State parametresi: idle | thinking | tool_bash | tool_read |
                   tool_write | tool_fetch | tool_grep | done | error
"""

import math
import time
import sys
import os
import re as _re

# ── Braille bit haritası ────────────────────────────────────────────────
#   col0  col1
#   0x01  0x08   row 0 (en üst)
#   0x02  0x10   row 1
#   0x04  0x20   row 2
#   0x40  0x80   row 3 (en alt)
_BR_MAP = [
    [0x01, 0x02, 0x04, 0x40],   # sol sütun
    [0x08, 0x10, 0x20, 0x80],   # sağ sütun
]

_ANSI_STRIP = _re.compile(r"\x1b\[[0-9;]*m")

def _br(bits_2x4):
    """2×4 piksel matrisini tek Braille karaktere çevirir."""
    b = 0
    for c in range(2):
        for r in range(4):
            if bits_2x4[c][r]:
                b |= _BR_MAP[c][r]
    return chr(0x2800 + b)

# ── Renk ────────────────────────────────────────────────────────────────
def _rgb(r, g, b, bg=False):
    return f"\x1b[{48 if bg else 38};2;{r};{g};{b}m"

def _mix(c1, c2, t):
    t = max(0.0, min(1.0, t))
    return tuple(round(a + (b - a) * t) for a, b in zip(c1, c2))

RST = "\x1b[0m"

# Tema renkleri (Mixium varsayılan) — parlak, karanlık değil
SKIN   = (210, 195, 255)   # açık mor, net görünür
SKIN2  = (160, 140, 240)   # gölge ama HÂLâ mor görünür (eskiden çok karanlıktı)
RIM    = (80, 230, 210)    # turkuaz rim parlak
WHITE  = (244, 248, 255)
DARK   = (15,  20,  35)
OK_G   = (74, 222, 128)    # yeşil parıltı
ERR_R  = (251, 113, 133)   # kırmızı

# ── Piksel tuvali ────────────────────────────────────────────────────────
class Canvas:
    """Piksel tabanlı tuval. set(x,y,rgb) ile piksel yaz, to_braille() ile çıktı al."""
    def __init__(self, W, H):
        self.W = W
        self.H = H
        self.buf = {}   # (x,y) -> (r,g,b)

    def set(self, x, y, rgb, over=True):
        xi, yi = int(round(x)), int(round(y))
        if 0 <= xi < self.W and 0 <= yi < self.H:
            if over or (xi, yi) not in self.buf:
                self.buf[(xi, yi)] = rgb

    def set_aa(self, x, y, rgb, over=True):
        """Anti-aliased nokta: komşu piksellere de yaz."""
        self.set(x, y, rgb, over)
        fx, fy = x - int(x), y - int(y)
        if fx > 0.3:
            self.set(x + 1, y, _mix(self.buf.get((int(x)+1, int(y)), (0,0,0)), rgb, fx * 0.5), over)
        if fy > 0.3:
            self.set(x, y + 1, _mix(self.buf.get((int(x), int(y)+1), (0,0,0)), rgb, fy * 0.5), over)

    def line(self, x0, y0, x1, y1, rgb, thick=1):
        """Bresenham çizgi."""
        dx, dy = abs(x1-x0), abs(y1-y0)
        steps = max(int(max(dx, dy) * 2.5), 2)
        for i in range(steps + 1):
            t = i / steps
            x = x0 + (x1 - x0) * t
            y = y0 + (y1 - y0) * t
            self.set(x, y, rgb)
            if thick > 1:
                self.set(x + 1, y, rgb)
                self.set(x, y + 1, rgb)

    def circle(self, cx, cy, rx, ry, rgb, fill=True, thick=1):
        """Elips çiz."""
        for y in range(max(0, int(cy-ry)-1), min(self.H, int(cy+ry)+2)):
            for x in range(max(0, int(cx-rx)-1), min(self.W, int(cx+rx)+2)):
                nx = (x - cx) / max(0.5, rx)
                ny = (y - cy) / max(0.5, ry)
                d = nx*nx + ny*ny
                if fill:
                    if d <= 1.0:
                        self.set(x, y, rgb)
                else:
                    edge = 1.0 - thick / max(rx, ry)
                    if edge <= d <= 1.0:
                        self.set(x, y, rgb)

    def _neighbors4(self, x, y):
        """4-yönlü komşu (yukarı/aşağı/sol/sağ). Sınır dışına taşmaz."""
        out = []
        if x > 0:           out.append((x - 1, y))
        if x < self.W - 1:  out.append((x + 1, y))
        if y > 0:           out.append((x, y - 1))
        if y < self.H - 1:  out.append((x, y + 1))
        return out

    def fill_holes(self, max_region=24, margin_pixels=1):
        """BFS flood-fill ile sınırlanmış boşlukları doldurur.

        İki geçişli akıllı doldurma:
          1) Tüm BOŞ bölgeler BFS ile dolaşılır; bir bölge "sınırlı"
             sayılır eğer hiçbir pikseli kenar çerçevesine (margin)
             ulaşmıyorsa.
          2) Bounded bölgelerin alanı küçükse (<= max_region) tamamen
             doldurulur — komşu piksellerin ağırlıklı ortalamasıyla.

        Bu algoritma göz bebeği gibi küçük fontanelleri ve gövde
        alt-örnekleme kaynaklı tek delikleri temizlerken, kollar
        arasındaki geniş boşlukları ve vücut kenarındaki hafif
        açıklıkları KORUR (kolları yapıştırmaz).

        margin_pixels=1 → sınırın 1 piksel içinden başlayan boşluk
        "sınırsız" sayılır (kolların arasındaki doğal hava boşluğu).
        """
        # 1) Sınır-dokunan boş pikselleri "outside" olarak işaretle
        outside = set()
        from collections import deque
        q = deque()
        # Kenardan başla
        for x in range(self.W):
            if (x, 0) not in self.buf:
                outside.add((x, 0)); q.append((x, 0))
            if (x, self.H - 1) not in self.buf:
                outside.add((x, self.H - 1)); q.append((x, self.H - 1))
        for y in range(self.H):
            if (0, y) not in self.buf:
                outside.add((0, y)); q.append((0, y))
            if (self.W - 1, y) not in self.buf:
                outside.add((self.W - 1, y)); q.append((self.W - 1, y))
        # BFS ile margin_pixels dahil genişlet
        for _ in range(margin_pixels):
            nq = deque()
            seen = set(outside)
            while q:
                cx, cy = q.popleft()
                for nx, ny in self._neighbors4(cx, cy):
                    if (nx, ny) in seen:
                        continue
                    if (nx, ny) not in self.buf:
                        seen.add((nx, ny))
                        nq.append((nx, ny))
            outside = seen
            q = nq

        # 2) Kalan boş bölgeleri BFS ile grupla; küçükse doldur
        visited = set(outside)
        fill_groups = []
        for sy in range(self.H):
            for sx in range(self.W):
                if (sx, sy) in visited:
                    continue
                if (sx, sy) in self.buf:
                    continue
                # yeni sınırlı bölge
                region = []
                rq = deque([(sx, sy)])
                visited.add((sx, sy))
                while rq:
                    cx, cy = rq.popleft()
                    region.append((cx, cy))
                    for nx, ny in self._neighbors4(cx, cy):
                        if (nx, ny) in visited:
                            continue
                        if (nx, ny) in self.buf:
                            continue
                        visited.add((nx, ny))
                        rq.append((nx, ny))
                if 0 < len(region) <= max_region:
                    fill_groups.append(region)

        # 3) Her bounded bölge için komşu piksellerden ortalama renk
        for region in fill_groups:
            r_acc = g_acc = b_acc = n_count = 0
            for cx, cy in region:
                for nx, ny in self._neighbors4(cx, cy):
                    if (nx, ny) in outside:
                        continue
                    c = self.buf.get((nx, ny))
                    if c is None:
                        continue
                    r_acc += c[0]; g_acc += c[1]; b_acc += c[2]
                    n_count += 1
            if n_count == 0:
                continue
            fill_rgb = (r_acc // n_count, g_acc // n_count, b_acc // n_count)
            for cx, cy in region:
                self.buf[(cx, cy)] = fill_rgb

    def to_braille_rows(self, fill_holes=False):
        """Piksel bufferını Braille+ANSI satırları listesine çevirir.

        fill_holes=False (varsayilan): animasyon sirasinda her frame
        BFS region-fill cagirmaz — bu, dokunun frame'den frame'e
        "morphing" etmesini onler (eski tasarimda da fill_yOK idi).
        Final/dondurulmus sprite uretmek istiyorsan fill_holes=True.
        """
        if fill_holes:
            self.fill_holes()
        cw = (self.W + 1) // 2
        ch = (self.H + 3) // 4
        rows = []
        for cy in range(ch):
            parts = [RST]          # her satır başında renk sıfırla
            last_rgb = None
            for cx in range(cw):
                bits = [[0]*4 for _ in range(2)]
                colors = []
                for dc in range(2):
                    for dr in range(4):
                        px = cx*2 + dc
                        py = cy*4 + dr
                        rgb = self.buf.get((px, py))
                        if rgb:
                            bits[dc][dr] = 1
                            colors.append(rgb)
                ch_rgb = colors[len(colors)//2] if colors else None
                br = _br(bits)
                if ch_rgb:
                    if ch_rgb != last_rgb:
                        parts.append(RST + _rgb(*ch_rgb))
                        last_rgb = ch_rgb
                    parts.append(br)
                else:
                    if last_rgb is not None:
                        parts.append(RST)
                        last_rgb = None
                    parts.append(' ')
            rows.append(''.join(parts) + RST)
        # Alttaki tamamen bos satirlari kirp — done/error gibi state'lerde
        # kollar yukari toplaninca 2-3 bos satir kalirdi (ekran israfi).
        while len(rows) > 1 and not _ANSI_STRIP.sub("", rows[-1]).strip():
            rows.pop()
        return rows


# ── Ahtapot gövde çizici ─────────────────────────────────────────────────
def _draw_body(cv, t, state, W, H, eyes_only=False):
    """Gövde (mantle) + gözler + nefes.

    eyes_only=True ise gövde pikselleri yeniden taranmaz; yalnizca göz
    + kaş katmanı üste çizilir. mixi_frame_braille iki kez çağırır:
    ilkinde gövde, ikincisinde sadece gözler — yüksek çözünürlükte
    gövde taraması (W×H×4 alt-örnek) en pahalı adım olduğu için
    tekrar etmemek performansı ~2× artırır.
    """
    hx = (W - 1) / 2.0
    breathe = 1.0 + 0.018 * math.sin(t * 1.4)

    # Error state: kızarma
    if state == 'error':
        body_color = _mix(SKIN, ERR_R, 0.55 + 0.15 * math.sin(t * 4))
        body_dark  = _mix(SKIN2, ERR_R, 0.4)
    elif state == 'done':
        body_color = _mix(SKIN, OK_G, 0.25 + 0.1 * math.sin(t * 2))
        body_dark  = SKIN2
    else:
        body_color = SKIN
        body_dark  = SKIN2

    # Damla formu parametreleri
    head_h = H * 0.52 * breathe
    ry = head_h / 2.0
    hy = ry * 0.80
    rx = W * 0.36 * (2.0 - breathe)

    if not eyes_only:
        # Gövde pikselleri — kenar/köşe deliklerini önlemek için her hücre
        # 2×2 alt-örnekle taranır; herhangi bir alt-örnek şeklin içindeyse
        # o tam piksel doldurulur (kapsama testi, nokta testinden daha sağlam).
        for y in range(H):
            for x in range(W):
                inside = False
                best_d = None
                for oy in (0.25, 0.75):
                    for ox in (0.25, 0.75):
                        nx = (x + ox - hx) / max(0.1, rx)
                        ny = (y + oy - hy) / max(0.1, ry)
                        shape_k = 1.0 + 0.15 * ny
                        d = (nx / shape_k)**2 + abs(ny)**2.0
                        if d <= 1.0:
                            inside = True
                            if best_d is None or d < best_d:
                                best_d = d
                if not inside:
                    continue
                nx = (x - hx) / max(0.1, rx)
                ny = (y - hy) / max(0.1, ry)
                d = best_d
                # Işık modeli: daha parlak taban (0.45 yerine 0.65)
                lam = 0.65 - 0.30 * (nx * 0.40 + ny * 0.60)
                lam = max(0.0, min(1.0, lam))
                if d > 0.82 and ny > -0.05:
                    rim_t = (d - 0.82) / 0.18
                    rgb = _mix(body_color, RIM, 0.30 + 0.40 * rim_t)
                else:
                    # min değeri yükselt: karanlık bölgeler de görünür olsun
                    rgb = _mix(body_dark, body_color, min(1.0, lam * 1.3 + 0.2))
                cv.set(x, y, rgb)

        # Done: yeşil parıltı halkası
        if state == 'done':
            pulse = 0.5 + 0.5 * math.sin(t * 3.5)
            for angle in range(0, 360, 8):
                a = math.radians(angle)
                px = hx + rx * 1.05 * math.cos(a)
                py = hy + ry * 1.05 * math.sin(a)
                rgb = _mix(RIM, OK_G, pulse)
                cv.set(px, py, rgb)

    # Gözler
    exo = W * 0.19
    eyy = hy + ry * 0.18
    erx = W * 0.11
    ery = ry * 0.36

    # Göz kırpma
    blink_cycle = 5.2
    bp = (t % blink_cycle) / blink_cycle
    blink = bp > 0.96

    # thinking: kaşlar çatılır (göz köşeleri yukarı)
    brow_offset = -ry * 0.08 if state == 'thinking' else 0

    # Bakış yönü
    if state in ('tool_bash', 'tool_write'):
        gx = W * 0.08   # sağa bak
        gy = ry * 0.05
    elif state == 'tool_read':
        gx = -W * 0.06
        gy = -ry * 0.05
    elif state == 'tool_fetch':
        gx = W * 0.10
        gy = -ry * 0.08
    elif state == 'thinking':
        gx = -W * 0.04 + W * 0.06 * math.sin(t * 0.8)
        gy = -ry * 0.12
    else:
        gx = 0.45 * math.sin(t * 0.55 + 0.4)
        gy = 0.22 * math.sin(t * 0.43 + 1.3)

    for sgn in (-1, 1):
        cx2 = hx + sgn * exo
        eh = ery * (0.12 if blink else 1.0)
        # Göz akı
        for dy2 in range(-int(ery)-1, int(ery)+2):
            for dx2 in range(-int(erx)-1, int(erx)+2):
                nx2 = dx2 / max(0.5, erx)
                ny2 = dy2 / max(0.5, max(0.5, eh))
                if nx2*nx2 + ny2*ny2 <= 1.0:
                    cv.set(cx2 + dx2, eyy + dy2 + brow_offset, WHITE)

        if blink:
            continue

        # Göz bebeği
        pcx = cx2 + gx
        pcy = eyy + gy + brow_offset
        pbr = erx * 0.46
        pbry = ery * 0.54
        for dy2 in range(-int(pbry)-1, int(pbry)+2):
            for dx2 in range(-int(pbr)-1, int(pbr)+2):
                if (dx2/max(0.5,pbr))**2 + (dy2/max(0.5,pbry))**2 <= 1.0:
                    cv.set(pcx + dx2, pcy + dy2, DARK)

        # Parıltı
        cv.set(pcx - erx*0.30, pcy - ery*0.38, WHITE)

    # Thinking: kaş çizgileri
    if state == 'thinking':
        for sgn in (-1, 1):
            cx2 = hx + sgn * exo
            y_brow = eyy + brow_offset - ery - 1
            x0b = cx2 - erx * 0.9
            x1b = cx2 + erx * 0.9
            y0b = y_brow + sgn * 0.8
            y1b = y_brow - sgn * 0.8
            brow_rgb = _mix(SKIN2, DARK, 0.6)
            cv.line(x0b, y0b, x1b, y1b, brow_rgb)

    return hx, hy, rx, ry


# ── Kol çizici ───────────────────────────────────────────────────────────
def _draw_arms(cv, t, state, W, H, hx, hy, rx, ry):
    """8 kol — state'e göre hedef noktalarına tween.

    ONEMLI: Bu fonksiyondaki kol cizim dongusu HER state icin calisir.
    Daha once dongu yanlislikla 'elif state == "error"' blogunun icinde
    kalmisti; bu yuzden idle/thinking/done durumlarinda kollar HIC
    cizilmiyor, ahtapot bos bir govde lekesi olarak gorunuyordu.
    """

    # Her kol için hedef noktası (normalleştirilmiş -1..1)
    # (target_x_offset, target_y_offset, curl_amp, extend_ratio)
    # target_x_offset: hx'e göre
    # extend_ratio: kolun ne kadar uzandığı (1.0 = tam)

    n_arm = 8
    ybase = hy + ry * 0.70

    # State bazlı özel kol pozisyonları
    # arm_overrides: arm_index -> (tx, ty, extend, curl_mul)
    arm_overrides = {}

    if state == 'thinking':
        # Kol 6 (sağ iç): başa gider
        arm_overrides[6] = (hx + rx * 0.2, hy - ry * 0.3, 0.6, 0.3)
        # Kol 2 (sol): kitap tutar (aşağıda)
        arm_overrides[2] = (hx - rx * 1.1, hy + ry * 0.5, 0.7, 0.2)

    elif state == 'tool_bash':
        # Kol 5 (sağ): terminale uzanır
        arm_overrides[5] = (W * 0.92, H * 0.45, 0.85, 0.1)

    elif state == 'tool_read':
        # İki kol karşılıklı uzanır
        arm_overrides[1] = (-W * 0.05, H * 0.55, 0.80, 0.15)
        arm_overrides[6] = (W * 1.05, H * 0.55, 0.80, 0.15)

    elif state == 'tool_write':
        # Kol 6: sağa uzanır (kalem ucu)
        arm_overrides[6] = (W * 0.90, H * 0.38, 0.80, 0.08)

    elif state == 'tool_fetch':
        # Kol 7: sağa yukarı uzanır (küre)
        arm_overrides[7] = (W * 0.95, H * 0.30, 0.75, 0.05)

    elif state == 'tool_grep':
        # Kol 6: sağ-aşağı (büyüteç)
        arm_overrides[6] = (W * 0.88, H * 0.60, 0.72, 0.12)

    elif state == 'done':
        # Tüm kollar içe toplanır, hafif sallanır
        for i in range(n_arm):
            u = (i / (n_arm - 1)) * 2.0 - 1.0
            arm_overrides[i] = (hx + u * rx * 0.6, H * 0.75, 0.5, 0.4)

    elif state == 'error':
        # Kollar düşer
        for i in range(n_arm):
            u = (i / (n_arm - 1)) * 2.0 - 1.0
            arm_overrides[i] = (hx + u * rx * 1.2, H * 0.95, 0.95, 0.05)

    # ── Kol çizimi — her state için çalışır ──────────────────────────
    for i in range(n_arm):
        u = (i / (n_arm - 1)) * 2.0 - 1.0
        x0 = hx + u * rx * 0.73
        y0 = ybase + (1.0 - u*u) * ry * 0.25
        tl = (H - 0.5) - y0
        if tl < 1.0:
            continue

        ph = i * 0.88 + 0.3

        ov = arm_overrides.get(i)
        steps = max(28, int(tl * 10))    # smoothstep easing'le akici
        for k in range(steps + 1):
            s = k / steps
            # yumuşak easing (smoothstep) → akıcı hareket
            e = s * s * (3.0 - 2.0 * s)

            if ov:
                tx, ty, ext, curl_mul = ov
                # idle'dan hedefe tween
                tween = min(1.0, e * 1.15)
                # idle kol animasyonu
                yn = y0 + tl * (e ** 0.85)
                curl_n = math.sin(2.8 * e + t * 2.2 + ph) * (0.18 + 0.6 * e)
                xn = x0 + u * (W * 0.25) * (e ** 1.25) + W * 0.05 * curl_n
                # hedef nokta yolu
                yt = y0 + (ty - y0) * e * ext
                xt = x0 + (tx - x0) * e * ext + W * 0.03 * curl_mul * math.sin(t * 3 + ph + e * 4)
                cx = xn + (xt - xn) * tween
                cy = yn + (yt - yn) * tween
            else:
                # Normal idle kol — smoothstep easing
                cy = y0 + tl * (e ** 0.85)
                curl = math.sin(2.8 * e + t * 2.2 + ph) * (0.18 + 0.65 * e)
                cx = x0 + u * (W * 0.26) * (e ** 1.25) + W * 0.055 * curl

            arm_rgb = _mix(SKIN2, SKIN, min(1.0, 0.15 + 0.65 * (1.0 - s)))
            # Tek-piksel set + alt piksel ikizi (Braille dogal komşuluk)
            # Buyuk oval smear KULLANILMAZ — smear hareket eden oval
            # leke birakip dokuyu 'morphing' yapiyordu.
            cv.set(cx, cy, arm_rgb, over=False)
            cv.set(cx, cy + 1, arm_rgb, over=False)
            # Kol kokunde kalinlas — yuksek cozunurlukte ince ip gibi
            # gorunmesin (govde tarafina dogru 1 piksel ek genislik).
            if s < 0.5:
                side = 1 if u >= 0 else -1
                cv.set(cx + side, cy, arm_rgb, over=False)
                cv.set(cx + side, cy + 1, arm_rgb, over=False)
            # Vantuzlar (kolun alt yarisinda)
            if 0.52 < s < 0.90 and k % max(1, steps // 6) == 0:
                cv.set(cx - u * 0.5, cy, _mix(RIM, DARK, 0.35), over=False)


# ── Aksesuar çizici ──────────────────────────────────────────────────────
def _draw_accessory(cv, t, state, W, H, hx, hy, rx, ry):
    """State'e özgü geometrik aksesuar."""

    if state == 'thinking':
        # Kitap: sol tarafta küçük dikdörtgen
        bx, by = hx - rx * 1.3, hy + ry * 0.3
        bw, bh = W * 0.12, H * 0.10
        for dy in range(int(bh)+1):
            for dx in range(int(bw)+1):
                t_v = dy / max(1, bh)
                cv.set(bx + dx, by + dy, _mix((200, 180, 120), (160, 130, 80), t_v))
        # Kitap çizgileri
        for line_y in range(1, int(bh), 2):
            cv.line(bx+1, by+line_y, bx+bw-1, by+line_y, (130, 100, 60))
        # Kalem: sağ kolun ucunda
        px_tip = hx + rx * 1.15
        py_tip = hy - ry * 0.45
        cv.line(px_tip, py_tip, px_tip + W*0.06, py_tip + H*0.08, (255, 220, 100))
        cv.set(px_tip + W*0.07, py_tip + H*0.09, DARK)   # kalem ucu

    elif state == 'tool_bash':
        # Terminal: sağda küçük ekran
        tx, ty = W * 0.82, H * 0.28
        tw, th = W * 0.16, H * 0.18
        for dy in range(int(th)+1):
            for dx in range(int(tw)+1):
                cv.set(tx+dx, ty+dy, (15, 20, 35))
        # Komut satırı: akan yazı
        cursor_x = int((t * 3) % max(1, tw - 2))
        cv.set(tx + 1, ty + 1, (100, 255, 100))   # $ prompt
        cv.set(tx + 2 + cursor_x % max(1, int(tw - 3)), ty + 1, (180, 255, 180))

    elif state == 'tool_read':
        # İki kol arasında dosya simgesi
        fx, fy = hx - W*0.06, H * 0.52
        fw, fh = W * 0.12, H * 0.14
        for dy in range(int(fh)+1):
            for dx in range(int(fw)+1):
                cv.set(fx+dx, fy+dy, (220, 230, 250))
        # Dosya üst köşe kırığı
        cv.set(fx+fw-1, fy, (180, 190, 210))
        # Satırlar
        for line_y in range(2, int(fh), 2):
            cv.line(fx+1, fy+line_y, fx+fw-2, fy+line_y, (160, 170, 200))

    elif state == 'tool_write':
        # Kalem ucu: sağ kolun ucunda
        px_tip = W * 0.88
        py_tip = H * 0.38
        cv.line(px_tip-2, py_tip+2, px_tip+1, py_tip-1, (255, 220, 80))
        cv.set(px_tip+1, py_tip-2, DARK)
        # Yazma dalgası: küçük çizgiler
        wave_t = t * 4
        for li in range(3):
            wx = px_tip + 2 + li * 1.5
            wy = py_tip + math.sin(wave_t + li) * 1.5
            cv.set(wx, wy, _mix(WHITE, RIM, 0.4))

    elif state == 'tool_fetch':
        # Küre: sağ kolun ucunda
        gx, gy, gr = W * 0.93, H * 0.28, min(W, H) * 0.055
        # Küre gövdesi
        for dy in range(-int(gr)-1, int(gr)+2):
            for dx in range(-int(gr)-1, int(gr)+2):
                d = math.sqrt(dx*dx + dy*dy)
                if d <= gr:
                    lam = 0.5 + 0.5 * (dx*0.5 - dy*0.7) / gr
                    cv.set(gx+dx, gy+dy, _mix((30, 80, 180), (100, 180, 255), lam))
        # Dalga halkası
        ring_r = gr * (1.2 + 0.3 * math.sin(t * 5))
        for ang in range(0, 360, 12):
            a = math.radians(ang)
            ring_fade = max(0, 1 - (ring_r - gr) / gr)
            rv = _mix(RIM, (30, 80, 180), 1 - ring_fade)
            cv.set(gx + ring_r * math.cos(a), gy + ring_r * math.sin(a) * 0.4, rv)

    elif state == 'tool_grep':
        # Büyüteç: kol ucunda
        mx, my, mr = W * 0.86, H * 0.58, min(W, H) * 0.05
        # Büyüteç camı (daire)
        cv.circle(mx, my, mr, mr, _mix(WHITE, RIM, 0.3), fill=True)
        cv.circle(mx, my, mr, mr, RIM, fill=False, thick=2)
        # Sap
        cv.line(mx + mr*0.7, my + mr*0.7, mx + mr*1.5, my + mr*1.5,
                _mix(SKIN2, DARK, 0.4), thick=2)

    elif state == 'done':
        # Gülümseme çizgisi (ağız)
        smile_y = hy + ry * 0.55
        smile_x0 = hx - rx * 0.35
        smile_x1 = hx + rx * 0.35
        for i in range(12):
            s = i / 11
            sx = smile_x0 + (smile_x1 - smile_x0) * s
            sy = smile_y + math.sin(s * math.pi) * ry * 0.12
            cv.set(sx, sy, DARK)


# ── Ana kare üretici ─────────────────────────────────────────────────────
def mixi_frame_braille(t=0.0, state='idle', size='full'):
    """Braille piksel motoru ile tek kare üretir -> ANSI satır listesi.

    size: 'full' | 'mid' | 'live' | 'tiny'
    Piksel boyutları (geniş × yüksek):
      full: 56×40  -> 28 Braille sütunu × 10 satır
      mid:  40×28  -> 20 Braille sütunu ×  7 satır
      live: 28×20  -> 14 Braille sütunu ×  5 satır
      tiny: 20×16  -> 10 Braille sütunu ×  4 satır
    """
    SIZES = {
        'full': (56, 40),
        'mid':  (40, 28),
        'live': (28, 20),
        'tiny': (20, 16),
    }
    W, H = SIZES.get(size, SIZES['full'])

    cv = Canvas(W, H)

    # Çizim sırası: kollar (altta) → gövde → aksesuarlar → gözler
    hx, hy, rx, ry = _draw_body(cv, t, state, W, H)
    _draw_arms(cv, t, state, W, H, hx, hy, rx, ry)
    _draw_accessory(cv, t, state, W, H, hx, hy, rx, ry)
    # Gözleri tekrar üste çiz (body üzerine) — gövdeyi yeniden taramadan
    hx, hy, rx, ry = _draw_body(cv, t, state, W, H, eyes_only=True)

    return cv.to_braille_rows()


# ── Demo ─────────────────────────────────────────────────────────────────
def demo():
    states = ['idle', 'thinking', 'tool_bash', 'tool_read',
              'tool_write', 'tool_fetch', 'tool_grep', 'done', 'error']
    state_idx = 0
    state = states[state_idx]
    t0 = time.time()
    prev_rows = 0

    print(f"\x1b[2J\x1b[H")
    print(f"  Mixium Braille Maskot  —  q: çık  space: state değiştir\n")

    import select as sel
    import tty, termios
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        while True:
            t = time.time() - t0
            rows = mixi_frame_braille(t, state, 'full')

            buf = []
            if prev_rows:
                buf.append(f"\x1b[{prev_rows}A")
            buf.append(f"\r\x1b[2K  State: \x1b[1m{state}\x1b[0m\n")
            for row in rows:
                buf.append(f"\r  {row}\n")
            buf.append(f"\r\x1b[2K  [space] sonraki state  [q] çık\n")
            sys.stdout.write(''.join(buf))
            sys.stdout.flush()
            prev_rows = len(rows) + 2

            if sel.select([sys.stdin], [], [], 1.0/15)[0]:
                ch = sys.stdin.read(1)
                if ch == 'q':
                    break
                elif ch == ' ':
                    state_idx = (state_idx + 1) % len(states)
                    state = states[state_idx]
                    t0 = time.time()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
        print(f"\n\x1b[0m")

if __name__ == '__main__':
    demo()

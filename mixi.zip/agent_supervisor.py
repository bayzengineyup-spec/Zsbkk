# -*- coding: utf-8 -*-
"""Mixium A23 — Agent Supervisor.

Monitors agents (status, error, duration, performance, resource use) and can
stop, restart or reassign a problematic agent. Monitoring only; execution
stays with the existing runtime.
"""
import threading
import time
import uuid


class AgentSupervisor:
    def __init__(self, providers=None, max_agents=32):
        self.providers = dict(providers or {})
        self.max_agents = max(1, int(max_agents))
        self._lock = threading.RLock()
        self.agents = {}

    def register(self, agent_id, role="", started=None):
        with self._lock:
            if len(self.agents) >= self.max_agents:
                return False
            row = {"id": str(agent_id), "role": str(role),
                   "status": "RUNNING", "started": started or time.time(),
                   "errors": [], "restarts": 0, "reassigns": 0,
                   "performance": 50.0, "resource": {}}
            self.agents[str(agent_id)] = row
            return dict(row)

    def observe(self, agent_id, status=None, error=None, performance=None, resource=None):
        with self._lock:
            row = self.agents.get(str(agent_id))
            if not row:
                return None
            if status:
                row["status"] = status
            if error:
                row["errors"].append(str(error)[:300])
                row["errors"] = row["errors"][-20:]
            if performance is not None:
                row["performance"] = max(0.0, min(100.0, float(performance)))
            if resource:
                row["resource"] = dict(resource)
            return dict(row)

    def stop(self, agent_id):
        return self.observe(agent_id, status="STOPPED")

    def restart(self, agent_id):
        with self._lock:
            row = self.agents.get(str(agent_id))
            if not row:
                return None
            row["restarts"] += 1
            row["started"] = time.time()
            row["status"] = "RESTARTING"
            return dict(row)

    def reassign(self, agent_id, new_role=None, new_agent_id=None):
        with self._lock:
            row = self.agents.get(str(agent_id))
            if not row:
                return None
            row["reassigns"] += 1
            if new_role:
                row["role"] = new_role
            if new_agent_id:
                row["reassigned_to"] = new_agent_id
            row["status"] = "REASSIGNED"
            return dict(row)

    def unhealthy(self, threshold=60.0):
        with self._lock:
            return [dict(a) for a in self.agents.values()
                    if a.get("status") == "RUNNING" and a.get("performance", 100) < threshold]

    def status(self):
        with self._lock:
            return {"agents": [dict(a) for a in self.agents.values()], "count": len(self.agents)}

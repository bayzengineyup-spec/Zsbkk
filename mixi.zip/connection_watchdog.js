// Prevent infinite connecting state
window.MixiumConnectionWatchdog={
 start(timeout=15000){
  setTimeout(()=>{
   const el=document.querySelector('[data-status="connecting"]');
   if(el && el.textContent.includes('BAĞLAN')){
    el.textContent='Bağlantı yeniden deneniyor...';
    window.dispatchEvent(new Event('mixium:reconnect'));
   }
  },timeout);
 }
};

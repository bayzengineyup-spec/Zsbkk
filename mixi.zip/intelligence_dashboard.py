# -*- coding: utf-8 -*-
"""
Mixium — Intelligence Dashboard API (Aşama 14G)

Yönetim paneline READ-ONLY veri sağlar (UI/frontend DEĞİŞMEZ):
    dna_activity / memory_growth / research_activity / knowledge_categories /
    improvement_suggestions / agent_performance / model_usage.

MIXIUM'a bağımlı değildir; store/personal/model_mgr/metrics_fn enjekte edilir.
"""

from pathlib import Path


class IntelligenceDashboard:
    def __init__(self, root=".", store=None, personal=None, model_mgr=None,
                 research_brain=None, metrics_fn=None):
        self.root = Path(root).expanduser().resolve()
        self.store = store
        self.personal = personal
        self.model_mgr = model_mgr
        self.research_brain = research_brain
        self.metrics_fn = metrics_fn

    def status(self):
        out = {
            "dna_activity": [],
            "memory_growth": 0,
            "research_activity": None,
            "knowledge_categories": {},
            "improvement_suggestions": [],
            "agent_performance": {},
            "model_usage": {},
        }
        if self.model_mgr is not None:
            try:
                out["model_usage"] = self.model_mgr.dna_status()
            except Exception:
                pass
        if self.store is not None:
            try:
                out["knowledge_categories"] = self.store.categories()
                out["memory_growth"] = self.store.count()
                out["dna_activity"] = [
                    {"category": r["category"], "content": r["content"][:80]}
                    for r in self.store.recent(10)]
            except Exception:
                pass
        if self.personal is not None:
            try:
                out["dna_activity"].extend(
                    [{"category": "preferences", "content": f["content"][:80]}
                     for f in self.personal.facts(5)])
            except Exception:
                pass
        if self.research_brain is not None:
            try:
                out["research_activity"] = self.research_brain.last_research()
            except Exception:
                pass
        if self.metrics_fn is not None:
            try:
                intel = self.metrics_fn()
                out["improvement_suggestions"] = intel.get("improvement_plan", [])
                out["agent_performance"] = {
                    "intelligence_score": intel.get("intelligence_score")}
            except Exception:
                pass
        return out

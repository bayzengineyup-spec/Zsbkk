#!/bin/bash
# ─────────────────────────────────────────────────────────────────────
#  Mixium Web — Termux baslatma
#  Kullanim:
#     bash mixiweb_baslat.sh          # 127.0.0.1:8420 + tarayici ac
#     bash mixiweb_baslat.sh 9000     # ozel port
#  Durdurma:  Ctrl+C  (veya bash mixiweb_baslat.sh --durdur)
# ─────────────────────────────────────────────────────────────────────
cd "$(dirname "$0")" || exit 1
# mixiweb.py'nin tam yolunu, calisma dizinini degistirmeden ONCE al —
# yoksa asagidaki "cd .." sonrasi goreli yol kirilir.
WEBDIR="$(pwd)"
# Motor (mixium_new.py) bir ust klasorde; web, calisma dizinini oradan
# alir ki dosya araclari (read/write/bash) proje klasorunde calissin.
cd .. || exit 1

if [ "$1" = "--durdur" ]; then
    pkill -9 -f mixiweb.py 2>/dev/null
    echo "Mixium Web durduruldu."
    exit 0
fi

PORT="${1:-8420}"

# onceki kopyayi kapat
pkill -9 -f mixiweb.py 2>/dev/null
sleep 1

echo "Mixium Web baslatiliyor (port $PORT)..."
python3 "$WEBDIR/mixiweb.py" --port "$PORT" &
PID=$!
trap 'kill $PID 2>/dev/null' EXIT

# sunucu hazir olana kadar bekle
for i in $(seq 1 20); do
    if curl -s -o /dev/null "http://127.0.0.1:$PORT/"; then
        break
    fi
    sleep 0.5
done

echo ""
echo "  ┌───────────────────────────────────────────────┐"
echo "  │  Tarayicida ac:  http://127.0.0.1:$PORT        │"
echo "  │  Durdurmak icin Ctrl+C bas.                   │"
echo "  └───────────────────────────────────────────────┘"
echo ""

# Termux'ta tarayiciyi ac (varsa)
if command -v termux-open-url >/dev/null 2>&1; then
    termux-open-url "http://127.0.0.1:$PORT"
fi

wait $PID

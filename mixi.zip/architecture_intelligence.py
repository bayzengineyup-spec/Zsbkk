# -*- coding: utf-8 -*-
"""Mixium A31 — Architecture Intelligence (Mimari analiz).

Sürekli analiz: dosya yapısı, bağımlılıklar (import), karmaşıklık, tekrar eden
kod, riskli alanlar. stdlib ast kullanır; ağır parser eklenmez. 800 dosya
sınırı korunur; SyntaxError crash yapmaz (dosya atlanır). Sonuç cache'lenir.
"""

import ast
import threading
import time
from pathlib import Path

IGNORE = {".git", "__pycache__", "node_modules", ".mixium", "venv", ".venv",
          "dist", "build", "mcp_browser", ".playwright-mcp"}


class ArchitectureIntelligence:
    def __init__(self, root=".", ignore=None, max_files=800, cache_ttl=120.0):
        self.root = Path(root).expanduser().resolve()
        self.ignore = IGNORE | set(ignore or ())
        self.max_files = max(1, int(max_files))
        self.cache_ttl = float(cache_ttl)
        self._lock = threading.Lock()
        self._cache = {"t": 0.0, "value": None}

    def _py_files(self):
        files = []
        try:
            for p in self.root.rglob("*.py"):
                if any(part in self.ignore for part in p.parts):
                    continue
                files.append(p)
                if len(files) >= self.max_files:
                    break
        except Exception:
            pass
        return files

    def _parse(self, path):
        try:
            src = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return None
        try:
            tree = ast.parse(src)
        except SyntaxError:
            return {"path": str(path), "syntax_error": True, "imports": [],
                    "classes": 0, "functions": 0, "lines": src.count("\n")}
        imports = []
        classes = functions = 0
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imports.extend(a.name.split(".")[0] for a in node.names)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    imports.append(node.module.split(".")[0])
            elif isinstance(node, ast.ClassDef):
                classes += 1
            elif isinstance(node, ast.FunctionDef):
                functions += 1
        return {"path": str(path), "syntax_error": False, "imports": sorted(set(imports)),
                "classes": classes, "functions": functions, "lines": src.count("\n")}

    def analyze(self):
        now = time.time()
        with self._lock:
            if self._cache["value"] is not None and now - self._cache["t"] < self.cache_ttl:
                return self._cache["value"]
        files = self._py_files()
        rows = [r for r in (self._parse(f) for f in files) if r]
        # bağımlılıklar (yerel modül → içe aktarılan yerel dosya)
        local = {p.stem: p.name for p in files}
        deps = {}
        for r in rows:
            if r.get("syntax_error"):
                continue
            imp = [i for i in r["imports"] if i in local]
            if imp:
                deps[Path(r["path"]).name] = sorted(imp)
        # karmaşıklık + riskli alanlar
        risky = []
        for r in rows:
            score = r["functions"] * 2 + r["classes"] * 4
            if score >= 120:
                risky.append({"file": Path(r["path"]).name, "complexity": score})
        risky.sort(key=lambda x: -x["complexity"])
        value = {
            "files": len(rows),
            "syntax_errors": sum(1 for r in rows if r.get("syntax_error")),
            "total_classes": sum(r["classes"] for r in rows),
            "total_functions": sum(r["functions"] for r in rows),
            "dependencies": deps,
            "risky": risky[:20],
            "ignore_dirs": sorted(self.ignore),
        }
        with self._lock:
            self._cache = {"t": now, "value": value}
        return value

    def status(self):
        a = self.analyze()
        return {"files": a["files"], "dependencies": len(a["dependencies"]),
                "risky": len(a["risky"])}

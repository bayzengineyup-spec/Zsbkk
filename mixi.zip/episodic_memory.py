# -*- coding: utf-8 -*-
"""
Mixium — Episodic Memory (Aşama 13F)

Görev/karar/sonuç/hata/çözüm gibi "bölümsel" kayıtların semantik olarak
hatırlanması. Mevcut AgentMemory'yi DEĞİŞTİRMEZ — ayrı bir katmandır.

- remember(kind, text, meta)  : kayıt ekler (task|decision|result|error|solution)
- recall_semantic(query)      : cosine benzerliğiyle en yakın kayıtları döner
- LRU max 100 + token sınırı korunur.

Semantic search için ağır vector DB YOK: kendi küçük hash-embedding + cosine
kullanılır (Mixium'un seyrek vektör yaklaşımının bağımsız bir kopyası — bu
modül MIXIUM'a bağımlı olmamalı). Kayıt şeması:
    {id, kind, text, meta, timestamp, embedding:[[idx,val],...]}
"""

import hashlib
import json
import math
import re
import threading
import time
import uuid
from pathlib import Path

MAX_RECORDS = 100
MAX_TEXT = 8000          # kayıt başına karakter sınırı
_DIM = 384
_TOKEN_RE = re.compile(r"[a-zçğıöşü0-9_]+", re.I)

KINDS = ("task", "decision", "result", "error", "solution")


def embed(text, dim=_DIM):
    """Seyrek hash-embedding: {indeks: ağırlık} (normalize)."""
    acc = {}
    for t in _TOKEN_RE.findall((text or "").lower()[:MAX_TEXT]):
        d = hashlib.blake2b(t.encode("utf-8", "ignore"), digest_size=8).digest()
        i = int.from_bytes(d[:4], "big") % dim
        sg = 1.0 if d[4] & 1 else -1.0
        acc[i] = acc.get(i, 0.0) + sg
    n = math.sqrt(sum(x * x for x in acc.values()))
    if not n:
        return {}
    return {i: x / n for i, x in acc.items() if abs(x) > 1e-9}


def cosine(a, b):
    """İki seyrek vektörün kosinüs benzerliği (ikisi de normalize)."""
    if not a or not b:
        return 0.0
    if len(a) > len(b):
        a, b = b, a
    g = b.get
    return sum(x * g(i) for i, x in a.items() if g(i) is not None)


def _sparse_to_dict(emb):
    if isinstance(emb, dict):
        return {int(k): float(v) for k, v in emb.items()}
    out = {}
    for pair in (emb or []):
        try:
            out[int(pair[0])] = float(pair[1])
        except Exception:
            continue
    return out


def _dict_to_sparse(emb):
    return [[int(i), float(x)] for i, x in (emb or {}).items()]


class EpisodicMemory:
    def __init__(self, root="."):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "agents" / "episodic.json"
        self.records = []
        self._lock = threading.Lock()
        self._load()

    # ---- persist (workspace fail-closed) ----
    def _allowed(self):
        try:
            d = self.path.resolve()
        except Exception:
            return False
        return d == self.root or self.root in d.parents

    def _load(self):
        try:
            if self.path.exists():
                self.records = json.loads(self.path.read_text("utf-8"))
        except Exception:
            self.records = []
        if not isinstance(self.records, list):
            self.records = []

    def _save(self):
        if not self._allowed():
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self.records, ensure_ascii=False),
                                 "utf-8")
        except Exception:
            pass

    # ---- API ----
    def remember(self, kind, text, meta=None):
        """Bir episodik kayıt ekler; (rec) döndürür."""
        with self._lock:
            kind = (kind or "note").lower()
            if kind not in KINDS:
                kind = "note"
            text = str(text)[:MAX_TEXT]
            emb = embed(text)
            rec = {
                "id": uuid.uuid4().hex[:8],
                "kind": kind,
                "text": text,
                "meta": meta or {},
                "timestamp": time.time(),
                "embedding": _dict_to_sparse(emb),
            }
            self.records.append(rec)
            if len(self.records) > MAX_RECORDS:
                self.records = self.records[-MAX_RECORDS:]   # LRU
            self._save()
            return rec

    def recall_semantic(self, query, limit=5, min_score=0.0):
        """Kosinüs benzerliğiyle en yakın kayıtları döndürür (semantic)."""
        qv = embed(query)
        with self._lock:
            scored = []
            for r in self.records:
                score = cosine(qv, _sparse_to_dict(r.get("embedding")))
                if score >= min_score:
                    scored.append((score, r))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [r for _, r in scored[:max(1, min(50, limit))]]

    def history(self, kind=None, limit=20):
        with self._lock:
            recs = [r for r in self.records if kind is None or r.get("kind") == kind]
            return list(recs[-limit:])

    def clear(self):
        with self._lock:
            self.records = []
            self._save()

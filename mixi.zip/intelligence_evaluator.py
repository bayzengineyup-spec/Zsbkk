# -*- coding: utf-8 -*-
"""
Mixium — Intelligence Evaluation Agent (Aşama 16G)

Mixium kendini ölçer:
- learning speed     (öğrenme hızı: kayıt artışı)
- knowledge quality  (ortalama confidence)
- prediction accuracy (karar güveni ortalaması — proxy)
- code improvement   (test başarı oranı)
- user satisfaction signals (kullanıcı geri bildirimi — proxy)

Çıktı:
    { score: 0-100, strengths: [], weaknesses: [], next_improvements: [] }

MIXIUM'a bağımlı değildir; metrik kaynakları enjekte edilir.
Fail-closed: kaynak yoksa nötr (50) skor, sistem çökmez.
"""

import json
import threading
import time
from pathlib import Path


class IntelligenceEvaluator:
    def __init__(self, root=".", metrics_fn=None):
        """metrics_fn() -> dict:
        {learning_records, avg_confidence, test_passed, test_total,
         decisions, avg_decision_confidence, satisfaction} — hepsi opsiyonel."""
        self.root = Path(root)
        self.dir = self.root / ".mixium" / "learning"
        self.metrics_fn = metrics_fn
        self._lock = threading.RLock()
        self._history = []
        self._load()

    def _allowed(self, p):
        try:
            p = Path(p).resolve()
            root = self.root.resolve()
            return root in p.parents or p == root
        except Exception:
            return False

    def _load(self):
        try:
            if self._allowed(self.dir / "evaluations.json"):
                with open(self.dir / "evaluations.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    self._history = data
        except Exception:
            pass

    def _save(self):
        try:
            if not self._allowed(self.dir):
                return
            self.dir.mkdir(parents=True, exist_ok=True)
            with open(self.dir / "evaluations.json", "w", encoding="utf-8") as f:
                json.dump(self._history[-100:], f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    # ── skorlama ────────────────────────────────────────────────────
    def _norm(self, value, lo=0, hi=100):
        try:
            v = float(value or 0)
            return max(lo, min(hi, v))
        except Exception:
            return lo

    def evaluate(self):
        m = {}
        if self.metrics_fn:
            try:
                m = self.metrics_fn() or {}
            except Exception:
                m = {}

        # alt metrikler (0-100)
        learning_speed = self._norm(m.get("learning_speed", 50))
        knowledge_quality = self._norm(m.get("knowledge_quality", 50))
        prediction_accuracy = self._norm(m.get("prediction_accuracy", 50))
        code_improvement = self._norm(m.get("code_improvement", 50))
        satisfaction = self._norm(m.get("satisfaction", 50))

        weights = {
            "learning_speed": 0.20,
            "knowledge_quality": 0.25,
            "prediction_accuracy": 0.15,
            "code_improvement": 0.25,
            "satisfaction": 0.15,
        }
        score = int(round(
            learning_speed * weights["learning_speed"] +
            knowledge_quality * weights["knowledge_quality"] +
            prediction_accuracy * weights["prediction_accuracy"] +
            code_improvement * weights["code_improvement"] +
            satisfaction * weights["satisfaction"]))

        strengths, weaknesses, next_improvements = [], [], []
        if knowledge_quality >= 70:
            strengths.append("Bilgi kalitesi yüksek (güven ortalaması iyi)")
        elif knowledge_quality < 45:
            weaknesses.append("Bilgi güveni düşük — doğrulayıcı eşiğini artır")
        if learning_speed >= 70:
            strengths.append("Öğrenme hızı iyi (kayıt artışı düzenli)")
        elif learning_speed < 45:
            weaknesses.append("Öğrenme hızı düşük — scheduler interval'ını kısalt")
            next_improvements.append("Scheduler interval'ını düşür / daha sık araştır")
        if code_improvement >= 70:
            strengths.append("Test başarı oranı yüksek")
        elif code_improvement < 45:
            weaknesses.append("Test başarı oranı düşük")
            next_improvements.append("DebugLoop repair cycle'ını gözden geçir")
        if prediction_accuracy >= 70:
            strengths.append("Karar güveni tutarlı")
        elif prediction_accuracy < 45:
            weaknesses.append("Karar güveni düşük")
            next_improvements.append("DecisionEngine kaynaklarını zenginleştir")
        if satisfaction >= 70:
            strengths.append("Kullanıcı memnuniyet sinyalleri olumlu")
        if not strengths:
            strengths.append("Sistem kararlı çalışıyor")
        if not weaknesses:
            weaknesses.append("Belirgin zayıflık yok (izleme sürüyor)")
        if not next_improvements:
            next_improvements.append("Yeni uzman kaynaklar ekle (research_brain)")

        result = {
            "score": score,
            "strengths": strengths[:5],
            "weaknesses": weaknesses[:5],
            "next_improvements": next_improvements[:5],
            "metrics": {
                "learning_speed": learning_speed,
                "knowledge_quality": knowledge_quality,
                "prediction_accuracy": prediction_accuracy,
                "code_improvement": code_improvement,
                "satisfaction": satisfaction,
            },
            "time": time.time(),
        }
        with self._lock:
            self._history.append(result)
            self._history = self._history[-100:]
            self._save()
        return result

    def history(self, limit=10):
        with self._lock:
            return list(self._history[-limit:])

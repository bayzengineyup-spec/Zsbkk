/* Connection recovery guard */
(function(){
 let timer;
 window.MixiumConnection={
   start(){
     clearTimeout(timer);
     timer=setTimeout(()=>{
       window.dispatchEvent(new CustomEvent("mixium:connection-timeout"));
     },15000);
   },
   done(){ clearTimeout(timer); }
 };
})();

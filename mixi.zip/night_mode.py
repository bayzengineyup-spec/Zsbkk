# -*- coding: utf-8 -*-
"""Mixium A25G — Night Autonomous Mode.

Kullanıcı yokken: sistemi test et → kalite ölç → sorun ara → düzeltme öner →
öğren. Güvenlik kuralları değiştirilemez; permission kapatılamaz; sandbox
aşılamaz. Tüm adımlar enjekte edilen provider'lar üzerinden çalışır.
"""

import time


class NightMode:
    def __init__(self, providers=None):
        self.providers = dict(providers or {})
        self.history = []

    def _get(self, name, *args, **kw):
        fn = self.providers.get(name)
        if fn is None:
            return None
        try:
            return fn(*args, **kw)
        except Exception as e:
            return {"error": str(e)[:200]}

    def run(self):
        t0 = time.time()
        rec = {"started": time.time(), "steps": []}

        # 1. sistemi test et
        rec["steps"].append({"step": "test", "result": self._get("test")})

        # 2. kalite ölç
        rec["steps"].append({"step": "quality", "result": self._get("quality")})

        # 3. sorun ara
        rec["steps"].append({"step": "find_issues", "result": self._get("find_issues")})

        # 4. düzeltme öner (öneri, uygulama değil)
        rec["steps"].append({"step": "suggest", "result": self._get("suggest")})

        # 5. öğren
        rec["steps"].append({"step": "learn", "result": self._get("learn", rec)})

        rec["finished"] = time.time()
        rec["elapsed"] = round(rec["finished"] - t0, 2)
        self.history.append(rec)
        return rec

    def status(self):
        return {"runs": len(self.history), "last": self.history[-1] if self.history else None,
                "recent": self.history[-5:]}

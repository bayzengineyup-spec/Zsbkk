# -*- coding: utf-8 -*-
"""Mixium — Experience Learning System (Aşama 19G)."""
import json
import threading
import time
import uuid
from pathlib import Path


class ExperienceLearning:
    def __init__(self, root=".", max_records=500):
        self.root = Path(root).expanduser().resolve()
        self.path = self.root / ".mixium" / "experiences.json"
        self.max_records = max_records
        self._lock = threading.RLock()
        self.records = []
        self._load()

    def _allowed(self):
        try:
            p, r = self.path.resolve(), self.root.resolve()
            return p == r or r in p.parents
        except Exception:
            return False

    def _load(self):
        try:
            if self.path.exists():
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.records = d if isinstance(d, list) else []
        except Exception:
            self.records = []

    def _save(self):
        if not self._allowed(): return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(self.records, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path); return True
        except Exception: return False

    def record(self, task, action, result=None, success=True, error="", pattern="", meta=None):
        with self._lock:
            rec = {"id": "exp_" + uuid.uuid4().hex[:10], "task": str(task)[:1000],
                   "action": str(action)[:1000], "result": str(result or "")[:2000],
                   "success": bool(success), "error": str(error or "")[:800],
                   "pattern": str(pattern or "")[:500], "meta": dict(meta or {}), "time": time.time()}
            self.records.append(rec); self.records = self.records[-self.max_records:]; self._save()
            return dict(rec)

    def recent(self, limit=20):
        with self._lock: return [dict(x) for x in reversed(self.records[-max(1, int(limit)):])]

    def patterns(self, limit=20):
        counts = {}
        for r in self.records:
            key = r.get("pattern") or ("success:" + str(r.get("action")) if r.get("success") else "failure:" + str(r.get("action")))
            counts[key] = counts.get(key, 0) + 1
        return [{"pattern": k, "count": v} for k, v in sorted(counts.items(), key=lambda x: -x[1])[:limit]]

    def status(self):
        total = len(self.records); success = sum(1 for r in self.records if r.get("success"))
        return {"records": total, "success": success, "failures": total - success,
                "success_rate": round(success * 100 / total, 1) if total else 0,
                "patterns": self.patterns(10), "recent": self.recent(10)}

# -*- coding: utf-8 -*-
"""Mixium A26 — Autonomous Engineering Memory.

Kaydeder: yapılan değişiklikler, bulunan hatalar, çözümler, başarısız
yaklaşımlar, başarılı mimari kararlar. Memory poisoning koruması: confidence
eşiği altındaki bilgi kaydedilmez. Semantic recall (embed/cosine enjeksiyonu).
"""

import json
import os
import threading
import time

MAX_RECORDS = 300
MIN_CONFIDENCE = 30  # poisoning koruması


class EngineeringMemory:
    KINDS = ("change", "bug", "solution", "failed_approach", "decision")

    def __init__(self, root=".", max_records=MAX_RECORDS, min_confidence=MIN_CONFIDENCE,
                 embed_fn=None, cosine_fn=None, persist_path=None):
        self.root = root
        self.max_records = max_records
        self.min_confidence = min_confidence
        self.embed_fn = embed_fn
        self.cosine_fn = cosine_fn
        self.persist_path = persist_path or os.path.join(root, ".mixium", "engineering_memory.json")
        self.records = []
        self.rejected = 0
        self._lock = threading.Lock()
        self._load()

    def _load(self):
        try:
            if os.path.exists(self.persist_path):
                with open(self.persist_path) as f:
                    self.records = json.load(f)[-self.max_records:]
        except Exception:
            self.records = []

    def _save(self):
        try:
            os.makedirs(os.path.dirname(self.persist_path), exist_ok=True)
            with open(self.persist_path, "w") as f:
                json.dump(self.records, f, ensure_ascii=False)
        except Exception:
            pass

    def record(self, kind, text, confidence=80, meta=None):
        """Düşük güvenli bilgi kaydedilmez (poisoning koruması)."""
        if kind not in self.KINDS:
            kind = "change"
        confidence = int(confidence)
        if confidence < self.min_confidence:
            self.rejected += 1
            return {"rejected": True, "reason": "düşük güven"}
        with self._lock:
            rec = {"id": "eng_%d" % int(time.time() * 1000),
                   "kind": kind, "text": str(text)[:2000],
                   "confidence": confidence, "meta": dict(meta or {}),
                   "timestamp": time.time(), "embedding": None}
            if self.embed_fn is not None:
                try:
                    rec["embedding"] = list(self.embed_fn(rec["text"]))
                except Exception:
                    rec["embedding"] = None
            self.records.append(rec)
            if len(self.records) > self.max_records:
                self.records = self.records[-self.max_records:]
            self._save()
            return rec

    def recall(self, query, top_k=5, kind=None):
        with self._lock:
            pool = [r for r in self.records if kind is None or r.get("kind") == kind]
            if not pool:
                return []
            if self.embed_fn is not None and self.cosine_fn is not None:
                try:
                    qv = self.embed_fn(query)
                    scored = [(self.cosine_fn(qv, r["embedding"]), r)
                              if r.get("embedding") else (0.0, r) for r in pool]
                    scored.sort(key=lambda x: x[0], reverse=True)
                    return [r for _, r in scored[:top_k]]
                except Exception:
                    pass
            q = (query or "").lower()
            scored = [(sum(1 for w in q.split() if w in r.get("text", "").lower()), r) for r in pool]
            scored.sort(key=lambda x: x[0], reverse=True)
            return [r for s, r in scored if s > 0][:top_k] or pool[-top_k:]

    def status(self):
        return {"records": len(self.records), "rejected": self.rejected,
                "by_kind": {k: sum(1 for r in self.records if r.get("kind") == k) for k in self.KINDS}}
